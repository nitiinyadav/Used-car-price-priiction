"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { getEditorLanguage, isLargeEditorFile } from "@/lib/file-editor";

let monacoInitPromise = null;

function LoadingState({ message }) {
  return (
    <div className="flex h-full items-center justify-center bg-gray-900 text-sm text-gray-500">
      {message}
    </div>
  );
}

function ErrorState({ message }) {
  return (
    <div className="flex h-full items-center justify-center bg-gray-900 px-4 text-center text-sm text-red-400">
      {message}
    </div>
  );
}

async function loadMonaco() {
  if (typeof window === "undefined") {
    throw new Error("Monaco can only initialize in the browser.");
  }

  if (!monacoInitPromise) {
    monacoInitPromise = import("monaco-editor").then((monaco) => {
      window.MonacoEnvironment = {
        getWorker(_, label) {
          switch (label) {
            case "json":
              return new Worker(
                new URL("monaco-editor/esm/vs/language/json/json.worker.js", import.meta.url)
              );
            case "css":
            case "scss":
            case "less":
              return new Worker(
                new URL("monaco-editor/esm/vs/language/css/css.worker.js", import.meta.url)
              );
            case "html":
            case "handlebars":
            case "razor":
              return new Worker(
                new URL("monaco-editor/esm/vs/language/html/html.worker.js", import.meta.url)
              );
            case "typescript":
            case "javascript":
              return new Worker(
                new URL(
                  "monaco-editor/esm/vs/language/typescript/ts.worker.js",
                  import.meta.url
                )
              );
            default:
              return new Worker(
                new URL("monaco-editor/esm/vs/editor/editor.worker.js", import.meta.url)
              );
          }
        },
      };

      return monaco;
    });
  }

  return monacoInitPromise;
}

/**
 * Monaco Editor wrapper tuned for browser-based editing of larger files.
 * @param {{ value: string, onChange: (v: string) => void, filePath: string, fileSize?: number, className?: string }} props
 */
export default function MonacoEditor({
  value,
  onChange,
  filePath,
  fileSize = 0,
  className = "",
}) {
  const containerRef = useRef(null);
  const editorRef = useRef(null);
  const monacoRef = useRef(null);
  const themeDefinedRef = useRef(false);
  const onChangeRef = useRef(onChange);
  const [loadError, setLoadError] = useState("");
  const [isReady, setIsReady] = useState(false);
  const isLargeFile = isLargeEditorFile(fileSize);

  onChangeRef.current = onChange;

  const options = useMemo(
    () => ({
      automaticLayout: true,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      fontSize: 13,
      lineHeight: 20,
      tabSize: 2,
      wordWrap: isLargeFile ? "off" : "on",
      wrappingStrategy: isLargeFile ? "simple" : "advanced",
      largeFileOptimizations: true,
      renderLineHighlight: "line",
      overviewRulerBorder: false,
      hideCursorInOverviewRuler: true,
      smoothScrolling: false,
      codeLens: !isLargeFile,
      folding: !isLargeFile,
      quickSuggestions: !isLargeFile,
      suggestOnTriggerCharacters: !isLargeFile,
      parameterHints: { enabled: !isLargeFile },
      occurrencesHighlight: isLargeFile ? "off" : "singleFile",
      selectionHighlight: !isLargeFile,
      bracketPairColorization: { enabled: !isLargeFile },
      guides: {
        bracketPairs: !isLargeFile,
        indentation: !isLargeFile,
        highlightActiveIndentation: !isLargeFile,
      },
      unicodeHighlight: {
        ambiguousCharacters: false,
        invisibleCharacters: !isLargeFile,
      },
      scrollbar: {
        verticalScrollbarSize: 10,
        horizontalScrollbarSize: 10,
      },
      padding: { top: 8, bottom: 8 },
    }),
    [isLargeFile]
  );

  useEffect(() => {
    let disposed = false;

    loadMonaco()
      .then((monaco) => {
        if (disposed || !containerRef.current) {
          return;
        }

        monacoRef.current = monaco;

        if (!themeDefinedRef.current) {
          monaco.editor.defineTheme("liveinsec-dark", {
            base: "vs-dark",
            inherit: true,
            rules: [],
            colors: {
              "editor.background": "#111827",
              "editor.lineHighlightBackground": "#1f2937",
              "editorLineNumber.foreground": "#4b5563",
              "editorLineNumber.activeForeground": "#9ca3af",
            },
          });
          themeDefinedRef.current = true;
        }

        const editor = monaco.editor.create(containerRef.current, {
          value: value || "",
          language: getEditorLanguage(filePath),
          theme: "liveinsec-dark",
          ...options,
        });

        editor.onDidChangeModelContent(() => {
          onChangeRef.current?.(editor.getValue());
        });

        editorRef.current = editor;
        setIsReady(true);
        setLoadError("");
        requestAnimationFrame(() => editor.layout());
      })
      .catch((error) => {
        console.error("Monaco failed to initialize:", error);
        if (!disposed) {
          setLoadError("Editor failed to initialize. Refresh the page and try again.");
        }
      });

    return () => {
      disposed = true;
      if (editorRef.current) {
        editorRef.current.dispose();
        editorRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) {
      return;
    }

    const model = editor.getModel();
    if (model) {
      monaco.editor.setModelLanguage(model, getEditorLanguage(filePath));
    }

    if (editor.getValue() !== (value || "")) {
      editor.setValue(value || "");
    }

    requestAnimationFrame(() => editor.layout());
  }, [filePath, value]);

  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) {
      return;
    }

    editor.updateOptions(options);
    requestAnimationFrame(() => editor.layout());
  }, [options]);

  if (loadError) {
    return (
      <div className={`min-h-0 flex-1 ${className}`}>
        <ErrorState message={loadError} />
      </div>
    );
  }

  return (
    <div className={`min-h-0 flex-1 ${className}`}>
      {!isReady && (
        <LoadingState
          message={isLargeFile ? "Loading large file editor..." : "Loading editor..."}
        />
      )}
      <div
        ref={containerRef}
        className={isReady ? "h-full w-full" : "hidden"}
        style={{ minHeight: 200 }}
      />
    </div>
  );
}
