'use client';

/**
 * FormPromisePanel — shown in Step 1 of the deploy wizard so users know:
 *   1. They get a built-in form API (not "what's that?")
 *   2. Where it'll appear (URL preview that updates with their subdomain)
 *   3. They don't have to build a backend
 *   4. The first 100 leads/month are free
 *
 * This lifts the "I deployed and now I'm lost" problem — by the time the
 * user clicks Deploy, they already understand the value-prop.
 */
export default function FormPromisePanel({ subdomain, freeQuota = 100 }) {
  const sub = subdomain && subdomain.length >= 3 ? subdomain : 'yoursite';
  // We can't show the real apiKey yet (it's generated at create-time),
  // so we show a stable example shape so they know what to expect.
  const exampleEndpoint = `https://liveinsec.com/api/forms/${sub}_xxxxxxxx`;

  return (
    <div className="rounded-2xl border border-indigo-200 dark:border-indigo-900 bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/40 dark:to-violet-950/30 p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="text-3xl flex-shrink-0">📬</div>
        <div>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">
            Every site gets a contact-form backend, free.
          </h3>
          <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">
            Your <span className="font-mono font-semibold">{sub}</span> site
            comes with a built-in API that turns any HTML form into leads in
            your dashboard. No code, no third-party Formspree subscription.
          </p>
        </div>
      </div>

      <div className="rounded-lg border border-indigo-100 dark:border-indigo-900 bg-white/60 dark:bg-gray-900/60 p-3">
        <p className="text-xs uppercase tracking-wider font-semibold text-indigo-700 dark:text-indigo-300 mb-1">
          Your form will post to
        </p>
        <code className="block text-xs font-mono text-gray-700 dark:text-gray-300 break-all">
          {exampleEndpoint}
        </code>
        <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
          We'll generate the unique <span className="font-mono">xxxxxxxx</span> key
          right after you click <strong>Deploy</strong>. If you pick a template
          with a contact form below, we'll wire it for you automatically — no
          edits needed.
        </p>
      </div>

      <ul className="mt-4 space-y-1.5 text-xs text-gray-700 dark:text-gray-300">
        <li className="flex items-center gap-2">
          <span className="text-emerald-500">✓</span>
          <span>{freeQuota} free submissions per month — every account</span>
        </li>
        <li className="flex items-center gap-2">
          <span className="text-emerald-500">✓</span>
          <span>Honeypot + rate-limit anti-spam built in</span>
        </li>
        <li className="flex items-center gap-2">
          <span className="text-emerald-500">✓</span>
          <span>CSV export, status workflow (Won / Lost / Contacted)</span>
        </li>
      </ul>
    </div>
  );
}
