'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';

const STATUS_OPTIONS = [
  { value: 'new', label: 'New', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' },
  { value: 'read', label: 'Read', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
  { value: 'contacted', label: 'Contacted', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
  { value: 'won', label: 'Won', color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300' },
  { value: 'lost', label: 'Lost', color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
  { value: 'spam', label: 'Spam / Overflow', color: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300' },
];

const DATE_PRESETS = [
  { value: '24h', label: 'Last 24h', hours: 24 },
  { value: '7d', label: 'Last 7 days', hours: 24 * 7 },
  { value: '30d', label: 'Last 30 days', hours: 24 * 30 },
  { value: 'all', label: 'All time', hours: null },
];

function statusBadge(status) {
  const opt = STATUS_OPTIONS.find((s) => s.value === status) || STATUS_OPTIONS[0];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${opt.color}`}>
      {opt.label}
    </span>
  );
}

export default function SubmissionsTable({
  initialSubmissions,
  siteId,
  siteName,
  totalCount = 0,
  page = 1,
  totalPages = 1,
  basePath = '',
  searchQuery = '',
  statusFilter = '',
  dateFrom = '',
  dateTo = '',
  datePreset = '',
  showSiteColumn = false,
  quota = null,
  monthOverflowCount = 0,
}) {
  const quotaState = (() => {
    if (!quota) return null;
    const used = Math.max(0, Number(quota.used) || 0);
    const total = Math.max(used, Number(quota.total) || 0);
    if (!total) return null;
    const ratio = used / total;
    let level = 'ok';
    if (monthOverflowCount > 0 || quota.remaining <= 0) level = 'overflow';
    else if (ratio >= 0.9) level = 'critical';
    else if (ratio >= 0.7) level = 'warning';
    return { used, total, remaining: Math.max(0, total - used), ratio, level };
  })();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [submissions, setSubmissions] = useState(initialSubmissions || []);
  const [expandedRow, setExpandedRow] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);
  const [searchInput, setSearchInput] = useState(searchQuery);

  // Keep submissions in sync with server-provided data when nav changes
  useEffect(() => {
    setSubmissions(initialSubmissions || []);
  }, [initialSubmissions]);

  // Debounced search → URL update
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchInput === searchQuery) return;
      const params = new URLSearchParams(searchParams);
      if (searchInput) params.set('q', searchInput);
      else params.delete('q');
      params.delete('page');
      router.replace(`${basePath}?${params.toString()}`);
    }, 350);
    return () => clearTimeout(timer);
  }, [searchInput]); // eslint-disable-line react-hooks/exhaustive-deps

  const updateParams = useCallback(
    (mutate) => {
      const params = new URLSearchParams(searchParams);
      mutate(params);
      params.delete('page');
      router.replace(`${basePath}?${params.toString()}`);
    },
    [searchParams, basePath, router]
  );

  function setDatePreset(preset) {
    updateParams((p) => {
      if (preset === 'all') {
        p.delete('preset'); p.delete('from'); p.delete('to');
      } else if (preset === 'custom') {
        p.set('preset', 'custom');
      } else {
        p.set('preset', preset);
        p.delete('from'); p.delete('to');
      }
    });
  }

  function setStatus(value) {
    updateParams((p) => {
      if (value) p.set('status', value);
      else p.delete('status');
    });
  }

  function resolveSiteId(sub) {
    return siteId || sub.siteId || sub.site?.id;
  }

  async function patchSubmission(sub, body) {
    const id = sub.id;
    const targetSiteId = resolveSiteId(sub);
    if (!targetSiteId) return;
    setUpdatingId(id);
    try {
      const res = await fetch(`/api/submissions/${targetSiteId}/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        const data = await res.json();
        setSubmissions((rows) => rows.map((r) => (r.id === id ? { ...r, ...data.submission } : r)));
      }
    } finally {
      setUpdatingId(null);
    }
  }

  async function deleteSubmission(sub) {
    const id = sub.id;
    const targetSiteId = resolveSiteId(sub);
    if (!targetSiteId) return;
    if (!confirm('Delete this submission permanently? This cannot be undone.')) return;
    setUpdatingId(id);
    try {
      const res = await fetch(`/api/submissions/${targetSiteId}/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setSubmissions((rows) => rows.filter((r) => r.id !== id));
      }
    } finally {
      setUpdatingId(null);
    }
  }

  function handleExpand(sub, index) {
    if (expandedRow === index) {
      setExpandedRow(null);
      return;
    }
    setExpandedRow(index);
    if (!sub.isRead) {
      patchSubmission(sub, { isRead: true, status: sub.status === 'new' ? 'read' : sub.status });
    }
  }

  const exportUrl = useMemo(() => {
    if (!siteId) return null;
    const p = new URLSearchParams();
    if (searchQuery) p.set('q', searchQuery);
    if (statusFilter) p.set('status', statusFilter);
    if (dateFrom) p.set('from', dateFrom);
    if (dateTo) p.set('to', dateTo);
    return `/api/submissions/${siteId}/export?${p.toString()}`;
  }, [siteId, searchQuery, statusFilter, dateFrom, dateTo]);

  const isFiltered = !!(searchQuery || statusFilter || datePreset || dateFrom || dateTo);

  return (
    <div>
      {quotaState && (
        <div
          className={`mb-4 rounded-xl border p-4 ${
            quotaState.level === 'overflow'
              ? 'border-red-300 bg-red-50 dark:border-red-800 dark:bg-red-950/30'
              : quotaState.level === 'critical'
              ? 'border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30'
              : quotaState.level === 'warning'
              ? 'border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950/20'
              : 'border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900'
          }`}
        >
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="min-w-0 flex-1">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Submissions this month
                </span>
                <span
                  className={`text-sm font-semibold tabular-nums ${
                    quotaState.level === 'overflow'
                      ? 'text-red-700 dark:text-red-400'
                      : quotaState.level === 'critical'
                      ? 'text-amber-700 dark:text-amber-400'
                      : quotaState.level === 'warning'
                      ? 'text-yellow-700 dark:text-yellow-400'
                      : 'text-gray-700 dark:text-gray-300'
                  }`}
                >
                  {quotaState.used} / {quotaState.total}
                  <span className="ml-1.5 text-xs font-normal text-gray-500 dark:text-gray-400">
                    ({quotaState.remaining} left)
                  </span>
                </span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800">
                <div
                  className={`h-full rounded-full transition-all ${
                    quotaState.level === 'overflow'
                      ? 'bg-red-500'
                      : quotaState.level === 'critical'
                      ? 'bg-amber-500'
                      : quotaState.level === 'warning'
                      ? 'bg-yellow-500'
                      : 'bg-indigo-500'
                  }`}
                  style={{ width: `${Math.min(100, Math.round(quotaState.ratio * 100))}%` }}
                />
              </div>
              {quotaState.level === 'overflow' && (
                <p className="mt-1.5 text-xs text-red-700 dark:text-red-400">
                  {monthOverflowCount > 0
                    ? `${monthOverflowCount} lead${monthOverflowCount === 1 ? '' : 's'} flagged as overflow — upgrade to recover them.`
                    : `At ${quotaState.used} of ${quotaState.total}. New leads will be tagged as overflow until you top up.`}
                </p>
              )}
              {quotaState.level === 'critical' && (
                <p className="mt-1.5 text-xs text-amber-700 dark:text-amber-400">
                  Running low — buy more now to avoid missing the next lead.
                </p>
              )}
              {quotaState.level === 'warning' && (
                <p className="mt-1.5 text-xs text-yellow-700 dark:text-yellow-400">
                  Heads up — {Math.round(quotaState.ratio * 100)}% of your monthly quota used.
                </p>
              )}
              {quotaState.level === 'ok' && quotaState.remaining < 100 && (
                <p className="mt-1.5 text-xs text-gray-500 dark:text-gray-400">
                  Less than 100 submissions remaining this month.
                </p>
              )}
            </div>
            {quotaState.level !== 'ok' && (
              <div className="flex flex-shrink-0 items-center sm:ml-4">
                <Link
                  href="/dashboard/store?feature=submissions"
                  className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-semibold text-white shadow-sm transition-colors ${
                    quotaState.level === 'overflow'
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-indigo-600 hover:bg-indigo-700'
                  }`}
                >
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                  {quotaState.level === 'overflow' ? 'Recover overflow leads' : 'Buy more leads'}
                </Link>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Filter bar */}
      <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-4 mb-4">
        <div className="grid gap-3 lg:grid-cols-12">
          {/* Search */}
          <div className="lg:col-span-5">
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Search</label>
            <div className="relative">
              <svg className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
              </svg>
              <input
                type="search"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search by name, email, IP, or any field…"
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm"
              />
            </div>
          </div>

          {/* Status filter */}
          <div className="lg:col-span-3">
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="">All statuses</option>
              {STATUS_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>

          {/* Date preset */}
          <div className="lg:col-span-4">
            <label className="block text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">Date</label>
            <div className="flex flex-wrap gap-1">
              {DATE_PRESETS.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setDatePreset(p.value)}
                  className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors ${
                    datePreset === p.value || (!datePreset && p.value === 'all')
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          {isFiltered ? 'Filtered: ' : ''}
          <span className="font-medium text-gray-900 dark:text-white">{totalCount}</span> submission{totalCount === 1 ? '' : 's'}
          {totalPages > 1 && <span className="text-gray-500"> · page {page} of {totalPages}</span>}
        </p>
        {exportUrl && submissions.length > 0 && (
          <a
            href={exportUrl}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:text-indigo-700"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Export filtered CSV
          </a>
        )}
      </div>

      {/* Empty state */}
      {(!submissions || submissions.length === 0) && (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-12 text-center">
          <div className="mx-auto w-14 h-14 rounded-full bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center mb-4">
            <svg className="w-7 h-7 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">
            {isFiltered ? 'No submissions match these filters' : 'No submissions yet'}
          </h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 max-w-md mx-auto">
            {isFiltered
              ? 'Try widening the date range or clearing filters.'
              : 'Add a contact form to your site and submissions will appear here. Use the "Send test submission" button on your site page to verify your setup.'}
          </p>
          {isFiltered && (
            <button
              onClick={() => router.replace(basePath)}
              className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              Clear all filters
            </button>
          )}
        </div>
      )}

      {/* Table */}
      {submissions && submissions.length > 0 && (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
              <thead className="bg-gray-50 dark:bg-gray-800/50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">When</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  {showSiteColumn && (
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Site</th>
                  )}
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lead</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Form</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-32">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
                {submissions.map((sub, index) => {
                  let data = {};
                  try { data = JSON.parse(sub.data); } catch { data = { _parseError: true, raw: sub.data }; }
                  const isExpanded = expandedRow === index;
                  const isUpdating = updatingId === sub.id;
                  const preview = Object.entries(data).filter(([k]) => !k.startsWith('_')).slice(0, 2)
                    .map(([k, v]) => `${k}: ${String(v).slice(0, 40)}`).join(' · ');
                  const isUnread = !sub.isRead;
                  const isOverflow = sub.quotaOverflow;

                  return (
                    <tr
                      key={sub.id}
                      className={`hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer transition-colors ${
                        isUnread ? 'bg-indigo-50/30 dark:bg-indigo-950/20' : ''
                      }`}
                      onClick={() => handleExpand(sub, index)}
                    >
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                        {isUnread && (
                          <span className="inline-block w-2 h-2 mr-2 rounded-full bg-indigo-600" title="Unread" />
                        )}
                        {new Date(sub.createdAt).toLocaleDateString('en-US', {
                          month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
                        })}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {statusBadge(sub.status || 'new')}
                        {isOverflow && (
                          <span className="ml-1 text-[10px] text-red-600" title="Above your monthly free quota">⚠ overflow</span>
                        )}
                      </td>
                      {showSiteColumn && (
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                          {sub.site?.name || '-'}
                        </td>
                      )}
                      <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                        {isExpanded ? (
                          <div className="space-y-1.5 max-w-2xl">
                            {data._parseError ? (
                              <div className="text-xs text-red-600">Couldn&apos;t parse this submission. Raw data:</div>
                            ) : (
                              Object.entries(data).filter(([k]) => !k.startsWith('_')).map(([k, v]) => (
                                <div key={k} className="text-sm">
                                  <span className="font-medium text-gray-700 dark:text-gray-300">{k}:</span>{' '}
                                  <span className="text-gray-900 dark:text-white break-words">{String(v)}</span>
                                </div>
                              ))
                            )}
                            {sub.ipAddress && (
                              <div className="text-xs text-gray-500 mt-2">IP: {sub.ipAddress}</div>
                            )}
                          </div>
                        ) : (
                          <span className="truncate block max-w-md text-gray-700 dark:text-gray-300">{preview || '—'}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{sub.formName}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="inline-flex items-center gap-1">
                          <select
                            value={sub.status || 'new'}
                            onChange={(e) => patchSubmission(sub, { status: e.target.value })}
                            disabled={isUpdating}
                            className="text-xs rounded-md border border-gray-300 dark:border-gray-700 dark:bg-gray-800 px-2 py-1 disabled:opacity-50"
                          >
                            {STATUS_OPTIONS.map((s) => (
                              <option key={s.value} value={s.value}>{s.label}</option>
                            ))}
                          </select>
                          <button
                            onClick={() => deleteSubmission(sub)}
                            disabled={isUpdating}
                            className="text-xs text-gray-400 hover:text-red-600 px-1 disabled:opacity-50"
                            title="Delete submission"
                          >
                            🗑
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && basePath && submissions.length > 0 && (
        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Page {page} of {totalPages}
          </p>
          <div className="flex items-center gap-2">
            {[1, page - 1, page, page + 1, totalPages]
              .filter((n, i, a) => n >= 1 && n <= totalPages && a.indexOf(n) === i)
              .sort((a, b) => a - b)
              .map((n, idx, arr) => (
                <span key={n} className="flex items-center gap-2">
                  {idx > 0 && arr[idx - 1] !== n - 1 && <span className="text-gray-400">…</span>}
                  <Link
                    href={`${basePath}?${(() => {
                      const p = new URLSearchParams(searchParams);
                      p.set('page', String(n));
                      return p.toString();
                    })()}`}
                    className={`rounded-lg border px-3 py-1.5 text-sm ${
                      n === page
                        ? 'border-indigo-600 bg-indigo-600 text-white'
                        : 'border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-400'
                    }`}
                  >
                    {n}
                  </Link>
                </span>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
