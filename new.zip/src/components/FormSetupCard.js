'use client';

import { useState } from 'react';
import Link from 'next/link';

/**
 * FormSetupCard — a self-contained, copy-and-test interactive walkthrough
 * for connecting a contact form to a deployed LiveInSec site.
 *
 * Rendered on the site detail page. Replaces the static "API key + code block"
 * section that was hard to discover and use.
 */
export default function FormSetupCard({
  siteId,
  siteName,
  apiKey,
  formEndpoint,
  honeypotField,
  primaryUrl,
  submissionsAccess,
  submissionCount,
}) {
  const [copied, setCopied] = useState({});
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [activeTab, setActiveTab] = useState('html');

  function copy(label, text) {
    navigator.clipboard.writeText(text).then(() => {
      setCopied((s) => ({ ...s, [label]: true }));
      setTimeout(() => setCopied((s) => ({ ...s, [label]: false })), 1500);
    });
  }

  async function sendTestSubmission() {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(`/api/sites/${siteId}/test-submission`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setTestResult({ ok: true, message: data.message });
      } else {
        setTestResult({ ok: false, message: data.error || 'Test failed' });
      }
    } catch (err) {
      setTestResult({ ok: false, message: 'Network error: ' + (err?.message || err) });
    } finally {
      setTesting(false);
    }
  }

  const htmlSnippet = `<form action="${formEndpoint}" method="POST">
  <input name="name" placeholder="Your Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>
  <input type="text" name="${honeypotField}" style="display:none" tabindex="-1" autocomplete="off" />
  <input type="hidden" name="_redirect" value="${primaryUrl}" />
  <button type="submit">Send</button>
</form>`;

  const ajaxSnippet = `fetch("${formEndpoint}", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    name: "John",
    email: "john@example.com",
    message: "Hello from my site!"
  })
})
.then(r => r.json())
.then(data => console.log("Submitted!", data));`;

  const reactSnippet = `// React / Next.js
async function handleSubmit(e) {
  e.preventDefault();
  const form = new FormData(e.target);
  const res = await fetch("${formEndpoint}", {
    method: "POST",
    body: form,
  });
  const data = await res.json();
  if (data.success) alert("Thanks! We'll be in touch.");
}`;

  if (!submissionsAccess) {
    return (
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-8 mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 mb-3 rounded-full bg-indigo-50 dark:bg-indigo-950/40 px-3 py-1 text-xs font-medium text-indigo-700 dark:text-indigo-300">
              <span>📬</span> Lead capture
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Capture leads from your site</h3>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 max-w-2xl">
              Add a contact form to your static site and every submission lands in your LiveInSec inbox — no backend code, no Formspree subscription. Free up to a monthly quota.
            </p>
          </div>
          <Link
            href={`/dashboard/store?feature=submissions`}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 text-sm font-semibold whitespace-nowrap"
          >
            Activate lead inbox
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden mb-8">
      {/* Header */}
      <div className="px-6 py-5 border-b border-gray-200 dark:border-gray-800 bg-gradient-to-br from-indigo-50/40 to-white dark:from-indigo-950/30 dark:to-gray-900">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <span>📬</span> Connect your contact form
            </h3>
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
              {submissionCount > 0
                ? `${submissionCount} submission${submissionCount === 1 ? '' : 's'} received so far.`
                : 'Three steps to start collecting leads from your site.'}
            </p>
          </div>
          <button
            onClick={sendTestSubmission}
            disabled={testing}
            className="inline-flex items-center justify-center gap-2 rounded-lg border border-indigo-600 bg-white text-indigo-700 hover:bg-indigo-50 dark:bg-gray-900 dark:hover:bg-gray-800 px-4 py-2 text-sm font-semibold disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {testing ? (
              <>
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" className="opacity-25"/><path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="3" className="opacity-75"/></svg>
                Sending…
              </>
            ) : (
              <>
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/></svg>
                Send test submission
              </>
            )}
          </button>
        </div>
        {testResult && (
          <div
            className={`mt-3 rounded-lg px-4 py-3 text-sm ${
              testResult.ok
                ? 'bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200'
                : 'bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
            }`}
          >
            {testResult.ok ? '✓' : '✗'} {testResult.message}
            {testResult.ok && (
              <Link href={`/dashboard/sites/${siteId}/submissions`} className="ml-2 underline font-medium">
                Open inbox →
              </Link>
            )}
          </div>
        )}
      </div>

      {/* 3-step walkthrough */}
      <div className="grid md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-200 dark:divide-gray-800">
        {/* Step 1: Endpoint */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 text-sm font-semibold">1</span>
            <span className="text-sm font-semibold text-gray-900 dark:text-white">Your form endpoint</span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
            Point any HTML form's <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded">action</code> here.
          </p>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-xs font-mono text-gray-800 dark:text-gray-200">
              {formEndpoint}
            </code>
            <button
              onClick={() => copy('endpoint', formEndpoint)}
              className="rounded-lg border border-gray-300 dark:border-gray-700 px-2.5 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
              title="Copy endpoint"
            >
              {copied.endpoint ? '✓' : '📋'}
            </button>
          </div>
        </div>

        {/* Step 2: API key */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 text-sm font-semibold">2</span>
            <span className="text-sm font-semibold text-gray-900 dark:text-white">API key (already in URL)</span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
            Already embedded above. Public by design — protected by origin checks + honeypot.
          </p>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-xs font-mono text-gray-800 dark:text-gray-200">
              {apiKey}
            </code>
            <button
              onClick={() => copy('key', apiKey)}
              className="rounded-lg border border-gray-300 dark:border-gray-700 px-2.5 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
              title="Copy API key"
            >
              {copied.key ? '✓' : '📋'}
            </button>
          </div>
        </div>

        {/* Step 3: Test it */}
        <div className="p-6">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 text-sm font-semibold">3</span>
            <span className="text-sm font-semibold text-gray-900 dark:text-white">Test it</span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400 mb-3">
            Click the button above to send a test lead — it'll appear in your inbox in seconds.
          </p>
          <Link
            href={`/dashboard/sites/${siteId}/submissions`}
            className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            View inbox →
          </Link>
        </div>
      </div>

      {/* Code samples */}
      <div className="border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-950/50">
        <div className="flex items-center justify-between px-6 pt-4">
          <div className="flex gap-1">
            {[
              { id: 'html', label: 'Plain HTML' },
              { id: 'ajax', label: 'Fetch / AJAX' },
              { id: 'react', label: 'React' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeTab === t.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          <button
            onClick={() =>
              copy(
                'snippet',
                activeTab === 'html' ? htmlSnippet : activeTab === 'ajax' ? ajaxSnippet : reactSnippet
              )
            }
            className="text-xs font-medium text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400"
          >
            {copied.snippet ? '✓ Copied' : '📋 Copy'}
          </button>
        </div>
        <pre className="bg-gray-900 text-green-400 px-6 py-4 mx-4 my-4 rounded-lg text-xs overflow-x-auto leading-relaxed">
          {activeTab === 'html' ? htmlSnippet : activeTab === 'ajax' ? ajaxSnippet : reactSnippet}
        </pre>
      </div>

      {/* Bottom helper */}
      <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-950/50">
        <details className="text-sm">
          <summary className="cursor-pointer font-medium text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
            How does the spam protection work?
          </summary>
          <div className="mt-3 text-xs text-gray-600 dark:text-gray-400 space-y-2">
            <p>
              The hidden <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded">{honeypotField}</code> field is a "honeypot" — humans
              never fill it, bots usually do. Submissions that contain it are silently discarded.
            </p>
            <p>Your form is also protected by origin checks (only submits from your site count) and per-IP rate limits.</p>
          </div>
        </details>
      </div>
    </div>
  );
}
