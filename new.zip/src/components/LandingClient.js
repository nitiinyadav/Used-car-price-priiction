"use client";

import Link from "next/link";
import { useEffect, useState, useMemo } from "react";
import SubdomainPreview from "@/components/SubdomainPreview";

/* ─────────────────────────────────────────────────────────
   LandingClient — conversion-focused homepage.

   Design principles applied:
   - One bold promise above the fold ("Drop a website. Get leads.")
   - Replace the previous fake loading-skeleton mockup with a LIVE
     animated demo of a contact form being filled in and a lead
     arriving in the inbox — visitors see the product, not a placeholder.
   - Real social-proof numbers passed in from a server component
     (no fake "12K sites deployed").
   - Concrete use cases with named scenarios that visitors can
     map onto themselves: "freelancer with portfolio", "restaurant
     taking reservations", "coaching center capturing leads".
   - FAQ that addresses the actual reasons people don't sign up.
   ───────────────────────────────────────────────────────── */

export default function LandingClient({ stats }) {
  return (
    <main>
      <Hero stats={stats} />
      <TrustStrip stats={stats} />
      <UseCases />
      <ThreePromises />
      <HowItWorks />
      <Comparison />
      <Pricing />
      <FAQ />
      <FinalCTA />
      <Footer />
    </main>
  );
}

/* ───────── Hero ───────── */
function Hero({ stats }) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white via-indigo-50/30 to-white dark:from-gray-950 dark:via-indigo-950/20 dark:to-gray-950 pt-16 pb-20 sm:pt-24 sm:pb-28">
      {/* Decorative gradient blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
        <div className="absolute top-20 -left-20 w-96 h-96 rounded-full bg-indigo-300/30 dark:bg-indigo-700/20 blur-3xl" />
        <div className="absolute top-40 -right-20 w-96 h-96 rounded-full bg-fuchsia-300/30 dark:bg-fuchsia-700/20 blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Copy */}
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-indigo-100 dark:bg-indigo-900/40 px-4 py-1.5 text-xs font-semibold text-indigo-700 dark:text-indigo-300">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
              </span>
              Free forever for 3 sites · No credit card
            </span>
            <h1 className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-gray-900 dark:text-white leading-[1.05]">
              Drop a website.{" "}
              <span className="bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                Get leads.
              </span>
            </h1>
            <p className="mt-5 text-lg text-gray-600 dark:text-gray-400 max-w-xl leading-relaxed">
              The fastest way to host a static website that <em>actually does something</em>.
              Built-in contact-form API, lead inbox, and analytics —
              <span className="text-gray-900 dark:text-white font-semibold"> in one click</span>.
              No Git, no CLI, no Formspree subscription.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/register"
                className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3.5 text-base font-semibold shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 transition-all"
              >
                Deploy free site
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </Link>
              <Link
                href="#how-it-works"
                className="inline-flex items-center gap-2 rounded-xl border border-gray-300 dark:border-gray-700 text-gray-800 dark:text-gray-200 hover:border-gray-400 dark:hover:border-gray-600 px-6 py-3.5 text-base font-semibold"
              >
                See how it works
              </Link>
            </div>
            <div className="mt-7 flex flex-wrap items-center gap-6 text-xs text-gray-500 dark:text-gray-400">
              <span className="flex items-center gap-1.5"><span className="text-emerald-500">✓</span> No CLI required</span>
              <span className="flex items-center gap-1.5"><span className="text-emerald-500">✓</span> Forms work out of the box</span>
              <span className="flex items-center gap-1.5"><span className="text-emerald-500">✓</span> INR or USD billing</span>
            </div>
          </div>

          {/* Live "form-arrives" animated demo */}
          <div className="relative">
            <LiveLeadDemo />
            <div className="absolute -inset-4 -z-10 bg-gradient-to-br from-indigo-200/20 via-violet-200/20 to-fuchsia-200/20 dark:from-indigo-800/15 dark:via-violet-800/15 dark:to-fuchsia-800/15 rounded-[3rem] blur-2xl" />
          </div>
        </div>

        {/* Subdomain check below the fold */}
        <div className="mt-16">
          <p className="text-center text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
            See your site URL before you sign up:
          </p>
          <SubdomainPreview />
        </div>
      </div>
    </section>
  );
}

/* ───────── Live animated demo of form arriving ───────── */
//
// This is what replaces the fake loading-skeleton frame. It's an actual
// scripted animation that cycles through three states:
//   1. Visitor types into a contact form on a "site"
//   2. Submission flies across to the LiveInSec inbox panel
//   3. A new "lead" row appears in the inbox with status "new"
// The cycle restarts every ~10 seconds, drawing the eye and showing
// what the product actually does.

const DEMO_LEADS = [
  { name: "Priya Sharma",  email: "priya@design.studio", message: "Loved your portfolio. Quick chat about a logo project?" },
  { name: "Marcus Lee",    email: "marcus@stripe.com",   message: "We're hiring. Are you open to roles?" },
  { name: "Anjali Patel",  email: "anjali@yoga.in",      message: "Want to book the studio next Saturday." },
];

function LiveLeadDemo() {
  const [phase, setPhase] = useState(0); // 0=typing, 1=sending, 2=arrived
  const [leadIdx, setLeadIdx] = useState(0);
  const [typed, setTyped] = useState({ name: "", email: "", message: "" });

  const lead = DEMO_LEADS[leadIdx];

  // Typing animation
  useEffect(() => {
    if (phase !== 0) return;
    setTyped({ name: "", email: "", message: "" });
    const fields = [["name", lead.name], ["email", lead.email], ["message", lead.message]];
    let totalDelay = 200;
    const timers = [];
    for (const [field, value] of fields) {
      for (let i = 1; i <= value.length; i++) {
        const t = setTimeout(() => setTyped((p) => ({ ...p, [field]: value.slice(0, i) })), totalDelay);
        timers.push(t);
        totalDelay += 25;
      }
      totalDelay += 250;
    }
    const sendTimer = setTimeout(() => setPhase(1), totalDelay + 300);
    timers.push(sendTimer);
    return () => timers.forEach(clearTimeout);
  }, [phase, leadIdx, lead]);

  // Sending animation → arrived
  useEffect(() => {
    if (phase !== 1) return;
    const t = setTimeout(() => setPhase(2), 700);
    return () => clearTimeout(t);
  }, [phase]);

  // Arrived → next cycle
  useEffect(() => {
    if (phase !== 2) return;
    const t = setTimeout(() => {
      setLeadIdx((i) => (i + 1) % DEMO_LEADS.length);
      setPhase(0);
    }, 4000);
    return () => clearTimeout(t);
  }, [phase]);

  return (
    <div className="relative">
      {/* Browser-frame mock with the contact form */}
      <div className="rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-2xl shadow-gray-300/40 dark:shadow-black/40 overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-400" />
            <span className="w-3 h-3 rounded-full bg-amber-400" />
            <span className="w-3 h-3 rounded-full bg-green-400" />
          </div>
          <div className="flex-1 mx-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md px-3 py-1 text-xs font-mono text-gray-500 dark:text-gray-400 truncate flex items-center gap-1.5">
            <svg className="w-3 h-3 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd"/></svg>
            yoursite.liveinsec.com
          </div>
        </div>
        <div className="p-6">
          <div className="text-sm font-semibold text-gray-900 dark:text-white mb-3">Contact Me</div>
          <div className="space-y-2.5">
            <DemoInput label="Name" value={typed.name} typing={phase === 0} />
            <DemoInput label="Email" value={typed.email} typing={phase === 0} />
            <DemoTextarea label="Message" value={typed.message} typing={phase === 0} />
            <div className="pt-1">
              <button
                className={`w-full rounded-lg py-2 text-sm font-semibold transition-all ${
                  phase >= 1
                    ? 'bg-emerald-500 text-white scale-[0.98]'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {phase === 0 && 'Send'}
                {phase === 1 && 'Sending...'}
                {phase === 2 && '✓ Sent!'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Inbox arrival card — fades in when phase===2 */}
      <div
        className={`absolute -bottom-8 -right-4 sm:-right-8 w-[280px] sm:w-[320px] rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-2xl shadow-indigo-300/30 dark:shadow-black/50 p-3 transition-all duration-500 ${
          phase === 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
        }`}
      >
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xl">📬</span>
          <span className="text-xs font-semibold text-gray-900 dark:text-white">Lead Inbox</span>
          <span className="ml-auto text-[10px] font-mono text-gray-400">just now</span>
        </div>
        <div className="rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900 p-2.5">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
            <span className="text-xs font-semibold text-gray-900 dark:text-white truncate">{lead.name}</span>
            <span className="ml-auto inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300">new</span>
          </div>
          <p className="text-xs text-gray-600 dark:text-gray-400 truncate">{lead.email}</p>
          <p className="text-[11px] text-gray-500 mt-1 truncate">{lead.message}</p>
        </div>
      </div>

      {/* "Flying" packet between form & inbox during sending phase */}
      <div
        className={`absolute top-1/2 right-4 w-3 h-3 rounded-full bg-indigo-500 shadow-lg shadow-indigo-500/50 transition-all duration-700 ${
          phase === 1 ? 'opacity-100 translate-x-12 -translate-y-6 scale-100' : 'opacity-0 translate-x-0 scale-50'
        }`}
        aria-hidden
      />
    </div>
  );
}

function DemoInput({ label, value, typing }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-gray-400 mb-1">{label}</p>
      <div className="rounded-md bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 px-3 py-1.5 text-xs text-gray-800 dark:text-gray-200 font-mono min-h-[28px] flex items-center">
        {value}
        {typing && <span className="inline-block w-px h-3 bg-indigo-500 ml-0.5 animate-pulse" />}
      </div>
    </div>
  );
}
function DemoTextarea({ label, value, typing }) {
  return (
    <div>
      <p className="text-[10px] uppercase tracking-wide text-gray-400 mb-1">{label}</p>
      <div className="rounded-md bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 px-3 py-1.5 text-xs text-gray-800 dark:text-gray-200 font-mono min-h-[60px]">
        {value}
        {typing && <span className="inline-block w-px h-3 bg-indigo-500 ml-0.5 animate-pulse" />}
      </div>
    </div>
  );
}

/* ───────── Trust strip with REAL DB stats ───────── */
function TrustStrip({ stats }) {
  const fmt = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1).replace(/\.0$/, '')}k` : String(n));
  const showBadges = (stats?.siteCount || 0) > 0;
  return (
    <section className="bg-gray-50 dark:bg-gray-900/40 border-y border-gray-100 dark:border-gray-800 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
              {showBadges ? fmt(stats.siteCount) : 'Just'}
            </p>
            <p className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 mt-1">
              {showBadges ? 'sites deployed' : 'launched'}
            </p>
          </div>
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
              {showBadges ? fmt(stats.submissionCount) : 'No'}
            </p>
            <p className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 mt-1">
              {showBadges ? 'leads collected' : 'lock-in'}
            </p>
          </div>
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
              {'<1s'}
            </p>
            <p className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 mt-1">deploy time</p>
          </div>
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">₹0</p>
            <p className="text-xs uppercase tracking-wider text-gray-500 dark:text-gray-400 mt-1">to start</p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────── Use Cases ───────── */
const USE_CASES = [
  {
    icon: '💼',
    title: 'Freelancer with a portfolio',
    pain: 'Your contact form is decoration — emails get lost.',
    fix: 'Every "Hire me" message lands in your Lead Inbox. Mark them Won, Lost, or Contacted.',
    accent: 'from-indigo-500 to-violet-500',
  },
  {
    icon: '🍽️',
    title: 'Restaurant or café',
    pain: 'WhatsApp DMs for reservations get lost in chat.',
    fix: 'A reservation form on your site → all bookings sorted by date in your inbox.',
    accent: 'from-rose-500 to-pink-500',
  },
  {
    icon: '🎓',
    title: 'Coaching center / tutor',
    pain: 'Parents call asking about classes. Half the calls go unanswered.',
    fix: 'A "Book a free demo class" form captures every interested parent — even at 11pm.',
    accent: 'from-amber-500 to-orange-500',
  },
  {
    icon: '🏠',
    title: 'Real-estate / interior',
    pain: 'You pay for ads but don\'t know which lead came from where.',
    fix: 'Tag forms by source. See exactly which property page brought the most enquiries.',
    accent: 'from-emerald-500 to-teal-500',
  },
  {
    icon: '🚀',
    title: 'Pre-launch / waitlist',
    pain: 'Coming-soon page collects emails — but where do they go?',
    fix: 'Right into your inbox, exportable as CSV when you\'re ready to launch.',
    accent: 'from-fuchsia-500 to-purple-500',
  },
  {
    icon: '👨‍💻',
    title: 'Developer with a side project',
    pain: 'Setting up Formspree, Sendgrid, S3 just to host an HTML demo.',
    fix: 'ZIP upload, free subdomain, free 100 leads/month. Done in 60 seconds.',
    accent: 'from-cyan-500 to-blue-500',
  },
];

function UseCases() {
  return (
    <section className="py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-sm font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">For builders who actually ship</p>
          <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">
            What you can launch this weekend
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            LiveInSec is built for the most common "I just need a website that works" cases.
            Pick one and go live in under a minute.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {USE_CASES.map((uc) => (
            <div
              key={uc.title}
              className="group relative rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 hover:shadow-xl hover:shadow-indigo-200/40 dark:hover:shadow-indigo-900/30 hover:-translate-y-0.5 transition-all"
            >
              <div className={`inline-flex w-12 h-12 rounded-xl bg-gradient-to-br ${uc.accent} items-center justify-center text-2xl mb-4`}>
                {uc.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{uc.title}</h3>
              <p className="mt-2 text-sm text-gray-500 dark:text-gray-400 italic">"{uc.pain}"</p>
              <p className="mt-3 text-sm text-gray-700 dark:text-gray-300">{uc.fix}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Three Promises ───────── */
function ThreePromises() {
  return (
    <section className="py-20 sm:py-28 bg-gray-50 dark:bg-gray-900/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">
            Three things we promise
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            We're not trying to be every hosting platform. We're trying to be the right one.
          </p>
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          <PromiseCard
            icon="🚫"
            title="No Git. No CLI. No DevOps."
            body="Drop a ZIP, write in our browser editor, or pick a template. If you can use Gmail, you can deploy a website here."
            chip="vs Vercel/Netlify"
          />
          <PromiseCard
            icon="📬"
            title="Forms that just work."
            body="Every site has a form API and a Lead Inbox built in. Free for the first 100 leads/month. Save the ₹650/mo Formspree fee."
            chip="vs Formspree"
          />
          <PromiseCard
            icon="🇮🇳"
            title="Made for India too."
            body="Pay in INR via UPI/Razorpay. GST invoices on the way. A timezone-friendly support team. Stripe + USD also work — we serve everyone."
            chip="vs Tiiny.host"
          />
        </div>
      </div>
    </section>
  );
}

function PromiseCard({ icon, title, body, chip }) {
  return (
    <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-7">
      <div className="flex items-center justify-between mb-4">
        <div className="text-3xl">{icon}</div>
        <span className="text-[10px] uppercase tracking-wider font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-full">{chip}</span>
      </div>
      <h3 className="text-xl font-bold text-gray-900 dark:text-white">{title}</h3>
      <p className="mt-3 text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{body}</p>
    </div>
  );
}

/* ───────── How It Works ───────── */
function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 sm:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">
            From signup to first lead in 90 seconds
          </h2>
        </div>
        <div className="relative">
          <div className="hidden lg:block absolute top-12 left-[16%] right-[16%] h-0.5 bg-gradient-to-r from-indigo-300 via-violet-300 to-fuchsia-300 dark:from-indigo-800 dark:via-violet-800 dark:to-fuchsia-800" />
          <div className="grid lg:grid-cols-3 gap-10 relative">
            <Step n="01" title="Sign up free" body="Email + password. No credit card. 10 seconds." color="indigo" />
            <Step n="02" title="Pick a template (or upload ZIP)" body="The contact form is pre-wired. Click Deploy and your site is live with its own subdomain." color="violet" />
            <Step n="03" title="Watch leads arrive" body="Send a test submission from the dashboard. Real submissions land here too — exportable as CSV." color="fuchsia" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Step({ n, title, body, color }) {
  const ring = { indigo: 'ring-indigo-200 dark:ring-indigo-900', violet: 'ring-violet-200 dark:ring-violet-900', fuchsia: 'ring-fuchsia-200 dark:ring-fuchsia-900' }[color];
  const bg = { indigo: 'from-indigo-500 to-indigo-600', violet: 'from-violet-500 to-violet-600', fuchsia: 'from-fuchsia-500 to-fuchsia-600' }[color];
  return (
    <div className="text-center">
      <div className={`mx-auto w-24 h-24 rounded-full bg-gradient-to-br ${bg} text-white text-2xl font-bold flex items-center justify-center ring-8 ${ring} ring-offset-4 ring-offset-white dark:ring-offset-gray-950 relative z-10 shadow-lg`}>
        {n}
      </div>
      <h3 className="mt-6 text-xl font-semibold text-gray-900 dark:text-white">{title}</h3>
      <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 max-w-xs mx-auto">{body}</p>
    </div>
  );
}

/* ───────── Comparison ───────── */
function Comparison() {
  const rows = [
    ['Upload ZIP, no Git/CLI',     true,  false, false, false],
    ['Built-in contact form API',  true,  'paid', false, false],
    ['Lead Inbox + status workflow', true, 'paid', false, false],
    ['Free subdomain',             true,  true,  true,  true],
    ['Custom domain',              true,  true,  true,  true],
    ['INR billing + UPI',          true,  false, false, false],
    ['Privacy-first analytics',    true,  'paid', false, false],
    ['No "trial expires" surprises', true, true,  true,  false],
  ];
  const headers = ['LiveInSec', 'Netlify', 'GitHub Pages', 'Tiiny.host'];
  const cellMark = (v) => {
    if (v === true)   return <span className="text-emerald-500 text-xl">✓</span>;
    if (v === 'paid') return <span className="text-amber-500 text-xs font-semibold">paid only</span>;
    return <span className="text-gray-300 dark:text-gray-700 text-xl">—</span>;
  };
  return (
    <section className="py-20 sm:py-24 bg-gray-50 dark:bg-gray-900/30">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">How we stack up</h2>
          <p className="mt-3 text-gray-600 dark:text-gray-400">Honest comparison. Verify any claim before you sign up.</p>
        </div>
        <div className="overflow-x-auto rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
            <thead>
              <tr>
                <th className="px-4 py-4 text-left text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">Feature</th>
                {headers.map((h, i) => (
                  <th key={h} className={`px-4 py-4 text-center text-xs font-semibold uppercase tracking-wider ${
                    i === 0 ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-500 dark:text-gray-400'
                  }`}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {rows.map(([label, ...vals]) => (
                <tr key={label} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="px-4 py-3.5 text-sm font-medium text-gray-900 dark:text-gray-100">{label}</td>
                  {vals.map((v, i) => (
                    <td key={i} className={`px-4 py-3.5 text-center ${i === 0 ? 'bg-indigo-50/50 dark:bg-indigo-950/20' : ''}`}>
                      {cellMark(v)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

/* ───────── Pricing ───────── */
function Pricing() {
  return (
    <section id="pricing" className="py-20 sm:py-28">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">Simple pricing. No surprises.</h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400">
            Free forever for portfolios and small projects. Upgrade only when you outgrow it.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {/* Free */}
          <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Free</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">For portfolios + side projects</p>
            <p className="mt-6 text-5xl font-bold text-gray-900 dark:text-white">₹0<span className="text-base font-medium text-gray-400"> / forever</span></p>
            <ul className="mt-6 space-y-3 text-sm text-gray-700 dark:text-gray-300">
              <Bullet>3 sites · free subdomains</Bullet>
              <Bullet>500 MB storage per site</Bullet>
              <Bullet>100 form submissions / month</Bullet>
              <Bullet>5 free custom domains</Bullet>
              <Bullet>Anti-spam (honeypot + rate limit)</Bullet>
              <Bullet>"Powered by LiveInSec" badge</Bullet>
            </ul>
            <Link
              href="/register"
              className="mt-7 block text-center w-full rounded-xl bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-5 py-3 text-sm font-semibold hover:opacity-90"
            >
              Start free
            </Link>
          </div>
          {/* Pro */}
          <div className="relative rounded-2xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-8 text-white shadow-xl shadow-indigo-500/30">
            <span className="absolute top-3 right-3 inline-flex items-center rounded-full bg-white/20 backdrop-blur px-2 py-0.5 text-[10px] uppercase tracking-wider font-semibold">Most popular</span>
            <h3 className="text-2xl font-bold">Pro</h3>
            <p className="mt-1 text-sm text-indigo-100">For freelancers, agencies, and small businesses</p>
            <p className="mt-6 text-5xl font-bold">₹399<span className="text-base font-medium text-indigo-200"> / mo</span></p>
            <p className="text-sm text-indigo-100">or $4.99/mo · cancel anytime</p>
            <ul className="mt-6 space-y-3 text-sm text-indigo-50">
              <Bullet light>20 sites · 500 MB each</Bullet>
              <Bullet light>5,000 leads / month</Bullet>
              <Bullet light>Email notifications on new leads</Bullet>
              <Bullet light>Remove "Powered by" badge</Bullet>
              <Bullet light>Priority support</Bullet>
              <Bullet light>30-day analytics retention</Bullet>
            </ul>
            <Link
              href="/register?plan=pro"
              className="mt-7 block text-center w-full rounded-xl bg-white text-indigo-700 px-5 py-3 text-sm font-semibold hover:bg-indigo-50"
            >
              Start with Pro
            </Link>
          </div>
        </div>
        <p className="mt-6 text-center text-sm text-gray-500 dark:text-gray-400">
          Need more? Buy à-la-carte features (extra leads, team seats, AI generator) without changing your plan.
        </p>
      </div>
    </section>
  );
}

function Bullet({ children, light }) {
  return (
    <li className="flex items-start gap-2.5">
      <span className={light ? 'text-emerald-200' : 'text-emerald-500'}>✓</span>
      <span>{children}</span>
    </li>
  );
}

/* ───────── FAQ ───────── */
const FAQ_ITEMS = [
  {
    q: "Do I need to know how to code?",
    a: "If you have an HTML file (or a ZIP from a designer), you're set. We even include 7 ready-made templates — pick one and the contact form is already wired.",
  },
  {
    q: "How are forms different from Formspree or Getform?",
    a: "We bundle hosting + forms + lead inbox. Formspree is forms-only and starts at $8/mo. Our free tier already includes 100 form submissions/month — most portfolios never need more.",
  },
  {
    q: "Will my site go offline if I don't pay?",
    a: "No. Free hosting is forever. Only the paid features (more leads, more sites, premium analytics) lapse if you stop paying. Your subdomain stays live.",
  },
  {
    q: "Can I bring my own domain?",
    a: "Yes — and the first 5 custom domains are free. Just point a CNAME to us and confirm in the dashboard.",
  },
  {
    q: "How is this different from Netlify or Vercel?",
    a: "Those tools assume you're a developer using Git. We work for anyone with an HTML file. We're also the only one with a built-in form-collection backend at this price point.",
  },
  {
    q: "Where is my site hosted?",
    a: "Our infrastructure runs in Mumbai (default for India) and US-East (default for international). We're moving custom-domain SSL to Caddy + Cloudflare in the next few weeks.",
  },
  {
    q: "Can I cancel anytime?",
    a: "Yes. Pro is month-to-month, no contracts. You can refund any à-la-carte purchase within 7 days.",
  },
];

function FAQ() {
  return (
    <section className="py-20 sm:py-24 bg-gray-50 dark:bg-gray-900/30">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">Common questions</h2>
        </div>
        <div className="space-y-3">
          {FAQ_ITEMS.map((item, i) => (
            <details
              key={i}
              className="group rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 px-5 py-4 open:shadow-lg open:shadow-indigo-100 dark:open:shadow-indigo-950/20 open:border-indigo-200 dark:open:border-indigo-900"
            >
              <summary className="cursor-pointer flex items-center justify-between font-semibold text-gray-900 dark:text-white text-base list-none">
                <span>{item.q}</span>
                <span className="text-indigo-500 transition-transform group-open:rotate-45 text-2xl leading-none ml-2">+</span>
              </summary>
              <p className="mt-3 text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                {item.a}
              </p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Final CTA ───────── */
function FinalCTA() {
  return (
    <section className="py-20 sm:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 px-8 py-14 sm:px-14 sm:py-20 text-center text-white shadow-xl shadow-indigo-500/30">
          <div className="absolute -top-20 -left-10 w-64 h-64 rounded-full bg-white/15 blur-3xl" aria-hidden></div>
          <div className="absolute -bottom-20 -right-10 w-64 h-64 rounded-full bg-fuchsia-300/30 blur-3xl" aria-hidden></div>
          <div className="relative">
            <h2 className="text-3xl sm:text-5xl font-bold tracking-tight">
              Ready to ship something real?
            </h2>
            <p className="mt-5 text-lg sm:text-xl text-indigo-100 max-w-2xl mx-auto">
              Free to start. Live in 30 seconds. No credit card.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                href="/register"
                className="inline-flex items-center gap-2 rounded-xl bg-white text-indigo-700 px-6 py-3.5 text-base font-bold shadow-lg shadow-black/10 hover:bg-indigo-50"
              >
                Deploy free site
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </Link>
              <Link
                href="/docs"
                className="inline-flex items-center gap-2 rounded-xl border-2 border-white/30 text-white px-6 py-3.5 text-base font-semibold hover:bg-white/10"
              >
                Read the docs
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────── Footer ───────── */
function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <p className="text-base font-bold text-gray-900 dark:text-white">LiveInSec</p>
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Static hosting + Lead Inbox in one product.
            </p>
          </div>
          <FooterCol title="Product" links={[
            { href: '/register', label: 'Sign up' },
            { href: '/login', label: 'Log in' },
            { href: '/docs', label: 'Docs' },
            { href: '#pricing', label: 'Pricing' },
          ]} />
          <FooterCol title="Compare" links={[
            { href: '#how-it-works', label: 'How it works' },
            { href: '#pricing', label: 'vs Netlify' },
            { href: '#pricing', label: 'vs Tiiny.host' },
            { href: '#pricing', label: 'vs Formspree' },
          ]} />
          <FooterCol title="Company" links={[
            { href: '/docs', label: 'Documentation' },
            { href: '#', label: 'Status' },
            { href: 'mailto:hello@liveinsec.com', label: 'Contact' },
          ]} />
        </div>
        <div className="mt-10 pt-6 border-t border-gray-100 dark:border-gray-900 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-gray-400">
          <p>© {new Date().getFullYear()} LiveInSec. Built in India.</p>
          <p>Made for people who don't want to fight their hosting.</p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 mb-3">{title}</p>
      <ul className="space-y-2">
        {links.map((l) => (
          <li key={l.label}>
            <Link href={l.href} className="text-sm text-gray-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
