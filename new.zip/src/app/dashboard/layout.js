import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import Image from "next/image";
import Sidebar from "@/components/Sidebar";
import {
  getSidebarFeatures,
  getUserFeatureOverview,
} from "@/lib/feature-access";
import prisma from "@/lib/prisma";

export const metadata = {
  title: "Dashboard - LiveInSec",
};

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/login");
  }

  // If OAuth user hasn't completed onboarding, redirect to complete profile
  const dbUser = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: {
      provider: true,
      onboardingCompletedAt: true,
      countryName: true,
      name: true,
    },
  });

  if (
    dbUser &&
    dbUser.provider !== "credentials" &&
    !dbUser.onboardingCompletedAt
  ) {
    redirect("/complete-profile");
  }

  // Fetch sidebar features and user's feature access overview
  let sidebarFeatures = [];
  let featureAccess = {};
  try {
    sidebarFeatures = await getSidebarFeatures();
    featureAccess = await getUserFeatureOverview(session.user.id);
  } catch (err) {
    // Feature table may not exist yet if migration hasn't run
    console.error("Failed to load sidebar features:", err.message);
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-950 overflow-hidden transition-colors">
      <Sidebar
        sidebarFeatures={sidebarFeatures}
        featureAccess={featureAccess}
      />
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header - sticky */}
        <div className="lg:hidden bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2 pl-10">
            <div className="relative w-7 h-7 rounded-lg overflow-hidden bg-white dark:bg-gray-900">
              <Image
                src="/system/logo.png"
                alt="LiveInSec logo"
                fill
                sizes="28px"
                className="object-contain"
                priority
              />
            </div>
            <span className="font-bold text-gray-900 dark:text-white">
              LiveInSec
            </span>
          </div>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {session.user.name}
          </span>
        </div>

        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 bg-gray-50 dark:bg-gray-950">
          {children}
        </div>
      </main>
    </div>
  );
}
