export const dynamic = "force-dynamic";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import Link from "next/link";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

export const metadata = {
  title: "Dashboard — LiveInSec",
  description: "Manage your sites, leads, and feature subscriptions in one place.",
};

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  // Run everything in parallel for speed
  const [sitesData, totalSubmissions, sevenDayStats, unreadCount, recentSubmissions] = await Promise.all([
    prisma.site.findMany({
      where: { userId: workspaceOwnerId },
      include: { _count: { select: { formsubmission: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.formSubmission.count({ where: { site: { userId: workspaceOwnerId } } }),
    prisma.formSubmission.groupBy({
      by: ['createdAt'],
      where: {
        site: { userId: workspaceOwnerId },
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
      _count: true,
    }),
    prisma.formSubmission.count({
      where: { site: { userId: workspaceOwnerId }, isRead: false },
    }),
    prisma.formSubmission.findMany({
      where: { site: { userId: workspaceOwnerId } },
      include: { site: { select: { id: true, name: true, subdomain: true } } },
      orderBy: { createdAt: "desc" },
      take: 6,
    }),
  ]);

  const sites = sitesData;
  const activeSites = sites.filter((s) => s.isActive).length;
  const recentSubmissionsCount = sevenDayStats.reduce((sum, r) => sum + r._count, 0);

  // Weekly trend bars (7-day micro chart)
  const trend = computeWeeklyTrend(sevenDayStats);

  const firstName = (session.user.name || '').split(' ')[0] || 'there';
  const greeting = getTimeGreeting();

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 dark:from-indigo-700 dark:via-violet-800 dark:to-fuchsia-800 p-8 sm:p-10 text-white shadow-xl shadow-indigo-500/10">
        <div className="absolute inset-0 opacity-20" aria-hidden>
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white/20 blur-3xl translate-x-1/3 -translate-y-1/3"></div>
          <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full bg-fuchsia-300/30 blur-3xl -translate-x-1/4 translate-y-1/4"></div>
        </div>

        <div className="relative">
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
            <div>
              <p className="text-sm font-medium text-indigo-100 uppercase tracking-wider">{greeting}</p>
              <h1 className="mt-1 text-3xl sm:text-4xl font-bold tracking-tight">
                Welcome back, {firstName}
              </h1>
              <p className="mt-2 text-indigo-100 max-w-xl text-base">
                {sites.length === 0
                  ? "Let's get your first website live. It only takes 30 seconds."
                  : `Your sites collected ${recentSubmissionsCount} new lead${recentSubmissionsCount === 1 ? '' : 's'} this week.`}
              </p>
            </div>
            {hasPermission(workspace, "create_sites") && (
              <Link
                href="/dashboard/sites/new"
                className="inline-flex items-center gap-2 self-start sm:self-end rounded-xl bg-white text-indigo-700 px-5 py-3 text-sm font-semibold hover:bg-indigo-50 transition-all shadow-lg shadow-black/10"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                </svg>
                Deploy a new site
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Onboarding checklist */}
      {sites.length <= 1 && (
        <OnboardingChecklist
          hasSite={sites.length > 0}
          hasSubmission={totalSubmissions > 0}
          emailVerified={!!session.user.emailVerifiedAt}
          firstSite={sites[0]}
        />
      )}

      {/* Stats grid */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          label="Active sites"
          value={activeSites}
          suffix={sites.length > activeSites ? `of ${sites.length}` : null}
          icon="🌐"
          accent="indigo"
        />
        <StatCard
          label="Total leads"
          value={totalSubmissions}
          suffix={null}
          icon="📬"
          accent="violet"
        />
        <StatCard
          label="Last 7 days"
          value={recentSubmissionsCount}
          suffix="leads"
          icon="📈"
          accent="fuchsia"
          trend={trend}
        />
        <StatCard
          label="Unread"
          value={unreadCount}
          suffix={unreadCount > 0 ? "to review" : "you're all caught up"}
          icon="✨"
          accent="emerald"
          highlight={unreadCount > 0}
          href={unreadCount > 0 ? "/dashboard/submissions" : null}
        />
      </section>

      {/* Two-column layout: sites + recent activity */}
      <section className="grid lg:grid-cols-3 gap-6">
        {/* Sites list */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Your sites</h2>
              <p className="text-xs text-gray-500 dark:text-gray-400">{sites.length} site{sites.length === 1 ? '' : 's'} deployed</p>
            </div>
            {sites.length > 0 && (
              <Link href="/dashboard/sites" className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                View all →
              </Link>
            )}
          </div>

          {sites.length === 0 ? (
            <DeployFirstSite />
          ) : (
            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              {sites.slice(0, 5).map((site) => (
                <Link
                  key={site.id}
                  href={`/dashboard/sites/${site.id}`}
                  className="flex items-center gap-4 px-6 py-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/40 dark:to-violet-900/40 flex items-center justify-center text-lg flex-shrink-0">
                    {site.isActive ? '🟢' : '⚪'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                      {site.name}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                      {site.subdomain}.liveinsec.com
                      {site.customDomain && ` · ${site.customDomain}`}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">{site._count.formsubmission}</p>
                    <p className="text-xs text-gray-500">leads</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Recent leads */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent leads</h2>
            {recentSubmissions.length > 0 && (
              <Link href="/dashboard/submissions" className="text-sm font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                Inbox →
              </Link>
            )}
          </div>
          {recentSubmissions.length === 0 ? (
            <div className="px-6 py-10 text-center">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-100 to-indigo-100 dark:from-violet-900/40 dark:to-indigo-900/40 flex items-center justify-center text-2xl mb-3">
                📭
              </div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">No leads yet</p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Add a contact form to your site to start collecting.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100 dark:divide-gray-800">
              {recentSubmissions.slice(0, 5).map((sub) => {
                let data = {};
                try { data = JSON.parse(sub.data); } catch {}
                const preview = data.email || data.name || Object.values(data)[0] || '—';
                return (
                  <Link
                    key={sub.id}
                    href={`/dashboard/sites/${sub.site.id}/submissions`}
                    className="block px-6 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      {!sub.isRead && (
                        <span className="w-2 h-2 rounded-full bg-indigo-500 flex-shrink-0" title="Unread"></span>
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900 dark:text-white truncate font-medium">{String(preview).slice(0, 40)}</p>
                        <p className="text-xs text-gray-500 truncate">{sub.site.name}</p>
                      </div>
                      <span className="text-xs text-gray-400 flex-shrink-0">
                        {timeAgo(sub.createdAt)}
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

// ─── Helper components ────────────────────────────────────────

function StatCard({ label, value, suffix, icon, accent = 'indigo', trend, highlight, href }) {
  const accents = {
    indigo:   'from-indigo-500/10 to-indigo-500/5 border-indigo-100 dark:border-indigo-900/40',
    violet:   'from-violet-500/10 to-violet-500/5 border-violet-100 dark:border-violet-900/40',
    fuchsia:  'from-fuchsia-500/10 to-fuchsia-500/5 border-fuchsia-100 dark:border-fuchsia-900/40',
    emerald:  'from-emerald-500/10 to-emerald-500/5 border-emerald-100 dark:border-emerald-900/40',
  };
  const inner = (
    <div className={`relative bg-gradient-to-br ${accents[accent]} bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 ${highlight ? 'ring-2 ring-emerald-400/40 ring-offset-2 ring-offset-gray-50 dark:ring-offset-gray-950' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <p className="text-xs uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400">{label}</p>
        <span className="text-2xl">{icon}</span>
      </div>
      <p className="text-3xl font-bold text-gray-900 dark:text-white">{value}</p>
      {suffix && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{suffix}</p>}
      {trend && trend.length > 0 && (
        <div className="mt-3 flex items-end gap-0.5 h-8">
          {trend.map((v, i) => (
            <div
              key={i}
              className={`flex-1 rounded-sm bg-${accent}-500/40 dark:bg-${accent}-400/40`}
              style={{ height: `${Math.max(8, (v / Math.max(1, ...trend)) * 100)}%` }}
            />
          ))}
        </div>
      )}
    </div>
  );
  return href ? <Link href={href}>{inner}</Link> : inner;
}

// Empty-state for users with 0 sites. Leads with what makes LiveInSec
// different (built-in form API + lead inbox), not just generic "deploy a site"
// — that helps new visitors realize the value prop before clicking Deploy.
function DeployFirstSite() {
  return (
    <div className="px-6 py-10 bg-gradient-to-br from-indigo-50/50 via-violet-50/30 to-fuchsia-50/30 dark:from-indigo-950/20 dark:via-violet-950/20 dark:to-fuchsia-950/20">
      <div className="text-center max-w-2xl mx-auto">
        <div className="mx-auto w-16 h-16 bg-white dark:bg-gray-900 rounded-2xl shadow-md flex items-center justify-center mb-4 text-3xl">
          📬
        </div>
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
          Launch a site that catches leads, not just visitors.
        </h3>
        <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
          Every site you deploy on LiveInSec comes with a built-in form API and a Lead Inbox — so your contact form actually does something. No backend, no Formspree subscription. Free for the first 100 leads/month.
        </p>
        <Link
          href="/dashboard/sites/new"
          className="mt-5 inline-flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-indigo-700 shadow-lg shadow-indigo-500/20"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" /></svg>
          Deploy your first site
        </Link>
      </div>

      {/* Three quick benefits */}
      <div className="mt-8 grid sm:grid-cols-3 gap-3 max-w-3xl mx-auto">
        <div className="rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-4">
          <div className="text-xl mb-1.5">⚡</div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">Live in 30 seconds</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Drop a ZIP, write in editor, or pick a template.</p>
        </div>
        <div className="rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-4">
          <div className="text-xl mb-1.5">📬</div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">Forms that just work</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Drop our endpoint into any HTML form. Done.</p>
        </div>
        <div className="rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-4">
          <div className="text-xl mb-1.5">🇮🇳</div>
          <p className="text-sm font-semibold text-gray-900 dark:text-white">Pay in INR or USD</p>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Razorpay + UPI for India, Stripe everywhere else.</p>
        </div>
      </div>
    </div>
  );
}

function OnboardingChecklist({ hasSite, hasSubmission, emailVerified, firstSite }) {
  const steps = [
    {
      done: emailVerified,
      label: "Verify your email address",
      hint: "We'll send a quick confirmation link.",
      href: "/dashboard/settings",
    },
    {
      done: hasSite,
      label: "Deploy your first website",
      hint: "Upload a ZIP, build in browser, or start from a template.",
      href: "/dashboard/sites/new",
    },
    {
      done: hasSubmission,
      label: "Connect a contact form",
      hint: firstSite ? "Open your site and use \"Send test submission\"." : "Deploy a site first.",
      href: firstSite ? `/dashboard/sites/${firstSite.id}` : null,
    },
  ];
  const completed = steps.filter((s) => s.done).length;
  const allDone = completed === steps.length;
  if (allDone) return null;

  return (
    <section className="rounded-2xl border border-indigo-100 dark:border-indigo-900/40 bg-gradient-to-br from-white to-indigo-50/30 dark:from-gray-900 dark:to-indigo-950/20 p-6">
      <div className="flex items-start justify-between mb-5">
        <div>
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">Get set up in 3 steps</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Complete these to start collecting leads.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{completed}/{steps.length}</span>
        </div>
      </div>
      <div className="grid sm:grid-cols-3 gap-4">
        {steps.map((step, idx) => (
          <Link
            key={idx}
            href={step.href || '#'}
            className={`relative rounded-xl border p-4 transition-all ${
              step.done
                ? 'border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/40 dark:bg-emerald-950/20'
                : 'border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900/50 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md'
            } ${!step.href ? 'cursor-default pointer-events-none' : ''}`}
          >
            <div className="flex items-center gap-3 mb-2">
              <div
                className={`flex h-7 w-7 items-center justify-center rounded-full font-bold text-xs ${
                  step.done
                    ? 'bg-emerald-500 text-white'
                    : 'bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300'
                }`}
              >
                {step.done ? '✓' : idx + 1}
              </div>
              <p className={`text-sm font-semibold ${step.done ? 'text-gray-500 dark:text-gray-500 line-through' : 'text-gray-900 dark:text-white'}`}>
                {step.label}
              </p>
            </div>
            {!step.done && <p className="text-xs text-gray-500 dark:text-gray-400">{step.hint}</p>}
          </Link>
        ))}
      </div>
      <div className="mt-5 h-1.5 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-fuchsia-500 transition-all duration-700"
          style={{ width: `${(completed / steps.length) * 100}%` }}
        />
      </div>
    </section>
  );
}

// ─── Helpers ──────────────────────────────────────────────────

function getTimeGreeting() {
  const h = new Date().getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

function timeAgo(date) {
  const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function computeWeeklyTrend(groupedRows) {
  // Bucket by day-of-week (last 7 days, oldest → newest)
  const days = Array.from({ length: 7 }, () => 0);
  const now = Date.now();
  for (const row of groupedRows || []) {
    const ms = new Date(row.createdAt).getTime();
    const dayDelta = Math.floor((now - ms) / (24 * 60 * 60 * 1000));
    if (dayDelta >= 0 && dayDelta < 7) {
      days[6 - dayDelta] += row._count;
    }
  }
  return days;
}
