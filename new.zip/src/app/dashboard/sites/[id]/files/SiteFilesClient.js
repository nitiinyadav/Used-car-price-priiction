'use client';

import {
  startTransition,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import dynamic from 'next/dynamic';
import {
  formatFileSize,
  isEditablePath,
  isEditorSizeSupported,
  isLargeEditorFile,
} from '@/lib/file-editor';

const MonacoEditor = dynamic(() => import('@/components/MonacoEditor'), {
  ssr: false,
  loading: () => (
    <div className="flex flex-1 items-center justify-center bg-gray-900 text-sm text-gray-500">
      Loading editor...
    </div>
  ),
});

const EXT_COLORS = {
  html: 'text-orange-400',
  css: 'text-blue-400',
  js: 'text-yellow-400',
  json: 'text-green-400',
  md: 'text-gray-300',
  svg: 'text-pink-400',
  txt: 'text-gray-400',
  ts: 'text-blue-300',
  tsx: 'text-cyan-300',
  jsx: 'text-yellow-300',
  py: 'text-emerald-300',
  sql: 'text-purple-300',
  yaml: 'text-amber-300',
  yml: 'text-amber-300',
  xml: 'text-rose-300',
};

const EXT_ICONS = {
  html: '</>',
  css: '{}',
  js: '()',
  json: '{}',
  md: '::',
  svg: '<>',
  txt: '--',
  ts: 'TS',
  tsx: 'TX',
  jsx: 'JX',
  py: 'PY',
  sql: 'DB',
  yaml: 'YM',
  yml: 'YM',
  xml: 'XM',
};

const AUTO_SAVE_DELAY = 2000;

function getExt(filePath) {
  return (filePath.split('.').pop() || '').toLowerCase();
}

export default function SiteFilesClient({ site }) {
  const [files, setFiles] = useState([]);
  const [selectedPath, setSelectedPath] = useState('');
  const [content, setContent] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadingContent, setLoadingContent] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newFilePath, setNewFilePath] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [openTabs, setOpenTabs] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [forceMonaco, setForceMonaco] = useState(false);

  const autoSaveTimer = useRef(null);
  const statusTimer = useRef(null);
  const listAbortRef = useRef(null);
  const contentAbortRef = useRef(null);
  const contentRequestIdRef = useRef(0);
  const fileMapRef = useRef(new Map());
  const encoderRef = useRef(null);
  const contentRef = useRef(content);
  const originalRef = useRef(originalContent);
  const selectedRef = useRef(selectedPath);
  const savingRef = useRef(false);

  contentRef.current = content;
  originalRef.current = originalContent;
  selectedRef.current = selectedPath;

  useEffect(() => {
    fileMapRef.current = new Map(files.map((file) => [file.path, file]));
  }, [files]);

  const selectedFile = useMemo(
    () => files.find((file) => file.path === selectedPath) || null,
    [files, selectedPath]
  );
  const selectedFileSize = selectedFile?.size || 0;
  const isEditable = isEditablePath(selectedPath);
  const isFileTooLarge = selectedFile ? !isEditorSizeSupported(selectedFile.size) : false;
  const isLargeFile = selectedFile ? isLargeEditorFile(selectedFile.size) : false;
  const isModified = isEditable && !isFileTooLarge && content !== originalContent;
  const totalSize = useMemo(
    () => files.reduce((accumulator, file) => accumulator + (file.size || 0), 0),
    [files]
  );
  const storageMB = (totalSize / (1024 * 1024)).toFixed(2);

  const showTransientStatus = useCallback((message) => {
    if (statusTimer.current) {
      clearTimeout(statusTimer.current);
    }

    setStatus(message);
    statusTimer.current = setTimeout(() => setStatus(''), 2000);
  }, []);

  const toggleSidebar = useCallback(() => {
    setSidebarOpen((prev) => {
      const next = !prev;
      try { localStorage.setItem('filesEditorSidebar', String(next)); } catch {}
      return next;
    });
  }, []);

  const getContentSize = useCallback((nextContent = '') => {
    if (!encoderRef.current && typeof TextEncoder !== 'undefined') {
      encoderRef.current = new TextEncoder();
    }

    if (!encoderRef.current) {
      return String(nextContent).length;
    }

    return encoderRef.current.encode(String(nextContent)).length;
  }, []);

  const syncFileSize = useCallback(
    (filePath, nextContent) => {
      const nextSize = getContentSize(nextContent);

      setFiles((previousFiles) =>
        previousFiles.map((file) =>
          file.path === filePath ? { ...file, size: nextSize } : file
        )
      );
    },
    [getContentSize]
  );

  const loadFiles = useCallback(async () => {
    if (listAbortRef.current) {
      listAbortRef.current.abort();
    }

    const controller = new AbortController();
    listAbortRef.current = controller;

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/sites/${site.id}/files`, {
        cache: 'no-store',
        signal: controller.signal,
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setError(data.error || 'Failed to load files.');
        return;
      }

      const nextFiles = Array.isArray(data.files)
        ? [...data.files].sort((left, right) => left.path.localeCompare(right.path))
        : [];

      setFiles(nextFiles);
      setOpenTabs((previousTabs) =>
        previousTabs.filter((tab) => nextFiles.some((file) => file.path === tab))
      );
      setSelectedPath((previousPath) => {
        if (!nextFiles.length) {
          return '';
        }

        if (previousPath && nextFiles.some((file) => file.path === previousPath)) {
          return previousPath;
        }

        const firstEditableFile = nextFiles.find((file) => isEditablePath(file.path));
        return firstEditableFile?.path || nextFiles[0].path;
      });
    } catch (loadError) {
      if (loadError.name !== 'AbortError') {
        setError('Failed to load files.');
      }
    } finally {
      if (listAbortRef.current === controller) {
        setLoading(false);
      }
    }
  }, [site.id]);

  const loadContent = useCallback(
    async (filePath) => {
      if (!filePath || !isEditablePath(filePath)) {
        startTransition(() => {
          setContent('');
          setOriginalContent('');
        });
        setLoadingContent(false);
        return;
      }

      const currentFile = fileMapRef.current.get(filePath);
      if (currentFile && !isEditorSizeSupported(currentFile.size)) {
        startTransition(() => {
          setContent('');
          setOriginalContent('');
        });
        setLoadingContent(false);
        setError(
          `This file is ${formatFileSize(currentFile.size)} and is too large to open safely in the browser editor.`
        );
        return;
      }

      if (contentAbortRef.current) {
        contentAbortRef.current.abort();
      }

      const controller = new AbortController();
      const requestId = contentRequestIdRef.current + 1;

      contentAbortRef.current = controller;
      contentRequestIdRef.current = requestId;

      setError('');

      try {
        const response = await fetch(
          `/api/sites/${site.id}/files?path=${encodeURIComponent(filePath)}`,
          {
            cache: 'no-store',
            signal: controller.signal,
          }
        );
        const data = await response.json().catch(() => ({}));

        if (
          controller.signal.aborted ||
          contentRequestIdRef.current !== requestId
        ) {
          return;
        }

        if (!response.ok) {
          startTransition(() => {
            setContent('');
            setOriginalContent('');
          });
          setError(data.error || 'Failed to load file.');
          return;
        }

        const nextContent = typeof data.content === 'string' ? data.content : '';

        startTransition(() => {
          setContent(nextContent);
          setOriginalContent(nextContent);
        });
      } catch (loadError) {
        if (loadError.name !== 'AbortError') {
          startTransition(() => {
            setContent('');
            setOriginalContent('');
          });
          setError('Failed to load file.');
        }
      } finally {
        if (
          contentAbortRef.current === controller &&
          contentRequestIdRef.current === requestId
        ) {
          setLoadingContent(false);
        }
      }
    },
    [site.id]
  );

  const saveFile = useCallback(async () => {
    if (!selectedRef.current || isFileTooLarge) return;

    setSaving(true);
    savingRef.current = true;
    setError('');

    try {
      const response = await fetch(`/api/sites/${site.id}/files`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filePath: selectedRef.current,
          content: contentRef.current,
        }),
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setError(data.error || 'Failed to save.');
        return;
      }

      setOriginalContent(contentRef.current);
      syncFileSize(selectedRef.current, contentRef.current);
      showTransientStatus('Saved');
    } catch {
      setError('Failed to save.');
    } finally {
      setSaving(false);
      savingRef.current = false;
    }
  }, [isFileTooLarge, showTransientStatus, site.id, syncFileSize]);

  const doAutoSave = useCallback(async () => {
    const filePath = selectedRef.current;
    const nextContent = contentRef.current;
    const previousContent = originalRef.current;

    if (
      !filePath ||
      nextContent === previousContent ||
      savingRef.current ||
      !isEditablePath(filePath)
    ) {
      return;
    }

    savingRef.current = true;

    try {
      const response = await fetch(`/api/sites/${site.id}/files`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath, content: nextContent }),
      });

      if (!response.ok) {
        return;
      }

      setOriginalContent(nextContent);
      syncFileSize(filePath, nextContent);
      showTransientStatus('Auto-saved');
    } catch {
      // Keep auto-save silent to avoid noisy failures while typing.
    } finally {
      savingRef.current = false;
    }
  }, [showTransientStatus, site.id, syncFileSize]);

  // Read sidebar preference from localStorage after mount.
  // Default: open on desktop, closed on mobile.
  useEffect(() => {
    try {
      const saved = localStorage.getItem('filesEditorSidebar');
      if (saved !== null) {
        setSidebarOpen(saved === 'true');
      } else {
        setSidebarOpen(window.matchMedia('(min-width: 1024px)').matches);
      }
    } catch {
      setSidebarOpen(false);
    }
  }, []);

  // Clear stale content BEFORE the browser paints when the selected file changes.
  // Without this, the previous file's content flashes in the editor for one frame.
  useLayoutEffect(() => {
    setContent('');
    setOriginalContent('');
    setLoadingContent(selectedPath ? isEditablePath(selectedPath) : false);
  }, [selectedPath]);

  useEffect(() => {
    loadFiles();

    return () => {
      if (listAbortRef.current) {
        listAbortRef.current.abort();
      }

      if (contentAbortRef.current) {
        contentAbortRef.current.abort();
      }

      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }

      if (statusTimer.current) {
        clearTimeout(statusTimer.current);
      }
    };
  }, [loadFiles]);

  useEffect(() => {
    if (!selectedPath) {
      setConfirmDelete(false);
      return;
    }

    setOpenTabs((previousTabs) =>
      previousTabs.includes(selectedPath)
        ? previousTabs
        : [...previousTabs, selectedPath]
    );
    setConfirmDelete(false);
    setForceMonaco(false);

    // Auto-close the mobile drawer when a file is selected.
    // Desktop sidebar stays open (user controls it with the toggle button).
    try {
      if (!window.matchMedia('(min-width: 1024px)').matches) {
        setSidebarOpen(false);
      }
    } catch {}

    loadContent(selectedPath);
  }, [loadContent, selectedPath]);

  useEffect(() => {
    if (!isModified) {
      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }
      return;
    }

    if (autoSaveTimer.current) {
      clearTimeout(autoSaveTimer.current);
    }

    autoSaveTimer.current = setTimeout(doAutoSave, AUTO_SAVE_DELAY);

    return () => {
      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }
    };
  }, [content, doAutoSave, isModified, originalContent]);

  // Cmd/Ctrl+S → save, Esc → exit fullscreen, F11 → toggle fullscreen.
  // Lock body scroll while fullscreen so the editor truly fills the viewport.
  useEffect(() => {
    function handleKey(event) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
        event.preventDefault();
        if (isModified && !saving) saveFile();
        return;
      }
      if (event.key === 'Escape' && isFullscreen) {
        event.preventDefault();
        setIsFullscreen(false);
        return;
      }
      if (event.key === 'F11') {
        event.preventDefault();
        setIsFullscreen((current) => !current);
      }
    }

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isFullscreen, isModified, saveFile, saving]);

  useEffect(() => {
    if (typeof document === 'undefined') return undefined;
    const previousOverflow = document.body.style.overflow;
    if (isFullscreen) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isFullscreen]);

  async function createFile() {
    const trimmedPath = newFilePath.trim();
    if (!trimmedPath) return;

    setError('');

    try {
      const response = await fetch(`/api/sites/${site.id}/files`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: trimmedPath, content: '' }),
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setError(data.error || 'Failed to create file.');
        return;
      }

      setNewFilePath('');
      setShowNewFile(false);
      setSelectedPath(trimmedPath);
      await loadFiles();
    } catch {
      setError('Failed to create file.');
    }
  }

  async function deleteFile() {
    if (!selectedPath) return;

    setError('');

    try {
      const response = await fetch(`/api/sites/${site.id}/files`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedPath }),
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setError(data.error || 'Failed to delete.');
        return;
      }

      closeTab(selectedPath);
      setConfirmDelete(false);
      await loadFiles();
    } catch {
      setError('Failed to delete.');
    }
  }

  async function handleUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`/api/sites/${site.id}/files`, {
        method: 'POST',
        body: formData,
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        setError(data.error || 'Failed to upload.');
        return;
      }

      await loadFiles();
    } catch {
      setError('Failed to upload.');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  }

  function closeTab(path) {
    setOpenTabs((previousTabs) => {
      const remainingTabs = previousTabs.filter((tab) => tab !== path);

      if (selectedRef.current === path) {
        setSelectedPath(remainingTabs[remainingTabs.length - 1] || '');
      }

      return remainingTabs;
    });
  }

  return (
    <div
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 flex flex-col overflow-hidden bg-gray-900'
          : 'overflow-hidden rounded-2xl border border-gray-700 bg-gray-900'
      }
      style={
        isFullscreen
          ? undefined
          : { height: 'calc(100vh - 220px)', minHeight: '500px' }
      }
    >
      <div className="flex items-center justify-between border-b border-gray-700 bg-gray-800 px-3 py-2 sm:px-4">
        <div className="flex min-w-0 items-center gap-2">
          <button
            type="button"
            onClick={toggleSidebar}
            className="mr-1 -ml-1 rounded p-1 text-gray-400 hover:bg-gray-700/60 hover:text-white"
            aria-label={sidebarOpen ? 'Hide explorer' : 'Show explorer'}
            title={sidebarOpen ? 'Hide explorer' : 'Show explorer'}
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="hidden gap-1.5 sm:flex">
            <div className="h-3 w-3 rounded-full bg-red-500" />
            <div className="h-3 w-3 rounded-full bg-yellow-500" />
            <div className="h-3 w-3 rounded-full bg-green-500" />
          </div>
          <span className="ml-1 truncate font-mono text-xs text-gray-400 sm:ml-3">
            {site.name} - File Editor
          </span>
        </div>
        <div className="flex flex-shrink-0 items-center gap-1 sm:gap-3">
          {error && <span className="hidden text-xs text-red-400 sm:inline">{error}</span>}
          {status && <span className="hidden text-xs text-emerald-400 sm:inline">{status}</span>}
          <label className="hidden cursor-pointer items-center gap-1 rounded p-1.5 text-xs text-gray-400 hover:bg-gray-700/60 hover:text-white sm:flex">
            <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            <span>{uploading ? 'Uploading...' : 'Upload'}</span>
            <input type="file" className="hidden" onChange={handleUpload} />
          </label>
          <label className="flex cursor-pointer items-center gap-1 rounded p-1.5 text-xs text-gray-400 hover:bg-gray-700/60 hover:text-white sm:hidden" aria-label={uploading ? 'Uploading' : 'Upload file'}>
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            <input type="file" className="hidden" onChange={handleUpload} />
          </label>
          <button
            type="button"
            onClick={() => setIsFullscreen((current) => !current)}
            className="rounded p-1.5 text-gray-400 hover:bg-gray-700/60 hover:text-white"
            aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
            title={isFullscreen ? 'Exit fullscreen (Esc)' : 'Fullscreen (F11)'}
          >
            {isFullscreen ? (
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9V5a1 1 0 00-1-1H4m16 0h-4a1 1 0 00-1 1v4m0 6v4a1 1 0 001 1h4M4 20h4a1 1 0 001-1v-4" />
              </svg>
            ) : (
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-5h-4m4 0v4m0-4l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
            )}
          </button>
        </div>
      </div>

      <div
        className="relative flex min-h-0 flex-1"
        style={isFullscreen ? undefined : { height: 'calc(100% - 64px)' }}
      >
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <div
          className={`border-r border-gray-700 bg-gray-800 ${
            sidebarOpen
              ? 'flex flex-col flex-shrink-0 fixed inset-y-0 left-0 z-30 w-64 shadow-2xl lg:relative lg:inset-auto lg:z-auto lg:w-56 lg:shadow-none'
              : 'hidden'
          }`}
        >
          <div className="flex items-center justify-between px-3 py-2 text-xs font-semibold uppercase tracking-wider text-gray-400">
            <span>Explorer</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowNewFile(true)}
                className="text-gray-400 hover:text-white"
                title="New file"
              >
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </button>
              <button
                type="button"
                onClick={toggleSidebar}
                className="text-gray-400 hover:text-white"
                title="Hide explorer"
              >
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {showNewFile && (
            <div className="px-2 pb-2">
              <input
                autoFocus
                value={newFilePath}
                onChange={(event) => setNewFilePath(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter') createFile();
                  if (event.key === 'Escape') {
                    setShowNewFile(false);
                    setNewFilePath('');
                  }
                }}
                onBlur={() => {
                  if (!newFilePath.trim()) {
                    setShowNewFile(false);
                  }
                }}
                className="w-full rounded border border-gray-600 bg-gray-700 px-2 py-1 text-xs text-white focus:border-indigo-500 focus:outline-none"
                placeholder="filename.html"
              />
            </div>
          )}

          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <p className="px-3 py-2 text-xs text-gray-500">Loading...</p>
            ) : files.length === 0 ? (
              <p className="px-3 py-2 text-xs text-gray-500">No files yet</p>
            ) : (
              files.map((file) => {
                const extension = getExt(file.path);
                const isActive = selectedPath === file.path;
                const tooLargeToEdit =
                  isEditablePath(file.path) && !isEditorSizeSupported(file.size);

                return (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => setSelectedPath(file.path)}
                    className={`group flex w-full items-center justify-between px-3 py-1.5 text-left text-xs ${
                      isActive
                        ? 'bg-gray-700/80 text-white'
                        : 'text-gray-400 hover:bg-gray-700/40 hover:text-white'
                    }`}
                    title={tooLargeToEdit ? 'Too large to edit in browser' : file.path}
                  >
                    <div className="flex min-w-0 items-center gap-2 truncate">
                      <span className={EXT_COLORS[extension] || 'text-gray-400'}>
                        {EXT_ICONS[extension] || '--'}
                      </span>
                      <span className="truncate">{file.path}</span>
                    </div>
                    <span className="ml-2 flex-shrink-0 text-[10px] text-gray-600">
                      {formatFileSize(file.size)}
                    </span>
                  </button>
                );
              })
            )}
          </div>

          <div className="border-t border-gray-700 px-3 py-2">
            <div className="mb-1 flex items-center justify-between text-[10px] text-gray-500">
              <span>Storage</span>
              <span>{storageMB} MB</span>
            </div>
            <div className="h-1 overflow-hidden rounded-full bg-gray-700">
              <div
                className="h-full rounded-full bg-indigo-500"
                style={{ width: `${Math.min((totalSize / (10 * 1024 * 1024)) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex flex-shrink-0 overflow-x-auto border-b border-gray-700 bg-gray-800">
            {openTabs.map((tab) => (
              <div
                key={tab}
                role="button"
                tabIndex={0}
                className={`group flex cursor-pointer items-center gap-1 border-r border-gray-700 px-3 py-2 font-mono text-xs ${
                  selectedPath === tab
                    ? 'border-b-2 border-b-indigo-500 bg-gray-900 text-white'
                    : 'text-gray-400 hover:text-white'
                }`}
                onClick={() => setSelectedPath(tab)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    setSelectedPath(tab);
                  }
                }}
              >
                <span className={EXT_COLORS[getExt(tab)] || 'text-gray-400'}>
                  {EXT_ICONS[getExt(tab)] || '--'}
                </span>
                <span className="max-w-[120px] truncate">{tab}</span>
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    closeTab(tab);
                  }}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter' || event.key === ' ') {
                      event.preventDefault();
                      event.stopPropagation();
                      closeTab(tab);
                    }
                  }}
                  className="ml-1 opacity-0 group-hover:opacity-100 hover:text-red-400"
                  aria-label={`Close ${tab}`}
                >
                  x
                </button>
              </div>
            ))}
          </div>

          {!selectedPath ? (
            <div className="flex flex-1 items-center justify-center text-gray-600">
              <div className="text-center">
                <svg className="mx-auto mb-4 h-16 w-16 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                </svg>
                <p className="text-sm">Select a file to edit</p>
                <p className="mt-1 text-xs text-gray-700">or create a new one from the explorer</p>
              </div>
            </div>
          ) : !isEditable ? (
            <div className="flex flex-1 items-center justify-center text-gray-500">
              <div className="text-center">
                <svg className="mx-auto mb-3 h-12 w-12 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="text-sm font-medium">{selectedPath}</p>
                <p className="mt-1 text-xs text-gray-600">Binary file - not editable in browser</p>
              </div>
            </div>
          ) : isFileTooLarge ? (
            <div className="flex flex-1 items-center justify-center px-6 text-gray-400">
              <div className="max-w-md text-center">
                <svg className="mx-auto mb-3 h-12 w-12 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 9v4m0 4h.01M5.07 19h13.86c1.54 0 2.5-1.67 1.73-3L13.73 4c-.77-1.33-2.69-1.33-3.46 0L3.34 16c-.77 1.33.19 3 1.73 3z" />
                </svg>
                <p className="text-sm font-medium text-white">{selectedPath}</p>
                <p className="mt-2 text-sm text-gray-400">
                  This file is {formatFileSize(selectedFileSize)} and exceeds the in-browser editing limit.
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Keeping this guard avoids freezing the page and protects the editor under heavy usage.
                </p>
              </div>
            </div>
          ) : loadingContent ? (
            <div className="flex flex-1 items-center justify-center bg-gray-900 text-sm text-gray-500">
              Loading file...
            </div>
          ) : (
            <div className="flex min-h-0 flex-1 flex-col">
              {isLargeFile && (
                <div className="flex flex-shrink-0 items-center justify-between border-b border-amber-500/20 bg-amber-500/10 px-4 py-2 text-xs text-amber-200">
                  <span>Large file ({formatFileSize(selectedFileSize)}) — lightweight editor active. No syntax highlighting.</span>
                  {forceMonaco ? (
                    <span className="ml-3 flex-shrink-0 text-amber-300/60">Monaco active</span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setForceMonaco(true)}
                      className="ml-3 flex-shrink-0 rounded px-2 py-0.5 text-amber-300 hover:bg-amber-500/20 hover:text-amber-100"
                    >
                      Load Monaco (may be slow)
                    </button>
                  )}
                </div>
              )}
              {isLargeFile && !forceMonaco ? (
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-0 flex-1 resize-none bg-gray-900 p-4 font-mono text-sm leading-5 text-gray-100 focus:outline-none"
                  spellCheck={false}
                  autoComplete="off"
                  autoCorrect="off"
                  autoCapitalize="off"
                />
              ) : (
                <MonacoEditor
                  value={content}
                  onChange={setContent}
                  filePath={selectedPath}
                  fileSize={selectedFileSize}
                  className="flex-1"
                />
              )}
            </div>
          )}

          <div className="flex flex-shrink-0 items-center justify-between bg-indigo-600 px-2 py-1 text-xs text-white sm:px-4">
            <div className="flex min-w-0 items-center gap-2 sm:gap-4">
              {selectedPath && (
                <>
                  <span className="max-w-[100px] truncate sm:max-w-none">{selectedPath}</span>
                  {selectedFile && <span className="hidden text-indigo-100 sm:inline">{formatFileSize(selectedFile.size)}</span>}
                  {isModified && (
                    <span className="flex flex-shrink-0 items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-amber-300" />
                      <span className="hidden sm:inline">Modified</span>
                    </span>
                  )}
                </>
              )}
            </div>
            <div className="flex flex-shrink-0 items-center gap-2 sm:gap-4">
              <span className="hidden sm:inline">{files.length} files</span>
              {selectedPath && <span className="font-mono">{getExt(selectedPath).toUpperCase() || 'TXT'}</span>}
              <div className="flex items-center gap-2">
                {isEditable && !isFileTooLarge && (
                  <button
                    type="button"
                    onClick={saveFile}
                    disabled={saving || !isModified || loadingContent}
                    className="flex items-center gap-1 hover:text-indigo-200 disabled:opacity-50"
                  >
                    <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                    </svg>
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                )}
                {selectedPath && !confirmDelete && (
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(true)}
                    className="flex items-center gap-1 hover:text-red-300"
                  >
                    <svg className="h-3.5 w-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Delete
                  </button>
                )}
                {confirmDelete && (
                  <>
                    <span className="text-red-300">Delete?</span>
                    <button type="button" onClick={deleteFile} className="font-medium text-red-300 hover:text-red-100">
                      Yes
                    </button>
                    <button type="button" onClick={() => setConfirmDelete(false)} className="hover:text-indigo-200">
                      No
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
