import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SubmissionsTable from '@/components/SubmissionsTable';
import SiteTabs from '@/components/SiteTabs';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { getUserFeatureQuota } from '@/lib/feature-access';

export async function generateMetadata({ params }) {
  return { title: 'Lead Inbox - LiveInSec' };
}

const ALLOWED_STATUS = ['new', 'read', 'contacted', 'won', 'lost', 'spam'];

function rangeForPreset(preset) {
  const now = new Date();
  if (preset === '24h') return { gte: new Date(now.getTime() - 24 * 60 * 60 * 1000) };
  if (preset === '7d') return { gte: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000) };
  if (preset === '30d') return { gte: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000) };
  return null;
}

export default async function SubmissionsPage({ params, searchParams }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const { id } = params;
  if (!hasPermission(workspace, 'view_submissions')) {
    notFound();
  }

  // Check feature-based access. Always fetch quota (even for superadmin) so the
  // upsell banner shows consistently when the inbox view loads.
  let hasSubmissionAccess = session.user.role === 'superadmin';
  let quotaInfo = null;
  let systemError = false;
  try {
    const quota = await getUserFeatureQuota(session.user.id, 'submissions');
    if (!hasSubmissionAccess) hasSubmissionAccess = quota.hasAccess;
    quotaInfo = quota;
  } catch (err) {
    console.error('Feature quota check failed:', err.message);
    if (!hasSubmissionAccess) systemError = true;
  }

  const site = await prisma.site.findFirst({
    where: { id, userId: workspace?.workspaceOwnerId || session.user.id },
  });

  if (!site) {
    notFound();
  }

  if (systemError) {
    return (
      <div className="p-6">
        <div className="rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/30 p-8 text-center">
          <p className="text-lg font-semibold text-amber-800 dark:text-amber-300 mb-2">Something went wrong</p>
          <p className="text-amber-600 dark:text-amber-400 text-sm">We couldn&apos;t verify your feature access. Please refresh the page or contact support.</p>
        </div>
      </div>
    );
  }

  // Users without submission feature see the upsell
  if (!hasSubmissionAccess) {
    const [totalSubmissions, recentCount] = await Promise.all([
      prisma.formSubmission.count({ where: { siteId: site.id } }),
      prisma.formSubmission.count({
        where: { siteId: site.id, createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
      }),
    ]);
    return (
      <div>
        <div className="mb-8">
          <Link href={`/dashboard/sites/${site.id}`} className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            <span>Back to {site.name}</span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Lead Inbox</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">Submissions overview for {site.name}</p>
        </div>
        <SiteTabs siteId={site.id} />

        <div className="mb-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total submissions</p>
            <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{totalSubmissions}</p>
          </div>
          <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
            <p className="text-sm text-gray-500 dark:text-gray-400">Last 7 days</p>
            <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{recentCount}</p>
          </div>
        </div>

        <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-8 text-center">
          <div className="mx-auto w-14 h-14 bg-indigo-100 dark:bg-indigo-900/40 rounded-full flex items-center justify-center mb-4">
            <svg className="w-7 h-7 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Activate your Lead Inbox</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto text-sm">
            Read individual submissions, manage them as leads, export to CSV, and (soon) get email notifications.
          </p>
          <Link href="/dashboard/store?feature=submissions" className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" /></svg>
            Activate Lead Inbox
          </Link>
        </div>
      </div>
    );
  }

  // Parse query parameters
  const page = Math.max(1, Number(searchParams?.page || 1));
  const query = String(searchParams?.q || '').trim();
  const status = String(searchParams?.status || '').trim();
  const preset = String(searchParams?.preset || '').trim();
  const fromDate = String(searchParams?.from || '').trim();
  const toDate = String(searchParams?.to || '').trim();
  const pageSize = 25;

  // Build the where clause
  const where = { siteId: site.id };
  if (query) {
    where.OR = [
      { formName: { contains: query } },
      { data: { contains: query } },
      { ipAddress: { contains: query } },
    ];
  }
  if (status && ALLOWED_STATUS.includes(status)) {
    where.status = status;
  }
  const presetRange = rangeForPreset(preset);
  if (presetRange) {
    where.createdAt = presetRange;
  } else if (fromDate || toDate) {
    where.createdAt = {};
    if (fromDate) where.createdAt.gte = new Date(fromDate);
    if (toDate) where.createdAt.lte = new Date(toDate);
  }

  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [submissions, total, recentCount, unreadCount, monthOverflowCount] = await Promise.all([
    prisma.formSubmission.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.formSubmission.count({ where }),
    prisma.formSubmission.count({
      where: {
        siteId: site.id,
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
      },
    }),
    prisma.formSubmission.count({ where: { siteId: site.id, isRead: false } }),
    prisma.formSubmission.count({
      where: {
        site: { userId: workspace?.workspaceOwnerId || session.user.id },
        quotaOverflow: true,
        createdAt: { gte: monthStart },
      },
    }),
  ]);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="mb-8">
        <Link
          href={`/dashboard/sites/${site.id}`}
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          <span>Back to {site.name}</span>
        </Link>

        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Lead Inbox</h1>
            <p className="mt-1 text-gray-500 dark:text-gray-400">
              Submissions collected from forms on <span className="font-medium">{site.name}</span>
            </p>
          </div>
          {quotaInfo && quotaInfo.hasAccess && quotaInfo.remaining != null && (
            <div className="rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900 px-4 py-2 text-sm">
              <span className="text-indigo-700 dark:text-indigo-300 font-medium">{quotaInfo.used}</span>
              <span className="text-indigo-600 dark:text-indigo-400"> / {quotaInfo.used + quotaInfo.remaining} this month</span>
            </div>
          )}
        </div>
      </div>

      <SiteTabs siteId={site.id} />

      <div className="mb-6 grid gap-4 md:grid-cols-4">
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
          <p className="text-xs uppercase tracking-wide font-medium text-gray-500 dark:text-gray-400">Total leads</p>
          <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
          <p className="text-xs uppercase tracking-wide font-medium text-gray-500 dark:text-gray-400">Last 7 days</p>
          <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{recentCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
          <p className="text-xs uppercase tracking-wide font-medium text-gray-500 dark:text-gray-400">Unread</p>
          <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{unreadCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
          <p className="text-xs uppercase tracking-wide font-medium text-gray-500 dark:text-gray-400">Showing</p>
          <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">{submissions.length}</p>
          <p className="text-xs text-gray-500">of {total}</p>
        </div>
      </div>

      <SubmissionsTable
        initialSubmissions={submissions}
        siteId={site.id}
        siteName={site.name}
        totalCount={total}
        page={page}
        totalPages={totalPages}
        basePath={`/dashboard/sites/${site.id}/submissions`}
        searchQuery={query}
        statusFilter={status}
        datePreset={preset}
        dateFrom={fromDate}
        dateTo={toDate}
        quota={quotaInfo}
        monthOverflowCount={monthOverflowCount}
      />
    </div>
  );
}
