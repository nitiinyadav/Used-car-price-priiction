"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import dynamic from "next/dynamic";
import FileUpload from "@/components/FileUpload";
import FormPromisePanel from "@/components/FormPromisePanel";
import { SITE_TEMPLATES } from "@/lib/site-templates";
import { getRootDomain, normalizeDomain } from "@/lib/utils";

const MonacoEditor = dynamic(() => import("@/components/MonacoEditor"), {
  ssr: false,
});

const STEP_INFO = 1;
const STEP_FILES = 2;
const STEP_DEPLOY = 3;
const STEP_SUCCESS = 4;

const STARTER_TEMPLATES = {
  "index.html": `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>My Site</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <h1>Hello World</h1>\n  <p>Welcome to my site.</p>\n  <script src="script.js"></script>\n</body>\n</html>`,
  "style.css": `* { margin: 0; padding: 0; box-sizing: border-box; }\nbody { font-family: system-ui, sans-serif; padding: 2rem; max-width: 800px; margin: 0 auto; }\nh1 { color: #1a1a1a; margin-bottom: 1rem; }\np { color: #666; line-height: 1.6; }`,
  "script.js": `// Your JavaScript here\nconsole.log('Site loaded');`,
};

const ZIP_PREVIEW_MAX_INLINE_FILE_BYTES = 2 * 1024 * 1024;
const ZIP_PREVIEW_MAX_TOTAL_BYTES = 5 * 1024 * 1024;

function normalizeZipEntryPath(entryName) {
  return String(entryName || "")
    .replace(/\\/g, "/")
    .replace(/^\.\/+/, "")
    .replace(/^\/+/, "");
}

function detectZipRootPrefix(entries) {
  const firstSegments = new Set(
    entries
      .map((entry) => normalizeZipEntryPath(entry).split("/")[0])
      .filter(Boolean),
  );

  if (firstSegments.size !== 1) {
    return "";
  }

  const [rootFolder] = [...firstSegments];
  const rootPrefix = `${rootFolder}/`;

  return entries.every((entry) => normalizeZipEntryPath(entry).startsWith(rootPrefix))
    ? rootPrefix
    : "";
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export default function NewSitePage() {
  const router = useRouter();
  const { data: session } = useSession();
  const isVerified = !!session?.user?.emailVerifiedAt;
  const [name, setName] = useState("");
  const [subdomain, setSubdomain] = useState("");
  const [customDomain, setCustomDomain] = useState("");
  const [deployMethod, setDeployMethod] = useState(null);
  const [file, setFile] = useState(null);
  const [editorFiles, setEditorFiles] = useState(
    Object.entries(STARTER_TEMPLATES).map(([path, content]) => ({
      path,
      content,
      original: content,
    })),
  );
  const [activeFile, setActiveFile] = useState("index.html");
  const [newFileName, setNewFileName] = useState("");
  const [showNewFile, setShowNewFile] = useState(false);
  const [step, setStep] = useState(STEP_INFO);
  const [error, setError] = useState("");
  const [editorSidebarOpen, setEditorSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [deployedSite, setDeployedSite] = useState(null);
  const [zipPreviewHtml, setZipPreviewHtml] = useState("");
  const [zipExtracting, setZipExtracting] = useState(false);
  const [zipFileTree, setZipFileTree] = useState([]);
  const [zipWarnings, setZipWarnings] = useState([]);
  const [previewMode, setPreviewMode] = useState("desktop"); // 'desktop' | 'tablet' | 'mobile'
  const [hasCustomDomainAccess, setHasCustomDomainAccess] = useState(false);
  const [loadingDomainAccess, setLoadingDomainAccess] = useState(true);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  // Extract ZIP when file is selected to generate preview + file tree + warnings
  useEffect(() => {
    if (!file || deployMethod !== "upload") {
      setZipPreviewHtml("");
      setZipFileTree([]);
      setZipWarnings([]);
      return;
    }
    let cancelled = false;
    (async () => {
      setZipExtracting(true);
      const warnings = [];
      try {
        const JSZip = (await import("jszip")).default;
        const buf = await file.arrayBuffer();
        const zip = await JSZip.loadAsync(buf);

        // Detect if all files are inside a single root folder
        const entries = Object.keys(zip.files).filter((n) => !zip.files[n].dir);
        const firstSlash = entries[0]?.indexOf("/");
        let prefix = "";
        if (firstSlash > 0) {
          const candidate = entries[0].substring(0, firstSlash + 1);
          if (entries.every((e) => e.startsWith(candidate))) {
            prefix = candidate;
          }
        }

        const resolve = (name) => (prefix ? name.replace(prefix, "") : name);

        // Build file tree with sizes
        const tree = [];
        for (const entry of entries) {
          const resolved = resolve(entry);
          const data = await zip.files[entry].async("uint8array");
          tree.push({ path: resolved, size: data.byteLength });
        }
        if (!cancelled) setZipFileTree(tree);

        // Validation checks
        const totalSize = tree.reduce((a, f) => a + f.size, 0);
        const hasIndex = tree.some((f) => f.path === "index.html");
        const hasCSS = tree.some((f) => f.path.endsWith(".css"));
        const largFiles = tree.filter((f) => f.size > 1024 * 1024);

        if (!hasIndex)
          warnings.push({
            type: "error",
            msg: "Missing index.html — your site will not load without it!",
          });
        if (!hasCSS)
          warnings.push({
            type: "info",
            msg: "No CSS file found — your site may look unstyled.",
          });
        if (largFiles.length > 0)
          warnings.push({
            type: "warn",
            msg: `${largFiles.length} file(s) over 1 MB — large files may slow page load.`,
          });
        if (totalSize > 5 * 1024 * 1024)
          warnings.push({
            type: "warn",
            msg: `Total size is ${(totalSize / (1024 * 1024)).toFixed(1)} MB — consider optimizing assets.`,
          });
        if (tree.length > 100)
          warnings.push({
            type: "info",
            msg: `${tree.length} files detected. Large sites may take longer to deploy.`,
          });
        if (tree.length === 0)
          warnings.push({
            type: "error",
            msg: "ZIP appears to be empty — no files found.",
          });

        if (hasIndex && tree.length > 0) {
          warnings.push({
            type: "success",
            msg: "Looks good! Your site has an index.html and is ready to deploy.",
          });
        }

        if (!cancelled) setZipWarnings(warnings);

        // Build preview separately so a preview-only failure does not mark the ZIP as invalid.
        try {
          const indexEntry = entries.find((e) => resolve(e) === "index.html");
          if (!indexEntry) {
            if (!cancelled) setZipPreviewHtml("");
            return;
          }

          let html = await zip.files[indexEntry].async("text");

          const cssEntries = entries.filter((e) => resolve(e).endsWith(".css"));
          for (const cssPath of cssEntries) {
            const cssContent = await zip.files[cssPath].async("text");
            const relative = resolve(cssPath);
            html = html.replace(
              new RegExp(
                `<link[^>]+href=["']${relative.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["'][^>]*>`,
                "g",
              ),
              `<style>${cssContent}</style>`,
            );
          }

          const jsEntries = entries.filter((e) => resolve(e).endsWith(".js"));
          for (const jsPath of jsEntries) {
            const jsContent = await zip.files[jsPath].async("text");
            const relative = resolve(jsPath);
            html = html.replace(
              new RegExp(
                `<script[^>]+src=["']${relative.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["'][^>]*></script>`,
                "g",
              ),
              `<script>${jsContent}<\/script>`,
            );
          }

          const imgEntries = entries.filter((e) =>
            /\.(png|jpe?g|gif|svg|webp|ico)$/i.test(resolve(e)),
          );
          for (const imgPath of imgEntries) {
            const imgData = await zip.files[imgPath].async("base64");
            const relative = resolve(imgPath);
            const ext = relative.split(".").pop().toLowerCase();
            const mimeMap = {
              png: "image/png",
              jpg: "image/jpeg",
              jpeg: "image/jpeg",
              gif: "image/gif",
              svg: "image/svg+xml",
              webp: "image/webp",
              ico: "image/x-icon",
            };
            const mimeType = mimeMap[ext] || "application/octet-stream";
            const dataUri = `data:${mimeType};base64,${imgData}`;
            html = html.replace(
              new RegExp(
                `(src|href)=["']${relative.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["']`,
                "g",
              ),
              `$1="${dataUri}"`,
            );
          }

          if (!cancelled) setZipPreviewHtml(html);
        } catch (previewError) {
          console.error("ZIP preview generation failed:", previewError);
          if (!cancelled) {
            setZipPreviewHtml("");
            setZipWarnings((current) => [
              ...current,
              {
                type: "info",
                msg: "ZIP contents were read successfully, but live preview could not be generated for this archive.",
              },
            ]);
          }
        }
      } catch (zipError) {
        console.error("ZIP scan failed:", zipError);
        if (!cancelled) {
          setZipPreviewHtml("");
          setZipFileTree([]);
          setZipWarnings([
            {
              type: "error",
              msg: "Failed to read this ZIP archive in the browser. Please re-export it as a standard ZIP and try again.",
            },
          ]);
        }
      } finally {
        if (!cancelled) setZipExtracting(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [file, deployMethod]);

  function handleSubdomainChange(e) {
    setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""));
  }

  function goToStep2() {
    if (!name.trim()) {
      setError("Site name is required");
      return;
    }
    if (!subdomain.trim()) {
      setError("Subdomain is required");
      return;
    }
    if (subdomain.length < 3) {
      setError("Subdomain must be at least 3 characters");
      return;
    }
    setError("");
    setStep(STEP_FILES);
  }

  function goToStep3() {
    if (deployMethod === "upload" && !file) {
      setError("Please upload a ZIP file");
      return;
    }
    if (
      deployMethod === "editor" &&
      !editorFiles.some((f) => f.path === "index.html")
    ) {
      setError("Your site must have an index.html");
      return;
    }
    setError("");
    setStep(STEP_DEPLOY);
  }

  function addEditorFile() {
    if (!newFileName.trim()) return;
    const p = newFileName.trim().replace(/\\/g, "/");
    if (editorFiles.some((f) => f.path === p)) {
      setError("File already exists");
      return;
    }
    setEditorFiles([...editorFiles, { path: p, content: "", original: "" }]);
    setActiveFile(p);
    setNewFileName("");
    setShowNewFile(false);
    setError("");
  }

  function deleteEditorFile(path) {
    if (path === "index.html") return;
    setEditorFiles(editorFiles.filter((f) => f.path !== path));
    if (activeFile === path) setActiveFile(editorFiles[0]?.path || "");
  }

  function updateFileContent(path, content) {
    setEditorFiles(
      editorFiles.map((f) => (f.path === path ? { ...f, content } : f)),
    );
  }

  const currentFile = editorFiles.find((f) => f.path === activeFile);

  async function handleDeploy() {
    setError("");
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("name", name.trim());
      formData.append("subdomain", subdomain.trim());
      if (customDomain.trim())
        formData.append("customDomain", normalizeDomain(customDomain));
      if (deployMethod === "upload") {
        formData.append("file", file);
      } else {
        const filesPayload = {};
        editorFiles.forEach((f) => {
          filesPayload[f.path] = f.content;
        });
        formData.append(
          "editorFiles",
          new Blob([JSON.stringify(filesPayload)], {
            type: "application/json",
          }),
        );
      }
      const res = await fetch("/api/sites", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Deployment failed");
        return;
      }
      setDeployedSite(data.site);
      setStep(STEP_SUCCESS);
    } catch {
      setError("An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  }

  // Check if user has purchased custom domain feature
  useEffect(() => {
    async function checkDomainAccess() {
      try {
        const res = await fetch("/api/feature-overview");
        if (res.ok) {
          const data = await res.json();
          const domainFeature = data.overview?.["custom-domain"];
          setHasCustomDomainAccess(domainFeature?.hasAccess || false);
        }
      } catch (err) {
        console.error("Failed to check domain access:", err);
      } finally {
        setLoadingDomainAccess(false);
      }
    }
    if (session?.user?.role === "superadmin") {
      setHasCustomDomainAccess(true);
      setLoadingDomainAccess(false);
    } else {
      checkDomainAccess();
    }
  }, [session]);

  const rootDomain = getRootDomain();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Step indicator */}
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-6">
          {[
            { num: 1, label: "Site Info" },
            { num: 2, label: "Add Files" },
            { num: 3, label: "Deploy" },
          ].map((s, i) => (
            <div key={s.num} className="flex items-center gap-3">
              {i > 0 && (
                <div
                  className={`h-px w-8 ${step >= s.num ? "bg-indigo-600" : "bg-gray-200 dark:bg-gray-700"}`}
                />
              )}
              <div className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${step >= s.num ? "bg-indigo-600 text-white" : "bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400"}`}
                >
                  {step > s.num ? (
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  ) : (
                    s.num
                  )}
                </div>
                <span
                  className={`text-sm font-medium hidden sm:block ${step >= s.num ? "text-gray-900 dark:text-white" : "text-gray-400"}`}
                >
                  {s.label}
                </span>
              </div>
            </div>
          ))}
        </div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Deploy New Site
        </h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          {step === STEP_INFO && "Name your site and choose a subdomain"}
          {step === STEP_FILES && "Upload files or build your site right here"}
          {step === STEP_DEPLOY && "Review and deploy your site"}
          {step === STEP_SUCCESS && "Congratulations!"}
        </p>
      </div>

      {error && (
        <div className="mb-6 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-xl text-sm">
          {error}
        </div>
      )}

      {/* STEP 1 */}
      {step === STEP_INFO && (
        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6 space-y-6">
          <div>
            <label
              htmlFor="name"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Site Name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoFocus
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
              placeholder="My Portfolio"
            />
            <p className="mt-1 text-xs text-gray-400">
              A friendly name visible only to you
            </p>
          </div>
          <div>
            <label
              htmlFor="subdomain"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Subdomain
            </label>
            <div className="flex">
              <input
                id="subdomain"
                type="text"
                value={subdomain}
                onChange={handleSubdomainChange}
                className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-l-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                placeholder="my-portfolio"
                maxLength={63}
              />
              <span className="px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-l-0 border-gray-300 dark:border-gray-700 rounded-r-xl text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">
                .{rootDomain.replace(/^https?:\/\//, "")}
              </span>
            </div>
          </div>
          <div>
            <label
              htmlFor="customDomain"
              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
            >
              Custom Domain{" "}
              <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            {loadingDomainAccess ? (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0 animate-pulse">
                    <svg
                      className="w-5 h-5 text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9"
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-gray-500">
                    Checking domain access...
                  </p>
                </div>
              </div>
            ) : hasCustomDomainAccess ? (
              <input
                id="customDomain"
                type="text"
                value={customDomain}
                onChange={(e) => setCustomDomain(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                placeholder="www.example.com"
              />
            ) : (
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <svg
                      className="w-5 h-5 text-indigo-600"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                      />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900">
                      Custom Domain is a paid feature
                    </p>
                    <p className="text-xs text-gray-500">
                      Connect your own domain with automatic SSL.
                    </p>
                  </div>
                  <a
                    href="/dashboard/store"
                    className="inline-flex items-center gap-1.5 bg-indigo-600 text-white px-4 py-2 rounded-lg text-xs font-medium hover:bg-indigo-700 transition-colors whitespace-nowrap"
                  >
                    <svg
                      className="w-3.5 h-3.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z"
                      />
                    </svg>
                    Buy Now
                  </a>
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-end">
            <button
              type="button"
              onClick={goToStep2}
              className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2"
            >
              Next{" "}
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </button>
          </div>
          </div>
          {/* Right column: forms-promise education panel */}
          <div className="lg:col-span-2 lg:sticky lg:top-6 self-start space-y-4">
            <FormPromisePanel subdomain={subdomain} freeQuota={100} />
            <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
                What happens after Deploy
              </p>
              <ol className="space-y-2 text-xs text-gray-600 dark:text-gray-400">
                <li className="flex gap-2"><span className="text-indigo-500 font-semibold">1.</span><span>Your site goes live at <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">{subdomain || 'yoursite'}.liveinsec.com</code></span></li>
                <li className="flex gap-2"><span className="text-indigo-500 font-semibold">2.</span><span>If you picked a template with a contact form, it's already wired</span></li>
                <li className="flex gap-2"><span className="text-indigo-500 font-semibold">3.</span><span>One click to send a test submission and confirm everything works</span></li>
                <li className="flex gap-2"><span className="text-indigo-500 font-semibold">4.</span><span>Share your URL — leads land in your Lead Inbox automatically</span></li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2 */}
      {step === STEP_FILES && (
        <div className="space-y-6">
          {!deployMethod && (
            <div className="grid md:grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setDeployMethod("upload")}
                className="bg-white dark:bg-gray-900 rounded-2xl border-2 border-gray-200 dark:border-gray-800 p-8 text-left hover:border-indigo-400 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/20 transition-all group"
              >
                <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/40 rounded-xl flex items-center justify-center mb-4 group-hover:bg-indigo-200 dark:group-hover:bg-indigo-900/60 transition-colors">
                  <svg
                    className="w-6 h-6 text-indigo-600 dark:text-indigo-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                  Upload ZIP
                </h3>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Already have your site files? Upload a ZIP containing your
                  HTML, CSS & JS.
                </p>
              </button>
              <button
                type="button"
                onClick={() => setDeployMethod("editor")}
                className="bg-white dark:bg-gray-900 rounded-2xl border-2 border-gray-200 dark:border-gray-800 p-8 text-left hover:border-purple-400 hover:bg-purple-50/30 dark:hover:bg-purple-900/20 transition-all group"
              >
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/40 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-200 dark:group-hover:bg-purple-900/60 transition-colors">
                  <svg
                    className="w-6 h-6 text-purple-600 dark:text-purple-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                  Build Here
                </h3>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  Create and edit files in a code editor. Start from a template
                  or scratch.
                </p>
              </button>
            </div>
          )}

          {/* Template picker — shown when editor is selected but no template chosen */}
          {deployMethod === "editor" && !selectedTemplate && (
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Choose a Template
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Pick a starting point for your site
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setDeployMethod(null)}
                  className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                >
                  Back
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {SITE_TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => {
                      setSelectedTemplate(tpl.id);
                      setEditorFiles(
                        Object.entries(tpl.files).map(([path, content]) => ({
                          path,
                          content,
                          original: content,
                        })),
                      );
                      setActiveFile("index.html");
                    }}
                    className={`group relative rounded-xl border-2 p-4 text-left transition-all ${
                      selectedTemplate === tpl.id
                        ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30 ring-2 ring-indigo-200 dark:ring-indigo-900/50'
                        : 'border-gray-200 dark:border-gray-700 hover:border-indigo-400 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/20'
                    }`}
                  >
                    <div className="text-2xl mb-2">{tpl.icon}</div>
                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                      {tpl.name}
                    </h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                      {tpl.description}
                    </p>
                    {tpl.hasContactForm && (
                      <span
                        className="absolute top-2 right-2 inline-flex items-center gap-1 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 px-2 py-0.5 text-[10px] font-semibold"
                        title="Contact form will be auto-wired to your Lead Inbox"
                      >
                        📬 form
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {deployMethod === "upload" && (
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Upload ZIP File
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setDeployMethod(null);
                    setFile(null);
                  }}
                  className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                >
                  Change method
                </button>
              </div>
              <FileUpload onFileSelect={setFile} />
              <p className="mt-3 text-xs text-gray-400">
                ZIP must contain{" "}
                <code className="bg-gray-100 px-1 py-0.5 rounded">
                  index.html
                </code>{" "}
                at the root.
              </p>
            </div>
          )}

          {deployMethod === "editor" && selectedTemplate && (
            <div className="bg-gray-900 rounded-2xl overflow-hidden border border-gray-700">
              <div className="flex items-center justify-between px-4 py-2 bg-gray-800 border-b border-gray-700">
                <div className="flex items-center gap-2">
                  {/* Mobile sidebar toggle */}
                  <button
                    type="button"
                    onClick={() => setEditorSidebarOpen(!editorSidebarOpen)}
                    className="lg:hidden text-gray-400 hover:text-white mr-1"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 6h16M4 12h16M4 18h16"
                      />
                    </svg>
                  </button>
                  <div className="flex gap-1.5 hidden sm:flex">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <span className="ml-1 sm:ml-3 text-xs text-gray-400 font-mono truncate">
                    {name || "untitled"} — LiveInSec Editor
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setDeployMethod(null);
                    setSelectedTemplate(null);
                  }}
                  className="text-xs text-gray-400 hover:text-white"
                >
                  Change method
                </button>
              </div>
              <div className="flex relative" style={{ minHeight: "480px" }}>
                {/* Mobile sidebar backdrop */}
                {editorSidebarOpen && (
                  <div
                    className="lg:hidden fixed inset-0 bg-black/40 z-20"
                    onClick={() => setEditorSidebarOpen(false)}
                  />
                )}
                <div
                  className={`
                  bg-gray-800 border-r border-gray-700 flex flex-col
                  ${
                    editorSidebarOpen
                      ? "fixed inset-y-0 left-0 z-30 w-64 shadow-2xl lg:relative lg:w-52 lg:shadow-none"
                      : "hidden lg:flex w-52"
                  }
                `}
                >
                  <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center justify-between">
                    <span>Explorer</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setShowNewFile(true)}
                        className="text-gray-400 hover:text-white"
                        title="New file"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 4v16m8-8H4"
                          />
                        </svg>
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditorSidebarOpen(false)}
                        className="lg:hidden text-gray-400 hover:text-white"
                      >
                        <svg
                          className="w-4 h-4"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                  {showNewFile && (
                    <div className="px-2 pb-2">
                      <input
                        autoFocus
                        value={newFileName}
                        onChange={(e) => setNewFileName(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") addEditorFile();
                          if (e.key === "Escape") {
                            setShowNewFile(false);
                            setNewFileName("");
                          }
                        }}
                        onBlur={() => {
                          if (!newFileName.trim()) setShowNewFile(false);
                        }}
                        className="w-full bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600 focus:outline-none focus:border-indigo-500"
                        placeholder="filename.html"
                      />
                    </div>
                  )}
                  <div className="flex-1 overflow-y-auto">
                    {editorFiles.map((f) => {
                      const isAct = activeFile === f.path;
                      const isMod = f.content !== f.original;
                      const ext = f.path.split(".").pop();
                      const cMap = {
                        html: "text-orange-400",
                        css: "text-blue-400",
                        js: "text-yellow-400",
                        json: "text-green-400",
                      };
                      return (
                        <div
                          key={f.path}
                          className={`group flex items-center justify-between px-3 py-1.5 cursor-pointer text-xs ${isAct ? "bg-gray-700/80 text-white" : "text-gray-400 hover:text-white hover:bg-gray-700/40"}`}
                          onClick={() => {
                            setActiveFile(f.path);
                            setEditorSidebarOpen(false);
                          }}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <span className={cMap[ext] || "text-gray-400"}>
                              {ext === "html"
                                ? "◆"
                                : ext === "css"
                                  ? "◈"
                                  : ext === "js"
                                    ? "◇"
                                    : "▫"}
                            </span>
                            <span className="truncate">{f.path}</span>
                            {isMod && (
                              <span className="w-2 h-2 rounded-full bg-amber-400 flex-shrink-0" />
                            )}
                          </div>
                          {f.path !== "index.html" && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteEditorFile(f.path);
                              }}
                              className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-400 ml-2"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className="flex-1 flex flex-col">
                  <div className="flex bg-gray-800 border-b border-gray-700 overflow-x-auto">
                    {editorFiles.map((f) => (
                      <button
                        key={f.path}
                        type="button"
                        onClick={() => setActiveFile(f.path)}
                        className={`px-4 py-2 text-xs font-mono border-r border-gray-700 whitespace-nowrap ${activeFile === f.path ? "bg-gray-900 text-white border-b-2 border-b-indigo-500" : "text-gray-400 hover:text-white"}`}
                      >
                        {f.path}
                        {f.content !== f.original && (
                          <span className="ml-1 text-amber-400">●</span>
                        )}
                      </button>
                    ))}
                  </div>
                  {currentFile ? (
                    <MonacoEditor
                      value={currentFile.content}
                      onChange={(v) => updateFileContent(activeFile, v)}
                      filePath={activeFile}
                      className="flex-1"
                    />
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-500 text-sm">
                      Select a file to edit
                    </div>
                  )}
                  <div className="flex items-center justify-between px-4 py-1 bg-indigo-600 text-white text-xs">
                    <span>{editorFiles.length} files</span>
                    <span className="font-mono">
                      {activeFile
                        ? activeFile.split(".").pop().toUpperCase()
                        : ""}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {deployMethod && (
            <div className="flex justify-between">
              <button
                type="button"
                onClick={() => setStep(STEP_INFO)}
                className="text-gray-600 hover:text-gray-900 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2"
              >
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 19l-7-7 7-7"
                  />
                </svg>{" "}
                Back
              </button>
              <button
                type="button"
                onClick={goToStep3}
                className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2"
              >
                Review & Deploy{" "}
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            </div>
          )}
        </div>
      )}

      {/* STEP 3 — Pre-deploy review */}
      {step === STEP_DEPLOY && (
        <div className="space-y-6">
          {/* Site info summary */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <svg
                className="w-5 h-5 text-indigo-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                />
              </svg>
              Deployment Summary
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                <p className="text-xs text-gray-400 uppercase font-medium tracking-wide">
                  Site Name
                </p>
                <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                  {name}
                </p>
              </div>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                <p className="text-xs text-gray-400 uppercase font-medium tracking-wide">
                  Subdomain
                </p>
                <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                  {subdomain}.{rootDomain.replace(/^https?:\/\//, "")}
                </p>
              </div>
              {customDomain && (
                <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                  <p className="text-xs text-gray-400 uppercase font-medium tracking-wide">
                    Custom Domain
                  </p>
                  <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                    {customDomain}
                  </p>
                </div>
              )}
              <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
                <p className="text-xs text-gray-400 uppercase font-medium tracking-wide">
                  Deploy Method
                </p>
                <p className="mt-1 font-semibold text-gray-900 dark:text-white">
                  {deployMethod === "upload"
                    ? `ZIP (${file?.name})`
                    : `${editorFiles.length} editor files`}
                </p>
              </div>
            </div>
          </div>

          {/* Health Check Panel — ZIP */}
          {deployMethod === "upload" && (
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
                <svg
                  className="w-5 h-5 text-indigo-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <h3 className="text-sm font-semibold text-gray-900">
                  Pre-deploy Health Check
                </h3>
              </div>
              {zipExtracting ? (
                <div className="px-6 py-8 flex flex-col items-center gap-3">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full border-4 border-indigo-100 animate-pulse" />
                    <svg
                      className="w-12 h-12 animate-spin absolute inset-0 text-indigo-600"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                      />
                    </svg>
                  </div>
                  <p className="text-sm text-gray-500">
                    Scanning your ZIP file...
                  </p>
                </div>
              ) : (
                <div className="px-6 py-4 space-y-2">
                  {zipWarnings.map((w, i) => (
                    <div
                      key={i}
                      className={`flex items-start gap-3 rounded-xl px-4 py-3 text-sm ${
                        w.type === "error"
                          ? "bg-red-50 text-red-700 border border-red-200"
                          : w.type === "warn"
                            ? "bg-amber-50 text-amber-700 border border-amber-200"
                            : w.type === "success"
                              ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                              : "bg-blue-50 text-blue-700 border border-blue-200"
                      }`}
                    >
                      {w.type === "error" && (
                        <svg
                          className="w-5 h-5 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                          />
                        </svg>
                      )}
                      {w.type === "warn" && (
                        <svg
                          className="w-5 h-5 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                      )}
                      {w.type === "success" && (
                        <svg
                          className="w-5 h-5 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                      )}
                      {w.type === "info" && (
                        <svg
                          className="w-5 h-5 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                          />
                        </svg>
                      )}
                      <span>{w.msg}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* File Inspector — ZIP */}
          {deployMethod === "upload" && zipFileTree.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <svg
                    className="w-5 h-5 text-indigo-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
                    />
                  </svg>
                  <h3 className="text-sm font-semibold text-gray-900">
                    Files in ZIP
                  </h3>
                </div>
                <span className="text-xs text-gray-400">
                  {zipFileTree.length} files &middot;{" "}
                  {(zipFileTree.reduce((a, f) => a + f.size, 0) / 1024).toFixed(
                    1,
                  )}{" "}
                  KB total
                </span>
              </div>
              <div className="max-h-60 overflow-y-auto divide-y divide-gray-50">
                {zipFileTree.map((f, i) => {
                  const ext = (f.path.split(".").pop() || "").toLowerCase();
                  const colorMap = {
                    html: "text-orange-500",
                    css: "text-blue-500",
                    js: "text-yellow-500",
                    json: "text-green-500",
                    png: "text-pink-500",
                    jpg: "text-pink-500",
                    jpeg: "text-pink-500",
                    svg: "text-pink-500",
                    gif: "text-pink-500",
                    webp: "text-pink-500",
                  };
                  const iconMap = {
                    html: "◆",
                    css: "◈",
                    js: "◇",
                    json: "▣",
                    png: "▢",
                    jpg: "▢",
                    jpeg: "▢",
                    svg: "○",
                    gif: "▢",
                    webp: "▢",
                    md: "□",
                    txt: "▫",
                  };
                  const sizeStr =
                    f.size > 1024 * 1024
                      ? `${(f.size / (1024 * 1024)).toFixed(1)} MB`
                      : f.size > 1024
                        ? `${(f.size / 1024).toFixed(1)} KB`
                        : `${f.size} B`;
                  const isLarge = f.size > 1024 * 1024;
                  return (
                    <div
                      key={i}
                      className="flex items-center justify-between px-6 py-2 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`${colorMap[ext] || "text-gray-400"} text-xs`}
                        >
                          {iconMap[ext] || "▫"}
                        </span>
                        <span className="text-sm text-gray-700 truncate">
                          {f.path}
                        </span>
                        {f.path === "index.html" && (
                          <span className="flex-shrink-0 text-[10px] bg-emerald-100 text-emerald-700 font-semibold px-1.5 py-0.5 rounded-full uppercase">
                            Entry
                          </span>
                        )}
                      </div>
                      <span
                        className={`text-xs flex-shrink-0 ml-3 ${isLarge ? "text-amber-600 font-semibold" : "text-gray-400"}`}
                      >
                        {sizeStr}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Visual Preview with Device Switcher */}
          {((deployMethod === "upload" && (zipPreviewHtml || zipExtracting)) ||
            deployMethod === "editor") && (
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <svg
                    className="w-5 h-5 text-indigo-600"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                  <h3 className="text-sm font-semibold text-gray-900">
                    Live Preview
                  </h3>
                </div>
                {/* Device mode switcher */}
                <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
                  <button
                    type="button"
                    onClick={() => setPreviewMode("desktop")}
                    className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors flex items-center gap-1 ${previewMode === "desktop" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                      />
                    </svg>
                    <span className="hidden sm:inline">Desktop</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode("tablet")}
                    className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors flex items-center gap-1 ${previewMode === "tablet" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"
                      />
                    </svg>
                    <span className="hidden sm:inline">Tablet</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewMode("mobile")}
                    className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors flex items-center gap-1 ${previewMode === "mobile" ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
                      />
                    </svg>
                    <span className="hidden sm:inline">Mobile</span>
                  </button>
                </div>
              </div>

              {/* Device frame wrapper */}
              <div
                className="bg-gray-100 flex items-start justify-center p-4 sm:p-8"
                style={{ minHeight: "420px" }}
              >
                {zipExtracting && deployMethod === "upload" ? (
                  <div className="flex flex-col items-center justify-center py-16 gap-3">
                    <svg
                      className="animate-spin h-8 w-8 text-indigo-600"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                      />
                    </svg>
                    <p className="text-sm text-gray-500">Building preview...</p>
                  </div>
                ) : (
                  <div
                    className={`bg-white rounded-lg shadow-2xl overflow-hidden transition-all duration-300 ${
                      previewMode === "desktop"
                        ? "w-full max-w-4xl"
                        : previewMode === "tablet"
                          ? "w-full max-w-[768px]"
                          : "w-full max-w-[375px]"
                    }`}
                  >
                    {/* Fake browser chrome */}
                    <div className="bg-gray-200 px-4 py-2 flex items-center gap-2">
                      <div className="flex gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
                        <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
                      </div>
                      <div className="flex-1 bg-white rounded-md px-3 py-1 text-xs text-gray-400 font-mono truncate">
                        {subdomain}.{rootDomain.replace(/^https?:\/\//, "")}
                      </div>
                    </div>
                    {/* Preview iframe */}
                    <iframe
                      title="Site Preview"
                      srcDoc={
                        deployMethod === "upload"
                          ? zipPreviewHtml ||
                            '<div style="display:flex;align-items:center;justify-content:center;height:300px;font-family:sans-serif;color:#9ca3af"><p>No preview available</p></div>'
                          : (() => {
                              const indexFile = editorFiles.find(
                                (f) => f.path === "index.html",
                              );
                              if (!indexFile)
                                return '<div style="display:flex;align-items:center;justify-content:center;height:300px;font-family:sans-serif;color:#9ca3af"><p>No index.html found</p></div>';
                              let html = indexFile.content;
                              editorFiles
                                .filter((f) => f.path.endsWith(".css"))
                                .forEach((f) => {
                                  html = html.replace(
                                    new RegExp(
                                      `<link[^>]+href=["']${f.path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["'][^>]*>`,
                                      "g",
                                    ),
                                    `<style>${f.content}</style>`,
                                  );
                                });
                              editorFiles
                                .filter((f) => f.path.endsWith(".js"))
                                .forEach((f) => {
                                  html = html.replace(
                                    new RegExp(
                                      `<script[^>]+src=["']${f.path.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["'][^>]*></script>`,
                                      "g",
                                    ),
                                    `<script>${f.content}<\/script>`,
                                  );
                                });
                              return html;
                            })()
                      }
                      className="w-full border-0"
                      style={{
                        height:
                          previewMode === "mobile"
                            ? "667px"
                            : previewMode === "tablet"
                              ? "500px"
                              : "400px",
                      }}
                      sandbox="allow-scripts"
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Email verification warning */}
          {!isVerified && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-amber-600"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                  />
                </svg>
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-semibold text-amber-800">
                  Email Not Verified
                </h4>
                <p className="text-sm text-amber-700 mt-1">
                  You must verify your email address before you can deploy a
                  site. Check your inbox for the verification link.
                </p>
                <button
                  type="button"
                  onClick={async () => {
                    await fetch("/api/auth/email/request-verification", {
                      method: "POST",
                    });
                    alert("Verification email sent! Check your inbox.");
                  }}
                  className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-amber-800 hover:text-amber-900 underline underline-offset-2"
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    />
                  </svg>
                  Resend Verification Email
                </button>
              </div>
            </div>
          )}

          {/* Deploy button row */}
          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={() => setStep(STEP_FILES)}
              className="text-gray-600 hover:text-gray-900 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2"
            >
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 19l-7-7 7-7"
                />
              </svg>{" "}
              Back
            </button>
            {!isVerified ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-amber-600 font-medium">
                  Verify email to deploy
                </span>
                <button
                  type="button"
                  disabled
                  className="bg-gray-300 text-gray-500 px-8 py-3 rounded-xl font-medium text-sm cursor-not-allowed flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                  Deploy Locked
                </button>
              </div>
            ) : zipWarnings.some((w) => w.type === "error") &&
              deployMethod === "upload" ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-red-600 font-medium">
                  Fix errors before deploying
                </span>
                <button
                  type="button"
                  onClick={() => setStep(STEP_FILES)}
                  className="bg-red-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-red-700 transition-colors flex items-center gap-2"
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                    />
                  </svg>
                  Fix Files
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleDeploy}
                disabled={loading}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <svg
                      className="animate-spin h-4 w-4"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                      />
                    </svg>
                    <span>Deploying...</span>
                  </>
                ) : (
                  <>
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                      />
                    </svg>
                    <span>Deploy Site</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Step 4: Success — leads with test submission + visible form API */}
      {step === STEP_SUCCESS && deployedSite && (
        <DeploySuccessScreen
          deployedSite={deployedSite}
          name={name}
          subdomain={subdomain}
          rootDomain={rootDomain}
          onDeployAnother={() => {
            setStep(STEP_INFO);
            setName("");
            setSubdomain("");
            setCustomDomain("");
            setFile(null);
            setDeployMethod(null);
            setDeployedSite(null);
            setSelectedTemplate(null);
          }}
        />
      )}
    </div>
  );
}

/**
 * DeploySuccessScreen — the celebratory success screen after a site deploys.
 *
 * Per session 4 design: this is the moment of maximum dopamine, so we lead
 * with the action that gives the user immediate value — sending a test
 * submission and seeing it land in their Lead Inbox. That single click is
 * the "aha moment" that makes the whole product click.
 */
function DeploySuccessScreen({ deployedSite, name, subdomain, rootDomain, onDeployAnother }) {
  const router = useRouter();
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [copiedField, setCopiedField] = useState(null);
  const liveUrl = `http://${subdomain}.${rootDomain}`;
  const formEndpoint = deployedSite?.formEndpoint
    || `${typeof window !== 'undefined' ? window.location.origin : ''}/api/forms/${deployedSite?.apiKey || ''}`;

  function copy(field, value) {
    navigator.clipboard.writeText(value).then(() => {
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 1400);
    });
  }

  async function sendTest() {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(`/api/sites/${deployedSite.id}/test-submission`, { method: 'POST' });
      const data = await res.json();
      setTestResult({ ok: res.ok, message: data.message || data.error || 'Done' });
    } catch (err) {
      setTestResult({ ok: false, message: 'Network error' });
    } finally {
      setTesting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Hero card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500 via-teal-500 to-indigo-600 p-8 sm:p-10 text-white shadow-xl">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-white/15 blur-3xl" aria-hidden></div>
        <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-fuchsia-400/20 blur-3xl" aria-hidden></div>
        <div className="relative">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/20 backdrop-blur px-3 py-1 text-xs font-medium">
            🎉 LIVE
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight">
            {name} is live.
          </h2>
          <p className="mt-2 text-emerald-50 text-base">
            Your site is on the air. Now let's prove the inbox works.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <a
              href={liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-xl bg-white text-indigo-700 px-5 py-3 text-sm font-semibold hover:bg-indigo-50 shadow-lg shadow-black/10"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
              </svg>
              Visit your site
            </a>
            <code className="inline-flex items-center rounded-lg bg-black/20 backdrop-blur px-3 py-2 text-xs font-mono">
              {subdomain}.{rootDomain}
            </code>
          </div>
        </div>
      </div>

      {/* The "aha" — try the form */}
      <div className="rounded-2xl border border-indigo-200 dark:border-indigo-900 bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/40 dark:to-violet-950/40 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <span className="flex items-center justify-center w-7 h-7 rounded-full bg-indigo-600 text-white text-xs font-bold">1</span>
              <h3 className="text-base font-semibold text-gray-900 dark:text-white">
                Send a test submission to your Lead Inbox
              </h3>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 ml-9">
              We'll fire a fake "John Doe" lead at your form endpoint so you can see how submissions appear.
            </p>
          </div>
          <button
            onClick={sendTest}
            disabled={testing}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white px-5 py-3 text-sm font-semibold whitespace-nowrap shadow-lg shadow-indigo-500/30"
          >
            {testing ? (
              <>
                <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" className="opacity-25"/>
                  <path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="3" className="opacity-75"/>
                </svg>
                Sending…
              </>
            ) : (
              <>
                📬 Send test submission
              </>
            )}
          </button>
        </div>
        {testResult && (
          <div className={`mt-4 rounded-lg px-4 py-3 text-sm ${
            testResult.ok
              ? 'bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200'
              : 'bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
          }`}>
            {testResult.ok ? '✓ ' : '✗ '}{testResult.message}
            {testResult.ok && (
              <button
                onClick={() => router.push(`/dashboard/sites/${deployedSite.id}/submissions`)}
                className="ml-2 underline font-medium hover:no-underline"
              >
                Open Lead Inbox →
              </button>
            )}
          </div>
        )}
      </div>

      {/* Form embed reference */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="flex items-center justify-center w-7 h-7 rounded-full bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300 text-xs font-bold">2</span>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">
            Your form endpoint (already wired in any template you picked)
          </h3>
        </div>
        <div className="ml-9 space-y-3">
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg px-3 py-2 text-xs font-mono text-gray-800 dark:text-gray-200">
              {formEndpoint}
            </code>
            <button
              onClick={() => copy('endpoint', formEndpoint)}
              className="rounded-lg border border-gray-300 dark:border-gray-700 px-3 py-2 text-xs font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
            >
              {copiedField === 'endpoint' ? '✓ Copied' : '📋 Copy'}
            </button>
          </div>
          <details className="text-sm">
            <summary className="cursor-pointer text-gray-600 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 font-medium">
              Show me the HTML to paste into a form
            </summary>
            <pre className="mt-3 bg-gray-900 text-green-400 rounded-lg p-4 text-xs overflow-x-auto leading-relaxed">{`<form action="${formEndpoint}" method="POST">
  <input name="name" placeholder="Your name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>
  <input type="text" name="company" style="display:none" tabindex="-1" autocomplete="off" />
  <button type="submit">Send</button>
</form>`}</pre>
            <p className="mt-2 text-xs text-gray-500">
              The hidden <code>company</code> field is anti-bot — humans never fill it, spam bots usually do.
            </p>
          </details>
        </div>
      </div>

      {/* Next steps */}
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="flex items-center justify-center w-7 h-7 rounded-full bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/40 dark:text-fuchsia-300 text-xs font-bold">3</span>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">What's next?</h3>
        </div>
        <div className="ml-9 grid sm:grid-cols-3 gap-3">
          <button
            type="button"
            onClick={() => {
              router.push(`/dashboard/sites/${deployedSite.id}`);
              router.refresh();
            }}
            className="text-left rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 hover:border-indigo-400 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 px-4 py-3 transition-colors"
          >
            <div className="text-lg mb-1">🛠</div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">Manage site</p>
            <p className="text-xs text-gray-500">Settings, files, analytics</p>
          </button>
          <button
            type="button"
            onClick={() => router.push('/dashboard/store')}
            className="text-left rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 hover:border-indigo-400 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 px-4 py-3 transition-colors"
          >
            <div className="text-lg mb-1">🚀</div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">Power up</p>
            <p className="text-xs text-gray-500">Custom domain, analytics, more</p>
          </button>
          <button
            type="button"
            onClick={onDeployAnother}
            className="text-left rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50 hover:border-indigo-400 hover:bg-indigo-50/50 dark:hover:bg-indigo-900/20 px-4 py-3 transition-colors"
          >
            <div className="text-lg mb-1">➕</div>
            <p className="text-sm font-semibold text-gray-900 dark:text-white">Deploy another</p>
            <p className="text-xs text-gray-500">Free for 3 sites</p>
          </button>
        </div>
      </div>
    </div>
  );
}
