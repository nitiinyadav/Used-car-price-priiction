// Next.js will serve this at /robots.txt
export default function robots() {
  const base = process.env.NEXT_PUBLIC_APP_URL || "https://liveinsec.com";
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/", "/dashboard/", "/admin/", "/login", "/register", "/reset-password", "/verify-email"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
    host: base,
  };
}
