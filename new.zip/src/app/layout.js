import { Inter } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";

const inter = Inter({ subsets: ["latin"] });

// SEO-tuned metadata. Landing-page-specific overrides should still set their
// own title/description via Next.js metadata API.
const APP_NAME = "LiveInSec";
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "https://liveinsec.com";
const APP_TAGLINE = "Host static websites + collect leads — no Git, no servers";
const APP_DESCRIPTION =
  "Drop a ZIP, deploy in seconds. Built-in form API, privacy-first analytics, custom domains, and a Lead Inbox — all in one place. Free forever for portfolios and small business sites.";

export const metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: `${APP_NAME} — ${APP_TAGLINE}`,
    template: `%s — ${APP_NAME}`,
  },
  description: APP_DESCRIPTION,
  applicationName: APP_NAME,
  authors: [{ name: APP_NAME }],
  generator: "Next.js",
  keywords: [
    "static site hosting",
    "free website hosting",
    "html hosting",
    "deploy zip website",
    "form collection api",
    "contact form backend",
    "lead inbox",
    "no-code website hosting",
    "subdomain hosting",
    "custom domain hosting",
    "GDPR analytics",
    "privacy-first analytics",
    "Netlify alternative",
    "Vercel alternative",
    "Tiiny.host alternative",
    "Formspree alternative",
    "India web hosting",
    "Razorpay hosting",
  ],
  icons: {
    icon: "/system/favicon.png",
    apple: "/system/favicon.png",
  },
  alternates: { canonical: "/" },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: `${APP_NAME} — ${APP_TAGLINE}`,
    description: APP_DESCRIPTION,
    type: "website",
    url: APP_URL,
    siteName: APP_NAME,
    locale: "en_US",
    images: [
      {
        url: "/system/logo.png",
        width: 1200,
        height: 630,
        alt: `${APP_NAME} — deploy a static website in seconds`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `${APP_NAME} — ${APP_TAGLINE}`,
    description: APP_DESCRIPTION,
    images: ["/system/logo.png"],
  },
  verification: {
    google: process.env.GOOGLE_SITE_VERIFICATION || undefined,
  },
};

// Structured data for Google rich results — Software / Web App listing.
const STRUCTURED_DATA = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: APP_NAME,
  applicationCategory: "WebApplication",
  operatingSystem: "Any (web)",
  description: APP_DESCRIPTION,
  url: APP_URL,
  offers: [
    {
      "@type": "Offer",
      price: "0",
      priceCurrency: "USD",
      name: "Free forever",
      description: "3 sites, 100 leads/month, free subdomain, custom domain support",
    },
  ],
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('theme');if(t==='dark'||(t!=='light'&&window.matchMedia('(prefers-color-scheme:dark)').matches)){document.documentElement.classList.add('dark')}}catch(e){}})()`,
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(STRUCTURED_DATA) }}
        />
      </head>
      <body
        className={`${inter.className} bg-white dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors`}
      >
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
