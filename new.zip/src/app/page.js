import Navbar from '@/components/Navbar';
import LandingClient from '@/components/LandingClient';
import prisma from '@/lib/prisma';

// Real social-proof numbers pulled from the DB.
// Cached at the route level so the landing page is fast under load.
async function getLandingStats() {
  try {
    const [siteCount, submissionCount, userCount] = await Promise.all([
      prisma.site.count({ where: { isActive: true } }),
      prisma.formSubmission.count(),
      prisma.user.count({ where: { deletedAt: null } }),
    ]);
    return { siteCount, submissionCount, userCount };
  } catch {
    // DB is down → don't crash the landing. Render with safe defaults.
    return { siteCount: 0, submissionCount: 0, userCount: 0 };
  }
}

// Refresh hourly so the numbers stay realistic without thrashing the DB.
export const revalidate = 3600;

export default async function HomePage() {
  const stats = await getLandingStats();
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 overflow-hidden">
      <Navbar />
      <LandingClient stats={stats} />
    </div>
  );
}
