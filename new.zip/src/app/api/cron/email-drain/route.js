import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { drainEmailQueue } from '@/lib/email';
import { audit } from '@/lib/audit';

// POST /api/cron/email-drain
// Drains pending emails. Run every 1-5 minutes via cron.
export async function POST(request) {
  const cronSecret = process.env.CRON_SECRET;
  if (!cronSecret || cronSecret.length < 16) {
    console.error('[CRON] email-drain: CRON_SECRET unset or too short — refusing to run');
    return NextResponse.json({ error: 'CRON_SECRET not configured' }, { status: 500 });
  }

  const authHeader = request.headers.get('authorization') || '';
  const expected = `Bearer ${cronSecret}`;
  const a = Buffer.from(authHeader);
  const b = Buffer.from(expected);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    await audit({ action: 'cron.unauthorized', target: 'email-drain' });
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const url = new URL(request.url);
  const batchSize = Math.min(200, Math.max(1, parseInt(url.searchParams.get('batchSize') || '50', 10) || 50));

  try {
    const stats = await drainEmailQueue({ batchSize });
    return NextResponse.json({ ok: true, stats });
  } catch (err) {
    console.error('[CRON] email-drain error:', err?.message || err);
    return NextResponse.json({ error: 'drain_failed' }, { status: 500 });
  }
}
