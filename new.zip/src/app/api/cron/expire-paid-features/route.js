import { NextResponse } from 'next/server';
import crypto from 'crypto';
import prisma from '@/lib/prisma';
import { audit } from '@/lib/audit';

// POST /api/cron/expire-paid-features
//
// B-PAY-06 — Daily job that flips expired paid entitlements:
//   1. Plan-level: users whose currentPeriodEndsAt has lapsed → planSlug='free',
//      subscriptionStatus='expired'. Sites stay LIVE (A-9). Only paid feature
//      gates lapse.
//   2. Marketplace: featurepurchase rows whose expiresAt < now and status='active'
//      → status='expired'.
//
// Auth: Authorization: Bearer ${CRON_SECRET}.  Fails closed if CRON_SECRET unset.
export async function POST(request) {
  const cronSecret = process.env.CRON_SECRET;
  if (!cronSecret || cronSecret.length < 16) {
    console.error('[CRON] expire-paid-features: CRON_SECRET unset or too short — refusing to run');
    return NextResponse.json({ error: 'CRON_SECRET not configured' }, { status: 500 });
  }

  const authHeader = request.headers.get('authorization') || '';
  const expected = `Bearer ${cronSecret}`;
  const a = Buffer.from(authHeader);
  const b = Buffer.from(expected);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    await audit({
      action: 'cron.unauthorized',
      target: 'expire-paid-features',
      details: { provided_length: authHeader.length },
    });
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const now = new Date();
  const summary = { plansLapsed: 0, purchasesLapsed: 0, errors: [] };

  // 1) Plan-level lapses
  try {
    const lapsedUsers = await prisma.user.findMany({
      where: {
        role: { not: 'superadmin' },
        planSlug: { not: 'free' },
        currentPeriodEndsAt: { lt: now },
        subscriptionStatus: { not: 'expired' },
      },
      select: { id: true, email: true },
      take: 1000,
    });

    for (const u of lapsedUsers) {
      try {
        await prisma.user.update({
          where: { id: u.id },
          data: {
            planSlug: 'free',
            subscriptionStatus: 'expired',
            currentPeriodEndsAt: null,
          },
        });
        await audit({ action: 'plan.lapsed', userId: u.id, target: u.email });
        summary.plansLapsed += 1;
      } catch (err) {
        console.error('[CRON] plan lapse failed for user', u.id, err?.message || err);
        summary.errors.push({ where: 'plan', userId: u.id, error: String(err?.message || err) });
      }
    }
  } catch (err) {
    console.error('[CRON] plan lapse sweep failed', err);
    summary.errors.push({ where: 'plan_sweep', error: String(err?.message || err) });
  }

  // 2) Marketplace feature lapses
  try {
    const lapsedPurchases = await prisma.featurepurchase.findMany({
      where: {
        status: 'active',
        expiresAt: { not: null, lt: now },
      },
      select: { id: true, userId: true, featureId: true },
      take: 5000,
    });

    if (lapsedPurchases.length > 0) {
      const ids = lapsedPurchases.map((p) => p.id);
      const updated = await prisma.featurepurchase.updateMany({
        where: { id: { in: ids } },
        data: { status: 'expired' },
      });
      summary.purchasesLapsed = updated.count;

      // One audit row summarising — avoids 5000 individual rows.
      await audit({
        action: 'feature.purchases_expired',
        details: { count: updated.count },
      });
    }
  } catch (err) {
    console.error('[CRON] feature lapse sweep failed', err);
    summary.errors.push({ where: 'feature_sweep', error: String(err?.message || err) });
  }

  return NextResponse.json({ ok: true, summary });
}
