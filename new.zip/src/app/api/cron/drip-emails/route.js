import crypto from 'crypto';
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import {
  dripDay2Template,
  dripDay7Template,
  dripDay14Template,
} from '@/lib/email-templates';

// POST /api/cron/drip-emails
// Run daily via cron job. Protected by CRON_SECRET.
// Sends Day 2, Day 7, Day 14 drip emails based on user signup date.
export async function POST(request) {
  const authHeader = request.headers.get('authorization');
  const cronSecret = process.env.CRON_SECRET;

  // Match the safety floor used by the email-drain cron — without a minimum
  // length requirement an operator could leave CRON_SECRET=x and brute-forcing
  // the cron endpoint would be trivial.
  if (!cronSecret || cronSecret.length < 16) {
    console.error('[CRON] drip-emails: CRON_SECRET unset or too short — refusing to run');
    return NextResponse.json({ error: 'CRON_SECRET not configured' }, { status: 500 });
  }

  const expected = `Bearer ${cronSecret}`;
  const actual = authHeader || '';
  if (actual.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(expected))) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const now = new Date();
    const results = { day2: 0, day7: 0, day14: 0, errors: 0 };

    // Day 2 drip: users created 2 days ago, lastDripStep = 0
    const day2Cutoff = new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000);
    const day2Users = await prisma.user.findMany({
      where: {
        lastDripStep: 0,
        createdAt: { lte: day2Cutoff },
      },
      select: { id: true, name: true, email: true },
      take: 100,
    });

    for (const user of day2Users) {
      try {
        const { subject, html, text } = dripDay2Template(user.name);
        await sendEmail({ to: user.email, subject, html, text });
        await prisma.user.update({ where: { id: user.id }, data: { lastDripStep: 1 } });
        results.day2++;
      } catch (err) {
        console.error(`Drip day2 failed for ${user.email}:`, err);
        results.errors++;
      }
    }

    // Day 7 drip: users created 7 days ago, lastDripStep = 1
    const day7Cutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const day7Users = await prisma.user.findMany({
      where: {
        lastDripStep: 1,
        createdAt: { lte: day7Cutoff },
      },
      select: { id: true, name: true, email: true },
      take: 100,
    });

    for (const user of day7Users) {
      try {
        const [siteCount, submissionCount] = await Promise.all([
          prisma.site.count({ where: { userId: user.id } }),
          prisma.formSubmission.count({ where: { site: { userId: user.id } } }),
        ]);
        const { subject, html, text } = dripDay7Template(user.name, siteCount, submissionCount);
        await sendEmail({ to: user.email, subject, html, text });
        await prisma.user.update({ where: { id: user.id }, data: { lastDripStep: 2 } });
        results.day7++;
      } catch (err) {
        console.error(`Drip day7 failed for ${user.email}:`, err);
        results.errors++;
      }
    }

    // Day 14 drip: users created 14 days ago, lastDripStep = 2
    const day14Cutoff = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
    const day14Users = await prisma.user.findMany({
      where: {
        lastDripStep: 2,
        createdAt: { lte: day14Cutoff },
      },
      select: { id: true, name: true, email: true },
      take: 100,
    });

    for (const user of day14Users) {
      try {
        const submissionCount = await prisma.formSubmission.count({
          where: { site: { userId: user.id } },
        });
        const { subject, html, text } = dripDay14Template(user.name, submissionCount);
        await sendEmail({ to: user.email, subject, html, text });
        await prisma.user.update({ where: { id: user.id }, data: { lastDripStep: 3 } });
        results.day14++;
      } catch (err) {
        console.error(`Drip day14 failed for ${user.email}:`, err);
        results.errors++;
      }
    }

    return NextResponse.json({ success: true, ...results });
  } catch (error) {
    console.error('Drip email cron error:', error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
