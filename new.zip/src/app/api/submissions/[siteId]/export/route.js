import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

const ALLOWED_STATUSES = ['new', 'read', 'contacted', 'won', 'lost', 'spam'];
const MAX_EXPORT_ROWS = 10_000;

function csvEscape(value) {
  const s = value == null ? '' : String(value);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

// GET /api/submissions/[siteId]/export?q=&from=&to=&status=
// Streams a CSV of every submission matching the filters. Capped at 10k rows.
export async function GET(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return new Response('Unauthorized', { status: 401 });

  const workspace = await getWorkspaceContext(session.user.id);
  if (!hasPermission(workspace, 'view_submissions')) {
    return new Response('Forbidden', { status: 403 });
  }

  const ownerId = workspace?.workspaceOwnerId || session.user.id;
  const site = await prisma.site.findFirst({
    where: { id: params.siteId, userId: ownerId },
    select: { id: true, name: true, subdomain: true },
  });
  if (!site) return new Response('Site not found', { status: 404 });

  const { searchParams } = new URL(request.url);
  const q = (searchParams.get('q') || '').trim();
  const from = searchParams.get('from');
  const to = searchParams.get('to');
  const status = searchParams.get('status');

  const where = { siteId: site.id };
  if (q) {
    where.OR = [
      { formName: { contains: q } },
      { data: { contains: q } },
      { ipAddress: { contains: q } },
    ];
  }
  if (status && ALLOWED_STATUSES.includes(status)) {
    where.status = status;
  }
  if (from || to) {
    where.createdAt = {};
    if (from) where.createdAt.gte = new Date(from);
    if (to) where.createdAt.lte = new Date(to);
  }

  // Pull all rows up to the cap
  const rows = await prisma.formSubmission.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: MAX_EXPORT_ROWS,
  });

  // Discover the union of data keys
  const allKeys = new Set();
  const parsed = rows.map((r) => {
    let data = {};
    try { data = JSON.parse(r.data); } catch { /* corrupted row → skip data fields */ }
    Object.keys(data).forEach((k) => allKeys.add(k));
    return { ...r, _parsed: data };
  });

  const dataKeys = [...allKeys];
  const headers = ['ID', 'Date', 'Form', 'Status', ...dataKeys, 'IP', 'User Agent'];
  const lines = [headers.map(csvEscape).join(',')];

  for (const r of parsed) {
    const row = [
      r.id,
      new Date(r.createdAt).toISOString(),
      r.formName,
      r.status || 'new',
      ...dataKeys.map((k) => r._parsed?.[k] ?? ''),
      r.ipAddress || '',
      r.userAgent || '',
    ];
    lines.push(row.map(csvEscape).join(','));
  }

  const csv = lines.join('\n');
  const filename = `${site.subdomain || 'site'}-submissions-${new Date().toISOString().split('T')[0]}.csv`;

  return new Response(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Cache-Control': 'no-store',
    },
  });
}
