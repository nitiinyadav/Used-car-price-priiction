import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { auditFromRequest } from '@/lib/audit';

const ALLOWED_STATUSES = ['new', 'read', 'contacted', 'won', 'lost', 'spam'];

// PATCH /api/submissions/[siteId]/[submissionId]
//   Body: { status?, isRead?, notes? }
// Update lead-inbox state on a single submission.
export async function PATCH(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'view_submissions')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const ownerId = workspace?.workspaceOwnerId || session.user.id;
    const site = await prisma.site.findFirst({
      where: { id: params.siteId, userId: ownerId },
      select: { id: true },
    });
    if (!site) return NextResponse.json({ error: 'Site not found' }, { status: 404 });

    const submission = await prisma.formSubmission.findFirst({
      where: { id: params.submissionId, siteId: site.id },
      select: { id: true },
    });
    if (!submission) return NextResponse.json({ error: 'Submission not found' }, { status: 404 });

    const body = await request.json().catch(() => ({}));
    const data = {};
    if (typeof body.status === 'string' && ALLOWED_STATUSES.includes(body.status)) {
      data.status = body.status;
    }
    if (typeof body.isRead === 'boolean') {
      data.isRead = body.isRead;
    }
    if (typeof body.notes === 'string') {
      data.notes = body.notes.slice(0, 4000);
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ error: 'No valid fields to update' }, { status: 400 });
    }

    const updated = await prisma.formSubmission.update({
      where: { id: submission.id },
      data,
    });

    await auditFromRequest(request, {
      action: 'submission.update',
      userId: session.user.id,
      target: submission.id,
      details: data,
    });

    return NextResponse.json({ ok: true, submission: updated });
  } catch (error) {
    console.error('Update submission error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/submissions/[siteId]/[submissionId]
export async function DELETE(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'view_submissions')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const ownerId = workspace?.workspaceOwnerId || session.user.id;
    const site = await prisma.site.findFirst({
      where: { id: params.siteId, userId: ownerId },
      select: { id: true },
    });
    if (!site) return NextResponse.json({ error: 'Site not found' }, { status: 404 });

    await prisma.formSubmission.deleteMany({
      where: { id: params.submissionId, siteId: site.id },
    });

    await auditFromRequest(request, {
      action: 'submission.delete',
      userId: session.user.id,
      target: params.submissionId,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('Delete submission error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
