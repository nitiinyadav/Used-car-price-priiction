import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { auditFromRequest } from '@/lib/audit';

// POST /api/sites/[id]/test-submission
//
// Send a synthetic submission to the site's own form endpoint. Used by the
// dashboard "Send test submission" button so the user can verify their form
// setup end-to-end without leaving the dashboard. Marked as test in the data.
export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const site = await prisma.site.findFirst({
      where: { id: params.id, userId: session.user.id },
      select: { id: true, name: true, apiKey: true, isActive: true, honeypotField: true },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    if (!site.isActive) {
      return NextResponse.json(
        { error: 'Site is inactive — re-enable it to send test submissions.' },
        { status: 400 }
      );
    }

    const submission = await prisma.formSubmission.create({
      data: {
        siteId: site.id,
        formName: 'test',
        data: JSON.stringify({
          name: 'LiveInSec Test User',
          email: 'test@liveinsec.com',
          message: `Test submission sent from your dashboard at ${new Date().toISOString()}.`,
          _source: 'dashboard_test_button',
        }),
        ipAddress: '127.0.0.1',
        userAgent: 'LiveInSec-Dashboard-Test',
        status: 'new',
      },
    });

    await auditFromRequest(request, {
      action: 'site.test_submission',
      userId: session.user.id,
      target: site.id,
      details: { submissionId: submission.id },
    });

    return NextResponse.json({
      ok: true,
      submissionId: submission.id,
      message: `Test submission delivered to "${site.name}". Open the Submissions tab to see it.`,
    });
  } catch (error) {
    console.error('Test submission error:', error);
    return NextResponse.json({ error: 'Failed to send test submission' }, { status: 500 });
  }
}
