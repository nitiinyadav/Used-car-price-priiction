import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

/**
 * Walk every text-like file in the site directory and swap the OLD api key for
 * the NEW one. Without this, rotating the key silently breaks every form on
 * the deployed site — the HTML still POSTs to /api/forms/{oldKey}, which 404s
 * because the DB no longer recognises that key. Run this AFTER the DB rotation
 * so the new key is the authoritative one if the rewrite partially fails.
 */
function rewireDeployedKey(deployPath, oldKey, newKey) {
  if (!deployPath || !oldKey || !newKey || oldKey === newKey) return;
  if (!fs.existsSync(deployPath)) return;

  const escaped = oldKey.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const oldKeyRegex = new RegExp(escaped, 'g');

  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(fullPath);
        continue;
      }
      if (!/\.(html?|md|txt|json|js|css)$/i.test(entry.name)) continue;
      try {
        const original = fs.readFileSync(fullPath, 'utf-8');
        const updated = original.replace(oldKeyRegex, newKey);
        if (updated !== original) {
          fs.writeFileSync(fullPath, updated, 'utf-8');
        }
      } catch (err) {
        console.error('Key rewrite failed for', fullPath, err?.message || err);
      }
    }
  }

  walk(deployPath);
}

// POST /api/sites/[id]/regenerate-key — Regenerate site API key (L-02)
export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const workspace = await getWorkspaceContext(session.user.id);
    if (workspace && !hasPermission(workspace, 'manage_sites')) {
      return NextResponse.json({ error: 'Permission denied' }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const oldApiKey = site.apiKey;
    const newApiKey = `lk_${crypto.randomBytes(24).toString('hex')}`;

    const updated = await prisma.site.update({
      where: { id: params.id },
      data: { apiKey: newApiKey },
      select: { id: true, apiKey: true },
    });

    // Rotate the key inside the deployed HTML so existing forms keep working
    // automatically. Best-effort — if the disk rewrite fails, we still return
    // success since the DB-side rotation completed and the user can redeploy.
    try {
      rewireDeployedKey(site.deployPath, oldApiKey, newApiKey);
    } catch (err) {
      console.error('Deployed-files key rewrite skipped:', err?.message || err);
    }

    return NextResponse.json({
      success: true,
      apiKey: updated.apiKey,
      message:
        'API key regenerated. Forms in your deployed files were updated automatically.',
    });
  } catch (error) {
    console.error('Regenerate API key error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
