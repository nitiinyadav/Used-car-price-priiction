export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { getLiveVisitorCount } from '@/lib/live-presence';

export async function GET(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const workspace = await getWorkspaceContext(session.user.id);
  if (!hasPermission(workspace, 'view_analytics')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const site = await prisma.site.findFirst({
    where: {
      id: params.id,
      userId: workspace?.workspaceOwnerId || session.user.id,
    },
    select: { id: true },
  });

  if (!site) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  return NextResponse.json({
    siteId: site.id,
    count: getLiveVisitorCount(site.id),
  });
}
