import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { extractZip, getSiteDir } from "@/lib/storage";
import {
  generateApiKey,
  isZipFile,
  normalizeDomain,
  validateSubdomain,
  validateDomain,
  RESERVED_SUBDOMAINS,
} from "@/lib/utils";
import { canUseFeature } from "@/lib/feature-access";
import { serializeAllowedOrigins } from "@/lib/site-security";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";
import { wireFormPlaceholdersInDeployedFiles } from "@/lib/form-wiring";
import fs from "fs";
import path from "path";

// GET /api/sites - List user's sites
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);

    const sites = await prisma.site.findMany({
      where: { userId: workspace?.workspaceOwnerId || session.user.id },
      include: { _count: { select: { formsubmission: true } } },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({ sites });
  } catch (error) {
    console.error("List sites error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}

// POST /api/sites - Create and deploy a new site
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, "create_sites")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const formData = await request.formData();
    const name = formData.get("name");
    const subdomain = formData.get("subdomain");
    const customDomainValue = formData.get("customDomain");
    const customDomain = customDomainValue
      ? normalizeDomain(customDomainValue)
      : null;
    const file = formData.get("file");
    const editorFilesBlob = formData.get("editorFiles");

    // Require verified email before deploying
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { emailVerifiedAt: true },
    });
    if (!user?.emailVerifiedAt) {
      return NextResponse.json(
        { error: "Please verify your email address before deploying a site." },
        { status: 403 },
      );
    }

    // Validate required fields
    if (!name || !subdomain || (!file && !editorFilesBlob)) {
      return NextResponse.json(
        { error: "Name, subdomain, and files are required" },
        { status: 400 },
      );
    }

    // Validate subdomain format
    const subdomainLower = subdomain.toLowerCase().trim();
    if (!validateSubdomain(subdomainLower)) {
      return NextResponse.json(
        {
          error:
            "Invalid subdomain. Use lowercase letters, numbers, and hyphens. Min 3 characters.",
        },
        { status: 400 },
      );
    }

    // Check reserved subdomains
    if (RESERVED_SUBDOMAINS.includes(subdomainLower)) {
      return NextResponse.json(
        { error: "This subdomain is reserved and cannot be used" },
        { status: 400 },
      );
    }

    // Check subdomain availability
    const existingSite = await prisma.site.findUnique({
      where: { subdomain: subdomainLower },
    });
    if (existingSite) {
      return NextResponse.json(
        { error: "This subdomain is already taken" },
        { status: 409 },
      );
    }

    // Check custom domain if provided
    if (customDomain) {
      if (!validateDomain(customDomain)) {
        return NextResponse.json(
          { error: "Please enter a valid custom domain like www.example.com" },
          { status: 400 },
        );
      }

      const existingCustom = await prisma.site.findUnique({
        where: { customDomain },
      });
      if (existingCustom) {
        return NextResponse.json(
          { error: "This custom domain is already in use" },
          { status: 409 },
        );
      }
    }

    // Check if user can use custom domain feature
    const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
    if (customDomain && session.user.role !== 'superadmin') {
      const canUseDomain = await canUseFeature(workspaceOwnerId, 'custom-domain');
      if (!canUseDomain) {
        return NextResponse.json(
          {
            error:
              "Custom domains require a purchase. Please buy the Custom Domain feature from the Feature Store.",
          },
          { status: 403 },
        );
      }
    }

    // Validate file (ZIP upload path)
    if (file) {
      if (!file?.name || !isZipFile(file.name)) {
        return NextResponse.json(
          { error: "Only ZIP files are accepted" },
          { status: 400 },
        );
      }

      const maxSize =
        parseInt(process.env.MAX_UPLOAD_SIZE_MB || "10", 10) * 1024 * 1024;
      if (file.size > maxSize) {
        return NextResponse.json(
          {
            error: `File size exceeds the maximum of ${process.env.MAX_UPLOAD_SIZE_MB || 10}MB`,
          },
          { status: 400 },
        );
      }
    }

    // Validate editor files
    let editorFilesData = null;
    if (editorFilesBlob) {
      try {
        const text = await editorFilesBlob.text();
        editorFilesData = JSON.parse(text);
        if (
          typeof editorFilesData !== "object" ||
          !editorFilesData["index.html"]
        ) {
          return NextResponse.json(
            { error: "Editor files must include index.html" },
            { status: 400 },
          );
        }
      } catch {
        return NextResponse.json(
          { error: "Invalid editor files data" },
          { status: 400 },
        );
      }
    }

    // Create site record
    const apiKey = generateApiKey();
    const site = await prisma.site.create({
      data: {
        name: name.trim(),
        subdomain: subdomainLower,
        customDomain: customDomain || null,
        apiKey,
        deployPath: "", // Will update after extraction
        allowedOrigins: serializeAllowedOrigins(""),
        honeypotField: "company",
        submissionRateLimit: 10,
        userId: workspaceOwnerId,
      },
    });

    // Deploy files
    try {
      let deployPath;
      if (editorFilesData) {
        // Editor files: write directly to site directory
        const siteDir = getSiteDir(site.id);
        if (fs.existsSync(siteDir)) {
          fs.rmSync(siteDir, { recursive: true, force: true });
        }
        fs.mkdirSync(siteDir, { recursive: true });
        const resolvedSiteDir = path.resolve(siteDir);
        for (const [filePath, content] of Object.entries(editorFilesData)) {
          const sanitized = filePath.replace(/\.\./g, "").replace(/^\//, "");
          const targetPath = path.resolve(siteDir, sanitized);
          if (
            !targetPath.startsWith(resolvedSiteDir + path.sep) &&
            targetPath !== resolvedSiteDir
          ) {
            continue;
          }
          const dir = path.dirname(targetPath);
          if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
          }
          fs.writeFileSync(targetPath, content, "utf-8");
        }
        deployPath = siteDir;
      } else {
        // ZIP upload: extract
        const buffer = Buffer.from(await file.arrayBuffer());
        deployPath = await extractZip(buffer, site.id);
      }

      // Auto-wire any form placeholders so contact forms work on first visit.
      try {
        wireFormPlaceholdersInDeployedFiles(deployPath, apiKey);
      } catch (rewriteErr) {
        console.error("Form placeholder rewrite skipped:", rewriteErr?.message || rewriteErr);
      }

      await prisma.site.update({
        where: { id: site.id },
        data: { deployPath },
      });
    } catch (extractError) {
      // Cleanup on failure
      await prisma.site.delete({ where: { id: site.id } });
      console.error("Deploy error:", extractError);
      return NextResponse.json(
        {
          error:
            extractError instanceof Error
              ? extractError.message
              : "Failed to deploy files.",
        },
        { status: 400 },
      );
    }

    const createdSite = await prisma.site.findUnique({
      where: { id: site.id },
      include: { _count: { select: { formsubmission: true } } },
    });

    const appUrl = (process.env.NEXT_PUBLIC_APP_URL || "").replace(/\/$/, "");
    const responseSite = {
      ...createdSite,
      formEndpoint: appUrl ? `${appUrl}/api/forms/${createdSite.apiKey}` : `/api/forms/${createdSite.apiKey}`,
    };

    return NextResponse.json({ site: responseSite }, { status: 201 });
  } catch (error) {
    console.error("Create site error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
