import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { featurePurchaseReceiptTemplate } from '@/lib/email-templates';
import { auditFromRequest } from '@/lib/audit';

// POST /api/feature-checkout/verify — Verify Razorpay payment + activate purchases.
// Hardened (A-10) against replay, double-spend, amount tampering, currency mismatch.
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderId, razorpayPaymentId, razorpaySignature } = await request.json();

    if (
      !orderId || !razorpayPaymentId || !razorpaySignature ||
      typeof orderId !== 'string' ||
      typeof razorpayPaymentId !== 'string' ||
      typeof razorpaySignature !== 'string'
    ) {
      return NextResponse.json({ error: 'Missing or invalid payment fields' }, { status: 400 });
    }

    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret || razorpayKeySecret.length < 10) {
      return NextResponse.json({ error: 'Payment secret not configured' }, { status: 500 });
    }

    // Run the full verify-and-activate as one interactive transaction.
    const result = await prisma.$transaction(async (tx) => {
      const order = await tx.featureorder.findFirst({
        where: { userId: session.user.id, razorpayOrderId: orderId },
        include: { orderitem: { include: { feature: true } } },
      });

      if (!order) return { error: 'Order not found', status: 404, code: 'order_not_found' };

      // Replay defense (A-10): once a signature has been accepted for this order,
      // any further verify attempt is a replay — even if the payment id/signature
      // arrive identical, we refuse to re-touch the entitlements.
      if (order.signatureUsedAt) {
        return {
          error: 'This payment has already been verified',
          status: 409,
          code: 'replay_blocked',
          orderId: order.id,
          alreadyVerified: true,
        };
      }

      // Idempotency: if already paid (legacy data without signatureUsedAt set),
      // surface a friendly success rather than re-creating purchases.
      if (order.status === 'paid') {
        return { success: true, idempotent: true, orderId: order.id };
      }

      if (order.status === 'failed') {
        return { error: 'This order is in a failed state', status: 400, code: 'order_failed' };
      }

      // L-09: Reject verification if the order is older than 30 minutes
      const orderAge = Date.now() - new Date(order.createdAt).getTime();
      if (orderAge > 30 * 60 * 1000) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: { status: 'failed' },
        });
        return { error: 'Order expired. Please create a new checkout.', status: 400, code: 'order_expired' };
      }

      // HMAC signature check
      const expectedSig = crypto
        .createHmac('sha256', razorpayKeySecret)
        .update(`${orderId}|${razorpayPaymentId}`)
        .digest('hex');

      // Constant-time compare
      const sigBufA = Buffer.from(expectedSig, 'utf8');
      const sigBufB = Buffer.from(razorpaySignature, 'utf8');
      const sigOk = sigBufA.length === sigBufB.length && crypto.timingSafeEqual(sigBufA, sigBufB);

      if (!sigOk) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: { status: 'failed', razorpayPaymentId, razorpaySignature },
        });
        return { error: 'Payment signature verification failed', status: 400, code: 'bad_signature' };
      }

      // Amount integrity check (defense against tampered Razorpay events)
      const itemsSum = order.orderitem.reduce((sum, oi) => sum + oi.totalPrice, 0);
      const storedTotal = order.currency === 'INR' ? order.totalAmountInr : order.totalAmountUsd;
      if (itemsSum !== storedTotal) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: { status: 'failed', razorpayPaymentId, razorpaySignature },
        });
        return { error: 'Order amount integrity check failed', status: 400, code: 'amount_mismatch' };
      }

      // All checks passed. Atomically: flip order to paid + lock signature + create entitlements + clear cart.
      const now = new Date();

      await tx.featureorder.update({
        where: { id: order.id },
        data: {
          status: 'paid',
          razorpayPaymentId,
          razorpaySignature,
          signatureUsedAt: now,
        },
      });

      const createdPurchases = [];
      for (const oi of order.orderitem) {
        let expiresAt = null;
        if (oi.durationDays) {
          // Duration semantic: total = durationDays * quantity (kept compatible with PART D Phase 1)
          expiresAt = new Date(now.getTime() + oi.durationDays * oi.quantity * 24 * 60 * 60 * 1000);
        }
        const purchase = await tx.featurepurchase.create({
          data: {
            userId: session.user.id,
            featureId: oi.featureId,
            quantity: oi.quantity,
            expiresAt,
            amountPaid: oi.totalPrice,
            currency: order.currency,
            razorpayPaymentId,
            orderId: order.id,
            status: 'active',
          },
        });
        createdPurchases.push({
          feature: oi.feature.name,
          slug: oi.feature.slug,
          quantity: oi.quantity,
          expiresAt: expiresAt ? expiresAt.toISOString() : null,
          amountPaid: oi.totalPrice,
          purchaseId: purchase.id,
        });
      }

      await tx.cartitem.deleteMany({ where: { userId: session.user.id } });

      return {
        success: true,
        orderId: order.id,
        purchases: createdPurchases,
        currency: order.currency,
        totalAmount: storedTotal,
      };
    });

    // Audit + email (outside the transaction)
    if (result.error) {
      await auditFromRequest(request, {
        action: result.code === 'replay_blocked' ? 'purchase.replay_blocked' : 'purchase.failed',
        userId: session.user.id,
        target: orderId,
        details: { code: result.code, reason: result.error },
      });
      return NextResponse.json({ error: result.error, code: result.code }, { status: result.status || 500 });
    }

    if (result.idempotent) {
      // Already-paid order being re-verified (no new entitlements created); not a security issue.
      return NextResponse.json({ success: true, idempotent: true, orderId: result.orderId });
    }

    await auditFromRequest(request, {
      action: 'purchase.success',
      userId: session.user.id,
      target: result.orderId,
      details: {
        items: result.purchases.map((p) => ({ slug: p.slug, qty: p.quantity })),
        currency: result.currency,
        amount: result.totalAmount,
      },
    });

    // Receipt email — fire-and-forget; queue layer in A-4 absorbs transient failures.
    if (session.user.email) {
      try {
        const emailData = featurePurchaseReceiptTemplate(
          session.user.name,
          result.purchases,
          result.totalAmount,
          result.currency,
          result.orderId
        );
        sendEmail({ to: session.user.email, ...emailData }).catch((err) =>
          console.error('[PURCHASE EMAIL] Failed:', err?.message || err)
        );
      } catch (e) {
        console.error('[PURCHASE EMAIL] Build error:', e);
      }
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Feature verify error:', error);
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 500 });
  }
}
