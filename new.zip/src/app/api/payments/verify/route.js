import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { auditFromRequest } from '@/lib/audit';

// POST /api/payments/verify — Verify Razorpay payment for plan upgrades.
// Hardened (A-10) against replay, double-spend, signature reuse.
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderId, razorpayPaymentId, razorpaySignature } = await request.json();

    if (
      !orderId || !razorpayPaymentId || !razorpaySignature ||
      typeof orderId !== 'string' ||
      typeof razorpayPaymentId !== 'string' ||
      typeof razorpaySignature !== 'string'
    ) {
      return NextResponse.json({ error: 'Missing or invalid payment fields' }, { status: 400 });
    }

    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret || razorpayKeySecret.length < 10) {
      return NextResponse.json({ error: 'Razorpay secret not configured' }, { status: 500 });
    }

    const result = await prisma.$transaction(async (tx) => {
      const payment = await tx.payment.findFirst({
        where: { userId: session.user.id, providerOrderId: orderId },
      });

      if (!payment) return { error: 'Pending checkout not found', status: 404, code: 'order_not_found' };

      // Replay defense (A-10)
      if (payment.signatureUsedAt) {
        return {
          error: 'This payment has already been verified',
          status: 409,
          code: 'replay_blocked',
          paymentId: payment.id,
        };
      }

      if (payment.status === 'completed') {
        // Legacy data without signatureUsedAt set — treat as idempotent success.
        return {
          success: true,
          idempotent: true,
          plan: payment.planSlug,
          expiresAt: payment.expiresAt.toISOString(),
        };
      }

      if (payment.status === 'failed') {
        return { error: 'This payment is in a failed state', status: 400, code: 'payment_failed' };
      }

      // Order age cap — 30 minutes
      if (Date.now() - new Date(payment.createdAt).getTime() > 30 * 60 * 1000) {
        await tx.payment.update({ where: { id: payment.id }, data: { status: 'failed' } });
        return { error: 'Order expired. Please retry checkout.', status: 400, code: 'order_expired' };
      }

      const expectedSig = crypto
        .createHmac('sha256', razorpayKeySecret)
        .update(`${orderId}|${razorpayPaymentId}`)
        .digest('hex');

      const sigBufA = Buffer.from(expectedSig, 'utf8');
      const sigBufB = Buffer.from(razorpaySignature, 'utf8');
      const sigOk = sigBufA.length === sigBufB.length && crypto.timingSafeEqual(sigBufA, sigBufB);

      if (!sigOk) {
        await tx.payment.update({
          where: { id: payment.id },
          data: {
            status: 'failed',
            providerPaymentId: razorpayPaymentId,
            providerSignature: razorpaySignature,
          },
        });
        return { error: 'Payment signature verification failed', status: 400, code: 'bad_signature' };
      }

      // Compute new period — chain from existing currentPeriodEndsAt if user is renewing
      const user = await tx.user.findUnique({
        where: { id: session.user.id },
        select: { currentPeriodEndsAt: true },
      });
      const now = new Date();
      const startsAt =
        user?.currentPeriodEndsAt && new Date(user.currentPeriodEndsAt) > now
          ? new Date(user.currentPeriodEndsAt)
          : now;
      const expiresAt = new Date(startsAt);
      if (payment.billingPeriod === 'yearly') {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      } else {
        expiresAt.setMonth(expiresAt.getMonth() + 1);
      }

      await tx.payment.update({
        where: { id: payment.id },
        data: {
          status: 'completed',
          startsAt,
          expiresAt,
          providerPaymentId: razorpayPaymentId,
          providerSignature: razorpaySignature,
          transactionId: razorpayPaymentId,
          signatureUsedAt: now,
        },
      });

      await tx.user.update({
        where: { id: session.user.id },
        data: {
          planSlug: payment.planSlug,
          subscriptionStatus: 'active',
          billingPeriod: payment.billingPeriod,
          billingCurrency: payment.currency,
          currentPeriodEndsAt: expiresAt,
          trialEndsAt: null,
        },
      });

      return {
        success: true,
        plan: payment.planSlug,
        billingPeriod: payment.billingPeriod,
        billingCurrency: payment.currency,
        expiresAt: expiresAt.toISOString(),
      };
    });

    if (result.error) {
      await auditFromRequest(request, {
        action: result.code === 'replay_blocked' ? 'payment.replay_blocked' : 'payment.failed',
        userId: session.user.id,
        target: orderId,
        details: { code: result.code, reason: result.error },
      });
      return NextResponse.json({ error: result.error, code: result.code }, { status: result.status || 500 });
    }

    if (!result.idempotent) {
      await auditFromRequest(request, {
        action: 'payment.success',
        userId: session.user.id,
        target: orderId,
        details: { plan: result.plan, billingPeriod: result.billingPeriod, currency: result.billingCurrency },
      });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Payment verification error:', error);
    return NextResponse.json({ error: 'Failed to verify payment' }, { status: 500 });
  }
}
