import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { deleteSiteFiles } from '@/lib/storage';
import { requireSuperAdmin } from '@/lib/admin-auth';
import { auditFromRequest } from '@/lib/audit';

const ALLOWED_PLANS = ['free', 'starter', 'pro', 'enterprise']; // legacy; D-3 will narrow to ['free','pro']
const ALLOWED_ROLES = ['user', 'superadmin'];

// PUT /api/admin/users/[id] - Update user
export async function PUT(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const user = await prisma.user.findUnique({ where: { id: params.id } });
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Prevent modifying other super admins
    if (user.role === 'superadmin' && user.id !== session.user.id) {
      return NextResponse.json({ error: 'Cannot modify other super admins' }, { status: 403 });
    }

    const body = await request.json();
    const updateData = {};

    if (body.plan && ALLOWED_PLANS.includes(body.plan)) {
      updateData.planSlug = body.plan;
      // Reset subscription state on admin-driven plan change so user isn't stuck "pro+expired"
      updateData.subscriptionStatus = body.plan === 'free' ? 'free' : 'active';
    }

    if (body.role && ALLOWED_ROLES.includes(body.role)) {
      updateData.role = body.role;
    }

    if (typeof body.name === 'string' && body.name.trim()) {
      updateData.name = body.name.trim().slice(0, 80);
    }

    if (typeof body.isBlocked === 'boolean') {
      updateData.isBlocked = body.isBlocked;
    }

    const updated = await prisma.user.update({
      where: { id: params.id },
      data: updateData,
    });

    await auditFromRequest(request, {
      action: 'admin.update_user',
      userId: session.user.id,
      target: params.id,
      details: updateData,
    });

    return NextResponse.json({
      user: {
        id: updated.id,
        name: updated.name,
        role: updated.role,
        plan: updated.planSlug,
        isBlocked: updated.isBlocked,
      },
    });
  } catch (error) {
    console.error('Admin update user error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/admin/users/[id] - Soft-delete user (B-ADM-03)
export async function DELETE(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const user = await prisma.user.findUnique({
      where: { id: params.id },
      include: { site: true }, // schema relation is `site` (not `sites`)
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    if (user.role === 'superadmin') {
      return NextResponse.json({ error: 'Cannot delete super admin accounts' }, { status: 403 });
    }

    const url = new URL(request.url);
    const hard = url.searchParams.get('hard') === '1';

    if (hard) {
      // Hard delete — remove files + cascade DB
      for (const site of user.site) {
        try { await deleteSiteFiles(site.id); } catch (e) { console.error('deleteSiteFiles failed', e); }
      }
      await prisma.user.delete({ where: { id: params.id } });
      await auditFromRequest(request, {
        action: 'admin.hard_delete_user',
        userId: session.user.id,
        target: params.id,
        details: { email: user.email, siteCount: user.site.length },
      });
    } else {
      // Soft delete — flag account, deactivate sites
      await prisma.$transaction([
        prisma.user.update({
          where: { id: params.id },
          data: { deletedAt: new Date(), isBlocked: true },
        }),
        prisma.site.updateMany({
          where: { userId: params.id },
          data: { isActive: false },
        }),
      ]);
      await auditFromRequest(request, {
        action: 'admin.soft_delete_user',
        userId: session.user.id,
        target: params.id,
        details: { email: user.email, siteCount: user.site.length },
      });
    }

    return NextResponse.json({ success: true, mode: hard ? 'hard' : 'soft' });
  } catch (error) {
    console.error('Admin delete user error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
