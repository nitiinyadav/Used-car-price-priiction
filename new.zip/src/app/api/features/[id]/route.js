import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { invalidateFeatureCache } from '@/lib/feature-access';
import { requireSuperAdmin } from '@/lib/admin-auth';
import { filterAdminPayload, getFeatureDef } from '@/lib/features-catalog';
import { auditFromRequest } from '@/lib/audit';

// Numeric coercion + clamps for the configurable fields.
function sanitize(field, raw) {
  if (raw === undefined || raw === null) return undefined;
  switch (field) {
    case 'priceUsd':
    case 'priceInr':
    case 'freeQuota':
    case 'publicQuota':
      const n = parseInt(raw, 10);
      return Number.isFinite(n) && n >= 0 ? n : undefined;
    case 'isActive':
      return raw === true || raw === 'true' || raw === 1 || raw === '1';
    default:
      return undefined;
  }
}

/**
 * PUT /api/features/[id]
 *
 * Admin updates the configurable knobs on a single feature. The set of editable
 * fields is declared per-feature in lib/features-catalog.js (`adminEditable`).
 * Anything else in the request body is ignored — admins cannot change slug,
 * type, name, description, etc. (that requires a code change to the catalog).
 */
export async function PUT(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const existing = await prisma.feature.findUnique({ where: { id: params.id } });
    if (!existing) {
      return NextResponse.json({ error: 'Feature not found' }, { status: 404 });
    }

    const def = getFeatureDef(existing.slug);
    if (!def) {
      return NextResponse.json(
        { error: `Feature "${existing.slug}" is no longer in the catalog. It cannot be edited.` },
        { status: 410 }
      );
    }

    const raw = await request.json().catch(() => ({}));
    const filtered = filterAdminPayload(existing.slug, raw);

    const data = {};
    for (const [k, v] of Object.entries(filtered)) {
      const sanitized = sanitize(k, v);
      if (sanitized !== undefined) data[k] = sanitized;
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json(
        {
          error: 'No editable fields supplied.',
          editable: def.adminEditable,
        },
        { status: 400 }
      );
    }

    const feature = await prisma.feature.update({ where: { id: params.id }, data });
    invalidateFeatureCache();

    await auditFromRequest(request, {
      action: 'admin.feature_update',
      userId: session.user.id,
      target: existing.slug,
      details: data,
    });

    return NextResponse.json({ feature });
  } catch (error) {
    console.error('Update feature error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/**
 * DELETE /api/features/[id]
 *
 * Disabled. The catalog is hardcoded; admins cannot remove features. To
 * temporarily hide a feature from the store, set `isActive: false` via PUT.
 */
export async function DELETE() {
  return NextResponse.json(
    {
      error:
        'Feature deletion is not supported. The catalog is hardcoded. To hide a feature, set isActive: false.',
    },
    { status: 405 }
  );
}
