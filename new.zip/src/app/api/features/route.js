import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { invalidateFeatureCache } from '@/lib/feature-access';
import { requireSuperAdmin } from '@/lib/admin-auth';
import { FEATURE_CATALOG, buildSeedRow } from '@/lib/features-catalog';
import { auditFromRequest } from '@/lib/audit';

// GET /api/features — List active features (public for store)
export async function GET() {
  try {
    const features = await prisma.feature.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
    return NextResponse.json({ features });
  } catch (error) {
    console.error('List features error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/**
 * POST /api/features
 *
 * Admin-only. The features catalog is HARDCODED in lib/features-catalog.js,
 * so this endpoint does NOT support free-form creation. Two modes:
 *
 *   { seed: true }              — sync DB rows from the catalog. Inserts missing
 *                                 features; for existing rows, only updates the
 *                                 metadata fields the admin can't tweak (name,
 *                                 description, icon, etc.). Pricing/freeQuota/
 *                                 isActive are preserved on existing rows.
 *
 *   { seed: true, hard: true }  — same as above but also overwrites pricing /
 *                                 freeQuota / isActive with defaults. Use with
 *                                 caution — undoes admin customisations.
 *
 * Direct creation of new features is not supported and returns 405.
 */
export async function POST(request) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json().catch(() => ({}));

    if (!body.seed) {
      return NextResponse.json(
        {
          error:
            'Feature creation is not supported. The catalog is hardcoded in lib/features-catalog.js. To add a feature, edit that file and redeploy.',
        },
        { status: 405 }
      );
    }

    const hard = !!body.hard;
    let created = 0;
    let updated = 0;
    let kept = 0;

    for (const def of FEATURE_CATALOG) {
      const seedRow = buildSeedRow(def);
      const existing = await prisma.feature.findUnique({ where: { slug: def.slug } });

      if (!existing) {
        await prisma.feature.create({ data: seedRow });
        created += 1;
        continue;
      }

      // Always update display metadata (name, description, icon, category, type,
      // limits, sidebar info, highlights). These should track the catalog.
      const baseUpdate = {
        name: seedRow.name,
        description: seedRow.description,
        icon: seedRow.icon,
        category: seedRow.category,
        type: seedRow.type,
        unitLabel: seedRow.unitLabel,
        minQty: seedRow.minQty,
        maxQty: seedRow.maxQty,
        stepQty: seedRow.stepQty,
        durationDays: seedRow.durationDays,
        isFeatured: seedRow.isFeatured,
        sortOrder: seedRow.sortOrder,
        showInSidebar: seedRow.showInSidebar,
        sidebarLabel: seedRow.sidebarLabel,
        sidebarIcon: seedRow.sidebarIcon,
        sidebarHref: seedRow.sidebarHref,
        highlights: seedRow.highlights,
      };

      const fullUpdate = hard
        ? {
            ...baseUpdate,
            priceUsd: seedRow.priceUsd,
            priceInr: seedRow.priceInr,
            freeQuota: seedRow.freeQuota,
            publicAccessType: seedRow.publicAccessType,
            publicQuota: seedRow.publicQuota,
            isActive: seedRow.isActive,
          }
        : baseUpdate;

      await prisma.feature.update({ where: { slug: def.slug }, data: fullUpdate });
      updated += 1;
    }

    // Disable any DB rows whose slug is no longer in the catalog (don't delete —
    // existing purchases reference them).
    const knownSlugs = FEATURE_CATALOG.map((f) => f.slug);
    const orphaned = await prisma.feature.updateMany({
      where: { slug: { notIn: knownSlugs }, isActive: true },
      data: { isActive: false },
    });

    invalidateFeatureCache();

    await auditFromRequest(request, {
      action: 'admin.features_seeded',
      userId: session.user.id,
      details: { created, updated, deactivated: orphaned.count, hard },
    });

    return NextResponse.json({
      success: true,
      created,
      updated,
      kept,
      deactivated: orphaned.count,
      mode: hard ? 'hard' : 'soft',
    });
  } catch (error) {
    console.error('Seed features error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
