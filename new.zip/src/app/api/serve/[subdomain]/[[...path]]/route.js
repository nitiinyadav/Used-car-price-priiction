import crypto from 'crypto';
import { NextResponse } from 'next/server';
import mime from 'mime-types';
import prisma from '@/lib/prisma';
import { getFile } from '@/lib/storage';
import { normalizeDomain } from '@/lib/utils';
import { trackSiteVisit } from '@/lib/analytics';

// ─── Live tracking script (B-PUB-02 fix: JSON.stringify the siteId) ────────────

function liveTrackingScript(siteId) {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
  let appOrigin = 'http://localhost:3000';
  try {
    const parsed = new URL(appUrl);
    appOrigin = `${parsed.protocol}//${parsed.host}`;
  } catch {
    /* keep fallback */
  }

  // siteId is a CUID — alphanumeric only — but JSON.stringify it anyway as
  // defense-in-depth so the injected script can never escape its <script> tag.
  const safeSiteId = JSON.stringify(String(siteId));
  const safeOrigin = JSON.stringify(appOrigin);

  return (
    `<script>(function(){try{` +
    `var O=${safeOrigin};` +
    `var S=${safeSiteId};` +
    `var k='liveinsec_live_visitor_'+S;` +
    `var v=localStorage.getItem(k);` +
    `if(!v){v=(self.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+Math.random().toString(36).slice(2);localStorage.setItem(k,v)}` +
    `var p=function(){var i=new Image();i.src=O+'/api/live/ping?site='+encodeURIComponent(S)+'&visitor='+encodeURIComponent(v)+'&t='+Date.now()};` +
    `p();setInterval(p,15000)` +
    `}catch(e){}})()</script>`
  );
}

function injectLiveTrackingHtml(fileContent, siteId) {
  let htmlStr = typeof fileContent === 'string' ? fileContent : fileContent.toString('utf-8');
  const tracker = liveTrackingScript(siteId);
  if (htmlStr.includes('</body>')) {
    htmlStr = htmlStr.replace('</body>', tracker + '</body>');
  } else {
    htmlStr += tracker;
  }
  return htmlStr;
}

// ─── Cache-Control by content type (A-8 / B-PUB-02) ────────────────────────────

function cacheControlForType(contentType) {
  if (contentType.startsWith('text/html')) return 'no-cache, must-revalidate';
  if (
    contentType.startsWith('image/') ||
    contentType.startsWith('font/') ||
    contentType === 'application/javascript' ||
    contentType === 'text/css'
  ) {
    return 'public, max-age=3600, must-revalidate';
  }
  return 'public, max-age=600, must-revalidate';
}

// ─── Security headers for served user content (A-8) ────────────────────────────
//
// User-deployed sites legitimately use inline <script> and inline styles, so we
// permit them, but constrain everything else: no eval, no plugins, no framing
// from another origin. Each user's content is sandboxed by being on its own
// subdomain (origin isolation = the real boundary).
function servedSiteSecurityHeaders() {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': [
      "default-src 'self' data: blob:",
      "script-src 'self' 'unsafe-inline' https:",
      "style-src 'self' 'unsafe-inline' https:",
      "img-src 'self' data: blob: https:",
      "font-src 'self' data: https:",
      "connect-src 'self' https: wss: ws:",
      "media-src 'self' data: blob: https:",
      "object-src 'none'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action *",
    ].join('; '),
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  };
}

function buildHeaders(contentType, contentLength, etag, extra = {}) {
  return {
    'Content-Type': contentType,
    'Content-Length': String(contentLength),
    'Cache-Control': cacheControlForType(contentType),
    ETag: etag,
    Vary: 'Accept-Encoding',
    ...servedSiteSecurityHeaders(),
    ...extra,
  };
}

function makeETag(buf) {
  const hash = crypto.createHash('sha256').update(buf).digest('base64').slice(0, 22);
  return `W/"${hash}"`;
}

function notFoundPage(siteLabel) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Not Found</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f9fafb; color: #374151; }
    .container { text-align: center; padding: 48px; }
    h1 { font-size: 48px; font-weight: 700; color: #111827; margin: 0 0 8px; }
    p { font-size: 18px; color: #6b7280; margin: 8px 0 0; }
    a { color: #4f46e5; text-decoration: none; display: inline-block; margin-top: 24px; font-weight: 500; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="container">
    <h1>404</h1>
    <p>The site <strong>${siteLabel || 'unknown'}</strong> was not found or is inactive.</p>
    <a href="${process.env.NEXT_PUBLIC_APP_URL || '/'}">Go to LiveInSec</a>
  </div>
</body>
</html>`;
}

// GET /api/serve/[subdomain]/[[...path]] — Serve static files for a deployed site.
export async function GET(request, { params }) {
  try {
    const { subdomain } = params;
    const pathSegments = params.path || [];
    const filePath = pathSegments.join('/') || 'index.html';
    const requestedDomain = normalizeDomain(
      request.nextUrl.searchParams.get('domain') ||
        request.headers.get('host') ||
        ''
    );

    const site =
      subdomain === '_custom'
        ? await prisma.site.findFirst({ where: { customDomain: requestedDomain } })
        : await prisma.site.findUnique({ where: { subdomain } });

    const siteLabel = subdomain === '_custom' ? requestedDomain : subdomain;

    if (!site || !site.isActive) {
      return new NextResponse(notFoundPage(siteLabel), {
        status: 404,
        headers: { 'Content-Type': 'text/html; charset=utf-8', ...servedSiteSecurityHeaders() },
      });
    }

    // ── Resolve file (with .html and /index.html fallbacks) ──
    let fileContent = await getFile(site.id, filePath);
    let resolvedPath = filePath;
    if (!fileContent) {
      const htmlContent = await getFile(site.id, filePath + '.html');
      if (htmlContent) {
        fileContent = htmlContent;
        resolvedPath = filePath + '.html';
      } else {
        const indexContent = await getFile(site.id, filePath + '/index.html');
        if (indexContent) {
          fileContent = indexContent;
          resolvedPath = filePath + '/index.html';
        }
      }
    }

    if (!fileContent) {
      return new NextResponse(notFoundPage(siteLabel), {
        status: 404,
        headers: { 'Content-Type': 'text/html; charset=utf-8', ...servedSiteSecurityHeaders() },
      });
    }

    const contentTypeRaw = mime.lookup(resolvedPath) || 'application/octet-stream';
    const charset = mime.charset(contentTypeRaw);
    const contentType = charset ? `${contentTypeRaw}; charset=${charset}` : contentTypeRaw;
    const isHtml = contentTypeRaw === 'text/html';

    // ── Build the response body (HTML gets the live-tracking script) ──
    let bodyBuf;
    if (isHtml) {
      const injected = injectLiveTrackingHtml(fileContent, site.id);
      bodyBuf = Buffer.from(injected, 'utf-8');
    } else {
      bodyBuf = Buffer.isBuffer(fileContent) ? fileContent : Buffer.from(fileContent);
    }

    // ── Conditional GET via ETag ──
    const etag = makeETag(bodyBuf);
    const ifNoneMatch = request.headers.get('if-none-match');
    if (ifNoneMatch && ifNoneMatch === etag) {
      return new NextResponse(null, {
        status: 304,
        headers: {
          ETag: etag,
          'Cache-Control': cacheControlForType(contentType),
          ...servedSiteSecurityHeaders(),
        },
      });
    }

    // Track the visit only on full responses (not 304s).
    if (isHtml) {
      try { await trackSiteVisit(site.id, request, `/${resolvedPath}`); } catch {}
    }

    return new NextResponse(bodyBuf, {
      status: 200,
      headers: buildHeaders(contentType, bodyBuf.length, etag),
    });
  } catch (error) {
    console.error('Serve error:', error);
    return new NextResponse('Internal Server Error', {
      status: 500,
      headers: { 'Content-Type': 'text/plain', ...servedSiteSecurityHeaders() },
    });
  }
}
