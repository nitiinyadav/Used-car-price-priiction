export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { markVisitorAlive } from '@/lib/live-presence';

function buildNoStoreHeaders(origin = '*') {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store, no-cache, must-revalidate',
    Pragma: 'no-cache',
  };
}

export async function OPTIONS(request) {
  const origin = request.headers.get('origin') || '*';
  return new NextResponse(null, {
    status: 204,
    headers: buildNoStoreHeaders(origin),
  });
}

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const siteId = searchParams.get('site') || '';
  const visitorId = searchParams.get('visitor') || '';
  const origin = request.headers.get('origin') || '*';

  if (!siteId || !visitorId) {
    return new NextResponse(null, {
      status: 400,
      headers: buildNoStoreHeaders(origin),
    });
  }

  markVisitorAlive(siteId, visitorId);

  return new NextResponse(null, {
    status: 204,
    headers: buildNoStoreHeaders(origin),
  });
}
