'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

export default function VerifyEmailClient({ token }) {
  const { update } = useSession();
  const [status, setStatus] = useState('loading');
  const [message, setMessage] = useState('Verifying your email...');

  useEffect(() => {
    async function verify() {
      if (!token) {
        setStatus('error');
        setMessage('Verification token is missing.');
        return;
      }

      try {
        const res = await fetch('/api/auth/email/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token }),
        });
        const data = await res.json();

        if (!res.ok) {
          setStatus('error');
          setMessage(data.error || 'Verification failed.');
          return;
        }

        setStatus('success');
        setMessage(data.message || 'Email verified successfully.');

        // Push the new emailVerifiedAt into the JWT session
        await update({
          emailVerifiedAt: data.emailVerifiedAt || new Date().toISOString(),
        });
      } catch {
        setStatus('error');
        setMessage('Verification failed.');
      }
    }

    verify();
  }, [token]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md rounded-3xl border border-gray-200 bg-white p-8 text-center shadow-sm">
        <div
          className={`mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full ${
            status === 'success'
              ? 'bg-emerald-100 text-emerald-700'
              : status === 'error'
                ? 'bg-red-100 text-red-700'
                : 'bg-gray-100 text-gray-600'
          }`}
        >
          {status === 'success' ? 'OK' : status === 'error' ? '!' : '...'}
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Email Verification</h1>
        <p className="mt-3 text-sm leading-6 text-gray-600">{message}</p>
        <Link
          href="/dashboard/settings"
          className="mt-6 inline-flex rounded-2xl bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-black"
        >
          Go to Settings
        </Link>
      </div>
    </div>
  );
}
