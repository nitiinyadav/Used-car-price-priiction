import prisma from '@/lib/prisma';
import AdminFeatureManager from './AdminFeatureManager';
import { FEATURE_CATALOG, getFeatureDef } from '@/lib/features-catalog';

export const metadata = {
  title: 'Feature Catalog — Admin — LiveInSec',
};

export default async function AdminFeaturesPage() {
  const now = new Date();
  const dbFeatures = await prisma.feature.findMany({
    orderBy: { sortOrder: 'asc' },
    include: {
      _count: {
        select: {
          featurepurchase: {
            where: {
              status: 'active',
              OR: [
                { expiresAt: null },
                { expiresAt: { gt: now } },
              ],
            },
          },
          cartitem: true,
        },
      },
    },
  });

  // Per-feature lifetime revenue
  const revenueByFeature = await prisma.featurepurchase.groupBy({
    by: ['featureId'],
    _sum: { amountPaid: true },
    _count: true,
  });
  const revenueMap = {};
  revenueByFeature.forEach((r) => {
    revenueMap[r.featureId] = {
      totalRevenue: r._sum.amountPaid || 0,
      totalPurchases: r._count,
    };
  });

  // Build the per-feature row, merging DB row with the hardcoded catalog metadata.
  // Features in DB but not in catalog are flagged as orphans (admins should not
  // edit them — they exist only because they once existed in code).
  const enriched = [];
  for (const f of dbFeatures) {
    const def = getFeatureDef(f.slug);
    enriched.push({
      ...f,
      activePurchases: f._count.featurepurchase,
      inCarts: f._count.cartitem,
      revenue: revenueMap[f.id]?.totalRevenue || 0,
      totalPurchases: revenueMap[f.id]?.totalPurchases || 0,
      adminEditable: def?.adminEditable || [],
      adminGuidance: def?.adminGuidance || null,
      isOrphaned: !def,
    });
  }

  // Surface catalog entries that have no DB row yet (the admin should run "seed").
  const dbSlugs = new Set(dbFeatures.map((f) => f.slug));
  const missingFromDb = FEATURE_CATALOG
    .filter((def) => !dbSlugs.has(def.slug))
    .map((def) => def.slug);

  return (
    <AdminFeatureManager
      features={enriched}
      missingFromDb={missingFromDb}
      catalogSize={FEATURE_CATALOG.length}
    />
  );
}
