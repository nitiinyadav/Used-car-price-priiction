'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

// Field definitions: how each editable knob is rendered in the admin form.
const FIELD_RENDERERS = {
  priceUsd: {
    label: 'Price (USD, in cents)',
    hint: 'e.g. 500 = $5.00. Use 0 to make this feature free.',
    type: 'number',
    step: 1,
    min: 0,
    formatHint: (v) => `≈ $${(Number(v) / 100).toFixed(2)}`,
  },
  priceInr: {
    label: 'Price (INR, in paise)',
    hint: 'e.g. 39900 = ₹399.00. Use 0 to make this feature free.',
    type: 'number',
    step: 100,
    min: 0,
    formatHint: (v) => `≈ ₹${(Number(v) / 100).toFixed(2)}`,
  },
  freeQuota: {
    label: 'Free quota for new users',
    hint: 'How much of this feature every new user gets without paying.',
    type: 'number',
    step: 1,
    min: 0,
  },
  publicQuota: {
    label: 'Public-access quota',
    hint: 'For "partial" or "timed" public access — units depend on feature type.',
    type: 'number',
    step: 1,
    min: 0,
  },
  isActive: {
    label: 'Visible in store',
    hint: 'Uncheck to temporarily hide this feature from end-users.',
    type: 'checkbox',
  },
};

function formatCurrency(value, currency) {
  if (currency === 'INR') return `₹${(Number(value) / 100).toFixed(2)}`;
  return `$${(Number(value) / 100).toFixed(2)}`;
}

export default function AdminFeatureManager({ features: initial, missingFromDb = [], catalogSize = 0 }) {
  const router = useRouter();
  const [features, setFeatures] = useState(initial);
  const [seeding, setSeeding] = useState(false);
  const [savingId, setSavingId] = useState(null);
  const [drafts, setDrafts] = useState({});      // featureId -> { fieldName: value }
  const [messages, setMessages] = useState({});  // featureId -> {ok, text}

  function setDraft(id, field, value) {
    setDrafts((d) => ({ ...d, [id]: { ...(d[id] || {}), [field]: value } }));
  }

  async function save(feature) {
    const draft = drafts[feature.id] || {};
    if (Object.keys(draft).length === 0) return;
    setSavingId(feature.id);
    setMessages((m) => ({ ...m, [feature.id]: null }));
    try {
      const res = await fetch(`/api/features/${feature.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(draft),
      });
      const data = await res.json();
      if (res.ok) {
        setFeatures((rows) => rows.map((r) => (r.id === feature.id ? { ...r, ...data.feature } : r)));
        setDrafts((d) => ({ ...d, [feature.id]: {} }));
        setMessages((m) => ({ ...m, [feature.id]: { ok: true, text: 'Saved.' } }));
        router.refresh();
      } else {
        setMessages((m) => ({ ...m, [feature.id]: { ok: false, text: data.error || 'Failed' } }));
      }
    } catch (err) {
      setMessages((m) => ({ ...m, [feature.id]: { ok: false, text: String(err?.message || err) } }));
    } finally {
      setSavingId(null);
    }
  }

  async function runSeed(hard = false) {
    if (hard && !confirm('Hard-seed will OVERWRITE all admin-edited prices and quotas with code defaults. Continue?')) return;
    setSeeding(true);
    try {
      const res = await fetch('/api/features', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seed: true, hard }),
      });
      const data = await res.json();
      if (res.ok) {
        alert(`Seed complete: ${data.created} new, ${data.updated} updated, ${data.deactivated} deactivated.`);
        router.refresh();
      } else {
        alert('Seed failed: ' + (data.error || res.statusText));
      }
    } catch (err) {
      alert('Seed error: ' + (err?.message || err));
    } finally {
      setSeeding(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Feature Catalog</h1>
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 max-w-2xl">
              The catalog is hardcoded in <code className="bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded">lib/features-catalog.js</code>.
              You cannot add or remove features here — only configure pricing, free quotas, and visibility.
              Adding a new feature requires a code change.
            </p>
            <p className="mt-2 text-xs text-gray-500">
              {features.length} feature{features.length === 1 ? '' : 's'} in DB · {catalogSize} in code catalog
              {missingFromDb.length > 0 && ` · ⚠ ${missingFromDb.length} catalog entr${missingFromDb.length === 1 ? 'y' : 'ies'} missing from DB`}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => runSeed(false)}
              disabled={seeding}
              className="rounded-lg border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/30 px-4 py-2 text-sm font-medium text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 disabled:opacity-50"
            >
              {seeding ? 'Syncing…' : 'Sync from catalog (safe)'}
            </button>
            <button
              onClick={() => runSeed(true)}
              disabled={seeding}
              className="rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30 px-4 py-2 text-sm font-medium text-red-700 dark:text-red-300 hover:bg-red-100 disabled:opacity-50"
            >
              Hard reset prices to code defaults
            </button>
          </div>
        </div>

        {missingFromDb.length > 0 && (
          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-800 px-4 py-3 text-sm">
            <strong className="text-amber-800 dark:text-amber-300">Missing from DB:</strong>{' '}
            <span className="text-amber-700 dark:text-amber-400">
              {missingFromDb.join(', ')}
            </span>{' '}
            — click <em>Sync from catalog</em> above to insert them.
          </div>
        )}
      </div>

      {features.map((feature) => {
        const draft = drafts[feature.id] || {};
        const dirty = Object.keys(draft).length > 0;
        const msg = messages[feature.id];
        const editableFields = feature.isOrphaned ? [] : (feature.adminEditable || []);

        return (
          <div
            key={feature.id}
            className={`rounded-2xl border bg-white dark:bg-gray-900 ${
              feature.isOrphaned ? 'border-amber-300 dark:border-amber-800' : 'border-gray-200 dark:border-gray-800'
            }`}
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-4">
                <div className="flex items-start gap-4">
                  <div className="text-4xl">{feature.icon}</div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className="text-lg font-semibold text-gray-900 dark:text-white">{feature.name}</h2>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded text-gray-700 dark:text-gray-300">{feature.slug}</code>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        feature.isActive
                          ? 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300'
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                      }`}>
                        {feature.isActive ? 'Live in store' : 'Hidden'}
                      </span>
                      {feature.isOrphaned && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-amber-100 text-amber-800">
                          Orphaned (not in catalog)
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 max-w-2xl">{feature.description}</p>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 text-center min-w-fit">
                  <div className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700">
                    <p className="text-xs text-gray-500">Active</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{feature.activePurchases}</p>
                  </div>
                  <div className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700">
                    <p className="text-xs text-gray-500">In carts</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">{feature.inCarts}</p>
                  </div>
                  <div className="px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700">
                    <p className="text-xs text-gray-500">Revenue</p>
                    <p className="text-lg font-semibold text-gray-900 dark:text-white">
                      {formatCurrency(feature.revenue, 'USD')}
                    </p>
                  </div>
                </div>
              </div>

              {/* Admin guidance */}
              {feature.adminGuidance && (
                <div className="mb-5 rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900 px-4 py-3 text-sm text-indigo-800 dark:text-indigo-200">
                  <strong>How to think about this:</strong> {feature.adminGuidance}
                </div>
              )}

              {feature.isOrphaned && (
                <div className="mb-5 rounded-lg border border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30 px-4 py-3 text-sm">
                  This feature is in the database but not in the code catalog. It cannot be edited.
                  Either re-add it to <code>lib/features-catalog.js</code> or leave it disabled.
                </div>
              )}

              {/* Editable fields */}
              {editableFields.length > 0 && (
                <div className="grid gap-4 md:grid-cols-2">
                  {editableFields.map((field) => {
                    const r = FIELD_RENDERERS[field];
                    if (!r) return null;
                    const draftValue = draft[field];
                    const currentValue = draftValue !== undefined ? draftValue : feature[field];

                    if (r.type === 'checkbox') {
                      return (
                        <label key={field} className="flex items-center gap-3 p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={!!currentValue}
                            onChange={(e) => setDraft(feature.id, field, e.target.checked)}
                            className="w-4 h-4 rounded border-gray-300 text-indigo-600"
                          />
                          <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-white">{r.label}</p>
                            <p className="text-xs text-gray-500">{r.hint}</p>
                          </div>
                        </label>
                      );
                    }

                    return (
                      <div key={field}>
                        <label className="block text-sm font-medium text-gray-900 dark:text-white mb-1">
                          {r.label}
                        </label>
                        <input
                          type={r.type}
                          value={currentValue ?? 0}
                          step={r.step}
                          min={r.min}
                          onChange={(e) => setDraft(feature.id, field, e.target.value)}
                          className="w-full rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                        />
                        <p className="mt-1 text-xs text-gray-500">
                          {r.hint}
                          {r.formatHint && (
                            <span className="ml-2 text-gray-400">{r.formatHint(currentValue)}</span>
                          )}
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Save bar */}
              {editableFields.length > 0 && (
                <div className="mt-5 flex items-center justify-between">
                  <div className="text-sm">
                    {msg && (
                      <span className={msg.ok ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}>
                        {msg.text}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {dirty && (
                      <button
                        onClick={() => setDrafts((d) => ({ ...d, [feature.id]: {} }))}
                        className="rounded-lg border border-gray-300 dark:border-gray-700 px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                      >
                        Discard
                      </button>
                    )}
                    <button
                      onClick={() => save(feature)}
                      disabled={!dirty || savingId === feature.id}
                      className="rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 dark:disabled:bg-gray-700 px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed"
                    >
                      {savingId === feature.id ? 'Saving…' : dirty ? 'Save changes' : 'No changes'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
