import { NextResponse } from 'next/server';
import { getLocalWildcardHost, getRootHost, stripPort } from '@/lib/utils';

export function middleware(request) {
  const hostname = request.headers.get('host') || '';
  const hostnameWithoutPort = stripPort(hostname);
  const rootDomainWithoutPort = getRootHost();
  const localWildcardHost = getLocalWildcardHost();

  const { pathname } = request.nextUrl;

  // L-07: HTTPS enforcement — default to ON in production, opt-out with FORCE_HTTPS=false
  const isProduction = process.env.NODE_ENV === 'production';
  const forceHttps = isProduction ? process.env.FORCE_HTTPS !== 'false' : process.env.FORCE_HTTPS === 'true';
  const proto = request.headers.get('x-forwarded-proto') || 'http';
  if (forceHttps && proto === 'http') {
    const httpsUrl = request.nextUrl.clone();
    httpsUrl.protocol = 'https:';
    return NextResponse.redirect(httpsUrl, 301);
  }

  // Security headers
  const response = handleRouting(request, hostname, hostnameWithoutPort, rootDomainWithoutPort, localWildcardHost, pathname);
  const res = (response && response !== NextResponse.next()) ? response : NextResponse.next();
  applySecurityHeaders(res);
  return res;
}

// M-06 / A-8: Security headers for the LiveInSec app surface (NOT for served user sites
// — those get their own headers in /api/serve/*).
//
// 'unsafe-inline' + 'unsafe-eval' on script-src are required by Next.js' runtime
// and the Monaco editor. A future ticket migrates these to nonce-based CSP.
function applySecurityHeaders(response) {
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-Frame-Options', 'SAMEORIGIN');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set(
    'Content-Security-Policy',
    [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://checkout.razorpay.com",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https: blob:",
      "connect-src 'self' wss: ws: https://api.razorpay.com https://api.resend.com",
      "frame-src https://api.razorpay.com https://checkout.razorpay.com",
      "font-src 'self' data:",
      "media-src 'self' data: blob:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'self'",
    ].join('; ')
  );
  response.headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  response.headers.set(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=(), payment=(self "https://checkout.razorpay.com")'
  );
  // I-03: Prevent caching of API responses with sensitive data.
  // NOTE: This is later overridden by /api/serve/* for static user sites.
  response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  response.headers.set('Pragma', 'no-cache');
}

function handleRouting(request, hostname, hostnameWithoutPort, rootDomainWithoutPort, localWildcardHost, pathname) {

  // Skip internal Next.js routes, API routes, and app routes.
  // /site/* is intentionally NOT in this list — that route is removed (C-2).
  if (
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/api/') ||
    pathname.startsWith('/login') ||
    pathname.startsWith('/register') ||
    pathname.startsWith('/forgot-password') ||
    pathname.startsWith('/reset-password') ||
    pathname.startsWith('/complete-profile') ||
    pathname.startsWith('/dashboard') ||
    pathname.startsWith('/admin') ||
    pathname.startsWith('/verify-email') ||
    pathname.startsWith('/docs') ||
    pathname === '/favicon.ico' ||
    pathname === '/robots.txt' ||
    pathname === '/sitemap.xml'
  ) {
    return NextResponse.next();
  }

  const isRootDomainRequest =
    hostnameWithoutPort === rootDomainWithoutPort ||
    hostnameWithoutPort === `www.${rootDomainWithoutPort}`;

  if (!isRootDomainRequest) {
    const candidateSuffixes = [
      `.${rootDomainWithoutPort}`,
      `.${localWildcardHost}`,
    ].filter((suffix, index, all) => all.indexOf(suffix) === index);

    for (const subdomainSuffix of candidateSuffixes) {
      if (!hostnameWithoutPort.endsWith(subdomainSuffix)) {
        continue;
      }

      const subdomain = hostnameWithoutPort.slice(0, -subdomainSuffix.length);

      if (subdomain) {
        const url = request.nextUrl.clone();
        url.pathname = `/api/serve/${subdomain}${
          pathname === '/' ? '/' : pathname
        }`;
        return NextResponse.rewrite(url);
      }
    }

    // Otherwise treat the hostname as a connected custom domain.
    const url = request.nextUrl.clone();
    url.pathname = `/api/serve/_custom${pathname === '/' ? '/' : pathname}`;
    url.searchParams.set('domain', hostnameWithoutPort);
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
