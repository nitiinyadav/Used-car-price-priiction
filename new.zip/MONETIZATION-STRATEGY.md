# LiveInSec Monetization Strategy
## Plans + Feature Store: Complete Wiring Spec

> Single-source-of-truth document for rewiring the LiveInSec purchasing system, plan structure, admin controls, and user journey. Hand this to an implementing LLM as the canonical spec.

---

## 1. Diagnosis — Why It's Broken Today

Three structural defects:

1. **Plans are decorative.** `user.planSlug` exists, but `getUserFeatureQuota()` ignores it. The Pro plan does not unlock anything in the feature store. Free and Pro users see identical free quotas, identical paid prices, identical store. Pro is paying $29/mo for a higher `maxSites` count and nothing else the user perceives.
2. **Admin can't grant or override.** Admin can edit prices, but cannot: change a user's plan, comp a user with a feature, process a refund, issue a coupon, or grant trial extensions. Every support-driven action requires direct DB edits.
3. **Plan ↔ Store don't talk.** Two parallel systems. A free user with 100 free submissions/month and a Pro user with 100 free submissions/month have the same submissions experience, even though Pro paid $29.

This document fixes all three at the same time, with a strategy informed by behavioural economics — not just by what's technically possible.

---

## 2. Business Strategy & Customer Psychology

### 2.1 The two-axis monetization model

Plans and Feature Store **complement each other** — they don't compete:

| | **Plans (subscription)** | **Feature Store (one-off / topup)** |
|---|---|---|
| Revenue type | Recurring (predictable) | Transactional (lumpy) |
| Buyer mindset | "I'm committing to this product" | "I have a specific problem, right now" |
| Role | Capture, lock-in, base capability | Overflow handling, expansion, vanity |
| Pricing pressure | Anchoring, social proof, decoy | Loss-aversion, urgency |

A healthy SaaS has **70–85% MRR from plans**, the remainder from add-on purchases. Right now LiveInSec has 0% from plans (because Pro unlocks nothing).

### 2.2 Psychology levers we will use

1. **Anchoring** — Pricing page shows all four tiers with Pro visually highlighted. Pro's $29 anchors the user's perception of "this is what good costs."
2. **Decoy effect** — Starter is intentionally weaker per-submission than Pro, so Pro looks like a steal. Starter exists to make Pro irresistible, not to be the destination.
3. **Loss aversion** — Free users see the count of submissions/leads they're about to lose, not abstract percentages.
4. **Endowment effect** — Free users get an automatic 7-day Pro trial after their first form submission. After 7 days, they lose analytics, branding-removal, and webhooks — and feel the loss.
5. **Reciprocity** — Generous-but-not-stuck free tier. Enough to build habit, not enough to plateau.
6. **Social proof** — "Most popular" badge on Pro. "X businesses run on Business" if/when we have testimonials.
7. **Urgency + commitment** — Annual billing = 2 months free (16.6% discount). First-month upgrade discount (20% off first month, code `LIVEUPGRADE`).
8. **Sunk-cost / lock-in** — Once user has sites and lead history, switching cost is high. We don't fight this; we lean into it via data import/export ease.

### 2.3 Why we're keeping the feature store

The feature store is a **conversion lever**, not the primary revenue product. Every store interaction is an opportunity to either:
- Solve their immediate pain (overflow pack), keeping them on free, **OR**
- Convert them to a plan ("$5 for 1k submissions, or $9/mo for 500/mo every month — and 3 sites — and email notifications").

Show the upgrade path **inside the cart**. Never let a user check out a topup without seeing the plan that would have made it cheaper.

---

## 3. Plan Architecture (Free / Starter / Pro / Business)

Replace the existing four-tier seed (which is too generous on Free and undifferentiated on Pro) with this:

### 3.1 Plan Tiers

| | **Free** | **Starter** | **Pro** ⭐ | **Business** |
|---|---|---|---|---|
| **Monthly** | $0 | $9 / ₹799 | **$29 / ₹2,499** | $99 / ₹8,499 |
| **Yearly** (16% off) | $0 | $90 / ₹7,990 | $290 / ₹24,990 | $990 / ₹84,990 |
| Sites | 1 | 3 | 25 | Unlimited |
| Submissions / month | 50 | 500 | **5,000** | 50,000 |
| Storage / site | 25 MB | 100 MB | 1 GB | 10 GB |
| Custom domains | 0 | 1 | 5 | Unlimited |
| Form notifications email | ❌ | ✅ | ✅ | ✅ |
| Webhooks | ❌ | ❌ | ✅ | ✅ |
| Analytics | 7-day trial | ❌ | ✅ included | ✅ advanced |
| LiveInSec branding | shown | shown | **removed** | removed |
| Team members | 0 | 0 | 3 | 15 |
| Priority support | ❌ | ❌ | ✅ email | ✅ Slack + dedicated |
| Audit logs | ❌ | ❌ | 30 days | 1 year |
| **Target buyer** | Hobbyist, evaluator | Solo creator, freelancer | Small business, agency | Mid-market, agency teams |

### 3.2 Why these numbers

- **Free 50/mo (was 100):** 100 free submissions/month means a small business never needs to upgrade. 50 means they hit the wall by mid-month and feel the friction.
- **Starter 500/mo at $9:** $0.018/submission. Looks fine alone, terrible next to Pro.
- **Pro 5,000/mo at $29:** $0.0058/submission — a 3.1× discount per unit vs Starter. This is the **decoy math** that makes Pro "the obvious choice."
- **Business 50,000/mo at $99:** $0.0019/submission. For agencies; mostly bought after Pro saturates.
- **Yearly discount = 2 months free:** standard SaaS norm; reduces churn and pulls cash forward.

### 3.3 Plan downgrade rules

- Active feature-store purchases (e.g., a 10,000-submission pack) **continue until expiry**. No clawback.
- New limits apply to **new** data only. If user has 25 sites on Pro and downgrades to Starter (3-site limit), existing 25 sites stay live, but they cannot create site #26.
- Unused yearly subscription → prorated refund only if within 14-day window. After that, plan continues until period end.
- Submission monthly quota immediately drops to new tier. If they're already over the new tier's quota, new submissions tag as overflow until the next month.

---

## 4. Feature Store Architecture (Topups & Add-ons)

Feature store stays, but its role is **clarified**: handle overflow and expansion, not replace plans.

### 4.1 Feature catalog

| Slug | Name | Type | Free Quota (Free plan) | Pro Quota | Topup Price (USD/INR) | Buy Limit Per Plan |
|---|---|---|---|---|---|---|
| `submissions-pack-1k` | 1,000 submission topup | one-shot | n/a | n/a | $5 / ₹399 | Free, Starter, Pro |
| `submissions-pack-5k` | 5,000 submission topup | one-shot | n/a | n/a | $20 / ₹1,599 (20% volume discount) | All |
| `extra-storage-100mb` | +100 MB storage (lifetime) | lifetime | — | — | $0.99 / ₹79 | All |
| `team-seat` | Extra team seat (lifetime per seat) | lifetime | — | — | $4.99 / ₹399 | Pro & Business only |
| `analytics-monthly` | Site Analytics (1 month) | duration 30d | 7-day trial | included | $5 / ₹399 | Starter only (Pro has it included) |
| `remove-branding-monthly` | Remove "Powered by" (1 month) | duration 30d | — | included | $1.99 / ₹159 | Free, Starter only |
| `custom-domain-extra` | Extra custom domain slot | lifetime | — | — | $2.99 / ₹239 | Starter & Pro (Business unlimited) |

### 4.2 Rules for the store

- A feature is **only purchasable** if it isn't already included in the user's current plan. Pro users do not see "Remove branding $1.99/mo" — they already have it.
- Topups (submissions-pack-1k, etc.) reset the **monthly quota usage** retroactively (i.e., if they bought a 1k pack mid-month, that 1k is added to remaining for that month). Lifetime add-ons (storage, seats) accumulate forever.
- **In-cart upsell:** when a Free user adds 5× `submissions-pack-1k` ($25) to cart, the cart UI shows "Pro plan gives you 5,000 submissions/month for $29 — would you like to upgrade instead?" with a one-click switch.
- All add-on purchases are **non-refundable after 7 days**.

---

## 5. The Plan ⇄ Feature Store Relationship

This is the wiring that's missing today. Implementation:

### 5.1 New Prisma model: `PlanFeature`

```prisma
model PlanFeature {
  id                String   @id @default(cuid())
  planId            String
  featureId         String
  includedQty       Int?     // null = no inclusion, just visibility rule
  isUnlimited       Boolean  @default(false)
  isHiddenInStore   Boolean  @default(false)  // hide from store for users on this plan
  storeDiscountPct  Int      @default(0)      // 0–100 discount on store price for this plan
  createdAt         DateTime @default(now())

  plan    Plan    @relation(fields: [planId], references: [id], onDelete: Cascade)
  feature Feature @relation(fields: [featureId], references: [id], onDelete: Cascade)

  @@unique([planId, featureId])
}
```

### 5.2 `getUserFeatureQuota()` rewrite

Today it ignores `user.planSlug`. New behaviour:

```
total_quota = feature.freeQuota
            + sum(active featurepurchase.quantity for this user/feature)
            + planFeature.includedQty for user.planId/feature  (if unlimited → return Infinity)

is_visible_in_store = NOT (planFeature.isHiddenInStore AND user is on that plan)

store_price = feature.priceUsd * (1 - planFeature.storeDiscountPct/100)
```

This is the **single function** that fixes the whole "Pro plan is useless" problem. Once Pro's `PlanFeature` row for `submissions` says `includedQty: 5000`, Pro users get 5,000/month free; everyone else still gets 50.

### 5.3 Plan upgrade is also a feature unlock

When a user moves from Free → Pro:
- Their `submissions` total quota jumps from 50 to 5,050 (if they had topups, those still count).
- `analytics` becomes accessible (was 7-day trial).
- `remove-branding-monthly` is hidden from store.
- `team-seat` becomes purchasable (was hidden).
- `customDomain` allowance jumps from 0 to 5.

All of this from one `planFeature` table read. No hardcoding in `feature-access.js`.

---

## 6. Admin Control Matrix

What admins need, and what we add. Anything marked **NEW** doesn't exist yet.

### 6.1 Plan controls

| Control | Status | Where |
|---|---|---|
| Edit plan name, prices, quotas | ✅ exists | `/admin/plans` |
| Toggle plan active/inactive | ✅ exists | `/admin/plans` |
| Set "Most Popular" badge | **NEW** | Add `Plan.badge`, `Plan.isHighlighted`, `Plan.ctaLabel` columns + form fields |
| Set yearly discount % | **NEW** | Computed from `priceYearly / priceMonthly`; show as % in admin |
| Hide plan from public pricing page | **NEW** | Add `Plan.isPublic` column |
| Configure trial days per plan | **NEW** | Add `Plan.trialDays` column (default 0; Pro = 7) |
| **Map plan → included features** | **NEW** | New page `/admin/plans/[id]/features` — table of all features with `includedQty`, `isUnlimited`, `isHiddenInStore`, `storeDiscountPct` |

### 6.2 Feature store controls

| Control | Status | Where |
|---|---|---|
| Edit feature name, prices, free quota | ✅ exists | `/admin/features` |
| Toggle feature active/featured | ✅ exists | `/admin/features` |
| Set min/max/step quantity | partial | Expose all of these in admin form |
| Set duration days | ✅ exists | `/admin/features` |
| **Restrict feature to specific plans** | **NEW** | Use `PlanFeature.isHiddenInStore = true` for plans that shouldn't see it |
| **Set per-plan discount on a feature** | **NEW** | Use `PlanFeature.storeDiscountPct` |
| Mark feature as "topup vs add-on vs vanity" | **NEW** | Add `Feature.storeRole` enum: `topup`, `expansion`, `unlock`, `vanity` (drives sort/group in store UI) |

### 6.3 User controls

These are all **NEW**. Build under `/admin/users/[id]`:

| Action | What it does | API |
|---|---|---|
| **Change plan** | Move user to a different plan; preserves purchases; logs audit | `POST /api/admin/users/[id]/change-plan { planSlug, billingPeriod, comp: bool }` |
| **Grant feature** | Manually add featurepurchase row (e.g. comp 1 month analytics) | `POST /api/admin/users/[id]/grant-feature { featureId, qty, durationDays, reason }` |
| **Extend trial** | Push `trialEndsAt` forward | `POST /api/admin/users/[id]/extend-trial { days }` |
| **Refund a purchase** | Mark purchase refunded, optionally call Razorpay refund API | `POST /api/admin/users/[id]/refund { orderId, amount, reason }` |
| **Suspend / unsuspend** | Soft-block account from creating sites or receiving submissions | `POST /api/admin/users/[id]/suspend { reason }` |
| **Login as user** | Impersonation for support (audit-logged) | `POST /api/admin/users/[id]/impersonate` |
| **View purchase history + sites + last login** | Read-only context panel | Already partly there |

### 6.4 Coupons & promotions

All **NEW**. Models + admin pages:

```prisma
model Coupon {
  id           String   @id @default(cuid())
  code         String   @unique
  name         String
  description  String?
  type         String   // "percent" | "fixed_usd" | "fixed_inr" | "free_months"
  value        Int      // percent (0-100) or cents/paise or months
  appliesTo    String   // "plans" | "features" | "all"
  scopeIds     String?  // JSON array of plan or feature IDs (null = all in scope)
  maxUses      Int?     // null = unlimited
  uses         Int      @default(0)
  perUserLimit Int      @default(1)
  validFrom    DateTime @default(now())
  validUntil   DateTime?
  isActive     Boolean  @default(true)
  createdBy    String
  createdAt    DateTime @default(now())
}

model CouponRedemption {
  id        String   @id @default(cuid())
  couponId  String
  userId    String
  orderId   String?
  amount    Int
  createdAt DateTime @default(now())

  coupon Coupon @relation(fields: [couponId], references: [id])
  user   User   @relation(fields: [userId], references: [id])

  @@unique([couponId, userId, orderId])
}
```

**Admin pages:**
- `/admin/coupons` — list, create, expire, see usage
- `/admin/coupons/[id]` — detail with redemption log

**User-facing:**
- Coupon code field on cart and on plan checkout
- `POST /api/coupons/validate { code, scope }` — returns discount + applicability

### 6.5 Refund queue

| Control | Status |
|---|---|
| `RefundRequest` model | ✅ exists in schema |
| User can request refund | **NEW** UI: `/dashboard/billing` "Request refund" button, only for purchases ≤ 7 days old |
| Admin sees queue | **NEW** `/admin/refunds` with approve/deny actions |
| Approve = call Razorpay refund API + mark purchase refunded + revoke entitlement | **NEW** |

### 6.6 Subscription tracking

Critical missing piece. Add:

```prisma
model PlanSubscription {
  id                  String    @id @default(cuid())
  userId              String    @unique
  planId              String
  status              String    // "trialing" | "active" | "past_due" | "cancelled" | "expired"
  billingPeriod       String    // "monthly" | "yearly"
  startedAt           DateTime  @default(now())
  currentPeriodStart  DateTime
  currentPeriodEnds   DateTime
  cancelAtPeriodEnd   Boolean   @default(false)
  cancelledAt         DateTime?
  trialEndsAt         DateTime?
  razorpaySubId       String?   // for recurring (or null if manual monthly renewal)
  razorpayCustomerId  String?
  createdAt           DateTime  @default(now())
  updatedAt           DateTime  @updatedAt

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)
  plan Plan @relation(fields: [planId], references: [id])
}
```

This unblocks: cancel-at-period-end UX, prorated downgrades, dunning, MRR reporting.

### 6.7 Revenue & funnel analytics (admin)

Replace the current `/admin/revenue` (which is sparse) with a real dashboard:

- **MRR breakdown** by plan
- **Conversion funnel**: signup → first site → first submission → quota warning → upgrade
- **Cart abandonment**: cart created → checkout initiated → payment verified
- **Churn**: subscriptions cancelled in the last 30/60/90 days
- **Refund rate** (refunded / total revenue)
- **Top features by revenue** (which store items earn the most)
- **Plan distribution** (current vs 30 days ago)

Each chart drillable to the underlying user list.

---

## 7. User Journey Flows

### 7.1 First-time signup

1. User signs up → put on Free plan, `lastDripStep = 0`.
2. Dashboard shows onboarding checklist: "Create your first site", "Add a form", "Receive your first submission".
3. After **first form submission**: kick off **automatic 7-day Pro trial** (`PlanSubscription.status = "trialing"`, `trialEndsAt = now + 7d`). Email: "You just got your first lead — we've unlocked Pro for 7 days so you can see analytics, custom domain, and webhooks."
4. Day 6: email warning trial ends tomorrow.
5. Day 7: trial ends → revert to Free → endowment effect kicks in (they miss what they had).

### 7.2 Free user hits 80% submissions

- In-app banner on `/dashboard/submissions`: "You've used 40 / 50 submissions this month. Top up or upgrade — leads beyond 50 will be tagged as overflow."
- CTA to cart with `submissions-pack-1k` pre-loaded **AND** plan upgrade comparison: "Buy 1,000 once for $5, or 5,000/month for $29 (Pro)."

### 7.3 Free user hits 100% (overflow)

- All new submissions still saved, tagged `quotaOverflow = true`, status `'spam'` (existing behaviour, keep it).
- Persistent red banner: "X overflow leads this month — upgrade or top up to recover them."
- Email at most once per 24h to site owner: "Your contact form is collecting leads above your quota."
- Overflow leads remain visible in inbox but blurred/redacted until the user upgrades or tops up. Once they do, all overflow rows become readable. **This is the loss-aversion lever.**

### 7.4 Free user buys submission pack

1. Cart → checkout → Razorpay → verify.
2. New `featurepurchase` row created with `qty = 1000`, `featureId = submissions-pack-1k`, `expiresAt = end of current month`.
3. `getUserFeatureQuota('submissions')` includes the topup, so `total = 50 + 1000 = 1050`.
4. Existing overflow rows remain tagged (we don't retroactively un-overflow), but visible without blur.
5. Receipt email + audit log.

### 7.5 Free user upgrades to Pro

1. From plan upsell or `/pricing` page → click "Upgrade to Pro."
2. Plan checkout: monthly vs yearly toggle, coupon field, payment.
3. On verify: create `PlanSubscription` (status `active`, period 1 month or 1 year), update `user.planSlug = 'pro'`, `user.planId`.
4. All `PlanFeature` rules apply immediately:
   - submissions quota = 5,050 (5k from plan + any unspent topups)
   - analytics on
   - branding-removed-monthly hidden from store
5. Audit log + welcome-to-pro email + admin notification.

### 7.6 Pro user runs out of submissions

Rare (5,000/mo), but if it happens:
- Same flow as 7.2, but the upsell is "Top up with 5k pack ($20)" or "Upgrade to Business."

### 7.7 Pro user wants to downgrade

1. `/dashboard/billing` → "Change plan" → select Starter.
2. UI shows what they'll lose: "You'll lose: webhooks, 22 sites, 3 team members, branding removal."
3. Option: "Cancel at period end" (default) vs "Downgrade now (prorated refund)."
4. If period-end: `PlanSubscription.cancelAtPeriodEnd = true`, plan continues until `currentPeriodEnds`.
5. If now: refund prorated unused days, downgrade immediately.

### 7.8 Pro user requests refund

1. `/dashboard/billing` → list of recent purchases → "Request refund" (only if ≤ 7 days, configurable).
2. User picks reason from dropdown + free-text.
3. Creates `RefundRequest` (status `pending`).
4. Admin sees in `/admin/refunds` queue. Approve/deny.
5. Approve = Razorpay refund API + mark purchase refunded + revoke entitlement (if active feature) + email user.

### 7.9 Pro user wants to cancel

1. Same `/dashboard/billing` → "Cancel subscription."
2. Friction: show what they'll lose, offer 1-month 50% off retention discount.
3. If they still cancel: `cancelAtPeriodEnd = true`. They keep Pro until period ends.
4. After period ends: revert to Free, audit log, win-back email after 7 days.

---

## 8. Schema Changes Required

```prisma
model Plan {
  // existing fields...

  // NEW visibility/marketing
  isPublic        Boolean @default(true)
  isHighlighted   Boolean @default(false)
  badge           String? // "Most Popular", "Best Value"
  ctaLabel        String? // "Upgrade Now"
  trialDays       Int     @default(0)

  // NEW relations
  planFeatures    PlanFeature[]
  subscriptions   PlanSubscription[]
}

model Feature {
  // existing fields...

  // NEW
  storeRole         String  @default("topup")  // topup | expansion | unlock | vanity
  isPubliclyVisible Boolean @default(true)     // hide entirely from anonymous /pricing page

  planFeatures      PlanFeature[]
}

model PlanFeature { ... see §5.1 ... }
model Coupon { ... see §6.4 ... }
model CouponRedemption { ... see §6.4 ... }
model PlanSubscription { ... see §6.6 ... }

model AdminGrant {
  id           String   @id @default(cuid())
  grantedBy    String   // admin user id
  recipientId  String   // user id
  type         String   // "feature" | "plan" | "credit" | "trial-extension"
  featureId    String?
  planId       String?
  qty          Int?
  durationDays Int?
  reason       String
  createdAt    DateTime @default(now())
}

model User {
  // existing...
  // NEW
  planSubscription  PlanSubscription?
  adminGrants       AdminGrant[]    @relation("recipientGrants")
}
```

Run `prisma migrate dev --name plans-and-store-rewire` then a one-off backfill script to create `PlanSubscription` rows for any user currently on a paid `planSlug`.

---

## 9. API Endpoints Required

### 9.1 New user endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/coupons/validate` | Validate code + return discount applicability |
| `POST` | `/api/plan-checkout` | Create Razorpay order for plan |
| `POST` | `/api/plan-checkout/verify` | Verify HMAC + create subscription |
| `POST` | `/api/subscription/cancel` | Cancel at period end |
| `POST` | `/api/subscription/change-plan` | Upgrade/downgrade |
| `POST` | `/api/refund-requests` | User-initiated refund request |

### 9.2 New admin endpoints

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/admin/users/[id]/change-plan` | Manual plan move |
| `POST` | `/api/admin/users/[id]/grant-feature` | Comp a feature |
| `POST` | `/api/admin/users/[id]/extend-trial` | Push trialEndsAt |
| `POST` | `/api/admin/users/[id]/refund` | Refund a purchase |
| `POST` | `/api/admin/users/[id]/suspend` | Soft-suspend |
| `POST` | `/api/admin/users/[id]/impersonate` | Login-as for support |
| `GET` `POST` | `/api/admin/coupons` | CRUD list/create |
| `PUT` `DELETE` | `/api/admin/coupons/[id]` | Update/disable |
| `GET` | `/api/admin/refund-requests` | Queue |
| `POST` | `/api/admin/refund-requests/[id]/approve` | Approve + Razorpay refund |
| `POST` | `/api/admin/refund-requests/[id]/deny` | Deny with reason |
| `GET` `POST` `PUT` `DELETE` | `/api/admin/plans/[id]/features` | Plan-feature mappings |
| `GET` | `/api/admin/analytics/funnel` | Conversion funnel data |
| `GET` | `/api/admin/analytics/mrr` | MRR breakdown |
| `GET` | `/api/admin/analytics/churn` | Churn report |

---

## 10. Pages to Add or Update

### 10.1 User-facing

| Page | Status | Notes |
|---|---|---|
| `/pricing` | **NEW** (public) | All plans side-by-side; Pro highlighted; monthly/yearly toggle; FAQ |
| `/dashboard/billing` | **NEW** | Current plan, next renewal, payment method, invoices, change/cancel plan, refund requests |
| `/dashboard/store` | exists, **expand** | Show "included in your Pro plan" badges; hide unbuyable items; show in-cart upgrade nudge |
| `/dashboard/cart` | exists, **expand** | Coupon field; plan-upgrade comparison panel |
| `/dashboard/submissions` | **expand** | Always-visible quota meter (already done in last session); upgrade CTA when ≥ 80%; overflow blur |

### 10.2 Admin-facing

| Page | Status | Notes |
|---|---|---|
| `/admin/plans` | exists | Add badge, isPublic, isHighlighted, trialDays, ctaLabel fields |
| `/admin/plans/[id]/features` | **NEW** | PlanFeature mapping editor: table of features × this plan |
| `/admin/features` | exists | Add storeRole + visibility fields |
| `/admin/users/[id]` | exists, **expand** | Plan change, grant feature, refund, extend trial, suspend, impersonate |
| `/admin/coupons` | **NEW** | List, create, expire, usage |
| `/admin/coupons/[id]` | **NEW** | Detail + redemptions |
| `/admin/refunds` | **NEW** | Queue with approve/deny |
| `/admin/grants` | **NEW** | Audit log of manual grants |
| `/admin/revenue` | exists, **expand** | MRR by plan, churn, funnel, refund rate |

---

## 11. Wiring Rules (the most important section for the implementing LLM)

These are the invariants the implementation must respect:

1. **`getUserFeatureQuota()` is the only place that decides feature access.** Every page that gates features must call it. No hardcoded plan checks elsewhere.
2. **`PlanFeature` table is the source of truth for what each plan includes.** `feature-access.js` reads this; nothing reads `Plan.maxSubmissions` etc. directly any more (those columns become marketing copy + initial seed only).
3. **`PlanSubscription` is the source of truth for a user's current plan.** `user.planSlug` becomes a denormalised cache, updated whenever the subscription changes. Never trust `user.planSlug` alone — always join through `PlanSubscription` for billing/period decisions.
4. **Idempotency is mandatory.** Both plan checkout and feature checkout must accept a client-supplied idempotency key, scoped per user (the latter is already wired). Webhooks from Razorpay must be replay-safe (we already have signature reuse protection on feature checkout — apply the same to plan checkout).
5. **Audit everything that affects entitlement.** Every plan change, grant, refund, suspension, impersonation creates an `auditlog` row with actor, target, action, before/after.
6. **Downgrades preserve purchased entitlements.** Lifetime add-ons (storage, seats) survive plan changes. Time-limited features (analytics-monthly, branding-monthly) run until expiry.
7. **Cache invalidation on plan or feature change.** Any change to `Plan`, `Feature`, or `PlanFeature` must call `invalidateFeatureCache(userId?)` (already partly there for features). Add the same hook to plan-feature edits.
8. **Free users always see what they're missing.** Locked features show in-store with a "Pro plan includes this — $29/mo" CTA, not "you can't buy this."
9. **In-cart upgrade is one click.** If cart total > current month's plan price diff, show "Upgrade to Pro instead — same items + ongoing benefits for $X" as a single button that swaps the cart for a plan checkout.
10. **No silent failures.** Razorpay errors, refund failures, webhook misses → admin Slack/email alert + visible-to-user error.

---

## 12. Implementation Phases

Don't try to ship all of this in one PR. Phased rollout:

### Phase 1 — Make Pro actually unlock things (1–2 days)
- Add `PlanFeature` model + migration.
- Seed plan-feature mappings for current four plans (Free / Starter / Pro / Business per §3.1 + §4.1).
- Rewrite `getUserFeatureQuota()` to read `PlanFeature`.
- Admin UI: `/admin/plans/[id]/features` editor.
- Update store UI: hide features included in user's plan; show "included" badge.

**Outcome:** Pro plan immediately differentiates. Existing Pro subscribers (if any) start seeing real value.

### Phase 2 — Subscription lifecycle (2–3 days)
- Add `PlanSubscription` model + migration + backfill.
- `POST /api/plan-checkout` + `/verify` (mirror feature-checkout structure).
- `/dashboard/billing` page.
- Cancel-at-period-end + downgrade flow.
- 7-day Pro trial on first form submission.

### Phase 3 — Admin user controls (1–2 days)
- Plan change, grant feature, extend trial, refund, suspend, impersonate.
- Audit log viewer.

### Phase 4 — Coupons & promos (2 days)
- `Coupon` + `CouponRedemption` models.
- Admin coupons CRUD page.
- Coupon field on cart + plan checkout.
- `LIVEUPGRADE` 20%-off-first-month code seeded.

### Phase 5 — Refund queue (1 day)
- User-initiated refund request.
- Admin queue + Razorpay refund API integration.

### Phase 6 — Analytics rebuild (2 days)
- MRR, churn, funnel, refund rate dashboards.
- `/admin/analytics/*` endpoints.

### Phase 7 — Pricing page + polish (1–2 days)
- Public `/pricing` page.
- In-cart upgrade nudge.
- Endowment-effect trial onboarding email sequence.

**Total: ~10–14 days of focused work** to ship a complete, sellable, controllable monetization stack.

---

## 13. Behavioural Targets (how we'll know it's working)

| Metric | Today | Target (90 days post-rollout) |
|---|---|---|
| Free → Paid conversion (any tier) | ~0% (no real reason to upgrade) | 3–5% |
| Pro → cancel within first month | n/a | < 15% |
| Cart abandonment rate (store) | unknown | < 60% |
| In-cart plan upgrade rate | n/a | 5–10% of cart sessions |
| Refund rate | unknown | < 3% |
| MRR contribution from plans vs store | 0% / 100% | 70% / 30% |
| 7-day trial → Pro conversion | n/a | 8–12% |

These are conservative SaaS benchmarks. If we hit even half of them, this rewiring pays for itself in the first quarter.

---

## 14. What this document deliberately does NOT cover

- **Tax / invoicing / GST** for Indian customers — needs a separate spec, but `priceInr` + Razorpay handles UI; back-office tax remains manual for now.
- **Annual-to-monthly conversions on existing customers** — punted to Phase 8; not blocking launch.
- **Affiliate / referral system** — out of scope for v1; add after MRR is established.
- **Multiple payment providers** — Razorpay only for v1. Stripe support exists in code but is unused; keep dormant.
- **Localised pricing** beyond INR — out of scope.

---

**End of spec.** Hand this whole document to the implementing LLM as the spec to follow. Each phase in §12 is a discrete deliverable; each phase has its own §8 (schema), §9 (API), §10 (pages), §11 (wiring rules) requirements drawn from this spec.
