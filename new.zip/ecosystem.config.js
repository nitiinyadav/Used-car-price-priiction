module.exports = {
  apps: [
    {
      name: "staticdrop",
      script: "server.js",
      env: {
        NODE_ENV: "development",
      },
    },
  ],
};
