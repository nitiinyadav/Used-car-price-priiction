# LiveInSec — Rewiring Plan

> Audience: an engineering LLM that will pick up tickets one at a time.
> Compiled: 2026-05-02
> Method: 4 parallel deep audits over every page, API route, lib file, server, and middleware.
>
> **Read first:** [PROJECT-SNAPSHOT.md](PROJECT-SNAPSHOT.md), [BUSINESS-RECOMMENDATIONS.md](BUSINESS-RECOMMENDATIONS.md).
> **This file replaces:** any need to crawl the codebase for understanding what's broken.

---

## How to use this document

This is a **ticket inventory**. Every section under "PART B" is a self-contained ticket an LLM can implement without reading other tickets. Each ticket has:

- **Path** — file(s) to touch
- **Status** — `KEEP` / `FIX` / `REWRITE` / `REMOVE`
- **Bugs / gaps found** — concrete defects the audit found
- **What to do** — the action to take
- **Acceptance** — how to know it's done
- **Depends on** — which other tickets must finish first (usually Part A)

**Execution order:**
1. Do everything in **PART A — Foundation** first. Without it, page-level fixes will be unstable.
2. Then **PART B — Pages**, in any order, but the suggested phasing in PART E gets revenue earliest.
3. **PART C — Files to delete** can happen any time after the corresponding feature is rewired.
4. **PART D — Schema migration** has its own ordering.

Owner has agreed: "do whatever you want with plans, admin, features, costing — make it reliable." Treat that as written approval for the structural changes here.

---

## TL;DR — The 6 truths the audit revealed

1. **Two parallel monetization systems** (`plan` + `feature*`) are both partly wired, neither fully. Pick one — the **feature marketplace** — and migrate plans into it. (PART D)
2. **Replay attacks possible** on both `feature-checkout/verify` and `payments/verify` — the same Razorpay signature can be re-submitted forever. Same severity as a leaked credit card. (Tickets B-MK-04, B-PAY-02)
3. **Client-side JWT escalation** — any logged-in user can run `update({ plan: 'enterprise' })` and become enterprise. Server reads token for plan checks in places. (Ticket B-AUTH-09 + remove from auth.js)
4. **In-memory state everywhere** (rate limit, live presence, feature cache) — none of it survives a restart, none of it works in cluster mode. The product can't run on more than one process today. (Ticket A-3)
5. **No transactional email actually sent** — verification, password reset, receipts all generate URLs but never reach inboxes. The product feels half-built. (Ticket A-4)
6. **Two duplicate code paths for serving sites** (`/api/serve/...` + `/site/[subdomain]`) and **two WebSocket servers** (`server.js` + `ws-server.js`). One of each is dead. (Tickets C-1, C-2)

Fix those six and the foundation is solid. *Then* add the new features from BUSINESS-RECOMMENDATIONS.md.

---

# PART A — Foundation (cross-cutting, do first)

These are not page-by-page tickets. They are infrastructure tickets that every later page-level fix depends on. Finish these before any tickets in PART B.

---

## A-1. Database schema cleanup + migration prep

**Status:** FIX
**Files:** `prisma/schema.prisma`, `prisma/seed.js`, plus new migration

**Why:**
- `plan.features` is a JSON-string field nobody reads at runtime. Dead.
- `payment.notes` and `payment.providerAccountId` are written but never read. Dead.
- `user.lastDripStep` only matters if drip emails actually run. Keep but document.
- The boolean flags on `plan` (`customDomain`, `formEmails`, `webhooks`, `analytics`) are duplicated by features in the marketplace. Dead once we collapse plans.
- The `featurepurchase.siteId` column exists for per-site entitlement but nothing writes to it. Either wire it up (we will, in PART D) or remove. We keep it.
- There is no `featureusageevent` table — needed for monthly-recurring quotas.
- There is no `idempotencyKey` field on `featureorder` or `payment` — needed to fix replay/double-spend.
- There is no `signatureUsed` flag on either order table — needed to defeat verify-replay.

**What to do:**
1. Add to `featureorder`: `idempotencyKey String? @unique`, `signatureUsedAt DateTime?`.
2. Add to `payment`: `idempotencyKey String? @unique`, `signatureUsedAt DateTime?`.
3. Add new model `featureusageevent`:
   ```prisma
   model featureusageevent {
     id        String   @id @default(cuid())
     userId    String
     featureId String
     siteId    String?
     quantity  Int      @default(1)
     metadata  String?  @db.Text
     createdAt DateTime @default(now())
     user      user     @relation(fields: [userId], references: [id], onDelete: Cascade)
     feature   feature  @relation(fields: [featureId], references: [id], onDelete: Cascade)
     @@index([userId, featureId, createdAt])
     @@index([siteId, featureId])
   }
   ```
4. Add new model `abuseflag` for content moderation (PART E will use it):
   ```prisma
   model abuseflag {
     id        String   @id @default(cuid())
     siteId    String
     reason    String   // 'malware' | 'phishing' | 'reported' | 'manual'
     status    String   @default("open") // 'open' | 'reviewed' | 'cleared' | 'taken_down'
     reporter  String?  // user id or 'system'
     details   String?  @db.Text
     createdAt DateTime @default(now())
     reviewedAt DateTime?
     site      site     @relation(fields: [siteId], references: [id], onDelete: Cascade)
     @@index([status])
     @@index([siteId])
   }
   ```
5. Mark deprecated: leave `plan.features`, `payment.notes`, `payment.providerAccountId` in the schema for one migration cycle, but stop writing to them. Final delete in a follow-up migration after PART D.
6. Update `prisma/seed.js`:
   - Seed exactly **two plans**: `free` (default) and `pro` (monthly, $4.99 / ₹399).
   - Remove Starter, Enterprise from seed. (Existing prod rows are migrated in PART D, not deleted here.)
   - Seed marketplace features with sane `freeQuota` so users experience value before paywall:
     - `submissions` — freeQuota=100/month, type=quantity, monthly recurring (PART D adds the recurring billing semantic).
     - `analytics` — freeQuota=7 days (publicAccessType=`timed`), type=duration.
     - `custom-domain` — freeQuota=0, type=quantity, durationDays=365.
     - `email-notifications` — NEW, freeQuota=0, type=duration (monthly).
     - `webhooks` — NEW, freeQuota=0, type=duration (monthly).
     - `extra-storage` — freeQuota=500MB, type=quantity, lifetime.
     - `team-members` — freeQuota=0, type=quantity, lifetime.
     - `password-protection` — NEW, freeQuota=0, type=boolean per-site.
     - `remove-branding` — NEW, freeQuota=0, type=duration (monthly).

**Acceptance:**
- `prisma migrate dev` runs cleanly.
- New tables exist; new fields exist with correct uniqueness.
- Seed produces only `free` + `pro` plans + the feature list above.

---

## A-2. Replace in-memory state with Redis

**Status:** REWRITE
**Files:** `src/lib/rate-limit.js`, `src/lib/live-presence.js`, `src/lib/feature-access.js` (cache layer), `src/lib/prisma.js` (no change, just for context)

**Why:**
- `rate-limit.js` keeps timestamps in `globalThis.__liveinsecRateLimits`. Survives nothing. In a 2-worker cluster, one IP gets double the budget.
- `live-presence.js` same problem.
- `feature-access.js` has a 60-second in-memory cache that gets stale across processes.
- All three are cluster-hostile and DoS-vulnerable.

**What to do:**
1. Add `ioredis` to dependencies. Read `REDIS_URL` from env (already in `lib/env.js` style — add it).
2. Create `src/lib/redis.js` exporting a singleton client; if `REDIS_URL` is empty, fall back to a no-op stub *only* in dev (warn loudly).
3. Rewrite `rate-limit.js` to use Redis sorted sets for sliding window: key = `rl:{namespace}:{identifier}`, score=timestamp, members=request id.
4. Rewrite `live-presence.js` to use Redis sets: key = `live:{siteId}`, members=visitor ids, with `EXPIRE` per-key for TTL.
5. Rewrite the cache in `feature-access.js` to use Redis with 60s TTL, but *invalidate on write* in admin/feature CRUD endpoints (publish a Redis pubsub message; subscribers refresh).
6. Add a `RATE_LIMIT_DRIVER` env: `memory` | `redis`. Default `redis` in production, `memory` in dev.

**Acceptance:**
- The product can run with `pm2 cluster max` and rate limits hold across workers.
- Restarting the server does not reset visitor counts mid-session.
- Admin feature edits show up in user dashboards within 10 seconds.

---

## A-3. PM2 / cluster + production server posture

**Status:** FIX
**Files:** `ecosystem.config.js`, `server.js`

**Why:**
- App name in PM2 config is `staticdrop` — not the product name.
- Single-process today; no cluster mode. Wastes cores on a multi-core VPS.
- No log rotation, no memory limits.

**What to do:**
1. Rename PM2 app to `liveinsec`.
2. Set `instances: 'max'`, `exec_mode: 'cluster'`, `max_memory_restart: '512M'`, `out_file`, `error_file`, `merge_logs: true`.
3. Add `/api/health` route that returns `200` with DB/Redis ping result; reference it in PM2 health checks.
4. In `server.js`, replace the in-memory `liveVisitors` and `dashboardListeners` Maps with Redis-backed state from A-2. The dashboard broadcast becomes a Redis pubsub subscription so a visitor connecting on worker N updates dashboards on worker M.

**Acceptance:**
- `pm2 start ecosystem.config.js` runs the app on N workers; live count is consistent across all workers.

---

## A-4. Real transactional email

**Status:** FIX
**Files:** `src/lib/email.js`, `src/lib/email-templates.js`, every place that "shows the verification URL inline"

**Why:**
- Email verification, password reset, payment receipts, form notifications — every one of them generates a URL but never sends an actual email. Audit confirms the dashboard and settings page literally render "click here to verify" with the raw URL.
- Without email, retention is dead and the product feels broken.

**What to do:**
1. Pick **Resend** (generous free tier, simple API) — already implied by code comments.
2. Set `RESEND_API_KEY`, `MAIL_FROM` env vars; validate in `lib/env.js`.
3. Implement `lib/email.js` with one function `sendMail({ to, subject, html, text, tags })` that calls Resend, tags the message with the user id + reason, and writes an `auditlog` entry.
4. On any send failure: log + retry (one immediate retry); if retry fails, queue to a `email_queue` table (new model, simple: `to`, `subject`, `html`, `attempts`, `nextAttemptAt`).
5. Replace every "[click here] {url}" inline UI with: send the email, show the user a "We sent a link to your inbox" confirmation. Owner shouldn't ever see a verification URL on screen again.
6. In dev, a console-driver mode (`MAIL_DRIVER=console`) prints emails instead of sending.

**Acceptance:**
- New signup → user receives a real email.
- Forgot password → real email.
- Payment success → receipt email arrives.
- Form submission (after the wedge feature is wired in B-FORM-02) → email arrives.

---

## A-5. HTTPS + CDN posture (Caddy + Cloudflare)

**Status:** FIX (infrastructure, not code-only)
**Files:** new `infra/Caddyfile`, doc updates, `next.config.mjs`

**Why:**
- Without HTTPS, no portfolio link is shareable. Hosting alone is unmonetizable.
- Single-server filesystem-served HTML is one viral LinkedIn post away from a CPU-saturating outage.

**What to do:**
1. Stand up Caddy in front of Node:
   - Route `*.liveinsec.com` and the apex to Node :4000.
   - Automatic Let's Encrypt for the wildcard + apex.
   - For each verified custom domain (read from DB at boot + on-demand via Caddy admin API), issue Let's Encrypt cert.
2. Put Cloudflare in front of Caddy: orange-cloud the wildcard subdomain, enable "Full (Strict)" SSL, cache static assets aggressively (HTML short, CSS/JS/image immutable).
3. In `/api/serve/...` (B-PUB-02), set proper `Cache-Control` per content type (HTML `no-cache`, assets `public, max-age=31536000, immutable` once we content-hash them).
4. Add a `Caddy admin API` write helper: `lib/caddy.js` with `addSiteCert(domain)` / `removeSiteCert(domain)`, called whenever a custom domain is verified or removed.
5. Update `docs/page.js` to remove the false "automatic SSL" claim until this is live.

**Acceptance:**
- Every served site loads on `https://` with a valid cert.
- A new custom domain reaches HTTPS within 60 seconds of DNS verification.
- Cloudflare cache hit ratio for assets is >80% in tests.

---

## A-6. Object storage migration

**Status:** FIX
**Files:** `src/lib/storage.js`, `src/lib/object-storage.js`, `src/app/api/sites/route.js`, `src/app/api/sites/[id]/redeploy/route.js`, `src/app/api/sites/[id]/files/route.js`, `src/app/api/serve/...`

**Why:**
- Local filesystem = single point of failure + impossible to scale horizontally.
- `object-storage.js` already exists; it's just not the default.

**What to do:**
1. Add env: `STORAGE_DRIVER=s3` | `local`, `S3_BUCKET`, `S3_REGION`, `S3_ENDPOINT` (R2-compatible), `S3_ACCESS_KEY`, `S3_SECRET_KEY`.
2. In `lib/storage.js`, `writeFile`/`readFile`/`listFiles`/`deleteFile`/`siteSize` route through a driver chosen at startup.
3. In `/api/serve/...`, when driver=s3, *redirect* (or proxy with streaming) to a signed S3 URL for binary assets, and inline-fetch HTML so the live-tracking script can be injected. (For Cloudflare-cached deployments, the redirect path is fine.)
4. One-time migration script `scripts/migrate-uploads-to-s3.js` reads each existing `uploads/<siteId>/*` and uploads it to S3 with the same key shape. Idempotent.
5. Rotate `IP_HASH_SALT` at startup if `IP_HASH_SALT` env is empty (warn loudly).

**Acceptance:**
- Setting `STORAGE_DRIVER=s3` and re-deploying a site from the dashboard puts files in the S3 bucket and serves them through Caddy.
- Disk usage on the Node host stops growing.

---

## A-7. Audit logging really wired

**Status:** FIX
**Files:** `src/lib/audit.js` (already exists), `prisma/schema.prisma` (`auditlog` exists)

**Why:**
- Several admin/auth code paths *call* `audit('admin.update_user', ...)` but the function isn't imported in those files — runtime crashes.
- Without audit logs, you can't investigate "who changed what" — and Indian compliance regimes increasingly require it.

**What to do:**
1. Verify `lib/audit.js` exports `audit({ userId, action, target, details, request })`.
2. Grep for every existing call site (`audit(`) — every one should `import { audit } from '@/lib/audit'` and await the call.
3. Add audit calls at every privilege boundary: login success/failure, password reset request/confirm, plan change, role promotion, site deletion, custom domain change, feature purchase, refund, admin actions, email send, cron run.
4. In admin dashboard, add a `/admin/audit` page (PART B-ADM-08) that lists the last 500 audit entries with filters by action+user.

**Acceptance:**
- Every admin action and every security-relevant event lands in `auditlog`.
- The admin audit page renders.
- No more `ReferenceError: audit is not defined` runtime failures.

---

## A-8. Strict CSP + served-site security headers

**Status:** FIX
**Files:** `src/middleware.js`, `src/app/api/serve/[subdomain]/[[...path]]/route.js`, `next.config.mjs`

**Why:**
- Current CSP allows `'unsafe-inline'` and `'unsafe-eval'` on dashboard routes.
- Served user sites have **no CSP at all**.
- The injected live-tracking script interpolates `siteId` directly into a `<script>` tag without `JSON.stringify` — a malformed siteId could break or escape it.

**What to do:**
1. Dashboard CSP: nonce-based `script-src 'self' 'nonce-XYZ' https://checkout.razorpay.com`. The nonce is generated per-request in middleware and read from a server component helper.
2. Served-site CSP (default for any HTML in `/api/serve/...`):
   - `default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'`. (User HTML legitimately uses inline styles/scripts; we accept that within the user's own subdomain origin only.)
   - `X-Frame-Options: DENY` by default; opt-in via site setting.
   - `Referrer-Policy: strict-origin-when-cross-origin`.
3. JSON.stringify the siteId before script injection.
4. Add `ETag` + conditional GET to `/api/serve/...`.
5. Add gzip/brotli — Next handles it for app routes; for `/api/serve/...` we add it manually for text MIME types.

**Acceptance:**
- Dashboard pages still work with strict CSP (no inline scripts that fail).
- `curl -I` on a served HTML page shows CSP, X-Frame-Options, Referrer-Policy, ETag.
- A served HTML payload of `<script>alert(parent.location)</script>` cannot read the parent (frame-ancestors none + correct Origin).

---

## A-9. Trial logic — neutralize sites-go-dark

**Status:** FIX
**Files:** `src/lib/billing.js`, `src/lib/site-security.js`, `src/lib/feature-access.js`, `src/app/api/sites/route.js`, `src/app/api/forms/[apiKey]/route.js`, `src/app/api/serve/...`

**Why:**
- Owner has decided: free tier is permanent, sites never go dark. Audit found trial-expiry logic still gates serving in `site-security.js` and form acceptance in `forms/[apiKey]/route.js`.
- This is the single most damaging design choice in the product. Until it's removed, any social proof you build is sabotaged.

**What to do:**
1. In `lib/site-security.js`: `isAccessSuspended()` and `isTrialExpired()` should return `false` always (or be deleted). Replace with `isSiteBlocked(site)` that only checks `site.isActive` and `abuseflag.status='taken_down'`.
2. In `lib/billing.js`: `getBillingSnapshot()` should NOT auto-downgrade as a side-effect. Move that logic to a cron `/api/cron/expire-paid-features` that runs daily and only flips `subscriptionStatus` (never blocks serving).
3. In `/api/forms/[apiKey]/route.js`: remove any "trial expired → reject submission". Replace with quota-check using `feature-access.js` — if user is over their submissions quota, optionally accept and email them "You've hit free limit; upgrade to keep collecting" rather than dropping silently.
4. Site creation always works on free plan; no trial countdown.

**Acceptance:**
- A user signs up, deploys a site, never pays — site is still live and reachable 60 days later.
- The cron expires *paid feature access* (analytics, custom domain) but never blocks the subdomain itself.

---

## A-10. Idempotency + replay defense across all payment flows

**Status:** REWRITE
**Files:** `src/app/api/feature-checkout/route.js`, `src/app/api/feature-checkout/verify/route.js`, `src/app/api/payments/checkout/route.js`, `src/app/api/payments/verify/route.js`, `src/app/api/payments/stripe-webhook/route.js`

**Why:**
- Owner can lose a lot of money. The audit found:
  - **Replay**: same Razorpay signature can be re-submitted forever to `feature-checkout/verify` and `payments/verify`. Each replay is a no-op only because the row is already `paid` — but if anything in that check breaks, a free reactivation pipeline opens.
  - **Double-spend**: clicking "Pay" twice creates two Razorpay orders.
  - **Amount tampering**: verify trusts the Razorpay-returned amount; doesn't compare against expected total stored at checkout time.
  - **Currency mismatch**: cart can be in INR while order is in USD.
  - **Email send failure does not fail the purchase** — user paid, no receipt, support burden.

**What to do:**
1. Every checkout request requires a client-supplied `idempotencyKey` (UUID). Server stores it on `featureorder.idempotencyKey` / `payment.idempotencyKey` (unique). If a request comes in with the same key, return the previously-created order (don't create a new one).
2. Every verify request: after signature passes, write `signatureUsedAt = now()` *atomically with* status flip. If `signatureUsedAt` is already non-null, reject as replay.
3. Verify amount: compare order's stored `totalAmount{Usd|Inr}` against the Razorpay/Stripe payment amount. If they differ by more than 1 unit (rounding), reject and log.
4. Lock currency at checkout time: `featureorder.currency` is authoritative; the cart UI re-renders prices from this source after checkout starts so the user can't switch and confuse themselves.
5. Email failure tolerance: the receipt email goes onto the queue from A-4 (so a Resend outage doesn't break checkout), but if the queue itself fails to enqueue, the order *still succeeds* — never block payment for email.
6. Every successful purchase: `audit('purchase.success', userId, orderId)`. Every replay attempt: `audit('purchase.replay_blocked', ...)`.

**Acceptance:**
- POST verify with the same payload twice → second call returns 409 with `replay_blocked`.
- POST checkout with the same idempotency key twice → second call returns the same order id.
- Tampered amount/currency → 400 with `amount_mismatch`.

---

## A-11. Drop the dual `plan` + `feature*` model — make features authoritative

**Status:** REWRITE — see PART D for the migration plan
**Files:** `prisma/schema.prisma`, `src/lib/plans.js`, `src/lib/feature-access.js`, every page that reads `plan.maxSites` / `plan.maxStorageMB` / etc.

**Why:**
- Audit confirmed: most plan boolean flags (`customDomain`, `formEmails`, `webhooks`, `analytics`) are duplicated by features. `plan.features` field is read nowhere. Plans page admin UI edits dead config.
- Two systems = double the bugs and confusion.

**What to do:**
- See [PART D](#part-d--schema-migration-plan).

---

# PART B — Pages

Page-by-page tickets. Each one is a self-contained ticket. Status legend:

- **KEEP** — works, leave it.
- **FIX** — has bugs/gaps; specific changes listed.
- **REWRITE** — too many issues; redo with new design listed.
- **REMOVE** — delete the file.

---

## B.AUTH — Authentication & onboarding

### B-AUTH-01. Login page

**Path:** `src/app/(auth)/login/page.js`
**Status:** FIX
**Bugs:**
- Calling `router.push()` *and* `router.refresh()` after sign-in causes flash/race.
- No debounce on submit; rapid clicks fire multiple sign-ins.
- OAuth buttons silently swallow `/api/auth/providers` failures.
- No client-side feedback for the 5-failed-attempts lockout returned by rate limit.
- No audit trail.

**What to do:**
1. After sign-in success, just `router.replace('/dashboard')`. Drop `refresh()`.
2. Disable submit button for 1.5s after click + during fetch.
3. Wrap `OAuthButtons` in an error boundary; render nothing on failure with a console warn — don't leave a blank gap.
4. When the rate-limited error comes back, surface "Too many attempts — try again in N minutes."
5. Log every login (success + failure) via A-7.

**Acceptance:** Login flow has no flash; failed login shows useful error; lockout has its own message; audit log shows entries.

---

### B-AUTH-02. Register page

**Path:** `src/app/(auth)/register/page.js`
**Status:** FIX
**Bugs:**
- No password strength meter.
- Country detection happens server-side at register, then the onboarding step asks again — UX repetition.
- Reserved subdomain check happens late.

**What to do:**
1. Add a simple password strength visualizer (4 levels — short, medium, strong, excellent).
2. If country was auto-detected, pre-select it in the next step and let the user override; don't force re-entry.
3. Defer the heavier business decisions (occupation, country) to the onboarding step that follows.

**Acceptance:** Registration flow is 2 short steps with no repeated fields.

---

### B-AUTH-03. Forgot-password page

**Path:** `src/app/(auth)/forgot-password/page.js`, `src/app/api/auth/password-reset/request/route.js`
**Status:** FIX
**Bugs:**
- Currently shows the reset URL inline instead of emailing it. (Cardinal sin.)
- No rate limit on the request endpoint — attacker can spam reset emails.

**What to do:**
1. After A-4, the request endpoint sends an email. The page shows: "If an account with this email exists, you'll receive a reset link shortly." (Don't reveal whether the email exists — privacy.)
2. Rate-limit by IP and by email (max 3 requests / 15 min).

**Acceptance:** A user gets a real email; no URLs are shown on screen.

---

### B-AUTH-04. Reset-password page

**Path:** `src/app/(auth)/reset-password/page.js`, `src/app/(auth)/reset-password/ResetPasswordClient.js`, `src/app/api/auth/password-reset/confirm/route.js`
**Status:** FIX
**Bugs:**
- Token expiry not surfaced clearly to user.
- No "your password was changed" notification email after success.
- Token can theoretically be used twice.

**What to do:**
1. On success, mark token as used (delete the row).
2. Send "your password was changed at {time} from IP {ip}" email after success (security best practice).
3. Show clear UI for expired/used tokens with a "request a new link" CTA.

**Acceptance:** Token used twice → second use 400; user receives a security notification email.

---

### B-AUTH-05. Complete-profile page (onboarding)

**Path:** `src/app/(auth)/complete-profile/page.js`, `src/app/api/auth/onboarding/route.js`
**Status:** FIX
**Bugs:**
- "Skip" leaves `onboardingCompletedAt` null forever — but the dashboard layout redirects to onboarding if null. Skip is broken.
- No way to come back later if user skipped.

**What to do:**
1. Skip writes `onboardingCompletedAt = now()` so the user is not bounced back.
2. Add `/dashboard/settings#profile` as the place to fill these fields later, and link from a banner if `phone`/`occupation` is null.

**Acceptance:** Skipping onboarding doesn't trap the user.

---

### B-AUTH-06. Verify-email page

**Path:** `src/app/verify-email/page.js`, `src/app/verify-email/VerifyEmailClient.js`, `src/app/api/auth/email/request-verification/route.js`, `src/app/api/auth/email/verify/route.js`
**Status:** FIX
**Bugs:**
- Verification URL is *shown* on the dashboard for the user to copy (settings page) instead of being emailed.
- Token doesn't expire on use; multi-use tokens are a small security risk.

**What to do:**
1. Email the URL via A-4. Settings shows a "Resend verification email" button instead.
2. Token deletes on successful verify; `auditlog` entry.

**Acceptance:** Verification email arrives; clicking link verifies; trying again says "already verified."

---

### B-AUTH-07. NextAuth route

**Path:** `src/app/api/auth/[...nextauth]/route.js` and `src/lib/auth.js`
**Status:** REWRITE (the JWT callback)
**Bugs:**
- `trigger === 'update'` lets the client write `plan`, `subscriptionStatus`, `billingPeriod`, `ownerId` into the JWT. This is the **client-side privilege escalation** finding from `03-CYBERSECURITY-AUDIT.md`. CRITICAL.
- Some server code reads `session.user.plan` straight from the token instead of the DB.
- No login attempt rate limiter at the auth layer (only at form layer).

**What to do:**
1. In the `update` branch of the JWT callback, only allow `name`, `phone`, `countryCode`, `countryName`, `emailVerifiedAt`, `billingCurrency`. Strip everything privilege-bearing. Comment why.
2. Audit every `session.user.plan` / `session.user.role` / `session.user.subscriptionStatus` reader and switch them to `getUserLimits(userId)` (which reads DB).
3. Add a server-side rate limiter on `POST /api/auth/callback/credentials`: max 5 failed attempts per IP per 15 min, max 10 per email per hour. Use Redis from A-2.
4. Move the `expiresAt`/`startsAt` calc out of the client.

**Acceptance:** A logged-in user calling `update({ plan: 'enterprise' })` from devtools has no effect on quota. Server logs an `audit('auth.privileged_update_attempt')`.

---

### B-AUTH-08. Profile + password APIs

**Path:** `src/app/api/auth/profile/route.js`, `src/app/api/auth/password/route.js`
**Status:** FIX
**Bugs:**
- No validation that phone is a number (storing garbage).
- Password change doesn't require *current* password (allows session-hijack-to-change-password attack).

**What to do:**
1. Phone: optional, but if present, must match `/^\+?[0-9 \-]{6,20}$/`.
2. Password change: require `currentPassword` field; verify with bcrypt before applying. Email user a "your password was changed" notification.

**Acceptance:** Hijacked session cannot change password without knowing the current one.

---

### B-AUTH-09. OAuth (Google + GitHub)

**Path:** `src/components/OAuthButtons.js`, `src/app/api/auth/[...nextauth]/route.js`, `src/lib/auth.js`
**Status:** ADD (currently scaffolded, not wired)
**Why:** Reduces signup friction by ~30% for the dev/student audience — owner agrees with this in the business doc.

**What to do:**
1. Add Google + GitHub providers to `auth.js`. Read `GOOGLE_CLIENT_ID/SECRET` and `GITHUB_CLIENT_ID/SECRET` from env.
2. On first OAuth signin, create the user with `provider='google'|'github'`, `password=null`, and skip the email verification step (provider already verified).
3. Bounce them to onboarding (complete-profile) like email/password users.
4. Audit log on first OAuth signin.

**Acceptance:** Click "Sign in with Google" works end-to-end.

---

## B.PUB — Public-facing (landing, docs, site serving, forms)

### B-PUB-01. Landing page

**Path:** `src/app/page.js`, `src/components/LandingClient.js`, `src/components/Navbar.js`, `src/components/CountUp.js`
**Status:** FIX
**Bugs:**
- Hardcoded fake testimonials with placeholder names ("Arjun Mehra", "Sarah Chen").
- "12K sites" / "99.9% uptime" / "<1s deploy" stats are made up.
- No real social proof.
- No live "X sites deployed today" counter sourced from DB.
- Comparison table claims (vs. Netlify/Vercel) are unverified — risky for credibility.

**What to do:**
1. Add a server component above LandingClient that fetches: `siteCount = await prisma.site.count({ where: { isActive: true } })`, `submissionCount = await prisma.formSubmission.count()`. Pass these as props.
2. Replace fake counters with real numbers ("X sites · Y leads collected · Z developers"). If small, that's fine — say "Built by founders in India · X sites and counting".
3. Remove the testimonial section until you have real ones (or label it clearly as "Built for users like…" hypothetical scenarios).
4. Tighten the comparison table to claims you can defend with screenshots.
5. Add a "Status: All systems operational" badge in the footer linking to `status.liveinsec.com` (separate static page).
6. Add real `<meta>` description, OG image, twitter card.

**Acceptance:** No fake numbers on landing. Real data used. Faster, no fake authority.

---

### B-PUB-02. Site-serving API

**Path:** `src/app/api/serve/[subdomain]/[[...path]]/route.js`
**Status:** REWRITE
**Bugs (already covered in A-5, A-6, A-8):**
- No CSP on served sites.
- siteId is interpolated into injected script unsafely.
- No ETag/conditional GET → wasted bandwidth.
- No compression for HTML/CSS/JS.
- `Cache-Control: public, max-age=3600` on every file regardless of type.
- Reads files synchronously into memory — no streaming for large assets.

**What to do:**
1. Apply the security headers from A-8.
2. Switch storage reads to streaming via Web `ReadableStream` for non-HTML files; for HTML, fully read so we can inject the live-tracking script.
3. ETag = sha256 hex of file bytes; on `If-None-Match` match → 304.
4. Cache-Control: HTML `no-cache, must-revalidate`; CSS/JS/images `public, max-age=31536000, immutable` (only safe once we content-hash deploy paths — for now use a deploy-id-based version, e.g., set `?v={deploymentId}` on the rewrite path).
5. JSON.stringify siteId, deploymentId, etc., before injecting into `<script>`.
6. 404 page is branded HTML with a link to the deployed site's home and a small "Powered by LiveInSec" footer.

**Acceptance:** `curl -I` shows correct headers; large assets stream; 304 works.

---

### B-PUB-03. Custom-domain serving

**Path:** `src/app/api/serve/[subdomain]/[[...path]]/route.js` (the `_custom` branch), `src/middleware.js`
**Status:** FIX
**Bugs:**
- The `_custom?domain=` query string is set by middleware, but if hostname parsing fails, the serve route returns ugly errors.
- No DNS-verified gate — any custom domain in the DB (even `customDomainVerified=false`) is served if hit.

**What to do:**
1. Only serve if `site.customDomainVerified === true`. If false, return a branded "Verifying your domain — please wait" page with instructions.
2. Add a `/api/sites/[id]/verify-domain` route that resolves the CNAME and confirms it points to `liveinsec.com`. Mark `customDomainVerified=true` on success. Trigger Caddy cert issuance.

**Acceptance:** Unverified custom domains show a setup page, not the actual site (so phishing risk is reduced).

---

### B-PUB-04. Forms API

**Path:** `src/app/api/forms/[apiKey]/route.js`, `src/lib/site-security.js`
**Status:** REWRITE
**Bugs:**
- CORS: when origin is disallowed, response sets `Access-Control-Allow-Origin: *` and 403. Browser sees 403 first; CORS header useless. Inconsistent.
- Webhook URL has SSRF protection only against `localhost/127.0.0.1/0.0.0.0/::1/metadata.google.internal`. Misses `10.x`, `172.16-31.x`, `192.168.x`, and IPv6-bracketed forms.
- API key is the *only* auth — if leaked in HTML (it always is), spam.
- Honeypot field collision: if user names a real field "company" (the default honeypot), all legit submissions silently dropped.
- Quota check is not atomic with insert — race condition allows over-limit submissions.
- No email validation on submitted email fields.
- No deduplication.

**What to do:**
1. Move CORS check to the very start; on disallowed origin, return 403 with no CORS headers (don't pretend the origin is allowed).
2. Block private IP ranges in webhook target; resolve hostname first, validate the IP, *then* fetch.
3. Make honeypot field name **per-site** with a sensible non-collision default (`__lis_hp__`); document in dashboard, code-block-show in setup wizard.
4. Add an optional `_signature` field — if set on the site, require HMAC of the request body using the site's API secret (separate from API key). This is opt-in security for power users.
5. Wrap quota check + insert in a transaction; if over quota, store the submission anyway but flag `quotaOverflow=true` and email the user "Your free quota was hit — leads after this are not visible until you upgrade".
6. Validate any field named `email` against an email regex; reject if invalid (configurable per site).
7. Dedup window: same site + same IP + same body hash within 30 seconds = silently accept but don't store.

**Acceptance:** SSRF cannot exfiltrate to `192.168.0.1`; API key reuse without origin allow-list is blocked; honeypot doesn't kill real fields.

---

### B-PUB-05. Live-presence ping

**Path:** `src/app/api/live/ping/route.js`, `src/lib/live-presence.js`
**Status:** FIX (after A-2)
**Bugs:**
- HTTP polling every 15s is wasteful when WebSocket is open. Pick one transport.
- Visitor id from localStorage is trivially spoofable — any origin can spam to inflate counts.

**What to do:**
1. Drop HTTP ping. Live-presence is WebSocket-only (server.js handles it).
2. Visitor id = sha256(IP_HASH_SALT + ip + user-agent). Server-derived; client can't spoof.

**Acceptance:** No `/api/live/ping` calls in dashboard or served sites; live count is accurate per IP.

---

### B-PUB-06. WebSocket server

**Path:** `server.js`, `src/app/api/ws-token/route.js`
**Status:** FIX (after A-2 + A-3)
**Bugs:**
- Visitor role accepts ANY connection — no auth, no per-IP cap. Trivial inflation attack.
- Maps are unbounded across worker lifetime in single-process; with cluster mode (A-3) they are per-worker.
- `ws-server.js` is a SECOND, unrelated WebSocket server on a different port. Dead code.

**What to do:**
1. Per-IP connection cap: 10 visitor connections / IP / site. Reject with 4006 close code.
2. Visitor ID derived as in B-PUB-05; reject duplicate connections from same visitor.
3. Move `liveVisitors` and `dashboardListeners` into Redis (set per site with TTL). Broadcast via Redis pubsub so all workers see the same count.
4. Delete `ws-server.js` (see C-2).

**Acceptance:** A botnet of 1000 IPs can each open 10 connections; the 11th from any IP is rejected. The count reads consistently across all workers.

---

### B-PUB-07. Docs page

**Path:** `src/app/docs/page.js`
**Status:** FIX
**Bugs:**
- Claims "automatic SSL" for custom domains — false until A-5 ships.
- No webhook payload schema.
- No troubleshooting for 404s.
- Honeypot section doesn't tell users where to change the field name.

**What to do:**
1. Audit every claim for truth; only document what works today.
2. Add: rate-limit defaults table, webhook payload example, common 404 causes, how to change honeypot field name + why you should.
3. Add `<a href="#anchor">` links so users can deep-link.
4. After B-PUB-04 ships HMAC, document it.

**Acceptance:** Reads as the work of someone who tested every example.

---

## B.DASH — User dashboard

### B-DASH-01. Dashboard layout + sidebar

**Path:** `src/app/dashboard/layout.js`, `src/components/Sidebar.js`
**Status:** FIX
**Bugs:**
- Feature service errors are swallowed — sidebar renders without items, no user-visible error.
- Sidebar features hardcode slug→href assumptions; if a slug is renamed in admin, nav silently breaks.

**What to do:**
1. If feature overview fails, render a small banner: "Couldn't load features — refresh." Don't crash.
2. Sidebar nav items come from feature catalog (`showInSidebar=true`) with the exact `sidebarHref` field as the link.
3. Add a sidebar "Unread submissions" badge — count of submissions with `isRead=false` (new field; default false for new submissions; mark read when user opens the inbox).

**Acceptance:** Sidebar resilient to feature errors; unread badge updates.

---

### B-DASH-02. Dashboard home

**Path:** `src/app/dashboard/page.js`
**Status:** FIX
**Bugs:**
- N+1: `sites.filter(active)` is JS-side; should be a count query.
- Onboarding checklist has a non-clickable "Receive first form submission" step.
- Empty submission state references `sites[0]?.apiKey` without null guards.
- Trial countdown referenced even though A-9 removes that behavior.

**What to do:**
1. Replace JS filtering with a Prisma `count` query.
2. Onboarding checklist becomes 4 steps with concrete CTAs:
   - Deploy your first site → /dashboard/sites/new
   - Verify your email → "Resend verification" button
   - Add a contact form to your site → opens a modal with the embed snippet
   - Connect a custom domain → /dashboard/sites/{firstSite}/settings
3. Remove all references to trial countdown.
4. Add a "Lead inbox preview" card that shows the 3 most recent submissions.

**Acceptance:** Home page works for a 0-site user; checklist progresses; trial nag gone.

---

### B-DASH-03. My Sites list

**Path:** `src/app/dashboard/sites/page.js`, `src/components/SiteCard.js`
**Status:** FIX
**Bugs:**
- Submission counts fetched per-card → N queries.
- No search/sort.
- "Deploy New" button confuses when permission denied (looks disabled but hrefs back).

**What to do:**
1. Single Prisma query: `findMany` with `include: { _count: { select: { formsubmission: true, sitevisit: true } } }`.
2. Add search box (filters by name/subdomain client-side, OK for <500 sites).
3. Add sort: newest, most submissions, alphabetical.
4. Permission denied → button reads "Upgrade to deploy more" + opens the store deep-linked to extra-sites.

**Acceptance:** Fast load on 100+ sites; search works; the "deploy" CTA never lies.

---

### B-DASH-04. Deploy New Site wizard

**Path:** `src/app/dashboard/sites/new/page.js`
**Status:** REWRITE
**Bugs:**
- ZIP upload reads the entire file in browser before any size check → big browser freezes.
- No real preview before deploy.
- Editor mode has no Cmd+S, no unsaved indicator, no localStorage draft.
- Custom domain input shown in step 1 but feature gate fails at step 3 → confusing.
- No template option (per BUSINESS-RECOMMENDATIONS.md, templates are a key activation lever).
- Race: subdomain availability check + create are not atomic.

**What to do:**
1. Step 1 (Site basics): name + subdomain (with live availability check, debounced 300ms). Custom domain field hidden if user lacks the feature; if visible, pre-validate.
2. Step 2 (Choose source): three tiles — *Upload ZIP* / *Build in browser* / *Start from template*.
3. Step 3 (Source content):
   - ZIP: client-side size check first (>10MB warn, >50MB block). Then parse with JSZip. Show file tree preview + index.html validation.
   - Editor: Monaco with starter `index.html` + `style.css` + `script.js`. Cmd+S saves to draft (localStorage). "Unsaved changes" indicator.
   - Template: render thumbnails of `lib/site-templates.js`; pick one → preview iframe.
4. Step 4 (Preview & deploy): iframe preview of the site as it will be served. "Looks good — deploy" button.
5. Backend: subdomain create must use `INSERT ... ON DUPLICATE KEY` semantics. Catch unique-constraint violation and surface "subdomain just taken" without leaving an orphan site row.

**Acceptance:** Big ZIP doesn't freeze browser; preview iframe shows the site; navigating away mid-edit prompts.

---

### B-DASH-05. Site detail (Overview)

**Path:** `src/app/dashboard/sites/[id]/page.js`, `src/app/dashboard/sites/[id]/SiteDetailClient.js`
**Status:** FIX
**Bugs:**
- API key is shown inline with no rotate button; if leaked, only fix is delete + recreate site.
- Custom domain section is huge and locked behind paywall — wastes space for free users.
- DNS instructions don't have a Verify DNS button.
- Form embed code is hardcoded with the API key inline; on regenerate, examples go stale.

**What to do:**
1. Add `POST /api/sites/{id}/regenerate-key` (already exists — wire it). Add a "Rotate API key" button with confirmation.
2. Show form embed code and dynamically reflect rotated key.
3. Custom domain card: collapsed by default; "Upgrade to use custom domain" CTA when locked.
4. Add a **Verify DNS** button calling the route from B-PUB-03.
5. Add a "Send test submission" button: server crafts a fake submission, sends it through `/api/forms/{apiKey}` with origin = the site's primary URL, surface the result. Confidence-builder.

**Acceptance:** User can rotate key; verify DNS; send a test form; embed snippets always reflect current state.

---

### B-DASH-06. Site Settings

**Path:** `src/app/dashboard/sites/[id]/settings/page.js`, `src/app/dashboard/sites/[id]/SiteDetailClient.js`
**Status:** FIX
**Bugs:**
- `isActive` toggle has no confirmation — one click and the site goes dark.
- No unsaved-changes warning if user navigates away mid-edit.
- `router.refresh()` after save reloads everything; UX heavy.
- Custom domain accepted with no DNS validation.
- Honeypot field name collision risk (B-PUB-04).

**What to do:**
1. Confirm dialog for `isActive=false` and for delete (already exists for delete, just make consistent).
2. Track `isDirty` state; warn before route change.
3. Replace `router.refresh()` with optimistic update + targeted refetch.
4. Custom domain field has its own "Verify" button; can't be saved as `verified` from UI.
5. Honeypot field input shows a "Common conflicts: company, email, phone — pick something obscure like __lis_hp__" warning.

**Acceptance:** Settings feels like a normal SaaS dashboard.

---

### B-DASH-07. Site Files (in-browser editor)

**Path:** `src/app/dashboard/sites/[id]/files/page.js`, `src/app/dashboard/sites/[id]/files/SiteFilesClient.js`
**Status:** REWRITE
**Bugs:**
- Auto-save errors are silently swallowed → user thinks file is saved when it isn't.
- Upload of file with same name silently overwrites without confirmation.
- No file-type detection on new file (must type full extension).
- No Cmd+S; no scroll buttons for tab bar; sidebar state not persisted.
- Storage meter hardcoded to 10MB cap.
- No undo / no version history.

**What to do:**
1. Auto-save: visible "Saving…/Saved/Failed — retry" indicator; on failure, queue the save and retry on connectivity, never silently lose.
2. Upload-with-conflict: prompt "Replace `index.html`?".
3. New file: dropdown for extension (.html / .css / .js / .json / .md / other) — default name from extension.
4. Cmd+S / Ctrl+S = save current tab.
5. Tab bar: horizontal scroll buttons + middle-click to close.
6. Sidebar state in localStorage.
7. Storage meter reads from feature quota (`extra-storage` from feature-access).
8. Add a tiny version history: every save creates a `siteFileVersion` row (new model: id, siteId, path, hashOrContent, createdAt). Up to 20 versions kept per file. Revert button per version.

**Acceptance:** Editor feels like a real tool; no silent data loss; storage meter reflects user's actual quota.

---

### B-DASH-08. Per-site submissions inbox

**Path:** `src/app/dashboard/sites/[id]/submissions/page.js`, `src/components/SubmissionsTable.js`
**Status:** REWRITE — to become the **Lead Inbox** (per BUSINESS-RECOMMENDATIONS.md §4.3)
**Bugs:**
- Search only against `formName` and JSON string (case-sensitive substring) — useless for actual contact data.
- Pagination size 10 (vs. 12 on global page — inconsistent).
- CSV export only exports the visible page.
- No way to mark read / archived / spam / contacted / won / lost.
- No filter by date range or by site.
- No "open in detail view".

**What to do:**
1. Schema additions: `FormSubmission.status` (`new` | `read` | `contacted` | `won` | `lost` | `spam`, default `new`); `FormSubmission.notes` text; `FormSubmission.tags` JSON.
2. Search: hit a small `formSubmissionIndex` table (denormalized: submissionId, fieldName, fieldValue, all lowercased) maintained on insert. Then ILIKE search by field/value.
3. Date-range filter (last 24h / 7d / 30d / custom).
4. CSV export: switch to a streaming server endpoint `GET /api/submissions/export?siteId=X&...filters` that streams every matching row, not just the visible page.
5. Status workflow buttons inline + a slide-over detail panel showing all fields, IP, user-agent, timestamp.
6. Mark read on open.
7. Bulk select: change status / delete / export / mark spam.

**Acceptance:** It looks and behaves like a CRM-lite, not a debug log. Owner can sell this as a "Lead Inbox" for ₹400/mo.

---

### B-DASH-09. Global submissions inbox

**Path:** `src/app/dashboard/submissions/page.js`
**Status:** FIX
**Bugs:**
- Same as B-DASH-08, plus pagination size 12 (vs 10) — inconsistent.
- Top-sites list doesn't link out.

**What to do:**
1. Reuse the rewritten Lead Inbox component from B-DASH-08, with an extra "Site" column and site filter.
2. Standardize pagination (use 25).
3. Top-sites list links to per-site inbox.

**Acceptance:** Single component covers both views.

---

### B-DASH-10. Per-site analytics

**Path:** `src/app/dashboard/sites/[id]/analytics/page.js`, `src/components/AnalyticsDashboard.js`
**Status:** FIX
**Bugs:**
- Live-count polling is hardcoded at 5s — hammer-prone.
- No time-series chart (only stat cards + bar lists).
- No referrer breakdown drill-down.
- No date-range picker.
- No export.

**What to do:**
1. Add date-range picker (24h / 7d / 30d / 90d / custom).
2. Time-series area chart for visits/day; pure SVG (already partly done) — add legend, hover tooltip.
3. Referrer/Country/Browser/Device tabs; each is a top-N bar list with drill-down to filtered detail view.
4. Replace polling with WebSocket subscription (server.js already supports dashboard role).
5. Export PNG/CSV.

**Acceptance:** Looks like a real analytics page; not a debug widget.

---

### B-DASH-11. Global consolidated analytics

**Path:** `src/app/dashboard/analytics/page.js`, `src/app/dashboard/analytics/ConsolidatedAnalytics.js`
**Status:** FIX
**Bugs:**
- "All sites" view is N independent dashboards stacked — not summed.
- Site tabs overflow with 20+ sites and don't scroll.

**What to do:**
1. "All sites" = single chart summing visits across all the user's sites; per-site mini-cards with sparkline + total.
2. Site tabs become a searchable dropdown when > 8 sites.

**Acceptance:** Truly consolidated view.

---

### B-DASH-12. Settings (workspace + profile + team)

**Path:** `src/app/dashboard/settings/page.js`, `src/app/dashboard/settings/SettingsClient.js`
**Status:** FIX
**Bugs:**
- Email verification link rendered in-page instead of emailed.
- Team member create has no email validation; team member delete is not implemented; permissions can't be edited (only delete + recreate).
- No account deletion flow.
- Phone has no validation.
- No billing/subscription overview.

**What to do:**
1. "Resend verification email" button (uses A-4).
2. Email validation in team add.
3. Implement DELETE on `/api/team/members/[id]`.
4. Implement PUT to update permissions on existing members.
5. Add a 4th tab: **Billing** — current plan, paid features, next renewal date, payment method (Razorpay last-4 if available), invoices list, link to Manage subscription / cancel.
6. Add "Delete account" at bottom of profile tab. Two-step confirmation → soft-delete user (mark `deletedAt`); hard-delete after 30 days via cron. Cancels active subscriptions.
7. Add "Change password" → require current password (B-AUTH-08).

**Acceptance:** Owner can confidently say "this is a real product" pointing at the settings page.

---

## B.STORE — Feature marketplace (user-facing)

### B-STORE-01. Store page

**Path:** `src/app/dashboard/store/page.js`
**Status:** FIX
**Bugs:**
- Currency toggle is local state only; not persisted; cart shows USD even after user picks INR.
- Deep link `?feature=slug` highlight times out at 3s — user misses it.
- "Running low" hardcoded at 20% — not configurable.
- "Recommended for you" only shows in 'all' tab.
- No one-click Buy Now per card.

**What to do:**
1. Currency in `user.billingCurrency` (already in schema). Toggle writes back to DB. Server sources of truth.
2. Deep-linked feature: scroll + persistent ring outline + auto-open quantity selector.
3. Recommended panel always visible at top, regardless of tab.
4. Each feature card has both **Buy Now** (skip cart, instant checkout for qty=1 of `recommendedQty`) and **Add to Cart**.
5. Add **Bundles** section above features (per BUSINESS-RECOMMENDATIONS.md §4 + §3 Strategy 2):
   - Starter Pack: submissions(1k) + analytics(3mo) + custom-domain(1) at 25% off.
   - Growth Pack: bigger.

**Acceptance:** Currency is sticky; deep-link works; bundles visible.

---

### B-STORE-02. Cart page

**Path:** `src/app/dashboard/cart/page.js`
**Status:** REWRITE
**Bugs:**
- Currency switch mid-cart can desync amount vs. currency sent to Razorpay.
- No tax/GST line.
- Cart never expires — stale cartitems persist forever.
- Quantity change doesn't refresh order summary in real time.
- No coupon field.
- Success screen reflects only what verify returned — partial successes can mislead.

**What to do:**
1. Lock currency once user clicks Checkout (already covered partially in A-10).
2. Show a tax line (placeholder: `0` for free tier, real GST when seller has GSTIN).
3. Cart expiry: 24 hours; cron clears stale items.
4. Real-time total recalculation on qty change.
5. Coupon code field — server-side validates against a new `coupon` model (id, code, discountType, discountValue, expiresAt, maxRedemptions, usedCount).
6. Success screen reads from the actual purchase rows, not the verify response.

**Acceptance:** Cart math is always right; tax line present; coupons work.

---

### B-STORE-03. Purchases page

**Path:** `src/app/dashboard/purchases/page.js`
**Status:** FIX
**Bugs:**
- Shows expired purchases but no "Renew now" CTA.
- Unit labels not explained.
- No usage dashboard ("you've used X of Y").
- No refund self-service.

**What to do:**
1. Each feature row shows: total quota / used / remaining / expiry. Progress bar if metered.
2. "Renew now" deep-links into store with the right feature + qty preselected.
3. Refund: within 7 days, "Request refund" button creates a `refundrequest` row (new model). Admin approves in B-ADM-09.
4. Unit labels with helper text.

**Acceptance:** User sees exactly what they own and what's left.

---

### B-STORE-04. Cart API

**Path:** `src/app/api/cart/route.js`
**Status:** FIX
**Bugs:**
- Inactive-feature cleanup is fire-and-forget (`.catch(() => {})`).
- No max-cart-size guard.
- No final qty validation at checkout time (only at cart-add time).

**What to do:**
1. Synchronous cleanup of inactive features.
2. Max 100 cart items per user.
3. Re-validate qty bounds inside `/api/feature-checkout` before creating Razorpay order.

**Acceptance:** Stale items can't poison checkout.

---

### B-STORE-05. Feature checkout

**Path:** `src/app/api/feature-checkout/route.js`, `src/app/api/feature-checkout/verify/route.js`
**Status:** REWRITE — see also A-10
**Bugs:** see audit. Replay risk, no idempotency, amount tampering, currency mismatch, email failure as silent fatal.

**What to do:** Implement A-10 in this slice; ensure receipts use the email queue.

**Acceptance:** A-10 acceptance.

---

### B-STORE-06. Purchases / feature-overview API

**Path:** `src/app/api/purchases/route.js`, `src/app/api/feature-overview/route.js`
**Status:** FIX
**Bugs:**
- `isExpired` checks `status !== 'active'` but only `'active'` is set anywhere — dead branch.
- No filtering by siteId despite schema support.
- No usage cap warning.

**What to do:**
1. Add `?siteId=` query for per-site entitlements.
2. Include `usagePct` and `nearLimit` flags in feature-overview response so dashboard can render warnings.
3. Wire `featureusageevent` (from A-1) for monthly metering on submissions.

**Acceptance:** Dashboard can show "you're at 87% of your monthly leads."

---

## B.PAY — Plan-level payments

### B-PAY-01. Plan checkout

**Path:** `src/app/api/payments/checkout/route.js`
**Status:** REWRITE — see A-10
**What to do:** A-10. Plus: only allow free → pro (single tier post PART D); reject Starter/Enterprise.

---

### B-PAY-02. Plan verify (Razorpay)

**Path:** `src/app/api/payments/verify/route.js`
**Status:** REWRITE — see A-10
**What to do:** A-10. Plus: chain `expiresAt` from current period end if user is renewing, not from now. Send a "Welcome to Pro" email on first upgrade.

---

### B-PAY-03. Stripe webhook

**Path:** `src/app/api/payments/stripe-webhook/route.js`
**Status:** FIX
**Bugs:**
- Idempotency relies only on `payment.status === 'completed'` check; if check fails for any reason, double-processed.
- Missing-payment case returns 200 silently.
- Doesn't handle `charge.dispute_created`, `invoice.payment_failed`.

**What to do:**
1. Use the same `signatureUsedAt` pattern as A-10.
2. If payment record not found, log + audit + 200 (Stripe will keep retrying otherwise; logging keeps a trail).
3. Add handlers for dispute and payment_failed (mark subscription as past_due, schedule dunning email).

**Acceptance:** Stripe webhooks are reliable + observable.

---

### B-PAY-04. Cron: trial-reminders

**Path:** `src/app/api/cron/trial-reminders/route.js`
**Status:** REMOVE (post-A-9)
**Why:** Trial behavior is going away. The job has no purpose.
**What to do:** Delete the route + the cron schedule. If a "did you know about Pro?" nudge is wanted later, that becomes a new job (`pro-nudge`) with different semantics.

---

### B-PAY-05. Cron: drip-emails

**Path:** `src/app/api/cron/drip-emails/route.js`
**Status:** FIX
**Bugs:**
- N+1 queries for user counts.
- `take: 100` per drip step; users beyond that get nothing.
- No audit trail of sent emails.
- CRON_SECRET unset → fails closed but doesn't log.

**What to do:**
1. Batch counts in a single query per step.
2. Loop with offset until done; cap at 1000 per step run; surface "X users skipped — re-run".
3. Write to `auditlog` for each send.
4. Log when CRON_SECRET is unset/incorrect (but still fail closed).

**Acceptance:** All eligible users get their drip; audit trail exists.

---

### B-PAY-06. New cron: paid-feature-expiry

**Path:** new `src/app/api/cron/expire-paid-features/route.js`
**Status:** ADD
**Why:** A-9 moves the expiry side-effect out of `getBillingSnapshot`. Need a job that does it.
**What to do:**
1. Daily: find `featurepurchase` rows where `expiresAt < now()` and `status='active'`. Set `status='expired'`. Audit each.
2. Send a 3-day-pre-expiry "your access expires soon" email.
3. Send an "expired — renew here" email day-after.
4. Invalidate Redis feature cache for affected users.

**Acceptance:** A user with an analytics purchase that expires today: dashboard reflects it tomorrow morning, with a renewal email in their inbox.

---

## B.ADM — Admin

### B-ADM-01. Admin layout + sidebar

**Path:** `src/app/admin/layout.js`, `src/components/AdminSidebar.js`
**Status:** KEEP
**Note:** Only thing missing is an audit-log link (added by B-ADM-08).

---

### B-ADM-02. Admin dashboard

**Path:** `src/app/admin/page.js`
**Status:** FIX
**Bugs:**
- Total revenue includes pending/failed.
- No MRR by plan, no churn, no LTV.
- No feature-marketplace revenue shown.
- Currencies summed naively.

**What to do:**
1. Revenue = sum where `status='completed'` only.
2. Split USD revenue from INR revenue (don't mix paise + cents).
3. Add MRR widget: sum of monthly-recurring features + Pro plan / month.
4. Add churn cohort: users whose `currentPeriodEndsAt` lapsed and didn't renew within 7 days.
5. Add ARPU (paying users only).
6. Add feature revenue bar by feature slug.

**Acceptance:** Owner can answer "what's our MRR?" in one click.

---

### B-ADM-03. Admin users

**Path:** `src/app/admin/users/page.js`, `src/app/admin/users/AdminUserActions.js`, `src/app/api/admin/users/[id]/route.js`
**Status:** FIX
**Bugs:**
- Promotion to admin is instant — no email confirmation.
- `audit()` called but not imported in some files (A-7 fixes the import; this fixes the calls).
- Plan change doesn't reset subscription state.
- Hard-delete only.

**What to do:**
1. Promotion to admin: send email confirmation + write `pendingRoleChange` field; only applies after user clicks the email link.
2. Add `user.deletedAt` + soft-delete; restore button.
3. On plan change, reset `subscriptionStatus`, `currentPeriodEndsAt` consistently.
4. Add a "send password reset" button (admin-initiated).
5. Add bulk export to CSV.

**Acceptance:** Audit log records every admin action on users; soft-delete works; promotion is two-step.

---

### B-ADM-04. Admin sites

**Path:** `src/app/admin/sites/page.js`
**Status:** FIX
**Bugs:**
- Read-only; can't disable/delete a site.
- No filter by user/plan.
- No flag-as-abuse button (will use the `abuseflag` from A-1).

**What to do:**
1. Add disable/delete buttons (audited).
2. Add user/plan filters + storage usage column.
3. Add "Flag for review" → creates an `abuseflag`; once flagged, the site shows a banner on serve "Site under review."

**Acceptance:** Admin can take a phishing site offline in one click.

---

### B-ADM-05. Admin submissions

**Path:** `src/app/admin/submissions/page.js`
**Status:** FIX
**Bugs:**
- `take: 100` no pagination.
- `JSON.parse` no try/catch — corrupted data crashes page.
- No filter / search / export.

**What to do:**
1. Pagination (25 per page, cursor or offset).
2. Try/catch around parse.
3. Filter by site, by date.

**Acceptance:** No crash on malformed data; usable at 10k+ submissions.

---

### B-ADM-06. Admin plans

**Path:** `src/app/admin/plans/page.js`, `src/app/admin/plans/AdminPlanActions.js`, `src/app/api/admin/plans/[id]/route.js`
**Status:** REWRITE — drop most of it
**What to do (after PART D):**
1. Reduce UI to just two read-write rows: **Free** and **Pro**. Each with editable price (USD/INR, monthly/yearly), name, description.
2. Remove fields that are no longer enforced (maxSites/maxStorageMB/etc. moved to feature catalog).
3. Remove the dead `features` JSON field.
4. Add a "WARNING — N active subscribers on this plan" before saving.
5. Add price sanity validation (yearly < 12 × monthly + 10%).

**Acceptance:** Admin manages exactly the two plans; no dead config.

---

### B-ADM-07. Admin features (the marketplace catalog)

**Path:** `src/app/admin/features/page.js`, `src/app/admin/features/AdminFeatureManager.js`, `src/app/api/features/route.js`, `src/app/api/features/[id]/route.js`
**Status:** REWRITE
**Bugs:** see audit — broken seed semantics, no validation, broken duration model, no dependency enforcement.

**What to do:**
1. Make seed fully idempotent (always overwrite all fields including price; admin's manual edits are still respected, but seed is the recovery path — admin has a "Reset to seed" button per feature).
2. Validate: `minQty <= maxQty`; `type='duration'` requires non-null `durationDays`; `type='boolean'` requires no `minQty/maxQty`; `publicAccessType='partial'` requires `publicQuota>0`; `publicAccessType='timed'` requires `publicExpiresAt`.
3. Enforce `requiresFeatureSlug`: when adding to cart, refuse if the prerequisite is not active for the user; surface "Get Analytics first" CTA.
4. Make duration semantics: **either** "purchase grants `durationDays` regardless of qty" (simpler) **or** "qty * durationDays" — pick the first; document. Migrate existing data accordingly (most users will have qty=1 anyway).
5. Soft-delete (mark inactive) instead of hard-delete; only allow hard-delete if zero purchases ever existed.
6. Cart-item check before delete.

**Acceptance:** Catalog is consistent; new features added via admin are validated; nothing crashes the cart.

---

### B-ADM-08. Admin audit log page

**Path:** new `src/app/admin/audit/page.js`
**Status:** ADD
**Why:** Needed for compliance + to investigate "who did what."
**What to do:** Paginated list of `auditlog` entries; filters by action, user, date.

**Acceptance:** Admin can answer "who promoted user X to admin?"

---

### B-ADM-09. Admin refunds

**Path:** new `src/app/admin/refunds/page.js`, new `src/app/api/admin/refunds/[id]/route.js`
**Status:** ADD
**Why:** Without a refund flow, every refund is a manual support ticket + Razorpay dashboard click.
**What to do:**
1. List of `refundrequest` rows.
2. Approve → call Razorpay refund API → mark `featurepurchase.status='refunded'` → audit.
3. Reject → set status, send email.

**Acceptance:** Refunds are one-click for admin.

---

### B-ADM-10. Admin health

**Path:** `src/app/admin/health/page.js`
**Status:** FIX
**What to do:** Add Redis ping (post-A-2). Add Caddy/SSL status (post-A-5). Add "emails queued" / "emails failed" widget (post-A-4).

**Acceptance:** One screen tells the operator if the system is healthy.

---

### B-ADM-11. Admin settings

**Path:** `src/app/admin/settings/page.js`
**Status:** FIX
**Bugs:** read-only despite name.
**What to do:** Implement editing of onboarding fields + occupation list (from `appconfig`); editing email-template overrides.
**Acceptance:** Admin can change the onboarding question list without redeploying.

---

# PART C — Files to remove entirely

These are dead, redundant, or actively confusing.

| Path | Why | Notes |
|------|-----|-------|
| C-1. `ws-server.js` | Standalone WS server on port 4001, never used by `server.js`. Confusing twin. | Delete. Update README if referenced. |
| C-2. `src/app/site/[subdomain]/[[...path]]/page.js` | Duplicate of middleware-rewrite-to-/api/serve. Two code paths for serving sites. | Delete. Document `/api/serve` as canonical in ARCHITECTURE.md. |
| C-3. `plan.features` field on `plan` model | Read by nothing at runtime. Dead. | Remove in a second migration after PART D stabilizes. |
| C-4. `payment.notes`, `payment.providerAccountId` columns | Never read. | Remove in a second migration. |
| C-5. Existing `Starter` and `Enterprise` plan rows in production DB | Owner has chosen Free + Pro only. | Migration script in PART D moves users off them, then deletes the plan rows. |
| C-6. `src/components/RotatingText.js` | Tiny, only used in landing. Inline into LandingClient. | Optional; not urgent. |
| C-7. Dead `_emailTemplate` overrides if any in `email-templates.js` | Audit when wiring A-4. | Keep templates that A-4 uses, delete the rest. |
| C-8. `src/app/api/live/ping/route.js` | Replaced by WebSocket-only live-presence (B-PUB-05). | Delete after B-PUB-05 ships. |

---

# PART D — Schema migration plan

Goal: collapse `plan` (multi-tier) and `feature*` (marketplace) into one coherent system.

**Final state:**
- Two plans: `free` (default) and `pro`. Plan controls **base quotas only** (e.g., baseline submissions/month, baseline storage). Plan does NOT contain feature flags.
- Marketplace features add **on top of the base quota**.
- A user's effective quota for any feature = `plan.baseQuota[feature] + sum(active featurepurchases[feature])`.

**Migration sequence (each step is a separate ticket the LLM can pick up):**

### D-1. Add new fields, don't drop old ones yet
1. Add to `plan`: `baseQuotas` (JSON, e.g., `{"submissions":100, "storageMB":500, "sites":3}`).
2. Backfill from existing `plan.maxSites/maxSubmissions/maxStorageMB/etc.` values.
3. Don't read the old fields anywhere; only `plan.baseQuotas`.

### D-2. Update `feature-access.js` to read base + marketplace
- `getUserFeatureQuota(userId, slug, siteId?)`:
  - Look up user's plan; read `plan.baseQuotas[slug]` (default 0).
  - Sum active marketplace purchases of the same slug.
  - Return base + sum.

### D-3. Migrate existing paid users off Starter / Enterprise
1. Find users with `planSlug='starter'`. Convert to `pro` (matching active period). Send "We've simplified our plans — your Starter plan is now Pro" email.
2. Find users with `planSlug='enterprise'`. Convert to `pro` + auto-grant marketplace credits roughly equivalent to enterprise quotas (custom-domains × 5, team-members × 10, etc.). Email.
3. Mark the Starter / Enterprise plan rows as `isActive=false`.

### D-4. Remove dead boolean flags from `plan`
- Delete `customDomain/formEmails/webhooks/analytics/teamMembers` columns.
- The marketplace features cover all of them.

### D-5. Delete dead Starter / Enterprise rows
- After 30 days of D-3 (anyone still on them is force-migrated).
- Delete the inactive plan rows.

### D-6. Implement monthly recurring submissions billing
- New behavior: `submissions` feature `type='monthly'` (extension of `quantity`). On purchase, sets `expiresAt = now + 30 days`. Each `featureusageevent` (form submission insert) increments usage. At expiration, usage is forgiven; if user hasn't renewed, they drop to base quota.
- Cron `expire-paid-features` (B-PAY-06) handles the renewal-vs-expire logic.

### D-7. Drop the dead columns (final cleanup)
- `plan.features` (JSON), `plan.maxSites`, `plan.maxStorageMB`, `plan.maxSubmissions`, `plan.maxFileSizeMB`, `plan.priority`.
- `payment.notes`, `payment.providerAccountId`.

**Acceptance for PART D as a whole:**
- New users → `free` plan; have 100 submissions/month from `plan.baseQuotas`.
- A user buying 1k extra submissions sees `1100/month` total in their dashboard.
- The admin plans page shows just Free + Pro with `baseQuotas` editable.
- Old Starter/Enterprise users smoothly upgraded.

---

# PART E — Suggested execution order

The LLM should pick tickets roughly in this order. Tickets in the same row can run in parallel.

| Phase | Tickets | Outcome |
|-------|---------|---------|
| **Phase 0 — Foundation** (1-2 weeks) | A-1, A-2, A-3, A-4, A-7, A-8 | Schema ready, Redis live, real email working, audit logs flowing, security headers correct. |
| **Phase 0.5 — Security blocking** (a few days) | B-AUTH-07 (JWT escalation fix), A-10 (replay/idempotency), B-PUB-04 (forms SSRF) | Three CRITICAL findings closed. Now safe to demo to anyone. |
| **Phase 1 — Stop the bleeding** (1 week) | A-9 (kill trial-expiry behavior), C-1, C-2, C-8 (delete dead code), B-PAY-04 (delete trial reminders cron) | Foundation reflects the strategic direction; no more sites going dark; no more dead twins. |
| **Phase 2 — Public-facing reliability** (1 week) | A-5 (HTTPS via Caddy), A-6 (S3), B-PUB-02 (serve rewrite), B-PUB-03 (custom-domain verify), B-PUB-06 (WS hardening) | Sites are HTTPS, fast, secure. Custom domains work. |
| **Phase 3 — Marketplace & billing rewire** (1.5 weeks) | A-11 + PART D (D-1 to D-3), B-ADM-06 (plans page), B-ADM-07 (features page), B-STORE-01..06 (store/cart/purchases), B-PAY-01..03, B-PAY-06 | Single coherent monetization system. |
| **Phase 4 — Auth polish** (3 days) | B-AUTH-01..06, B-AUTH-08, B-AUTH-09 (OAuth) | Login/registration feels modern; emails actually arrive. |
| **Phase 5 — Dashboard polish** (1.5 weeks) | B-DASH-01..12 | Dashboard feels like a real product. Lead Inbox is sellable. |
| **Phase 6 — Admin completeness** (3 days) | B-ADM-01..05, B-ADM-08..11 | Owner can run the business from the admin panel. |
| **Phase 7 — Cleanup** (2 days) | PART C (remove dead files), PART D (D-4 to D-7) | Schema and code are clean. |

**Total: ~6 weeks of focused engineering for one engineer + LLM.** Roughly halves with two engineers.

After Phase 7, **all the BUSINESS-RECOMMENDATIONS.md new features (form-email-notifications, lead-inbox-already-done, AI generator, templates, malware scan, white-label, etc.) can be added on a solid foundation.** Trying to add them first is what got us here.

---

# Appendix — Master ticket index

For the LLM running through tickets one at a time:

```
PART A — Foundation (do first):
  A-1   Database schema cleanup + new tables
  A-2   Redis (rate limit, presence, cache)
  A-3   PM2 cluster + health
  A-4   Real transactional email (Resend)
  A-5   HTTPS + Caddy + Cloudflare
  A-6   Object storage (S3/R2)
  A-7   Audit logging really wired
  A-8   Strict CSP + served-site security
  A-9   Neutralize sites-go-dark trial logic
  A-10  Idempotency + replay defense
  A-11  Drop dual plan + feature model (driver for PART D)

PART B — Pages:
  B-AUTH-01..09   Auth pages
  B-PUB-01..07    Public pages (landing, serve, forms, docs, WS)
  B-DASH-01..12   User dashboard
  B-STORE-01..06  Marketplace
  B-PAY-01..06    Payments + crons
  B-ADM-01..11    Admin

PART C — Deletions:
  C-1..C-8

PART D — Schema migration:
  D-1..D-7

PART E — Execution order
```

Each ticket id is a self-contained prompt for an LLM. Hand it the ticket id + `docs/memory/REWIRING-PLAN.md` and it can work without further context.
