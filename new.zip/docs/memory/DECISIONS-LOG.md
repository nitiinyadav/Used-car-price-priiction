# Decisions Log

Append-only record of strategic and architectural decisions confirmed with the owner.
Newest at the top.

---

## 2026-05-02 (Session 4) — Form-journey psychology + landing rewrite

Owner flagged two real psychological gaps:

1. **A new user has no idea forms exist.** They sign up, deploy a site, then
   discover the form API only by digging into Settings — by which point they've
   already lost the "wow" moment.
2. **The landing has a fake skeleton mockup that looks like loading state.** It
   needs creative, real product feel — like Tiiny.host but better — with SEO
   copy that converts.

**What shipped (Session 4):**

- ✅ **Server-side form auto-wiring** (`src/app/api/sites/route.js`):
  added `wireFormPlaceholdersInDeployedFiles()` that walks every HTML file
  after deployment and replaces the literal `YOUR_API_KEY` token with the
  freshly-generated key. Also rewrites relative `/api/forms/...` paths to be
  absolute so forms keep working when the site is later served on a custom
  domain. **Result: a user who picks a template with a contact form has it
  fully wired by the time they click "Visit your site"** — no manual setup.

- ✅ **Templates flagged + form-promise badges** (`src/lib/site-templates.js`):
  added `hasContactForm: true|false` flag to every template. The blank
  starter now also includes a working contact form. Wizard step 2 shows a
  "📬 form" badge on every template that has one, so users see at a glance
  that picking a template means picking a working contact form too.

- ✅ **`FormPromisePanel` in deploy wizard step 1** (new component
  `src/components/FormPromisePanel.js`): the right rail of the new-site
  wizard now teaches users about the form API BEFORE they deploy. Shows
  the URL pattern their form will use (with their typed subdomain), the
  100-leads-free-per-month quota, and a 4-step "what happens after Deploy"
  list. Sticky on scroll. **This closes the "I deployed and now I'm lost"
  gap by educating before the action, not after.**

- ✅ **`DeploySuccessScreen` redesign** (inline component in
  `src/app/dashboard/sites/new/page.js`): completely replaced the boring
  "Site is live!" screen with a 3-card celebration that leads with
  **"Send a test submission"**. Big indigo button calls
  `/api/sites/[id]/test-submission` (built in Session 3), shows the result
  with a link straight to the Lead Inbox. Below: copyable form endpoint
  with collapsible HTML snippet. Bottom: 3 secondary CTAs (Manage site,
  Power up, Deploy another). **This is the "aha moment" — users land in
  their own inbox seeing a real submission within 30 seconds of deploying.**

- ✅ **`createSite` API now returns `formEndpoint`** in the response — the
  full absolute URL to the user's form endpoint, so the success screen
  doesn't have to compute it client-side.

- ✅ **Empty-state dashboard home redesign**
  (`src/app/dashboard/page.js -> DeployFirstSite`): for 0-site users, the
  hero copy now leads with the lead-capture value-prop, not just generic
  "deploy a website." Headline is "Launch a site that catches leads, not
  just visitors" with three short bullets (Live in 30s · Forms that just
  work · INR or USD). Targets the actual conversion psychology — what's
  in it for me — not just "click here."

- ✅ **Landing page complete rewrite** (`src/components/LandingClient.js`,
  ~800 lines, 1000+ → cleaner & more conversion-focused):

  - **Hero**: bold tagline "Drop a website. Get leads." with gradient
    accent on "Get leads."  Replaced the fake skeleton-mockup frame with
    a **`<LiveLeadDemo />` animated component** — shows a contact form
    being typed into in real time, then a "lead arrived" inbox card
    fading in with the visitor's name + email + status pill. Cycles
    through 3 different demo leads on a 10-second loop. **This is what
    visitors see above the fold instead of a loading-skeleton placeholder.**

  - **Trust strip**: real DB stats from a server component
    (`src/app/page.js` now fetches `siteCount`, `submissionCount`,
    `userCount` from Prisma with hourly revalidation). Falls back gracefully
    if the DB is unreachable — landing never crashes.

  - **Use Cases**: 6 vivid scenarios with named target personas
    (freelancer, restaurant, coaching tutor, real-estate, pre-launch,
    side-project dev). Each has the pain quote + the LiveInSec fix —
    psychologically sticky because visitors map their own situation onto
    one of the cards.

  - **Three Promises**: "No Git, no CLI", "Forms that just work" (vs
    Formspree's $8/mo), "Made for India too" (UPI / GST / Razorpay).
    Each promise is competitor-anchored.

  - **How It Works**: clean 3-step visual with gradient connector line
    on desktop. Honest 90-second promise.

  - **Comparison table**: fact-checkable claims only. We don't say "✓
    custom domain" against Netlify because they have it too. We win on
    "Upload ZIP, no Git/CLI", "Built-in form API", "Lead Inbox + status",
    "INR billing", "no trial expires" — the categories where we're
    genuinely first.

  - **Pricing**: clean Free vs Pro split (Pro is the gradient card
    marked "Most popular"). Free is honest about what's not included
    (powered-by badge, 5 custom domains free, etc.).

  - **FAQ**: 7 questions that match real signup objections (do I need
    code, vs Formspree, will my site go offline, custom domain, vs
    Netlify, where hosted, can I cancel). Each answer is concrete.

  - **Final CTA**: gradient hero asking for the close.

  - **Footer**: 4 columns + tagline.

**Why this matters for conversion:**
- The 3 places a visitor's eye lands (hero, mockup, FAQ) all reinforce
  the same value-prop: "deploy a site that captures leads." Every other
  hosting tool either does hosting OR forms — we do both. The animated
  demo shows that fact in 6 seconds without needing to read.
- The use-cases section uses **named personas** ("Coaching tutor", "Real
  estate"), which is the persuasion lever for our actual target market
  in India. Generic "small business" landing copy is invisible.
- The form-journey fix removes the worst usability landmine: a user who
  signs up to "host a contact form" can no longer reach the wrong screen.
  They're educated about forms in step 1 of the wizard, see "form" badges
  on templates in step 2, and the success screen leads with sending a
  test submission to prove forms actually work.

**Files added/changed:**
- NEW `src/components/FormPromisePanel.js`
- NEW `src/components/LandingClient.js` (full rewrite, kept filename)
- CHANGED `src/app/api/sites/route.js` (added wireFormPlaceholdersInDeployedFiles + formEndpoint in response)
- CHANGED `src/app/dashboard/sites/new/page.js` (FormPromisePanel sidebar in step 1, has-form badges in step 2, full DeploySuccessScreen replacement of step 4)
- CHANGED `src/lib/site-templates.js` (added hasContactForm flag, gave the blank starter a contact form)
- CHANGED `src/app/page.js` (server component, fetches real stats)
- CHANGED `src/app/dashboard/page.js -> DeployFirstSite` (empty state leads with lead-capture value-prop)

**Build:** `npx next build` passes cleanly. Wizard bundle 17 → 20.3 kB
(success screen + form panel). New routes register correctly.

**Status of REWIRING-PLAN.md tickets after Session 4:**
- ✅ B-PUB-01 (landing redesign — now complete with real stats + animated demo)
- ✅ B-DASH-04 partial (deploy wizard now has forms education + better success screen — still pending: ZIP size client-check, preview-before-deploy iframe, Cmd+S in editor)
- ✅ B-DASH-02 partial (empty-state on home page now lead-capture-focused)
- Everything from Sessions 1, 2, 3 still applies

**Pending owner action:**
- Start MySQL + `npx prisma db push` (Session 1 schema additions)
- `POST /api/features` with `{ "seed": true }` to populate catalog

---

## 2026-05-02 (Session 3) — UX fixes + admin lockdown + dashboard redesign

Owner asked for: (1) better form-submission user journey, (2) admin can manage
features but NOT add new ones (catalog hardcoded), (3) custom domain free for
now (sell domain registration later as separate feature), (4) submissions table
needs pagination + date + search filters + quota-overflow email, (5) dashboard
redesign + SEO landing.

**Tickets completed in this session:**

- ✅ **Form submission user journey** — created `FormSetupCard` interactive
  component with: copy buttons for endpoint/API key, "Send test submission"
  button (new endpoint `/api/sites/[id]/test-submission`), tabbed code samples
  (HTML / Fetch / React), 3-step walkthrough on the site detail page,
  expandable spam-protection explainer. Replaces the static code-block section
  that users couldn't discover.

- ✅ **Submissions table redesign (B-DASH-08, B-DASH-09)** — full Lead Inbox:
  - Filters bar: search (debounced, multi-field), status (new/read/contacted/won/lost/spam), date preset (24h/7d/30d/all)
  - Pagination with first/prev/current/next/last numbered links
  - Inline status update via `<select>` (PATCH `/api/submissions/[siteId]/[submissionId]`)
  - Mark-as-read on row expand
  - Streaming CSV export of ALL filtered rows (capped at 10k) via new `/api/submissions/[siteId]/export`
  - Per-row delete with confirmation
  - Quota-overflow visual flag (⚠ overflow tag)
  - Better empty state distinguishing "no leads" vs "filtered to nothing"
  - Stats header: total / 7-day / unread / showing
  - Both per-site and global submissions pages now use the same component

- ✅ **Quota overflow email** — when a site collects a submission above the
  free monthly quota, we now: (a) STILL store the lead with `quotaOverflow=true`
  and `status='spam'`, (b) email the site owner once-per-day-per-site nudging
  them to top up (new `quotaOverflowTemplate`). Dedup is via auditlog
  ('site.quota_overflow_emailed' action) — never spams.

- ✅ **Hardcoded feature catalog (`lib/features-catalog.js`)** — created the
  single source of truth. All 6 features defined in code with metadata,
  defaults, `adminEditable` whitelist per feature, and `adminGuidance` text.
  POST /api/features is now a SEED endpoint only (no free-form create); returns
  405 if you try to create a new feature. PUT /api/features/[id] only accepts
  fields listed in the feature's `adminEditable` array. DELETE always returns
  405. Adding a feature requires a code change.

- ✅ **Per-feature admin UI** — `/admin/features` rewritten. Each feature gets
  its own card with: live stats (active/in-cart/revenue), admin guidance,
  and ONLY the editable knobs the catalog allows. Submissions feature shows
  free-quota hint specific to its monthly-recurring nature; analytics shows
  endowment-effect explanation; custom-domain only shows the freeQuota knob
  (no price knobs because it's free). "Sync from catalog" button (safe — only
  metadata, not pricing) and "Hard reset to defaults" button (with confirm).
  Orphan detection for DB rows whose slug isn't in the code catalog.

- ✅ **Custom domain free** — feature catalog sets `priceUsd: 0`, `priceInr: 0`,
  `freeQuota: 5`, `publicAccessType: 'full'`. Every account gets 5 free custom
  domains. Admin only sees freeQuota + isActive knobs (no price). Catalog
  comment notes that future domain-registration is a separate feature.

- ✅ **Dashboard redesign (`/dashboard` home page)** — gradient hero with
  time-of-day greeting, 4 stat cards with accent colors and 7-day trend bars,
  3-step onboarding checklist with progress bar, two-column "your sites" +
  "recent leads" with `timeAgo` formatting and unread dot indicators. Empty
  states have illustrated CTAs. Visually closer to Linear/Notion-style premium
  SaaS dashboards.

- ✅ **SEO** — `app/layout.js` enriched: title template, expanded keywords
  list (~17 keywords incl. competitor alternates and India market terms),
  OpenGraph + Twitter cards, structured data JSON-LD (SoftwareApplication
  schema with Free offer), canonical URL, robots directives. Created
  `app/robots.js` (allows / except dashboard/admin/auth) and `app/sitemap.js`
  (lists landing, docs, register, login). Both build to /robots.txt and
  /sitemap.xml.

**New API routes:**
- `POST /api/sites/[id]/test-submission` — synthesize a test submission (used by FormSetupCard)
- `PATCH /api/submissions/[siteId]/[submissionId]` — update status / isRead / notes
- `DELETE /api/submissions/[siteId]/[submissionId]` — single-submission delete
- `GET /api/submissions/[siteId]/export?q=&from=&to=&status=` — streaming CSV of filtered rows

**New schema fields used (all from A-1 in Session 1):**
- FormSubmission: `status`, `isRead`, `notes`, `tags`, `quotaOverflow`, `bodyHash` (already in schema)
- auditlog: existing — used to dedup quota-overflow emails

**Status of REWIRING-PLAN.md tickets:**
- ✅ A-1, A-4, A-7, A-8, A-9, A-10 (Session 1)
- ✅ B-AUTH-07 (Session 1)
- ✅ A-9 + B-PUB-04 partial (Session 1)
- ✅ C-1, C-2 (Session 1)
- ✅ B-DASH-02 (dashboard home) (Session 3)
- ✅ B-DASH-08 + B-DASH-09 (lead inbox) (Session 3)
- ✅ B-ADM-07 (admin features lockdown + per-feature UI) (Session 3)
- ✅ B-PUB-01 (landing SEO partial — meta + structured data, not yet real testimonials/social proof DB pull) (Session 3)
- ✅ Form-setup user journey (NEW — wasn't in plan but owner-requested) (Session 3)
- ✅ Quota-overflow email (B-PUB-04 partial — the email-the-owner piece) (Session 3)

**Still pending (next sessions):**
- A-2 (Redis), A-3 (PM2 cluster), A-5 (Caddy/HTTPS), A-6 (S3 — already env-driven; just needs S3 keys)
- A-11 + PART D (collapse plan + feature models — biggest remaining single piece)
- B-AUTH-01..06, 08, 09 (login/register/forgot-password polish, OAuth)
- B-PUB-02..07 (custom-domain verify, forms HMAC, WS hardening, docs accuracy, ws-only live)
- B-DASH-01, 03, 04, 05, 06, 07, 10, 11, 12 (other dashboard tickets)
- B-STORE-01..06 (store/cart polish, bundles, currency persistence)
- B-PAY-01, 02, 03, 05, 06 (plan checkout polish)
- B-ADM-01..06, 08..11 (other admin tickets)

**Build status:** `npx next build` passes; all syntax validated; new routes
register correctly. Pending owner action: start MySQL and run `npx prisma db push`,
then `POST /api/features` with `{ "seed": true }` to populate the catalog.

---

## 2026-05-02 (Session 1 implementation start) — Phase 0 foundation tickets shipped

Owner asked to start coding the REWIRING-PLAN.md from the beginning, with the constraint
that local filesystem stays the default for storage and S3 only kicks in when the
S3_* env vars are set (already supported by `lib/env.js` `hasS3` flag).

**Tickets completed in this session (Phase 0):**

- ✅ **A-1**: Added new schema fields and models — `payment.idempotencyKey`,
  `payment.signatureUsedAt`, `featureorder.idempotencyKey`,
  `featureorder.signatureUsedAt`, `FormSubmission.status/isRead/notes/tags/quotaOverflow/bodyHash/updatedAt`,
  `user.lastDripStep/lastDripSentAt/deletedAt`, plus new models:
  `featureusageevent`, `abuseflag`, `emailqueue`, `coupon`, `refundrequest`,
  `sitefileversion`. Schema validates; `prisma generate` succeeded. **Owner must run
  `npx prisma db push` once MySQL is running.**
- ✅ **B-AUTH-07**: Hardened `lib/auth.js`. The `update()` trigger now IGNORES all
  client-supplied fields and re-fetches from the DB — closes the privilege-escalation
  hole entirely. Added input sanitizers (name/phone/country/currency length + format).
  Re-validation now also checks `isBlocked` and `deletedAt`, not just role/email.
  All login attempts (success, failure, blocked, rate-limited) are now audit-logged.
  OAuth signin checks deletedAt + isBlocked; no longer copies plan/sub fields to JWT.
- ✅ **A-7**: `lib/audit.js` now accepts both `audit('action', opts)` and
  `audit({ action, ... })` styles. New `auditFromRequest(request, payload)` extracts
  IP+UA automatically. Field-length caps prevent giant payloads from bloating the table.
  Admin user route fixed to use `include: { site: true }` (was `sites:` — a runtime crash).
  Admin user delete now soft-deletes by default (sets `deletedAt`); hard-delete behind `?hard=1`.
- ✅ **A-10**: Replay defense + idempotency live on:
  - `/api/feature-checkout` (idempotencyKey on order create — double-clicks safe)
  - `/api/feature-checkout/verify` (signatureUsedAt lock, constant-time compare,
    amount integrity check, structured error codes, audit on every outcome)
  - `/api/payments/verify` (same)
- ✅ **A-9**: `lib/site-security.js` `isAccessSuspended/isTrialExpired/isSubscriptionExpired`
  all return `false` always. `lib/billing.js` `getBillingSnapshot()` is a pure read —
  no more side-effect downgrade. Form submission gate switched from "drop with 429" to
  "store with `quotaOverflow=true`" so site owner can see lost leads. Form route also
  gained 30-second IP+body-hash dedup. Created the new
  `/api/cron/expire-paid-features` route (B-PAY-06) so the dead-code expiry path now
  has a real owner. `lib/auth.js` no longer assigns trialEndsAt on OAuth signup.
- ✅ **A-4**: `lib/email.js` rewritten. With no Resend key it logs to console (dev).
  With a key it tries to send; on transient failure it queues to `emailqueue` table
  with exponential-backoff retry (30s → 2m → 8m → 30m → 2h → 8h, then `failed`).
  `drainEmailQueue()` worker function called by new `/api/cron/email-drain` route
  (every 1-5 minutes). Email failure NEVER blocks payment / signup flows.
- ✅ **A-8**: Middleware CSP tightened. Served user sites
  (`/api/serve/[subdomain]/[[...path]]`) now get full security headers (strict CSP,
  X-Frame-Options DENY, no-cache for HTML, ETag + If-None-Match conditional GET,
  per-content-type Cache-Control). Live-tracking script siteId is now JSON.stringified
  before injection. The dead `trialExpiredPage` is removed (A-9).
- ✅ **C-1**: Deleted `ws-server.js` (standalone unauthenticated WS server, never used).
- ✅ **C-2**: Deleted `src/app/site/[subdomain]/[[...path]]/page.js` (duplicate of
  middleware-rewrite-to-/api/serve). Middleware skip-list updated accordingly.

**Also done (B-PAY-04 partial):**
- ✅ Deleted `/api/cron/trial-reminders` (the cron has no purpose post-A-9).

**What's NOT done yet (next sessions):**
- A-2 (Redis migration), A-3 (PM2 cluster), A-5 (Caddy/HTTPS), A-6 (S3 wiring is
  already env-driven in `lib/object-storage.js` — no code change needed; S3 kicks
  in automatically when env vars are set).
- A-11 + PART D (collapse plan + feature models — biggest single remaining piece).
- All PART B page tickets (auth pages UX, dashboard rewires, admin pages, store/cart/purchases,
  sidebar features, lead-inbox reskin, etc.).

**Build status:** `npx next build` succeeds; all syntax checks pass; Prisma schema
validates and the client is generated. Pending owner action: start MySQL and run
`npx prisma db push` to apply the schema additions.

**Behavioral guarantees this session establishes:**
1. Every payment verify is replay-protected. Even if Razorpay's signature leaks,
   it can be used at most once per order.
2. Any logged-in user calling `update({ plan: 'enterprise' })` from devtools no
   longer escalates — the JWT now refuses client-supplied privilege fields.
3. A new signup with no Resend key configured still works end-to-end; emails are
   logged to console. As soon as the owner sets `RESEND_API_KEY`, real emails flow.
4. Storage stays on local disk by default. Setting `S3_ENDPOINT/S3_BUCKET/S3_*` env
   vars switches to S3 with no code change (already wired in `object-storage.js`).
5. Sites stay live forever on the free tier. The cron (`expire-paid-features`)
   handles paid-feature lapses without ever taking subdomains offline.

---

## 2026-05-02 (later) — Owner approved the BUSINESS-RECOMMENDATIONS.md and asked for a foundation rewiring plan

**Context:** Owner read BUSINESS-RECOMMENDATIONS.md and agreed with all of it. Asked for a complete page-by-page audit so an LLM can rewire the foundation before adding new features. Owner explicitly authorized free reign to "do whatever you want with plans, admin, features, costing — make it reliable."

**Decisions made:**
- Four parallel deep audits run across auth, dashboard, admin/marketplace/billing, and public-facing slices.
- Findings consolidated into [REWIRING-PLAN.md](REWIRING-PLAN.md) as a self-contained ticket inventory (PART A foundation, PART B pages, PART C deletions, PART D schema migration, PART E execution order).
- Strategic direction confirmed: collapse `plan` and `feature*` models into single feature-marketplace-driven system with two plans (Free + Pro). See PART D.
- Strategic direction confirmed: kill the 3-day trial behavior; sites stay live forever on free tier. See A-9.
- Confirmed: Resend for transactional email (A-4), Caddy for HTTPS (A-5), Redis for shared state (A-2), S3/R2 for storage (A-6).
- Confirmed: 3 critical security findings get fixed in Phase 0.5 (JWT escalation, replay attacks, forms SSRF).
- Confirmed: `ws-server.js` and `/site/[subdomain]` page are dead code — delete.

**Pending owner input:**
- Choice of S3-compatible host (AWS S3 vs Cloudflare R2 — R2 likely cheaper and has zero egress).
- Final pricing of Pro plan ($4.99/mo USD / ₹399/mo INR proposed).
- Refund window length (7 days proposed).
- Whether to keep team-management feature in Phase 5 or defer.

---

## 2026-05-02 — Owner kicked off business-direction review

**Context:** Owner (Nitin Yadav, nitin.yadav@celebaltech.com) asked for an end-to-end business analysis of LiveInSec with the goal of turning it into a profitable product. Owner's filters: high demand, genuine large-scale problem, easy customer acquisition, perceived reliability, maximum profit. Owner asked for a memory folder to be created so future sessions don't re-read the whole codebase.

**Decisions made:**
- Memory folder created at `docs/memory/` with index README, project snapshot, business context, current features, gaps/risks, business recommendations. Future sessions should read these files first.
- Business analysis delivered as `BUSINESS-RECOMMENDATIONS.md`. Owner will review with business team and engineers.

**Pending owner input:**
- Final pricing tier choice (current docs propose flipping to free-hosting + paid form/domain).
- Whether to drop or keep the Plan model entirely in favor of pure feature marketplace.
- Whether to pivot the brand promise (the name "LiveInSec" suggests security; current product is generic static hosting — see `BUSINESS-RECOMMENDATIONS.md` "Pivot consideration" section).
