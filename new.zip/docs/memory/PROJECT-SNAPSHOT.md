# LiveInSec — Project Snapshot

> Fast load file. Read this first before anything else.
> Last updated: 2026-05-02

## What it is (one line)

A SaaS that lets non-technical users **upload a ZIP of a static website and get it live on a subdomain** in seconds, with a built-in form-collection API and an à-la-carte feature marketplace.

## Origin name

Internally was once called "StaticDrop" — some older docs (`docs/IDEA.md`, `docs/PRODUCT_REVIEW.md`) still use that name. The current product name is **LiveInSec**.

## Stack

- Next.js 14 (App Router, JavaScript — not TypeScript)
- Prisma ORM, MySQL (schema declares `provider = "mysql"`; some old docs say SQLite/PostgreSQL — current source of truth is `prisma/schema.prisma`)
- NextAuth.js (JWT, credentials provider)
- Tailwind CSS
- Razorpay (live) + Stripe (partially wired)
- Monaco editor for in-browser code editing
- WebSocket server (`ws-server.js`) for live visitor presence
- AdmZip for ZIP extraction; AWS S3 SDK present for object storage

## Database models (from `prisma/schema.prisma`)

- `user` — auth, plan, role, owner relation (for team members), trial/period dates
- `site` — subdomain, customDomain, apiKey, deployPath, allowedOrigins, honeypotField, rate limit, webhookUrl, notifyEmail
- `FormSubmission` — form leads keyed by site
- `sitevisit` — analytics with hashed IP + country
- `plan` — legacy plan-based limits (still in code but partly deprecated by feature marketplace)
- `feature` + `cartitem` + `featureorder` + `orderitem` + `featurepurchase` — the à-la-carte marketplace (the new monetization model)
- `payment` — plan-level Razorpay/Stripe payments
- `auditlog`, `emailverificationtoken`, `passwordresettoken`, `appconfig`

## Key folders

- `src/app/(auth)` — login, register, onboarding
- `src/app/dashboard` — user dashboard (sites, submissions, analytics, store, cart, purchases, settings)
- `src/app/admin` — superadmin tools
- `src/app/api` — REST endpoints (sites, forms, feature-checkout, cart, cron, payments, serve, submissions, team, ws-token, live, etc.)
- `src/app/site` — local preview routes
- `src/lib` — auth, plans, billing, feature-access, storage, security, email, rate-limit, currency, etc.
- `src/middleware.js` — subdomain + custom-domain routing
- `prisma/` — schema, migrations, seed
- `uploads/` — deployed site files (gitignored)

## Two parallel monetization models live in code

1. **Plans** (`plan` model): Free / Starter / Pro / Enterprise — older, simpler.
2. **Feature marketplace** (`feature*` models): à-la-carte purchases of submissions, analytics, custom-domain, team-members, storage. This is the strategic direction per `docs/01-STRATEGIC-BUSINESS-ANALYSIS.md`.

The plan code is partly redundant — the feature-marketplace approach is what should be doubled down on. See `BUSINESS-RECOMMENDATIONS.md`.

## Current state (honest)

- **Works locally** for the happy path: sign up → deploy ZIP → see site at `*.lvh.me:3000` → collect forms.
- **Not production-ready**: no HTTPS for served sites, no CDN, transactional email infrastructure incomplete (`docs/PRODUCT_REVIEW.md` flags this), 3-day trial design is hostile to users, several CRITICAL security findings open in `docs/03-CYBERSECURITY-AUDIT.md`.
- **Pre-revenue**: feature marketplace exists but is buried; no contextual upgrade prompts; no email drip; no social proof on landing.
