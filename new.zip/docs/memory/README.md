# LiveInSec — Project Memory

This folder is a fast-loading project snapshot for AI agents (and human reviewers).
Read these files instead of crawling the entire codebase each session.

## Index

- [PROJECT-SNAPSHOT.md](PROJECT-SNAPSHOT.md) — One-page summary: what LiveInSec is, current state, stack, models, key folders.
- [BUSINESS-CONTEXT.md](BUSINESS-CONTEXT.md) — Owner's goal, target market, monetization model, competitive landscape.
- [CURRENT-FEATURES.md](CURRENT-FEATURES.md) — What is already built (working) and what is partially built.
- [GAPS-AND-RISKS.md](GAPS-AND-RISKS.md) — Critical infra/UX/security gaps that block monetization.
- [DECISIONS-LOG.md](DECISIONS-LOG.md) — Append-only log of strategic and architectural decisions made with the owner.
- [BUSINESS-RECOMMENDATIONS.md](BUSINESS-RECOMMENDATIONS.md) — Prioritized roadmap of features to add, keep, drop.
- [REWIRING-PLAN.md](REWIRING-PLAN.md) — **Page-by-page ticket inventory** for rewiring the foundation before adding new features. The execution doc.

## Update Rules

1. When the owner makes a strategic decision, append it to `DECISIONS-LOG.md` with date.
2. When a major feature ships, update `CURRENT-FEATURES.md` and remove from `GAPS-AND-RISKS.md`.
3. Keep `PROJECT-SNAPSHOT.md` under 200 lines — link to detail files for everything else.
4. Never duplicate content between files. Cross-link instead.
