# Current Features (as of 2026-05-02)

## ✅ Working

### Hosting
- Email + password registration, NextAuth JWT sessions
- ZIP upload → extracted → served on `<sub>.lvh.me:3000` and `localhost:3000/site/<sub>`
- Path-traversal protection in extractor
- Single-folder ZIP auto-flatten
- Re-deploy keeps the same URL/API key
- Activate / deactivate / delete site
- Wildcard subdomain routing via middleware
- Custom domain detection via middleware (CNAME)
- In-browser Monaco code editor with starter templates
- Sample / template-based site deploy

### Forms
- Per-site API key form endpoint (`/api/forms/:apiKey`)
- Honeypot field, configurable per-site
- Per-IP rate limiting (in-memory)
- Allowed origin whitelist
- Submission inbox (global + per-site tab)
- CSV export
- Webhook URL field exists on `site` model (delivery may be partial)

### Analytics
- Page-view tracking with SHA-256-hashed IP (privacy-friendly)
- Country detection
- Referrer + user agent capture

### Live presence
- WebSocket server tracks active visitors per site (real-time count)

### Monetization plumbing
- Razorpay integration (orders, signature verification, atomic transactions)
- Stripe SDK installed (partial)
- Multi-currency: USD + INR
- Plan model + feature-marketplace model both seeded
- Cart, order, purchase records
- Per-feature `freeQuota`, `publicAccessType` (none/full/partial/timed)
- Audit log table

### Admin
- Superadmin dashboard with revenue tracking, user management, plan editing
- Block users, change plans, edit feature catalog

### Team / multi-user
- Owner-managed team members with `memberPermissions` JSON
- `ownerId` self-relation on `user`

### Trial / billing
- 3-day trial on signup
- Auto-downgrade on trial expiry (cron route exists)
- Trial-expired sites stop serving + stop accepting submissions

## ⚠️ Partial / weak

- **Email delivery** — templates exist but actual SMTP/Resend/SendGrid wiring is incomplete. Email verification "link" in many places must be copied manually.
- **Stripe** — installed, partly wired, not the default checkout path.
- **HTTPS on served sites** — middleware serves HTTP only. No Let's Encrypt / Caddy / Cloudflare tunnel set up.
- **CDN** — not present. Files served straight from Node filesystem via `/api/serve/...`.
- **S3/R2 storage** — `@aws-sdk/client-s3` is installed, `lib/object-storage.js` exists, but `uploads/` is local filesystem.
- **Webhooks for forms** — field exists, delivery worker not confirmed.
- **In-memory rate limiter** — needs Redis for multi-instance.
- **Password reset flow** — token model exists; user-facing flow may be incomplete.
- **Social login (Google / GitHub)** — not present.
- **Real-time tracking** — works but `Map` is unbounded (memory leak risk noted in audit).

## ❌ Missing entirely

- Email notifications when a form is submitted (the #1 retention driver per `PRODUCT_REVIEW.md`)
- Auto-SSL for custom domains
- Image optimization / CDN
- Site preview before deploy
- Blog / docs / SEO content
- Referral system / affiliate tracking
- Bundles in the feature store
- "Powered by LiveInSec" badge → referral link
- Account deletion flow
- GST-compliant invoices for India
- Production error tracking (Sentry/equivalent)
- Automated tests / CI
- DB backup strategy
