# Gaps and Risks — Why money isn't coming yet

> Compiled from `docs/01-STRATEGIC-BUSINESS-ANALYSIS.md`, `docs/03-CYBERSECURITY-AUDIT.md`,
> `docs/04-FEATURE-STORE-BUG-REPORT.md`, `docs/PRODUCT_REVIEW.md` — and from inspecting the schema.

## Tier 1 — Block monetization entirely (fix before any marketing)

| # | Gap | Why it kills revenue |
|---|-----|----------------------|
| T1-1 | **No HTTPS on served sites** | Chrome shows "Not Secure". Nobody shares a portfolio link with that warning. Word-of-mouth dies at the door. |
| T1-2 | **No transactional email** | No verification, no password reset, no submission alerts, no receipts. Product feels half-built. |
| T1-3 | **3-day trial cuts off live sites** | Student shares portfolio Monday → interviewer clicks Friday → dead site. Reputation destroyer. |
| T1-4 | **Critical security findings open** | Client-side JWT can self-promote to enterprise (`auth.js`). CRON endpoint public if env var missing. Per `03-CYBERSECURITY-AUDIT.md`. |
| T1-5 | **Local filesystem storage** | One server crash = all customer sites gone permanently. Cannot legally promise reliability. |
| T1-6 | **No CDN** | A portfolio shared on LinkedIn that gets 500 simultaneous clicks crashes the server. |

## Tier 2 — Caps how much each user is worth

| # | Gap | Effect |
|---|-----|--------|
| T2-1 | Form submission email/webhook notifications missing | The single #1 retention/upsell trigger is missing. |
| T2-2 | Feature store buried in sidebar; no in-context paywalls with value preview | Users never reach checkout. |
| T2-3 | Free quotas on most features set to 0 | Users can't experience value before paywall — Endowment Effect not fired. |
| T2-4 | No bundles | ARPU stuck at $3-5 instead of $9-25. |
| T2-5 | No annual pricing on duration features | All revenue is month-to-month, churn-vulnerable. |
| T2-6 | Submissions are lifetime quota, not monthly recurring | Once-bought users never return to spend more. |
| T2-7 | Stripe not completed | Non-India customers can't pay at all. |

## Tier 3 — Caps top-of-funnel growth

| # | Gap | Effect |
|---|-----|--------|
| T3-1 | No Google / GitHub OAuth | Target audience (devs/students) expects this; signup friction loses ~30%. |
| T3-2 | No "Powered by LiveInSec" referral badge | Free distribution channel ignored. |
| T3-3 | No SEO content / blog / public docs | Zero organic discovery. |
| T3-4 | Landing page has no real social proof | Conversion <2%. Replace fake logos with DB counter ("X sites deployed"). |
| T3-5 | No referral / affiliate system | Viral coefficient zero. |
| T3-6 | No site templates / 1-click demo | New users with no HTML file at hand can't activate. |
| T3-7 | No public site gallery | Lost free marketing. |

## Tier 4 — Caps retention (users sign up, deploy once, forget)

| # | Gap | Effect |
|---|-----|--------|
| T4-1 | No onboarding email drip (Day 0 / 2 / 7 / 14) | 40% of users who don't engage in 48h never come back (SaaS benchmark). |
| T4-2 | No weekly analytics digest email | No reason to log in unless something breaks. |
| T4-3 | No new-submission notification | The single sticky moment in the product never fires. |
| T4-4 | No "Getting Started" checklist on dashboard | Users don't discover form API, custom domain, analytics. |
| T4-5 | No post-deploy celebration / share screen | Aha-moment + word-of-mouth missed at the highest-engagement moment. |

## Tier 5 — Hidden landmines

| # | Risk | Effect |
|---|------|--------|
| T5-1 | Subdomain abuse (`bank-login.liveinsec.com`) | Reputation-destroying phishing risk. No abuse moderation pipeline. |
| T5-2 | Editor "Build Here" files bypass upload size limit | A user can paste megabytes of text. |
| T5-3 | Race condition in subdomain creation | Two simultaneous signups for same subdomain. Needs unique-constraint try/catch. |
| T5-4 | WebSocket presence Map is unbounded | Memory leak under load. |
| T5-5 | No account deletion flow | GDPR / Indian DPDPA non-compliance. |
| T5-6 | No GST invoices | Indian businesses can't expense purchases. Legal compliance issue. |
| T5-7 | Admin role checked from JWT only | Per security audit, must verify against DB. |
