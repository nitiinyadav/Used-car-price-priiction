# Business Context

## Owner's goal (stated 2026-05-02)

> "I want to use this project for earning money. LiveInSec is my incomplete idea and I want it a complete project for earning money and make it a big useful project that really solves people's problems and covers a large amount of people's needs."

Decision filters the owner gave for any feature suggestion:

1. The functionality should be **in demand** by people.
2. It should solve a **genuine problem** for a **large number of people**.
3. It should be **easy to acquire customers** for.
4. The app should look **reliable** to users.
5. It should give **maximum profit**.

## Target audience (current)

Per `docs/IDEA.md` and `docs/PRODUCT_REVIEW.md`:

- Students deploying portfolios for job applications
- Freelance developers / designers showing client work
- Small business owners with a static site someone built for them
- Indian SaaS market specifically (INR pricing, Razorpay, UPI)
- Hobby developers wanting zero-config hosting

## Where money can come from

- **Wedge product:** form-submission collection (Formspree charges $8/mo for this; we bundle hosting + forms).
- **Recurring:** analytics, custom domains (annual), team seats, email/webhook notifications.
- **One-time:** extra storage, extra submissions packs.
- **Future:** marketplace commission on third-party features/templates.

## Competitive landscape (compressed)

| Competitor       | Free tier offers                                   | Where LiveInSec can win                                   |
|------------------|----------------------------------------------------|-----------------------------------------------------------|
| Netlify / Vercel | Free hosting + HTTPS + CDN, but require Git/CLI    | No-Git ZIP upload UX for non-developers                   |
| GitHub Pages     | Free + custom domain, requires Git                 | Same — no-Git audience                                    |
| Tiiny.host       | Direct competitor: ZIP upload + URL                | Forms API + analytics + INR pricing + bundled marketplace |
| Formspree/Basin  | Form API only, $8+/mo                              | We bundle this with hosting                               |
| Squarespace/Wix  | Hosted builders, expensive                         | We're 10x cheaper for users who already have HTML         |

The honest truth from `docs/PRODUCT_REVIEW.md`: hosting alone is commoditized and competing-against-free. The realistic moat is **"hosting + forms + analytics + India-friendly billing in one product, with no Git/CLI required."**

## Key strategic conclusions already in the docs

- Make basic hosting **permanently free** (compete on convenience, not price). Drop the 3-day-trial death trap.
- Monetize the **form API** (volume tiers, email notifications, webhooks).
- Charge for **custom domains with auto-SSL** — this is the most natural upgrade.
- Build retention via **email** (form submission alerts, weekly visitor digests).
- Lean into the **feature marketplace** model (à-la-carte) — psychologically reduces purchase anxiety vs. forcing tier upgrades.
