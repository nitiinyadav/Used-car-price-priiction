// Custom server that runs Next.js + WebSocket server for live visitor tracking
const { createServer } = require("http");
const { parse } = require("url");
const next = require("next");
const { WebSocketServer } = require("ws");
const jwt = require("jsonwebtoken");
const { getToken } = require("next-auth/jwt");

const dev = process.env.NODE_ENV === "development";
const hostname = process.env.HOSTNAME || "0.0.0.0";
const port = process.env.PORT ? parseInt(process.env.PORT) : 4000;

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

// ── Security: Connection limits (M-02) ──
const MAX_VISITORS_PER_SITE = 1000;
const MAX_DASHBOARD_PER_SITE = 50;
const MAX_TOTAL_CONNECTIONS = 10000;
let totalConnections = 0;

// Track live visitors per site: Map<siteSubdomain, Set<ws>>
const liveVisitors = new Map();
// Track dashboard listeners: Map<siteId, Set<ws>>
const dashboardListeners = new Map();

// ── Security: Verify JWT token for dashboard WebSocket (H-01) ──
function verifyDashboardToken(token) {
  try {
    const secret = process.env.NEXTAUTH_SECRET;
    if (!secret) return null;
    const decoded = jwt.verify(token, secret, { algorithms: ["HS256"] });
    if (decoded?.purpose !== "ws-auth" || !decoded?.sub) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

async function verifyDashboardAuth(req, token) {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) return null;

  const wsToken = token ? verifyDashboardToken(token) : null;
  if (wsToken) {
    return wsToken;
  }

  try {
    const sessionToken = await getToken({ req, secret });
    if (sessionToken?.sub || sessionToken?.id) {
      return sessionToken;
    }
  } catch {
    return null;
  }

  return null;
}

function getLiveCount(key) {
  return liveVisitors.get(key)?.size || 0;
}

function broadcastToListeners(siteId) {
  const listeners = dashboardListeners.get(siteId);
  if (!listeners) return;
  const count = getLiveCount(siteId);
  const msg = JSON.stringify({ type: "live_count", siteId, count });
  for (const ws of listeners) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

app.prepare().then(() => {
  const server = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url, true);
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error("Error handling request:", err);
      res.statusCode = 500;
      res.end("Internal server error");
    }
  });

  const wss = new WebSocketServer({ server, path: "/ws/live" });

  wss.on("connection", async (ws, req) => {
    // ── Global connection limit (M-02) ──
    totalConnections++;
    if (totalConnections > MAX_TOTAL_CONNECTIONS) {
      ws.close(4004, "Server at capacity");
      totalConnections--;
      return;
    }

    ws.on("close", () => {
      totalConnections--;
    });

    const url = new URL(req.url, `http://${req.headers.host}`);
    const role = url.searchParams.get("role"); // 'visitor' or 'dashboard'
    const siteId = url.searchParams.get("site");

    if (!siteId || typeof siteId !== "string" || siteId.length > 50) {
      ws.close(4001, "Missing or invalid site parameter");
      return;
    }

    if (role === "visitor") {
      // Per-site visitor limit (M-02)
      if (!liveVisitors.has(siteId)) liveVisitors.set(siteId, new Set());
      const siteSet = liveVisitors.get(siteId);
      if (siteSet.size >= MAX_VISITORS_PER_SITE) {
        ws.close(4005, "Site at capacity");
        return;
      }
      siteSet.add(ws);
      broadcastToListeners(siteId);

      ws.on("close", () => {
        const set = liveVisitors.get(siteId);
        if (set) {
          set.delete(ws);
          if (set.size === 0) liveVisitors.delete(siteId);
        }
        broadcastToListeners(siteId);
      });

      // Keep alive ping every 30s
      const interval = setInterval(() => {
        if (ws.readyState === 1) ws.ping();
      }, 30000);
      ws.on("close", () => clearInterval(interval));
    } else if (role === "dashboard") {
      // ── Security: Require auth token for dashboard connections (H-01) ──
      const token = url.searchParams.get("token");
      const decoded = await verifyDashboardAuth(req, token);
      if (!decoded) {
        ws.close(4003, "Invalid or expired token");
        return;
      }

      // Per-site dashboard listener limit (M-02)
      if (!dashboardListeners.has(siteId))
        dashboardListeners.set(siteId, new Set());
      const listenerSet = dashboardListeners.get(siteId);
      if (listenerSet.size >= MAX_DASHBOARD_PER_SITE) {
        ws.close(4005, "Too many dashboard listeners for this site");
        return;
      }
      listenerSet.add(ws);

      // Send initial count
      const count = getLiveCount(siteId);
      ws.send(JSON.stringify({ type: "live_count", siteId, count }));

      ws.on("close", () => {
        const set = dashboardListeners.get(siteId);
        if (set) {
          set.delete(ws);
          if (set.size === 0) dashboardListeners.delete(siteId);
        }
      });
    } else {
      ws.close(4002, "Invalid role");
    }
  });

  server.listen(port, hostname, () => {
    console.log(`> LiveInSec ready on http://${hostname}:${port}`);
    console.log(
      `> WebSocket live tracking on ws://${hostname}:${port}/ws/live`,
    );
  });
});
