import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import Link from 'next/link';
import { getUserLimits } from '@/lib/plans';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const limits = await getUserLimits(session.user.id);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  const [sites, totalSubmissions] = await Promise.all([
    prisma.site.findMany({
      where: { userId: workspaceOwnerId },
      include: { _count: { select: { submissions: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.formSubmission.count({
      where: { site: { userId: workspaceOwnerId } },
    }),
  ]);

  const recentSubmissions = await prisma.formSubmission.findMany({
    where: { site: { userId: workspaceOwnerId } },
    include: { site: { select: { name: true, subdomain: true } } },
    orderBy: { createdAt: 'desc' },
    take: 5,
  });

  const activeSites = sites.filter((s) => s.isActive).length;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          Welcome back, {session.user.name}!
        </h1>
        <p className="mt-1 text-gray-500">
          Here&apos;s an overview of your deployed sites
        </p>
      </div>

      {/* Stats - 3 clean cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {activeSites}<span className="text-sm font-normal text-gray-400">/{sites.length}</span>
              </p>
              <p className="text-sm text-gray-500">Active Sites</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{totalSubmissions}</p>
              <p className="text-sm text-gray-500">Form Submissions</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900 capitalize">
                {limits.plan === 'free' ? 'Free' : limits.plan}
              </p>
              <p className="text-sm text-gray-500">Current Plan</p>
            </div>
          </div>
        </div>
      </div>

      {/* Onboarding Checklist — shown for new users */}
      {sites.length <= 1 && limits.plan === 'free' && (
        <OnboardingChecklist
          hasSite={sites.length > 0}
          hasSubmission={totalSubmissions > 0}
          emailVerified={!!session.user.emailVerified}
        />
      )}

      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-3 mb-8">
        {hasPermission(workspace, 'create_sites') && (
          <Link
            href="/dashboard/sites/new"
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors flex items-center space-x-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span>Deploy New Site</span>
          </Link>
        )}
        <Link
          href="/dashboard/sites"
          className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:border-gray-400 transition-colors"
        >
          View All Sites
        </Link>
        <Link
          href="/dashboard/submissions"
          className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:border-gray-400 transition-colors"
        >
          Open Inbox
        </Link>
      </div>

      {/* Recent Submissions */}
      {recentSubmissions.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">
              Recent Form Submissions
            </h2>
          </div>
          <div className="divide-y divide-gray-200">
            {recentSubmissions.map((sub) => {
              const data = JSON.parse(sub.data);
              const preview = Object.entries(data)
                .slice(0, 3)
                .map(([k, v]) => `${k}: ${v}`)
                .join(', ');

              return (
                <div key={sub.id} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {sub.site.name}
                      </p>
                      <p className="text-sm text-gray-500 mt-0.5 truncate max-w-md">
                        {preview}
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">
                      {new Date(sub.createdAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty state */}
      {sites.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
            />
          </svg>
          <h3 className="mt-4 text-lg font-medium text-gray-900">
            No sites deployed yet
          </h3>
          <p className="mt-2 text-gray-500">
            Deploy your first website to get started
          </p>
          <Link
            href="/dashboard/sites/new"
            className="mt-6 inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
          >
            Deploy Your First Site
          </Link>
        </div>
      )}
    </div>
  );
}

function OnboardingChecklist({ hasSite, hasSubmission, emailVerified }) {
  const steps = [
    {
      done: emailVerified,
      label: 'Verify your email address',
      href: null,
    },
    {
      done: hasSite,
      label: 'Deploy your first website',
      href: '/dashboard/sites/new',
    },
    {
      done: hasSubmission,
      label: 'Receive your first form submission',
      href: null,
    },
  ];

  const completed = steps.filter((s) => s.done).length;
  const allDone = completed === steps.length;

  if (allDone) return null;

  return (
    <div className="mb-8 rounded-xl border border-indigo-200 bg-indigo-50 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Getting Started</h2>
          <p className="text-sm text-gray-500">Complete these steps to get the most out of StaticDrop</p>
        </div>
        <span className="text-sm font-medium text-indigo-600">
          {completed}/{steps.length} done
        </span>
      </div>
      <div className="space-y-3">
        {steps.map((step, idx) => (
          <div key={idx} className="flex items-center gap-3">
            <div
              className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${
                step.done
                  ? 'bg-green-500 text-white'
                  : 'border-2 border-gray-300 text-gray-300'
              }`}
            >
              {step.done ? (
                <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                <span className="text-xs font-bold">{idx + 1}</span>
              )}
            </div>
            {step.href && !step.done ? (
              <a href={step.href} className="text-sm font-medium text-indigo-600 hover:text-indigo-800">
                {step.label}
              </a>
            ) : (
              <span className={`text-sm ${step.done ? 'text-gray-400 line-through' : 'text-gray-700'}`}>
                {step.label}
              </span>
            )}
          </div>
        ))}
      </div>
      <div className="mt-4 h-2 rounded-full bg-gray-200">
        <div
          className="h-2 rounded-full bg-indigo-500 transition-all"
          style={{ width: `${(completed / steps.length) * 100}%` }}
        />
      </div>
    </div>
  );
}
