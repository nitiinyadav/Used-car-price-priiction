import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import Sidebar from '@/components/Sidebar';
import Link from 'next/link';
import { getUserLimits } from '@/lib/plans';

export const metadata = {
  title: 'Dashboard - StaticDrop',
};

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const limits = await getUserLimits(session.user.id);
  const isSuperAdmin = session.user.role === 'superadmin';

  // Slim trial bar: only for non-superadmin free users still on trial
  const showTrialBar =
    !isSuperAdmin &&
    limits &&
    limits.plan === 'free' &&
    !limits.trialExpired &&
    limits.trialDaysLeft > 0;

  const trialDaysLeft = limits?.trialDaysLeft || 0;

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <Sidebar />
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header - sticky */}
        <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 bg-indigo-600 rounded-lg flex items-center justify-center">
              <svg
                className="w-4 h-4 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                />
              </svg>
            </div>
            <span className="font-bold text-gray-900">StaticDrop</span>
          </div>
          <span className="text-sm text-gray-500">{session.user.name}</span>
        </div>

        {/* Slim trial banner - sticky at top */}
        {showTrialBar && (
          <div className="shrink-0 bg-gradient-to-r from-indigo-600 to-purple-600 px-4 py-2 text-center text-sm text-white">
            <span>
              {trialDaysLeft} day{trialDaysLeft !== 1 ? 's' : ''} left in your
              free trial
            </span>
            <span className="mx-2 text-white/50">|</span>
            <Link
              href="/dashboard/upgrade"
              className="font-semibold underline underline-offset-2 hover:text-white/90"
            >
              Upgrade now
            </Link>
          </div>
        )}

        {/* Scrollable content area */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
