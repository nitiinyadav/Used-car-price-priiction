import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import SubmissionsTable from '@/components/SubmissionsTable';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { redirect } from 'next/navigation';

export const metadata = {
  title: 'Submission Inbox - StaticDrop',
};

export default async function DashboardSubmissionsPage({ searchParams }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, 'view_submissions')) {
    redirect('/dashboard');
  }

  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
  const page = Math.max(1, Number(searchParams?.page || 1));
  const query = String(searchParams?.q || '').trim();
  const pageSize = 12;

  const where = {
    site: { userId: workspaceOwnerId },
    ...(query
      ? {
          OR: [
            { formName: { contains: query } },
            { data: { contains: query } },
            { site: { name: { contains: query } } },
          ],
        }
      : {}),
  };

  const [submissions, total, recentCount, sitesWithSubmissions] = await Promise.all([
    prisma.formSubmission.findMany({
      where,
      include: {
        site: { select: { id: true, name: true, subdomain: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.formSubmission.count({ where }),
    prisma.formSubmission.count({
      where: {
        site: { userId: workspaceOwnerId },
        createdAt: {
          gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        },
      },
    }),
    prisma.site.count({
      where: { userId: workspaceOwnerId, submissions: { some: {} } },
    }),
  ]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Submission Inbox</h1>
        <p className="mt-1 text-gray-500">
          Review incoming leads across all of your deployed sites.
        </p>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Total Submissions</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Last 7 Days</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Sites Receiving Leads</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">
            {sitesWithSubmissions}
          </p>
        </div>
      </div>

      <form className="mb-4 rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="Search by site name, form name, or submission content"
            className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Search
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-gray-200 bg-white p-6">
        <SubmissionsTable
          submissions={submissions}
          siteName="all-sites"
          totalCount={total}
          page={page}
          totalPages={totalPages}
          basePath="/dashboard/submissions"
          searchQuery={query}
          showSiteColumn
        />
      </div>
    </div>
  );
}
