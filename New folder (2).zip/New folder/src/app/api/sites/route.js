import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { extractZip, getSiteDir } from '@/lib/storage';
import {
  generateApiKey,
  isZipFile,
  normalizeDomain,
  validateSubdomain,
  validateDomain,
  RESERVED_SUBDOMAINS,
} from '@/lib/utils';
import { getUserLimits } from '@/lib/plans';
import { serializeAllowedOrigins } from '@/lib/site-security';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

// GET /api/sites - List user's sites
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);

    const sites = await prisma.site.findMany({
      where: { userId: workspace?.workspaceOwnerId || session.user.id },
      include: { _count: { select: { submissions: true } } },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ sites });
  } catch (error) {
    console.error('List sites error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// POST /api/sites - Create and deploy a new site
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'create_sites')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const formData = await request.formData();
    const name = formData.get('name');
    const subdomain = formData.get('subdomain');
    const customDomainValue = formData.get('customDomain');
    const customDomain = customDomainValue
      ? normalizeDomain(customDomainValue)
      : null;
    const file = formData.get('file');
    const editorFilesBlob = formData.get('editorFiles');

    // Validate required fields
    if (!name || !subdomain || (!file && !editorFilesBlob)) {
      return NextResponse.json(
        { error: 'Name, subdomain, and files are required' },
        { status: 400 }
      );
    }

    // Validate subdomain format
    const subdomainLower = subdomain.toLowerCase().trim();
    if (!validateSubdomain(subdomainLower)) {
      return NextResponse.json(
        {
          error:
            'Invalid subdomain. Use lowercase letters, numbers, and hyphens. Min 3 characters.',
        },
        { status: 400 }
      );
    }

    // Check reserved subdomains
    if (RESERVED_SUBDOMAINS.includes(subdomainLower)) {
      return NextResponse.json(
        { error: 'This subdomain is reserved and cannot be used' },
        { status: 400 }
      );
    }

    // Check subdomain availability
    const existingSite = await prisma.site.findUnique({
      where: { subdomain: subdomainLower },
    });
    if (existingSite) {
      return NextResponse.json(
        { error: 'This subdomain is already taken' },
        { status: 409 }
      );
    }

    // Check custom domain if provided
    if (customDomain) {
      if (!validateDomain(customDomain)) {
        return NextResponse.json(
          { error: 'Please enter a valid custom domain like www.example.com' },
          { status: 400 }
        );
      }

      const existingCustom = await prisma.site.findUnique({
        where: { customDomain },
      });
      if (existingCustom) {
        return NextResponse.json(
          { error: 'This custom domain is already in use' },
          { status: 409 }
        );
      }
    }

    // Check site limit based on user's plan
    const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
    const limits = await getUserLimits(workspaceOwnerId);
    const userSiteCount = await prisma.site.count({
      where: { userId: workspaceOwnerId },
    });
    if (userSiteCount >= limits.maxSites) {
      return NextResponse.json(
        { error: `You can have a maximum of ${limits.maxSites} sites on your current plan. Upgrade to deploy more.` },
        { status: 403 }
      );
    }

    if (limits.trialExpired) {
      return NextResponse.json(
        {
          error:
            'Your 3-day free trial has ended. Upgrade a plan to deploy new sites.',
        },
        { status: 403 }
      );
    }

    // Check custom domain permission
    if (customDomain && !limits.customDomain) {
      return NextResponse.json(
        { error: 'Custom domains are not available on the free plan. Please upgrade.' },
        { status: 403 }
      );
    }

    // Validate file (ZIP upload path)
    if (file) {
      if (!file?.name || !isZipFile(file.name)) {
        return NextResponse.json(
          { error: 'Only ZIP files are accepted' },
          { status: 400 }
        );
      }

      const maxSize =
        parseInt(process.env.MAX_UPLOAD_SIZE_MB || '10', 10) * 1024 * 1024;
      if (file.size > maxSize) {
        return NextResponse.json(
          { error: `File size exceeds the maximum of ${process.env.MAX_UPLOAD_SIZE_MB || 10}MB` },
          { status: 400 }
        );
      }
    }

    // Validate editor files
    let editorFilesData = null;
    if (editorFilesBlob) {
      try {
        const text = await editorFilesBlob.text();
        editorFilesData = JSON.parse(text);
        if (typeof editorFilesData !== 'object' || !editorFilesData['index.html']) {
          return NextResponse.json(
            { error: 'Editor files must include index.html' },
            { status: 400 }
          );
        }
      } catch {
        return NextResponse.json(
          { error: 'Invalid editor files data' },
          { status: 400 }
        );
      }
    }

    // Create site record
    const apiKey = generateApiKey();
    const site = await prisma.site.create({
      data: {
        name: name.trim(),
        subdomain: subdomainLower,
        customDomain: customDomain || null,
        apiKey,
        deployPath: '', // Will update after extraction
        allowedOrigins: serializeAllowedOrigins(''),
        honeypotField: 'company',
        submissionRateLimit: 10,
        userId: workspaceOwnerId,
      },
    });

    // Deploy files
    try {
      let deployPath;
      if (editorFilesData) {
        // Editor files: write directly to site directory
        const siteDir = getSiteDir(site.id);
        if (fs.existsSync(siteDir)) {
          fs.rmSync(siteDir, { recursive: true, force: true });
        }
        fs.mkdirSync(siteDir, { recursive: true });
        const resolvedSiteDir = path.resolve(siteDir);
        for (const [filePath, content] of Object.entries(editorFilesData)) {
          const sanitized = filePath.replace(/\.\./g, '').replace(/^\//, '');
          const targetPath = path.resolve(siteDir, sanitized);
          if (!targetPath.startsWith(resolvedSiteDir + path.sep) && targetPath !== resolvedSiteDir) {
            continue;
          }
          const dir = path.dirname(targetPath);
          if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
          }
          fs.writeFileSync(targetPath, content, 'utf-8');
        }
        deployPath = siteDir;
      } else {
        // ZIP upload: extract
        const buffer = Buffer.from(await file.arrayBuffer());
        deployPath = await extractZip(buffer, site.id);
      }

      await prisma.site.update({
        where: { id: site.id },
        data: { deployPath },
      });
    } catch (extractError) {
      // Cleanup on failure
      await prisma.site.delete({ where: { id: site.id } });
      console.error('Deploy error:', extractError);
      return NextResponse.json(
        {
          error:
            extractError instanceof Error
              ? extractError.message
              : 'Failed to deploy files.',
        },
        { status: 400 }
      );
    }

    const createdSite = await prisma.site.findUnique({
      where: { id: site.id },
      include: { _count: { select: { submissions: true } } },
    });

    return NextResponse.json({ site: createdSite }, { status: 201 });
  } catch (error) {
    console.error('Create site error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
