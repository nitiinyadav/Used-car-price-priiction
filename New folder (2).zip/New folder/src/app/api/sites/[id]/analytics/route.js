import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export async function GET(request, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const workspace = await getWorkspaceContext(session.user.id);
  if (!hasPermission(workspace, 'view_analytics')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const site = await prisma.site.findFirst({
    where: { id: params.id, userId: workspace?.workspaceOwnerId || session.user.id },
    select: { id: true },
  });

  if (!site) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  const { searchParams } = new URL(request.url);
  const period = searchParams.get('period') || '7d';

  const days = period === '30d' ? 30 : period === '90d' ? 90 : 7;
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const [visits, topPages, topReferrers, countries] = await Promise.all([
    // Raw visits for time-series aggregation
    prisma.siteVisit.findMany({
      where: { siteId: site.id, createdAt: { gte: since } },
      select: { createdAt: true, ipHash: true },
      orderBy: { createdAt: 'asc' },
    }),
    // Top pages
    prisma.siteVisit.groupBy({
      by: ['path'],
      where: { siteId: site.id, createdAt: { gte: since } },
      _count: { path: true },
      orderBy: { _count: { path: 'desc' } },
      take: 10,
    }),
    // Top referrers (exclude null/empty)
    prisma.siteVisit.groupBy({
      by: ['referrer'],
      where: {
        siteId: site.id,
        createdAt: { gte: since },
        referrer: { not: null },
      },
      _count: { referrer: true },
      orderBy: { _count: { referrer: 'desc' } },
      take: 10,
    }),
    // Countries
    prisma.siteVisit.groupBy({
      by: ['countryCode'],
      where: { siteId: site.id, createdAt: { gte: since } },
      _count: { countryCode: true },
      orderBy: { _count: { countryCode: 'desc' } },
      take: 10,
    }),
  ]);

  // Build daily time-series
  const dailyMap = {};
  const uniqueByDay = {};
  for (let i = 0; i < days; i++) {
    const d = new Date(Date.now() - (days - 1 - i) * 24 * 60 * 60 * 1000);
    const key = d.toISOString().slice(0, 10);
    dailyMap[key] = 0;
    uniqueByDay[key] = new Set();
  }

  for (const v of visits) {
    const key = v.createdAt.toISOString().slice(0, 10);
    if (dailyMap[key] !== undefined) {
      dailyMap[key]++;
      uniqueByDay[key].add(v.ipHash);
    }
  }

  const timeSeries = Object.entries(dailyMap).map(([date, views]) => ({
    date,
    views,
    visitors: uniqueByDay[date]?.size || 0,
  }));

  // Count unique visitors for the period
  const uniqueIps = new Set(visits.map((v) => v.ipHash));

  // Clean referrer URLs to show just domains
  const referrers = topReferrers
    .filter((r) => r.referrer)
    .map((r) => {
      let domain = r.referrer;
      try {
        domain = new URL(r.referrer).hostname;
      } catch {}
      return { source: domain, count: r._count.referrer };
    });

  return NextResponse.json({
    period,
    totalViews: visits.length,
    uniqueVisitors: uniqueIps.size,
    timeSeries,
    topPages: topPages.map((p) => ({ path: p.path, count: p._count.path })),
    referrers,
    countries: countries.map((c) => ({
      code: c.countryCode || 'Unknown',
      count: c._count.countryCode,
    })),
  });
}
