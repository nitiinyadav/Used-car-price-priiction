import prisma from '@/lib/prisma';
import { getSiteSize } from '@/lib/storage';

export const metadata = {
  title: 'System Health - Admin - StaticDrop',
};

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function StatusBadge({ ok, label }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
        ok ? 'bg-green-900/50 text-green-400' : 'bg-red-900/50 text-red-400'
      }`}
    >
      <span className={`w-2 h-2 rounded-full ${ok ? 'bg-green-400' : 'bg-red-400'}`} />
      {label}
    </span>
  );
}

export default async function SystemHealthPage() {
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  // Database stats
  const [
    totalUsers,
    totalSites,
    totalVisits,
    totalSubmissions,
    totalPayments,
    recentVisits7d,
    recentSubmissions7d,
    topStorageSites,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.site.count(),
    prisma.siteVisit.count(),
    prisma.formSubmission.count(),
    prisma.payment.count(),
    prisma.siteVisit.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    prisma.formSubmission.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    prisma.site.findMany({
      select: { id: true, subdomain: true, name: true, user: { select: { email: true } } },
      orderBy: { createdAt: 'asc' },
      take: 20,
    }),
  ]);

  // Calculate storage per site
  const siteStorage = await Promise.all(
    topStorageSites.map(async (site) => {
      let size = 0;
      try {
        size = await getSiteSize(site.id);
      } catch {}
      return { ...site, storageBytes: size };
    })
  );

  siteStorage.sort((a, b) => b.storageBytes - a.storageBytes);
  const topBySizeSlice = siteStorage.slice(0, 10);
  const totalStorageBytes = siteStorage.reduce((sum, s) => sum + s.storageBytes, 0);

  // Service checks
  const hasEmail = !!process.env.RESEND_API_KEY;
  const hasStripe = !!process.env.STRIPE_SECRET_KEY;
  const hasRazorpay = !!process.env.RAZORPAY_KEY_ID;
  const hasS3 = !!process.env.S3_BUCKET;
  const hasGoogleOAuth = !!process.env.GOOGLE_CLIENT_ID;
  const hasGitHubOAuth = !!process.env.GITHUB_CLIENT_ID;
  const hasHttps = process.env.FORCE_HTTPS === 'true';

  // Database check
  let dbHealthy = false;
  try {
    await prisma.$queryRaw`SELECT 1`;
    dbHealthy = true;
  } catch {}

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">System Health</h1>
        <p className="mt-1 text-gray-400">
          Storage usage, database stats, and service status monitoring.
        </p>
      </div>

      {/* Service Status */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Service Status</h2>
        <div className="flex flex-wrap gap-3">
          <StatusBadge ok={dbHealthy} label="Database" />
          <StatusBadge ok={hasEmail} label="Email (Resend)" />
          <StatusBadge ok={hasStripe} label="Stripe" />
          <StatusBadge ok={hasRazorpay} label="Razorpay" />
          <StatusBadge ok={hasS3} label="S3 Storage" />
          <StatusBadge ok={hasGoogleOAuth} label="Google OAuth" />
          <StatusBadge ok={hasGitHubOAuth} label="GitHub OAuth" />
          <StatusBadge ok={hasHttps} label="HTTPS Enforced" />
        </div>
      </div>

      {/* Key Database Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard label="Total Users" value={totalUsers.toLocaleString()} />
        <MetricCard label="Total Sites" value={totalSites.toLocaleString()} />
        <MetricCard label="Total Visits" value={totalVisits.toLocaleString()} sub={`${recentVisits7d.toLocaleString()} last 7d`} />
        <MetricCard label="Form Submissions" value={totalSubmissions.toLocaleString()} sub={`${recentSubmissions7d.toLocaleString()} last 7d`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Storage Overview */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-1">Storage Usage</h2>
          <p className="text-sm text-gray-500 mb-4">
            Total: {formatBytes(totalStorageBytes)} across {totalSites} sites
          </p>
          <div className="space-y-3">
            {topBySizeSlice.length === 0 ? (
              <p className="text-sm text-gray-500">No sites deployed yet.</p>
            ) : (
              topBySizeSlice.map((site) => {
                const pct = totalStorageBytes > 0 ? (site.storageBytes / totalStorageBytes) * 100 : 0;
                return (
                  <div key={site.id}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <div className="truncate max-w-[180px]">
                        <span className="text-white font-medium">{site.name || site.subdomain}</span>
                        <span className="text-gray-500 ml-1 text-xs">({site.user.email})</span>
                      </div>
                      <span className="text-gray-400">{formatBytes(site.storageBytes)}</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-gray-700">
                      <div
                        className="h-1.5 rounded-full bg-indigo-500 transition-all"
                        style={{ width: `${Math.max(pct, 1)}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* System Info */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">System Info</h2>
          <div className="space-y-3">
            <InfoRow label="Node.js" value={process.version} />
            <InfoRow label="Platform" value={process.platform} />
            <InfoRow label="Environment" value={process.env.NODE_ENV || 'development'} />
            <InfoRow label="App URL" value={process.env.NEXT_PUBLIC_APP_URL || 'Not set'} />
            <InfoRow label="Root Domain" value={process.env.NEXT_PUBLIC_ROOT_DOMAIN || 'Not set'} />
            <InfoRow label="Database" value="PostgreSQL" />
            <InfoRow
              label="Memory Usage"
              value={formatBytes(process.memoryUsage().heapUsed) + ' / ' + formatBytes(process.memoryUsage().heapTotal)}
            />
            <InfoRow label="Uptime" value={formatUptime(process.uptime())} />
            <InfoRow label="Total Payments" value={totalPayments.toLocaleString()} />
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value, sub }) {
  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 p-5">
      <p className="text-sm text-gray-400">{label}</p>
      <p className="text-2xl font-bold text-white mt-1">{value}</p>
      {sub && <p className="text-xs text-gray-500 mt-1">{sub}</p>}
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="flex justify-between text-sm py-2 border-b border-gray-700 last:border-0">
      <span className="text-gray-400">{label}</span>
      <span className="text-white font-mono text-xs">{value}</span>
    </div>
  );
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}
