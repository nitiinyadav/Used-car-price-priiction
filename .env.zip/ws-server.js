// ws-server.js
const { WebSocketServer } = require("ws");

const PORT = 4001;

// Track live visitors
const liveVisitors = new Map();
const dashboardListeners = new Map();

function getLiveCount(siteId) {
  return liveVisitors.get(siteId)?.size || 0;
}

function broadcast(siteId) {
  const listeners = dashboardListeners.get(siteId);
  if (!listeners) return;

  const msg = JSON.stringify({
    type: "live_count",
    siteId,
    count: getLiveCount(siteId),
  });

  for (const ws of listeners) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

const wss = new WebSocketServer({ port: PORT });

wss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const role = url.searchParams.get("role");
  const siteId = url.searchParams.get("site");

  if (!siteId) {
    ws.close(4001, "Missing site");
    return;
  }

  if (role === "visitor") {
    if (!liveVisitors.has(siteId)) liveVisitors.set(siteId, new Set());
    liveVisitors.get(siteId).add(ws);

    broadcast(siteId);

    ws.on("close", () => {
      const set = liveVisitors.get(siteId);
      if (set) {
        set.delete(ws);
        if (set.size === 0) liveVisitors.delete(siteId);
      }
      broadcast(siteId);
    });
  }

  else if (role === "dashboard") {
    if (!dashboardListeners.has(siteId))
      dashboardListeners.set(siteId, new Set());

    dashboardListeners.get(siteId).add(ws);

    ws.send(
      JSON.stringify({
        type: "live_count",
        siteId,
        count: getLiveCount(siteId),
      })
    );

    ws.on("close", () => {
      const set = dashboardListeners.get(siteId);
      if (set) {
        set.delete(ws);
        if (set.size === 0) dashboardListeners.delete(siteId);
      }
    });
  }

  else {
    ws.close(4002, "Invalid role");
  }
});

console.log(`🚀 WebSocket running on ws://0.0.0.0:${PORT}`);
