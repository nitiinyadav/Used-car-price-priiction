'use client';

import { useEffect, useRef, useState } from 'react';

const WORDS = ['30 Seconds', 'One Click', 'Zero Config', 'No Servers'];

export default function RotatingText() {
  const [index, setIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setIndex((prev) => (prev + 1) % WORDS.length);
        setIsAnimating(false);
      }, 400);
    }, 3000);
    return () => clearInterval(intervalRef.current);
  }, []);

  return (
    <span className="relative inline-block overflow-hidden align-bottom" style={{ minWidth: '280px' }}>
      <span
        className={`inline-block bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent transition-all duration-400 ${
          isAnimating ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'
        }`}
      >
        {WORDS[index]}
      </span>
    </span>
  );
}
