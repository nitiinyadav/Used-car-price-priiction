'use client';

import { useState, useCallback } from 'react';
import Link from 'next/link';

export default function SubdomainPreview() {
  const [subdomain, setSubdomain] = useState('');
  const [status, setStatus] = useState(null); // null | 'checking' | 'available' | 'taken' | 'invalid'
  const [reason, setReason] = useState('');
  const [timer, setTimer] = useState(null);

  const checkSubdomain = useCallback((value) => {
    if (timer) clearTimeout(timer);

    const cleaned = value.toLowerCase().replace(/[^a-z0-9-]/g, '');
    setSubdomain(cleaned);

    if (cleaned.length < 3) {
      setStatus(null);
      setReason('');
      return;
    }

    setStatus('checking');
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/subdomain-check?subdomain=${encodeURIComponent(cleaned)}`);
        const data = await res.json();
        if (data.available) {
          setStatus('available');
          setReason('');
        } else {
          setStatus('taken');
          setReason(data.reason || 'Not available');
        }
      } catch {
        setStatus(null);
      }
    }, 400);
    setTimer(t);
  }, [timer]);

  return (
    <div className="mx-auto max-w-xl mt-12">
      <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6 shadow-lg shadow-gray-200/50 dark:shadow-black/20">
        <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3 text-center">
          Claim your subdomain — it&apos;s free
        </p>
        <div className="flex items-center gap-0 rounded-xl border-2 border-gray-200 dark:border-gray-700 focus-within:border-indigo-500 dark:focus-within:border-indigo-400 transition-colors overflow-hidden bg-gray-50 dark:bg-gray-800">
          <input
            type="text"
            value={subdomain}
            onChange={(e) => checkSubdomain(e.target.value)}
            placeholder="yourname"
            maxLength={63}
            className="flex-1 bg-transparent px-4 py-3.5 text-base font-medium text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none min-w-0"
          />
          <span className="text-sm font-medium text-gray-400 dark:text-gray-500 pr-4 whitespace-nowrap">
            .liveinsec.com
          </span>
        </div>

        {/* Status feedback */}
        <div className="mt-3 min-h-[28px]">
          {status === 'checking' && (
            <p className="text-sm text-gray-400 flex items-center gap-2">
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
              Checking availability...
            </p>
          )}
          {status === 'available' && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-green-600 dark:text-green-400 font-medium flex items-center gap-1.5">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" /></svg>
                <span className="font-semibold">{subdomain}.liveinsec.com</span> is available!
              </p>
              <Link
                href={`/register?subdomain=${encodeURIComponent(subdomain)}`}
                className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-colors whitespace-nowrap"
              >
                Claim it →
              </Link>
            </div>
          )}
          {status === 'taken' && (
            <p className="text-sm text-red-500 dark:text-red-400 flex items-center gap-1.5">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              {reason}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
