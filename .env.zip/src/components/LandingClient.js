'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import SubdomainPreview from '@/components/SubdomainPreview';
import AnimateOnScroll from '@/components/AnimateOnScroll';
import CountUp from '@/components/CountUp';

/* ─── Rotating hero text ─── */
const HERO_WORDS = ['30 Seconds', 'One Click', 'Zero Config', 'No Servers'];

function useRotatingText(words, interval = 3000) {
  const [index, setIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  useEffect(() => {
    const id = setInterval(() => {
      setAnimating(true);
      setTimeout(() => {
        setIndex((p) => (p + 1) % words.length);
        setAnimating(false);
      }, 350);
    }, interval);
    return () => clearInterval(id);
  }, [words, interval]);
  return { word: words[index], animating };
}

/* ─── Parallax mouse tracker for hero ─── */
function useParallax() {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const handler = (e) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 20;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      el.style.transform = `translate(${x}px, ${y}px)`;
    };
    window.addEventListener('mousemove', handler, { passive: true });
    return () => window.removeEventListener('mousemove', handler);
  }, []);
  return ref;
}

/* ─── Feature card data ─── */
const FEATURES = [
  { icon: '⚡', title: 'One-Click Deploy', desc: 'Upload a ZIP or use our code editor. Live in seconds — no CLI, no build step, no config files.', gradient: 'from-amber-500 to-orange-500', bg: 'from-amber-500/10 to-orange-500/10 dark:from-amber-500/5 dark:to-orange-500/5' },
  { icon: '🌐', title: 'Free Subdomain + Custom Domain', desc: 'Get yoursite.liveinsec.com instantly. Connect your own domain with automatic SSL.', gradient: 'from-sky-500 to-cyan-500', bg: 'from-sky-500/10 to-cyan-500/10 dark:from-sky-500/5 dark:to-cyan-500/5' },
  { icon: '📬', title: 'Form Collection API', desc: 'Collect leads without backend code. View submissions in dashboard, export to CSV.', gradient: 'from-violet-500 to-purple-500', bg: 'from-violet-500/10 to-purple-500/10 dark:from-violet-500/5 dark:to-purple-500/5' },
  { icon: '📊', title: 'Real-Time Analytics', desc: 'Page views, unique visitors, and live visitor count — all privacy-friendly and built in.', gradient: 'from-emerald-500 to-teal-500', bg: 'from-emerald-500/10 to-teal-500/10 dark:from-emerald-500/5 dark:to-teal-500/5' },
  { icon: '✏️', title: 'Built-in Code Editor', desc: 'Write HTML, CSS, JS in your browser with syntax highlighting and live preview.', gradient: 'from-rose-500 to-pink-500', bg: 'from-rose-500/10 to-pink-500/10 dark:from-rose-500/5 dark:to-pink-500/5' },
  { icon: '🔒', title: 'Enterprise Security', desc: 'SSL everywhere, rate limiting, IP blocking, CORS control, and honeypot spam protection.', gradient: 'from-indigo-500 to-blue-500', bg: 'from-indigo-500/10 to-blue-500/10 dark:from-indigo-500/5 dark:to-blue-500/5' },
];

const STEPS = [
  { num: '01', title: 'Create Account', desc: 'Sign up in 10 seconds. No credit card, no commitment.', color: 'from-indigo-600 to-indigo-500', glow: 'shadow-indigo-500/30' },
  { num: '02', title: 'Upload or Code', desc: 'Drag & drop a ZIP or build from scratch in our editor.', color: 'from-violet-600 to-violet-500', glow: 'shadow-violet-500/30' },
  { num: '03', title: 'Go Live Instantly', desc: 'Your site is live on a free subdomain. Add forms, analytics, custom domains.', color: 'from-fuchsia-600 to-fuchsia-500', glow: 'shadow-fuchsia-500/30' },
];

const TESTIMONIALS = [
  { quote: "I deployed my portfolio in literally 30 seconds. Beat every other platform I've tried.", name: 'Arjun Mehra', role: 'Freelance Developer', avatar: 'AM' },
  { quote: 'The form collection API saved us 2 weeks of backend work. Launched our lead gen site in an afternoon.', name: 'Sarah Chen', role: 'Marketing Lead', avatar: 'SC' },
  { quote: 'Moved 15 client landing pages here. Custom domain setup was painless. Excellent support.', name: 'Rahul Sharma', role: 'Agency Owner', avatar: 'RS' },
];

/* ─── Feature card with hover tilt ─── */
function FeatureCard({ feature, index }) {
  const ref = useRef(null);
  const handleMove = (e) => {
    const rect = ref.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    ref.current.style.transform = `perspective(600px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg) translateY(-4px)`;
  };
  const handleLeave = () => {
    ref.current.style.transform = 'perspective(600px) rotateY(0) rotateX(0) translateY(0)';
  };

  return (
    <AnimateOnScroll animation="animate-fade-up" delay={`stagger-${index + 1}`}>
      <div
        ref={ref}
        onMouseMove={handleMove}
        onMouseLeave={handleLeave}
        className={`group relative rounded-3xl border border-gray-200/60 dark:border-gray-800/60 bg-gradient-to-br ${feature.bg} p-8 transition-all duration-300 hover:shadow-2xl hover:shadow-gray-200/50 dark:hover:shadow-black/30 cursor-default`}
        style={{ transformStyle: 'preserve-3d', transition: 'transform 0.15s ease, box-shadow 0.3s ease' }}
      >
        <div className={`inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br ${feature.gradient} text-white text-xl mb-5 shadow-lg`}>
          {feature.icon}
        </div>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{feature.title}</h3>
        <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400">{feature.desc}</p>
        <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-[0.04] transition-opacity duration-500`} />
      </div>
    </AnimateOnScroll>
  );
}

/* ═══════════════════════════════════════════════
   MAIN LANDING CLIENT COMPONENT
   ═══════════════════════════════════════════════ */
export default function LandingClient() {
  const { word: heroWord, animating } = useRotatingText(HERO_WORDS);
  const parallaxRef = useParallax();

  return (
    <>
      {/* ── HERO ─────────────────────────────────────── */}
      <section className="relative isolate min-h-[90vh] flex items-center">
        {/* Ambient gradient blobs with parallax */}
        <div ref={parallaxRef} className="absolute inset-0 -z-10 overflow-hidden transition-transform duration-700 ease-out will-change-transform">
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[1000px] h-[700px] rounded-full bg-gradient-to-br from-indigo-400/25 via-violet-400/20 to-fuchsia-400/15 dark:from-indigo-600/15 dark:via-violet-600/10 dark:to-fuchsia-600/8 blur-3xl animate-gradient" />
          <div className="absolute top-20 right-0 w-[500px] h-[500px] rounded-full bg-gradient-to-l from-sky-300/15 to-transparent dark:from-sky-600/8 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-gradient-to-r from-amber-200/15 to-transparent dark:from-amber-500/8 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-24 pt-20 lg:pb-32 lg:pt-24 w-full">
          <div className="mx-auto max-w-4xl text-center">
            {/* Social proof badge */}
            <div className="animate-fade-up mb-8 inline-flex items-center gap-2.5 rounded-full border border-indigo-200/80 dark:border-indigo-800/60 bg-white/60 dark:bg-gray-900/60 glass px-5 py-2 shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" />
              </span>
              <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300 tracking-wide">2,400+ websites deployed this month</span>
            </div>

            {/* Main headline with rotating text */}
            <h1 className="animate-fade-up stagger-1 text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight text-gray-900 dark:text-white leading-[1.06]">
              Your Website, Live in
              <br className="hidden sm:block" />
              <span className="relative inline-flex overflow-hidden h-[1.15em] align-bottom justify-center" style={{ minWidth: '300px' }}>
                <span
                  className={`inline-block bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent transition-all duration-350 ease-out ${
                    animating ? 'opacity-0 translate-y-3 scale-95' : 'opacity-100 translate-y-0 scale-100'
                  }`}
                >
                  {heroWord}
                </span>
              </span>
            </h1>

            {/* Subtitle */}
            <p className="animate-fade-up stagger-2 mx-auto mt-7 max-w-2xl text-lg sm:text-xl leading-8 text-gray-600 dark:text-gray-400">
              Drop a ZIP. Pick a subdomain. Done. No terminal, no DevOps, no waiting.
              <br className="hidden sm:block" />
              <strong className="text-gray-900 dark:text-white">Free forever</strong> for small projects. Scale when you&apos;re ready.
            </p>

            {/* CTA buttons */}
            <div className="animate-fade-up stagger-3 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/register"
                className="group relative w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:from-indigo-500 hover:to-violet-500 transition-all duration-300 shadow-xl shadow-indigo-600/25 dark:shadow-indigo-600/15 hover:shadow-2xl hover:shadow-indigo-500/30 hover:-translate-y-0.5"
              >
                Start Deploying — It&apos;s Free
                <svg className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </Link>
              <Link
                href="#how-it-works"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 text-gray-700 dark:text-gray-300 px-6 py-4 rounded-2xl text-lg font-semibold hover:bg-gray-100/80 dark:hover:bg-gray-800/80 transition-all duration-300 border border-transparent hover:border-gray-200 dark:hover:border-gray-700"
              >
                See How It Works
                <svg className="w-4 h-4 transition-transform duration-300 group-hover:translate-y-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
              </Link>
            </div>

            {/* Trust indicators */}
            <div className="animate-fade-up stagger-4 mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-xs font-medium text-gray-500 dark:text-gray-500">
              {[
                { icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z', label: 'SSL Included' },
                { icon: 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z', label: 'No Credit Card' },
                { icon: 'M13 10V3L4 14h7v7l9-11h-7z', label: 'Instant Deploy' },
              ].map((t) => (
                <span key={t.label} className="flex items-center gap-1.5 transition-colors hover:text-gray-700 dark:hover:text-gray-300">
                  <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={t.icon} /></svg>
                  {t.label}
                </span>
              ))}
            </div>

            {/* Subdomain preview */}
            <SubdomainPreview />
          </div>

          {/* Browser mockup */}
          <AnimateOnScroll animation="animate-scale-in" className="relative mx-auto mt-16 max-w-5xl">
            <div className="rounded-2xl border border-gray-200/80 dark:border-gray-800/80 bg-white dark:bg-gray-900 shadow-2xl shadow-gray-300/30 dark:shadow-black/40 overflow-hidden ring-1 ring-black/5 dark:ring-white/5">
              {/* Chrome bar */}
              <div className="flex items-center gap-2 border-b border-gray-200 dark:border-gray-800 px-4 py-3 bg-gray-50/80 dark:bg-gray-900/80">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400 hover:bg-red-500 transition-colors" />
                  <div className="w-3 h-3 rounded-full bg-amber-400 hover:bg-amber-500 transition-colors" />
                  <div className="w-3 h-3 rounded-full bg-green-400 hover:bg-green-500 transition-colors" />
                </div>
                <div className="flex-1 mx-4 bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-1.5 text-xs text-gray-400 font-mono flex items-center gap-2">
                  <svg className="w-3 h-3 text-green-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" /></svg>
                  yoursite.liveinsec.com
                </div>
              </div>
              {/* Dashboard skeleton */}
              <div className="grid grid-cols-12 gap-4 p-6 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950 min-h-[260px] sm:min-h-[320px]">
                <div className="col-span-3 hidden sm:block space-y-3">
                  <div className="h-6 w-24 rounded-lg bg-indigo-200/60 dark:bg-indigo-800/40 animate-pulse" />
                  <div className="h-4 w-full rounded bg-gray-200/80 dark:bg-gray-800/80" />
                  <div className="h-4 w-3/4 rounded bg-gray-200/80 dark:bg-gray-800/80" />
                  <div className="h-4 w-5/6 rounded bg-indigo-100 dark:bg-indigo-900/40" />
                  <div className="h-4 w-2/3 rounded bg-gray-200/80 dark:bg-gray-800/80" />
                </div>
                <div className="col-span-12 sm:col-span-9 space-y-4">
                  <div className="flex gap-3">
                    {[
                      { color: 'bg-indigo-200 dark:bg-indigo-800' },
                      { color: 'bg-emerald-200 dark:bg-emerald-800' },
                      { color: 'bg-violet-200 dark:bg-violet-800' },
                    ].map((c, i) => (
                      <div key={i} className={`flex-1 h-20 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4 ${i === 2 ? 'hidden sm:block' : ''}`}>
                        <div className="h-3 w-16 rounded bg-gray-200/80 dark:bg-gray-700 mb-2" />
                        <div className={`h-6 w-12 rounded ${c.color}`} />
                      </div>
                    ))}
                  </div>
                  <div className="h-36 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4">
                    <div className="h-3 w-24 rounded bg-gray-200/80 dark:bg-gray-700 mb-4" />
                    <div className="grid grid-cols-5 gap-2 h-20 items-end">
                      {[20, 45, 30, 65, 50].map((h, i) => (
                        <div key={i} className="rounded-t-lg bg-gradient-to-t from-indigo-500/40 to-indigo-400/10 dark:from-indigo-600/40 dark:to-indigo-500/10" style={{ height: `${h}%` }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -inset-4 -z-10 bg-gradient-to-b from-indigo-100/40 via-transparent to-transparent dark:from-indigo-900/15 rounded-3xl blur-2xl" />
          </AnimateOnScroll>
        </div>
      </section>

      {/* ── CREDIBILITY BAR ──────────────────────────── */}
      <section className="border-y border-gray-100 dark:border-gray-800/60 bg-gray-50/50 dark:bg-gray-900/30 py-12 overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-[11px] font-semibold uppercase tracking-[0.25em] text-gray-400 dark:text-gray-600 mb-8">Trusted by developers & businesses worldwide</p>
          <div className="flex flex-wrap items-center justify-center gap-x-14 gap-y-5">
            {[
              { name: 'Portfolio', accent: 'Hub', color: 'text-indigo-400' },
              { name: 'Launch', accent: 'Kit', color: 'text-emerald-400' },
              { name: 'Site', accent: 'Forge', color: 'text-violet-400' },
              { name: 'Pixel', accent: 'Labs', color: 'text-amber-400' },
              { name: 'Web', accent: 'Shift', color: 'text-rose-400' },
            ].map((b) => (
              <span key={b.name} className="text-2xl font-black tracking-tight text-gray-300 dark:text-gray-700 transition-colors hover:text-gray-400 dark:hover:text-gray-500 select-none">
                {b.name}<span className={b.color}>{b.accent}</span>
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ─────────────────────────────────── */}
      <section className="py-28 lg:py-36" id="features">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <AnimateOnScroll animation="animate-fade-up" className="mx-auto max-w-2xl text-center mb-20">
            <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 mb-3">Platform</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white leading-tight">Everything to Ship Fast</h2>
            <p className="mt-5 text-lg text-gray-500 dark:text-gray-400 leading-relaxed">Stop spending hours on servers. Start building the product.</p>
          </AnimateOnScroll>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((f, i) => (
              <FeatureCard key={f.title} feature={f} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ─────────────────────────────── */}
      <section className="py-28 lg:py-36 bg-gray-50/80 dark:bg-gray-900/40" id="how-it-works">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <AnimateOnScroll animation="animate-fade-up" className="mx-auto max-w-2xl text-center mb-20">
            <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 mb-3">Simple</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white leading-tight">Three Steps. That&apos;s It.</h2>
            <p className="mt-5 text-lg text-gray-500 dark:text-gray-400">No learning curve. If you can zip a folder, you can deploy a website.</p>
          </AnimateOnScroll>

          <div className="relative grid md:grid-cols-3 gap-8 lg:gap-12">
            {/* Connector line */}
            <div className="hidden md:block absolute top-16 left-[16.67%] right-[16.67%] h-0.5">
              <div className="h-full bg-gradient-to-r from-indigo-300 via-violet-300 to-fuchsia-300 dark:from-indigo-700 dark:via-violet-700 dark:to-fuchsia-700 rounded-full" />
            </div>

            {STEPS.map((s, i) => (
              <AnimateOnScroll key={s.num} animation="animate-fade-up" delay={`stagger-${i + 1}`} className="relative text-center group">
                <div className={`relative z-10 mx-auto w-16 h-16 bg-gradient-to-br ${s.color} rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg ${s.glow} group-hover:scale-110 transition-transform duration-300`}>
                  {s.num}
                </div>
                <h3 className="mt-6 text-lg font-bold text-gray-900 dark:text-white">{s.title}</h3>
                <p className="mt-3 text-sm leading-6 text-gray-500 dark:text-gray-400 max-w-xs mx-auto">{s.desc}</p>
              </AnimateOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* ── FORM API SHOWCASE ────────────────────────── */}
      <section className="py-28 lg:py-36 overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <AnimateOnScroll animation="animate-slide-left">
              <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-violet-600 dark:text-violet-400 mb-3">No Backend Needed</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white leading-tight">Collect Leads with Zero Code</h2>
              <p className="mt-5 text-lg text-gray-500 dark:text-gray-400 leading-relaxed">
                Every deployed site gets a unique API endpoint. Point your HTML form to it, and we capture every submission — with spam protection, rate limiting, and email alerts.
              </p>
              <ul className="mt-8 space-y-4">
                {[
                  'Works with standard HTML forms',
                  'Supports AJAX / fetch submissions',
                  'View & export in your dashboard',
                  'Spam protection + honeypot built in',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 dark:bg-green-900/40 flex items-center justify-center">
                      <svg className="w-3.5 h-3.5 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <span className="text-sm font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </AnimateOnScroll>

            <AnimateOnScroll animation="animate-slide-right" className="relative">
              <div className="rounded-2xl border border-gray-200/80 dark:border-gray-800/80 bg-gray-950 p-6 text-sm font-mono shadow-2xl shadow-gray-400/15 dark:shadow-black/40 ring-1 ring-white/5">
                <div className="flex items-center space-x-2 mb-5">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-xs text-gray-500 ml-3 font-sans">index.html</span>
                </div>
                <pre className="text-green-400 overflow-x-auto leading-7 text-xs sm:text-sm">
{`<!-- Just add your form endpoint -->
<form
  action="https://liveinsec.com/api/forms/YOUR_KEY"
  method="POST"
>
  <input name="name" placeholder="Name" />
  <input name="email" type="email"
         placeholder="Email" />
  <textarea name="message"
    placeholder="Message"></textarea>

  <input type="hidden" name="_redirect"
    value="https://yoursite.com/thanks" />

  <button type="submit">Send</button>
</form>`}
                </pre>
              </div>
              <div className="absolute -inset-4 -z-10 rounded-3xl bg-gradient-to-br from-violet-200/30 to-fuchsia-200/30 dark:from-violet-800/15 dark:to-fuchsia-800/15 blur-2xl" />
            </AnimateOnScroll>
          </div>
        </div>
      </section>

      {/* ── STATS BAR with animated counters ─────────── */}
      <section className="py-20 bg-gray-50/80 dark:bg-gray-900/40 border-y border-gray-100 dark:border-gray-800/60">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { end: 12, suffix: 'K+', label: 'Sites Deployed' },
              { end: 99.9, suffix: '%', label: 'Uptime Guaranteed' },
              { end: 1, prefix: '<', suffix: 's', label: 'Deploy Time' },
              { end: 4.9, suffix: '/5', label: 'User Rating' },
            ].map((s) => (
              <AnimateOnScroll key={s.label} animation="animate-fade-up">
                <div className="text-4xl sm:text-5xl font-black text-gray-900 dark:text-white tabular-nums">
                  <CountUp end={s.end} suffix={s.suffix} prefix={s.prefix || ''} />
                </div>
                <div className="mt-2 text-sm font-medium text-gray-500 dark:text-gray-400">{s.label}</div>
              </AnimateOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ─────────────────────────────── */}
      <section className="py-28 lg:py-36">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <AnimateOnScroll animation="animate-fade-up" className="mx-auto max-w-2xl text-center mb-16">
            <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 mb-3">Testimonials</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white">Loved by Builders</h2>
          </AnimateOnScroll>

          <div className="grid md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <AnimateOnScroll key={t.name} animation="animate-fade-up" delay={`stagger-${i + 1}`}>
                <div className="group rounded-2xl border border-gray-200/80 dark:border-gray-800/60 bg-white dark:bg-gray-900/80 p-8 transition-all duration-300 hover:shadow-xl hover:shadow-gray-200/40 dark:hover:shadow-black/20 hover:-translate-y-1">
                  <div className="flex gap-1 mb-5">
                    {[...Array(5)].map((_, idx) => (
                      <svg key={idx} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                    ))}
                  </div>
                  <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400 mb-6">&ldquo;{t.quote}&rdquo;</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-white text-xs font-bold">{t.avatar}</div>
                    <div>
                      <p className="text-sm font-bold text-gray-900 dark:text-white">{t.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-500">{t.role}</p>
                    </div>
                  </div>
                </div>
              </AnimateOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* ── COMPARISON TABLE ─────────────────────────── */}
      <section className="py-28 lg:py-36 bg-gray-50/80 dark:bg-gray-900/40">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <AnimateOnScroll animation="animate-fade-up" className="text-center mb-16">
            <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 mb-3">Compare</span>
            <h2 className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Why LiveInSec?</h2>
          </AnimateOnScroll>

          <AnimateOnScroll animation="animate-scale-in">
            <div className="rounded-2xl border border-gray-200/80 dark:border-gray-800/60 bg-white dark:bg-gray-900/80 overflow-hidden shadow-lg shadow-gray-200/30 dark:shadow-black/20">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-800">
                    <th className="text-left px-6 py-4 font-semibold text-gray-500 dark:text-gray-400">Feature</th>
                    <th className="px-6 py-4 font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/30">LiveInSec</th>
                    <th className="px-6 py-4 font-semibold text-gray-500 dark:text-gray-400">Others</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800/60">
                  {[
                    { feature: 'Deploy Time', us: '< 30 seconds', them: '2-5 minutes' },
                    { feature: 'Free Subdomain', us: true, them: 'Limited' },
                    { feature: 'Form Collection', us: true, them: false },
                    { feature: 'Built-in Editor', us: true, them: false },
                    { feature: 'Custom Domains', us: true, them: 'Paid only' },
                    { feature: 'Credit Card Required', us: false, them: true },
                  ].map((r) => (
                    <tr key={r.feature} className="hover:bg-gray-50/50 dark:hover:bg-gray-800/30 transition-colors">
                      <td className="px-6 py-3.5 text-gray-700 dark:text-gray-300 font-medium">{r.feature}</td>
                      <td className="px-6 py-3.5 text-center bg-indigo-50/30 dark:bg-indigo-950/20">
                        {typeof r.us === 'boolean' ? (
                          r.us ? <span className="text-green-500 text-lg">✓</span> : <span className="text-red-400 text-lg">✗</span>
                        ) : (
                          <span className="font-semibold text-gray-900 dark:text-white">{r.us}</span>
                        )}
                      </td>
                      <td className="px-6 py-3.5 text-center text-gray-500 dark:text-gray-500">
                        {typeof r.them === 'boolean' ? (
                          r.them ? <span className="text-green-500 text-lg">✓</span> : <span className="text-red-400 text-lg">✗</span>
                        ) : (
                          <span>{r.them}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </AnimateOnScroll>
        </div>
      </section>

      {/* ── PRICING CTA ──────────────────────────────── */}
      <section className="py-28 lg:py-36">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <AnimateOnScroll animation="animate-fade-up">
            <span className="inline-block text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400 mb-3">Pricing</span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 dark:text-white">Pay Only For What You Need</h2>
            <p className="mt-5 text-lg text-gray-500 dark:text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Start free and add features from our Feature Store. Custom domains, analytics, extra submissions — all à la carte.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/register" className="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-violet-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:from-indigo-500 hover:to-violet-500 transition-all duration-300 shadow-xl shadow-indigo-600/25 dark:shadow-indigo-600/15 hover:shadow-2xl hover:-translate-y-0.5">
                Get Started Free
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </Link>
              <Link href="/docs" className="text-gray-700 dark:text-gray-300 px-6 py-4 rounded-2xl text-lg font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300">
                Read the Docs &rarr;
              </Link>
            </div>
          </AnimateOnScroll>
        </div>
      </section>

      {/* ── FINAL CTA ────────────────────────────────── */}
      <section className="relative py-28 lg:py-36 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 animate-gradient" />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDgpIi8+PC9zdmc+')] opacity-40" />
        </div>
        <AnimateOnScroll animation="animate-fade-up" className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white leading-tight">
            Stop Overthinking Hosting.
            <br />
            <span className="text-white/80">Just Ship It.</span>
          </h2>
          <p className="mt-6 max-w-xl mx-auto text-lg text-white/70 leading-relaxed">
            Join thousands of developers, freelancers, and businesses who deploy here. Your first site is free — forever.
          </p>
          <Link
            href="/register"
            className="mt-10 inline-flex items-center gap-2 bg-white text-indigo-700 px-10 py-4 rounded-2xl text-lg font-black hover:bg-gray-50 transition-all duration-300 shadow-xl shadow-black/10 hover:shadow-2xl hover:-translate-y-0.5"
          >
            Create Free Account
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
          </Link>
          <p className="mt-4 text-sm text-white/50">No credit card required. Deploy in under 60 seconds.</p>
        </AnimateOnScroll>
      </section>

      {/* ── FOOTER ───────────────────────────────────── */}
      <footer className="bg-gray-950 text-gray-400 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                </div>
                <span className="text-white font-bold text-lg">LiveInSec</span>
              </div>
              <p className="text-sm text-gray-500 leading-relaxed">Deploy static websites instantly. No servers required.</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-2.5 text-sm">
                <li><Link href="#features" className="hover:text-white transition-colors duration-200">Features</Link></li>
                <li><Link href="/register" className="hover:text-white transition-colors duration-200">Feature Store</Link></li>
                <li><Link href="#how-it-works" className="hover:text-white transition-colors duration-200">How It Works</Link></li>
                <li><Link href="/docs" className="hover:text-white transition-colors duration-200">Documentation</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Account</h4>
              <ul className="space-y-2.5 text-sm">
                <li><Link href="/login" className="hover:text-white transition-colors duration-200">Sign In</Link></li>
                <li><Link href="/register" className="hover:text-white transition-colors duration-200">Create Account</Link></li>
                <li><Link href="/dashboard" className="hover:text-white transition-colors duration-200">Dashboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2.5 text-sm">
                <li><Link href="/privacy" className="hover:text-white transition-colors duration-200">Privacy Policy</Link></li>
                <li><Link href="/terms" className="hover:text-white transition-colors duration-200">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">&copy; {new Date().getFullYear()} LiveInSec. All rights reserved.</p>
            <div className="flex items-center gap-6 text-sm text-gray-500">
              <span className="flex items-center gap-1.5"><svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" /></svg>SSL Secured</span>
              <span className="flex items-center gap-1.5">
                <span className="relative flex h-2 w-2"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" /><span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" /></span>
                All Systems Operational
              </span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
