"use client";

import { useState, useEffect, useCallback, useRef } from "react";

// Pure SVG area chart — no external dependencies
function AreaChart({ data, dataKey, label, color = "#6366f1", height = 200 }) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center" style={{ height }}>
        <p className="text-sm text-gray-500">No data for this period</p>
      </div>
    );
  }

  const values = data.map((d) => d[dataKey]);
  const max = Math.max(...values, 1);
  const padding = { top: 20, right: 12, bottom: 30, left: 44 };
  const w = 600;
  const h = height;
  const chartW = w - padding.left - padding.right;
  const chartH = h - padding.top - padding.bottom;

  const points = data.map((d, i) => ({
    x: padding.left + (i / (data.length - 1 || 1)) * chartW,
    y: padding.top + chartH - (d[dataKey] / max) * chartH,
    value: d[dataKey],
    label: d.date,
  }));

  const linePath = points
    .map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`)
    .join(" ");
  const areaPath = `${linePath} L${points[points.length - 1].x},${padding.top + chartH} L${points[0].x},${padding.top + chartH} Z`;

  // Y-axis ticks
  const yTicks = [
    0,
    Math.round(max * 0.25),
    Math.round(max * 0.5),
    Math.round(max * 0.75),
    max,
  ];
  const uniqueTicks = [...new Set(yTicks)];

  // X-axis labels (show ~5-7 labels max)
  const step = Math.max(1, Math.floor(data.length / 6));
  const xLabels = data.filter(
    (_, i) => i % step === 0 || i === data.length - 1,
  );

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }}>
      <defs>
        <linearGradient id={`grad-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>

      {/* Grid lines */}
      {uniqueTicks.map((tick) => {
        const y = padding.top + chartH - (tick / max) * chartH;
        return (
          <g key={tick}>
            <line
              x1={padding.left}
              y1={y}
              x2={w - padding.right}
              y2={y}
              stroke="#e5e7eb"
              strokeWidth="1"
            />
            <text
              x={padding.left - 8}
              y={y + 4}
              textAnchor="end"
              fontSize="11"
              fill="#9ca3af"
            >
              {tick}
            </text>
          </g>
        );
      })}

      {/* Area fill */}
      <path d={areaPath} fill={`url(#grad-${dataKey})`} />

      {/* Line */}
      <path
        d={linePath}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Data points */}
      {points.map((p, i) => (
        <circle
          key={i}
          cx={p.x}
          cy={p.y}
          r="3"
          fill={color}
          stroke="white"
          strokeWidth="1.5"
        >
          <title>{`${p.label}: ${p.value} ${label}`}</title>
        </circle>
      ))}

      {/* X-axis labels */}
      {xLabels.map((d) => {
        const idx = data.indexOf(d);
        const x = padding.left + (idx / (data.length - 1 || 1)) * chartW;
        const dateStr = new Date(d.date + "T00:00:00").toLocaleDateString(
          "en-US",
          {
            month: "short",
            day: "numeric",
          },
        );
        return (
          <text
            key={d.date}
            x={x}
            y={h - 6}
            textAnchor="middle"
            fontSize="11"
            fill="#9ca3af"
          >
            {dateStr}
          </text>
        );
      })}
    </svg>
  );
}

function PeriodSelector({ value, onChange }) {
  const options = [
    { label: "7 days", value: "7d" },
    { label: "30 days", value: "30d" },
    { label: "90 days", value: "90d" },
  ];

  return (
    <div className="flex gap-1 rounded-lg bg-gray-100 dark:bg-gray-800 p-1">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
            value === opt.value
              ? "bg-white dark:bg-gray-900 text-gray-900 dark:text-white shadow-sm"
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

function StatCard({ label, value, change }) {
  return (
    <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-5">
      <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
      <p className="mt-1 text-2xl font-bold text-gray-900 dark:text-white">
        {typeof value === "number" ? value.toLocaleString() : value}
      </p>
      {change !== undefined && (
        <p
          className={`mt-1 text-xs ${change >= 0 ? "text-green-600" : "text-red-600"}`}
        >
          {change >= 0 ? "↑" : "↓"} {Math.abs(change)}% vs previous period
        </p>
      )}
    </div>
  );
}

function BarList({ items, labelKey, valueKey, maxItems = 8 }) {
  if (!items || items.length === 0) {
    return <p className="text-sm text-gray-500">No data yet.</p>;
  }

  const max = Math.max(...items.map((i) => i[valueKey]), 1);
  return (
    <div className="space-y-2">
      {items.slice(0, maxItems).map((item, idx) => (
        <div key={idx}>
          <div className="flex items-center justify-between text-sm mb-1">
            <span className="text-gray-700 dark:text-gray-300 truncate max-w-[200px]">
              {item[labelKey]}
            </span>
            <span className="font-medium text-gray-900 dark:text-white">
              {item[valueKey].toLocaleString()}
            </span>
          </div>
          <div className="h-2 w-full rounded-full bg-gray-100 dark:bg-gray-800">
            <div
              className="h-2 rounded-full bg-indigo-500 transition-all"
              style={{ width: `${(item[valueKey] / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function LiveCountBadge({ count }) {
  return (
    <div className="rounded-xl border border-green-200 dark:border-green-800 bg-white dark:bg-gray-900 p-5">
      <p className="text-sm text-gray-500 dark:text-gray-400">Live Visitors</p>
      <div className="flex items-center gap-2 mt-1">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500" />
        </span>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{count}</p>
      </div>
      <p className="mt-1 text-xs text-green-600">Currently on site</p>
    </div>
  );
}

function useLiveCount(siteId) {
  const [count, setCount] = useState(0);
  const wsRef = useRef(null);
  const reconnectTimer = useRef(null);

  useEffect(() => {
    if (!siteId) return;

    async function connect() {
      try {
        // Fetch a short-lived auth token for WebSocket (H-01)
        let token = '';
        try {
          const tokenRes = await fetch('/api/ws-token');
          if (tokenRes.ok) {
            const tokenData = await tokenRes.json();
            token = tokenData.token || '';
          }
        } catch { /* proceed without token in dev */ }

        const proto = window.location.protocol === "https:" ? "wss" : "ws";
        const host = window.location.host;
        const ws = new WebSocket(
          `${proto}://${host}/ws/live?role=dashboard&site=${siteId}&token=${encodeURIComponent(token)}`,
        );

        ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            if (msg.type === "live_count") setCount(msg.count);
          } catch {
            /* ignore */
          }
        };

        ws.onclose = () => {
          wsRef.current = null;
          reconnectTimer.current = setTimeout(connect, 5000);
        };

        ws.onerror = () => ws.close();

        wsRef.current = ws;
      } catch {
        /* ignore */
      }
    }

    connect();

    return () => {
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      if (wsRef.current) wsRef.current.close();
    };
  }, [siteId]);

  return count;
}

export default function AnalyticsDashboard({ siteId }) {
  const [period, setPeriod] = useState("7d");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [chartMode, setChartMode] = useState("views");
  const liveCount = useLiveCount(siteId);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/sites/${siteId}/analytics?period=${period}`,
      );
      if (res.ok) {
        setData(await res.json());
      }
    } catch (err) {
      console.error("Failed to fetch analytics", err);
    } finally {
      setLoading(false);
    }
  }, [siteId, period]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading && !data) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
      </div>
    );
  }

  if (!data) {
    return <p className="text-gray-500">Failed to load analytics.</p>;
  }

  return (
    <div className="space-y-6">
      {/* Header with period selector */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          {["views", "visitors"].map((mode) => (
            <button
              key={mode}
              onClick={() => setChartMode(mode)}
              className={`rounded-md px-3 py-1.5 text-sm font-medium capitalize transition-colors ${
                chartMode === mode
                  ? "bg-indigo-100 text-indigo-700"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
        <PeriodSelector value={period} onChange={setPeriod} />
      </div>

      {/* Stat cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <LiveCountBadge count={liveCount} />
        <StatCard label="Page Views" value={data.totalViews} />
        <StatCard label="Unique Visitors" value={data.uniqueVisitors} />
        <StatCard
          label="Avg. Views/Day"
          value={
            data.timeSeries.length > 0
              ? Math.round(data.totalViews / data.timeSeries.length)
              : 0
          }
        />
      </div>

      {/* Time-series chart */}
      <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
        <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">
          {chartMode === "views" ? "Page Views" : "Unique Visitors"} Over Time
        </h2>
        <AreaChart
          data={data.timeSeries}
          dataKey={chartMode === "views" ? "views" : "visitors"}
          label={chartMode === "views" ? "views" : "visitors"}
          color={chartMode === "views" ? "#6366f1" : "#10b981"}
          height={240}
        />
      </div>

      {/* Bottom panels */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Top Pages */}
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">
            Top Pages
          </h2>
          <BarList items={data.topPages} labelKey="path" valueKey="count" />
        </div>

        {/* Referrers */}
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">
            Top Referrers
          </h2>
          <BarList items={data.referrers} labelKey="source" valueKey="count" />
        </div>

        {/* Countries */}
        <div className="rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
          <h2 className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">
            Visitor Countries
          </h2>
          <BarList items={data.countries} labelKey="code" valueKey="count" />
        </div>
      </div>
    </div>
  );
}
