'use client';

import { useEffect, useRef, useState } from 'react';

export default function AnimateOnScroll({
  children,
  animation = 'animate-fade-up',
  delay = '',
  threshold = 0.15,
  className = '',
  as: Tag = 'div',
}) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(el);
        }
      },
      { threshold }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold]);

  return (
    <Tag
      ref={ref}
      className={`${className} ${visible ? `${animation} ${delay}` : 'opacity-0'}`}
    >
      {children}
    </Tag>
  );
}
