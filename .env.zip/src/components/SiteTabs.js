'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function SiteTabs({ siteId }) {
  const pathname = usePathname();
  const tabs = [
    { href: `/dashboard/sites/${siteId}`, label: 'Overview' },
    { href: `/dashboard/sites/${siteId}/submissions`, label: 'Submissions' },
    { href: `/dashboard/sites/${siteId}/analytics`, label: 'Analytics' },
    { href: `/dashboard/sites/${siteId}/files`, label: 'Files' },
    { href: `/dashboard/sites/${siteId}/settings`, label: 'Settings' },
  ];

  return (
    <div className="mb-6 border-b border-gray-200 dark:border-gray-800">
      <nav className="flex gap-2">
        {tabs.map((tab) => {
          const isActive = pathname === tab.href;

          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={`rounded-t-lg px-4 py-2 text-sm font-medium transition-colors ${
                isActive
                  ? 'border border-b-white dark:border-b-gray-950 border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 text-indigo-700 dark:text-indigo-400'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
