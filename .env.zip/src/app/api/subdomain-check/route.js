import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

const RESERVED_SUBDOMAINS = [
  'www', 'api', 'app', 'admin', 'dashboard', 'mail', 'smtp', 'ftp',
  'ns1', 'ns2', 'dns', 'cdn', 'static', 'assets', 'media', 'blog',
  'docs', 'help', 'support', 'status', 'dev', 'staging', 'test',
  'localhost', 'liveinsec', 'store', 'shop',
];

// GET /api/subdomain-check?subdomain=mysite
export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const subdomain = (searchParams.get('subdomain') || '').toLowerCase().trim();

  if (!subdomain || subdomain.length < 3 || subdomain.length > 63) {
    return NextResponse.json({ available: false, reason: 'Subdomain must be 3-63 characters' });
  }

  if (!/^[a-z0-9][a-z0-9-]*[a-z0-9]$/.test(subdomain) && subdomain.length > 2) {
    return NextResponse.json({ available: false, reason: 'Only lowercase letters, numbers, and hyphens allowed' });
  }

  if (RESERVED_SUBDOMAINS.includes(subdomain)) {
    return NextResponse.json({ available: false, reason: 'This subdomain is reserved' });
  }

  const existing = await prisma.site.findUnique({
    where: { subdomain },
    select: { id: true },
  });

  if (existing) {
    return NextResponse.json({ available: false, reason: 'This subdomain is already taken' });
  }

  return NextResponse.json({ available: true, subdomain });
}
