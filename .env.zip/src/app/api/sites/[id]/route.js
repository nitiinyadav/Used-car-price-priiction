import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { deleteSiteFiles } from "@/lib/storage";
import { canUseFeature } from "@/lib/feature-access";
import { normalizeDomain, validateDomain } from "@/lib/utils";
import { serializeAllowedOrigins } from "@/lib/site-security";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

// GET /api/sites/[id] - Get site details
export async function GET(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
      include: { _count: { select: { formsubmission: true } } },
    });

    if (!site) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    return NextResponse.json({ site });
  } catch (error) {
    console.error("Get site error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}

// PUT /api/sites/[id] - Update site settings
export async function PUT(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, "manage_sites")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    const body = await request.json();
    const updateData = {};

    if (body.name !== undefined) {
      if (!body.name?.trim()) {
        return NextResponse.json(
          { error: "Site name cannot be empty" },
          { status: 400 },
        );
      }
      updateData.name = body.name.trim();
    }

    if (body.customDomain !== undefined) {
      const customDomain = normalizeDomain(body.customDomain);

      if (customDomain) {
        if (!validateDomain(customDomain)) {
          return NextResponse.json(
            {
              error: "Please enter a valid custom domain like www.example.com",
            },
            { status: 400 },
          );
        }

        const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
        if (session.user.role !== 'superadmin') {
          const hasAccess = await canUseFeature(workspaceOwnerId, 'custom-domain');
          if (!hasAccess) {
            return NextResponse.json(
              {
                error:
                  "Custom domains require a purchase. Please buy the Custom Domain feature from the Feature Store.",
              },
              { status: 403 },
            );
          }
        }

        // Check if custom domain is already in use by another site
        const existing = await prisma.site.findUnique({
          where: { customDomain },
        });
        if (existing && existing.id !== site.id) {
          return NextResponse.json(
            { error: "This custom domain is already in use" },
            { status: 409 },
          );
        }
        updateData.customDomain = customDomain;
      } else {
        updateData.customDomain = null;
      }
    }

    if (body.isActive !== undefined) {
      updateData.isActive = Boolean(body.isActive);
    }

    if (body.allowedOrigins !== undefined) {
      updateData.allowedOrigins = serializeAllowedOrigins(body.allowedOrigins);
    }

    if (body.honeypotField !== undefined) {
      updateData.honeypotField =
        String(body.honeypotField || "")
          .trim()
          .replace(/[^a-zA-Z0-9_-]/g, "") || "company";
    }

    if (body.submissionRateLimit !== undefined) {
      updateData.submissionRateLimit = Math.min(
        100,
        Math.max(1, Number(body.submissionRateLimit) || 10),
      );
    }

    const updated = await prisma.site.update({
      where: { id: site.id },
      data: updateData,
      include: { _count: { select: { formsubmission: true } } },
    });

    return NextResponse.json({ site: updated });
  } catch (error) {
    console.error("Update site error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}

// DELETE /api/sites/[id] - Delete site
export async function DELETE(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, "manage_sites")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    // Delete files
    await deleteSiteFiles(site.id);

    // Delete database record (cascades to submissions)
    await prisma.site.delete({ where: { id: site.id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete site error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
