import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

// POST /api/sites/[id]/regenerate-key — Regenerate site API key (L-02)
export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const workspace = await getWorkspaceContext(session.user.id);
    if (workspace && !hasPermission(workspace, 'manage_sites')) {
      return NextResponse.json({ error: 'Permission denied' }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const newApiKey = `lk_${crypto.randomBytes(24).toString('hex')}`;

    const updated = await prisma.site.update({
      where: { id: params.id },
      data: { apiKey: newApiKey },
      select: { id: true, apiKey: true },
    });

    return NextResponse.json({
      success: true,
      apiKey: updated.apiKey,
      message: 'API key regenerated. Update your forms with the new key.',
    });
  } catch (error) {
    console.error('Regenerate API key error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
