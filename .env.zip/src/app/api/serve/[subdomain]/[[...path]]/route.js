import { NextResponse } from 'next/server';
import mime from 'mime-types';
import prisma from '@/lib/prisma';
import { getFile } from '@/lib/storage';
import { normalizeDomain } from '@/lib/utils';
import { trackSiteVisit } from '@/lib/analytics';

// Tiny script injected into served HTML to track live visitors via WebSocket
function liveTrackingScript(siteId) {
  return `<script>(function(){try{var p=location.protocol==='https:'?'wss':'ws';var h=location.host;var s=new WebSocket(p+'://'+h+'/ws/live?role=visitor&site=${siteId}');s.onclose=function(){setTimeout(function(){try{var r=new WebSocket(p+'://'+h+'/ws/live?role=visitor&site=${siteId}');r.onerror=function(){}}catch(e){}},5000)};s.onerror=function(){}}catch(e){}})()</script>`;
}

// GET /api/serve/[subdomain]/[[...path]] - Serve static files for a deployed site
export async function GET(request, { params }) {
  try {
    const { subdomain } = params;
    const pathSegments = params.path || [];
    const filePath = pathSegments.join('/') || 'index.html';
    const requestedDomain = normalizeDomain(
      request.nextUrl.searchParams.get('domain') ||
        request.headers.get('host') ||
        ''
    );

    const site =
      subdomain === '_custom'
        ? await prisma.site.findFirst({
            where: { customDomain: requestedDomain },
          })
        : await prisma.site.findUnique({
            where: { subdomain },
          });

    const siteLabel = subdomain === '_custom' ? requestedDomain : subdomain;

    if (!site || !site.isActive) {
      return new NextResponse(notFoundPage(siteLabel), {
        status: 404,
        headers: { 'Content-Type': 'text/html' },
      });
    }

    // Get the file
    const fileContent = await getFile(site.id, filePath);

    if (!fileContent) {
      // Try with .html extension
      const htmlContent = await getFile(site.id, filePath + '.html');
      if (htmlContent) {
        await trackSiteVisit(site.id, request, `/${filePath}`);
        return new NextResponse(htmlContent, {
          status: 200,
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'public, max-age=300',
          },
        });
      }

      // Try index.html in the path as directory
      const indexContent = await getFile(site.id, filePath + '/index.html');
      if (indexContent) {
        await trackSiteVisit(site.id, request, `/${filePath}/`);
        return new NextResponse(indexContent, {
          status: 200,
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'public, max-age=300',
          },
        });
      }

      return new NextResponse(notFoundPage(siteLabel), {
        status: 404,
        headers: { 'Content-Type': 'text/html' },
      });
    }

    // Determine content type
    const contentType = mime.lookup(filePath) || 'application/octet-stream';
    const charset = mime.charset(contentType);

    const headers = {
      'Content-Type': charset
        ? `${contentType}; charset=${charset}`
        : contentType,
      'Content-Length': String(fileContent.length),
      'Cache-Control': 'public, max-age=3600',
    };

    // Add security headers
    if (contentType === 'text/html') {
      await trackSiteVisit(site.id, request, `/${filePath}`);
      headers['X-Content-Type-Options'] = 'nosniff';
      headers['X-Frame-Options'] = 'SAMEORIGIN';
      headers['Cache-Control'] = 'public, max-age=300';

      // Inject live visitor tracking script
      let htmlStr = typeof fileContent === 'string' ? fileContent : fileContent.toString('utf-8');
      const tracker = liveTrackingScript(site.id);
      if (htmlStr.includes('</body>')) {
        htmlStr = htmlStr.replace('</body>', tracker + '</body>');
      } else {
        htmlStr += tracker;
      }
      headers['Content-Length'] = String(Buffer.byteLength(htmlStr, 'utf-8'));

      return new NextResponse(htmlStr, { status: 200, headers });
    }

    return new NextResponse(fileContent, {
      status: 200,
      headers,
    });
  } catch (error) {
    console.error('Serve error:', error);
    return new NextResponse('Internal Server Error', {
      status: 500,
      headers: { 'Content-Type': 'text/plain' },
    });
  }
}

function notFoundPage(siteLabel) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Not Found</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f9fafb; color: #374151; }
    .container { text-align: center; padding: 48px; }
    h1 { font-size: 48px; font-weight: 700; color: #111827; margin: 0 0 8px; }
    p { font-size: 18px; color: #6b7280; margin: 8px 0 0; }
    a { color: #4f46e5; text-decoration: none; display: inline-block; margin-top: 24px; font-weight: 500; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="container">
    <h1>404</h1>
    <p>The site <strong>${siteLabel || 'unknown'}</strong> was not found or is inactive.</p>
    <a href="${process.env.NEXT_PUBLIC_APP_URL || '/'}">Go to LiveInSec</a>
  </div>
</body>
</html>`;
}

function trialExpiredPage(siteLabel) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Suspended</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #fff7ed; color: #7c2d12; }
    .container { text-align: center; padding: 48px; max-width: 560px; }
    h1 { font-size: 40px; font-weight: 700; color: #9a3412; margin: 0 0 12px; }
    p { font-size: 18px; line-height: 1.6; margin: 0 0 12px; }
    a { color: #c2410c; text-decoration: none; font-weight: 600; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Subscription Needed</h1>
    <p>The site <strong>${siteLabel || 'this site'}</strong> is currently suspended because the owner's trial or subscription is no longer active.</p>
    <p><a href="${process.env.NEXT_PUBLIC_APP_URL || '/dashboard/store'}">Visit the Feature Store to reactivate</a></p>
  </div>
</body>
</html>`;
}
