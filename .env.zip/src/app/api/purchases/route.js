export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

// GET /api/purchases — Get current user's active purchases
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const purchases = await prisma.featurepurchase.findMany({
      where: { userId: session.user.id },
      include: { feature: true },
      orderBy: { createdAt: "desc" },
    });

    // Group by feature slug
    const grouped = {};
    for (const p of purchases) {
      const slug = p.feature.slug;
      if (!grouped[slug]) {
        grouped[slug] = {
          feature: p.feature,
          totalQuantity: 0,
          activePurchases: [],
          expiredPurchases: [],
        };
      }

      const isExpired =
        p.status !== "active" ||
        (p.expiresAt && new Date(p.expiresAt) <= new Date());

      if (isExpired) {
        grouped[slug].expiredPurchases.push(p);
      } else {
        grouped[slug].totalQuantity += p.quantity;
        grouped[slug].activePurchases.push(p);
      }
    }

    return NextResponse.json({ purchases, grouped });
  } catch (error) {
    console.error("Get purchases error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
