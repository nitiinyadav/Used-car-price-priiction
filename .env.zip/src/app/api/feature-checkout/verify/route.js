import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { featurePurchaseReceiptTemplate } from '@/lib/email-templates';

// POST /api/feature-checkout/verify — Verify Razorpay payment and create purchases
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderId, razorpayPaymentId, razorpaySignature } = await request.json();

    if (!orderId || !razorpayPaymentId || !razorpaySignature) {
      return NextResponse.json({ error: 'Missing payment verification fields' }, { status: 400 });
    }

    if (typeof orderId !== 'string' || typeof razorpayPaymentId !== 'string' || typeof razorpaySignature !== 'string') {
      return NextResponse.json({ error: 'Invalid payment verification fields' }, { status: 400 });
    }

    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret || razorpayKeySecret.length < 10) {
      return NextResponse.json({ error: 'Payment secret not configured or invalid' }, { status: 500 });
    }

    // Find the featureorder — use interactive transaction for atomicity
    const result = await prisma.$transaction(async (tx) => {
      const order = await tx.featureorder.findFirst({
        where: {
          userId: session.user.id,
          razorpayOrderId: orderId,
        },
        include: {
          orderitem: { include: { feature: true } },
        },
      });

      if (!order) {
        return { error: 'Order not found', status: 404 };
      }

      // Idempotency: if already paid, return success without creating duplicate purchases
      if (order.status === 'paid') {
        return {
          success: true,
          message: 'Payment already verified',
          orderId: order.id,
        };
      }

      // Reject if already failed — don't allow retries on a failed order
      if (order.status === 'failed') {
        return { error: 'This order has already been marked as failed', status: 400 };
      }

      // L-09: Reject verification if order is older than 30 minutes
      const orderAge = Date.now() - new Date(order.createdAt).getTime();
      if (orderAge > 30 * 60 * 1000) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: { status: 'failed' },
        });
        return { error: 'Order expired. Please create a new checkout.', status: 400 };
      }

      // Verify Razorpay signature
      const generatedSignature = crypto
        .createHmac('sha256', razorpayKeySecret)
        .update(`${orderId}|${razorpayPaymentId}`)
        .digest('hex');

      if (generatedSignature !== razorpaySignature) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: {
            status: 'failed',
            razorpayPaymentId,
            razorpaySignature,
          },
        });

        return { error: 'Payment signature verification failed', status: 400 };
      }

      // Signature verified — validate amount matches our order (BUG-13)
      const expectedTotal = order.orderitem.reduce((sum, oi) => sum + oi.totalPrice, 0);
      const storedTotal = order.currency === 'INR' ? order.totalAmountInr : order.totalAmountUsd;
      if (expectedTotal !== storedTotal) {
        console.error(`[PURCHASE] Amount mismatch for order ${order.id}: items sum ${expectedTotal} vs stored ${storedTotal}`);
        await tx.featureorder.update({
          where: { id: order.id },
          data: { status: 'failed', razorpayPaymentId, razorpaySignature },
        });
        return { error: 'Order amount integrity check failed', status: 400 };
      }

      // Signature verified — update order status FIRST
      await tx.featureorder.update({
        where: { id: order.id },
        data: {
          status: 'paid',
          razorpayPaymentId,
          razorpaySignature,
        },
      });

      // Create feature purchases
      const now = new Date();
      for (const oi of order.orderitem) {
        let expiresAt = null;
        if (oi.durationDays) {
          // For duration features: quantity = number of periods (e.g., 3 months)
          // Total duration = durationDays * quantity
          expiresAt = new Date(now.getTime() + oi.durationDays * oi.quantity * 24 * 60 * 60 * 1000);
        }

        await tx.featurepurchase.create({
          data: {
            userId: session.user.id,
            featureId: oi.featureId,
            quantity: oi.quantity, // Always store the real purchased quantity
            expiresAt,
            amountPaid: oi.totalPrice,
            currency: order.currency,
            razorpayPaymentId,
            orderId: order.id,
            status: 'active',
          },
        });
      }

      // Clear the user's cart ONLY after all purchases are committed
      await tx.cartitem.deleteMany({ where: { userId: session.user.id } });

      return {
        success: true,
        orderId: order.id,
        purchases: order.orderitem.map((oi) => ({
          feature: oi.feature.name,
          slug: oi.feature.slug,
          quantity: oi.quantity,
          expiresAt: oi.durationDays
            ? new Date(now.getTime() + oi.durationDays * oi.quantity * 24 * 60 * 60 * 1000).toISOString()
            : null,
        })),
      };
    });

    // Handle results from transaction
    if (result.error) {
      return NextResponse.json({ error: result.error }, { status: result.status || 500 });
    }

    // Log successful purchase for audit
    console.log(`[PURCHASE] User ${session.user.id} purchased: ${result.purchases?.map(p => p.feature).join(', ')} — Order ${result.orderId}`);

    // Send purchase receipt email (non-blocking)
    if (result.purchases && session.user.email) {
      try {
        // Fetch order to get total amount
        const order = await prisma.featureorder.findUnique({
          where: { id: result.orderId },
          select: { totalAmountUsd: true, totalAmountInr: true, currency: true },
        });
        if (order) {
          const totalAmount = order.currency === 'INR' ? order.totalAmountInr : order.totalAmountUsd;
          const emailData = featurePurchaseReceiptTemplate(
            session.user.name,
            result.purchases,
            totalAmount,
            order.currency,
            result.orderId
          );
          sendEmail({ to: session.user.email, ...emailData }).catch((err) =>
            console.error('[PURCHASE EMAIL] Failed:', err)
          );
        }
      } catch (emailErr) {
        console.error('[PURCHASE EMAIL] Error:', emailErr);
      }
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Feature verify error:', error);
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 500 });
  }
}
