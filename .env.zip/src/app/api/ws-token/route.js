import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

// GET /api/ws-token — Generate a short-lived JWT for WebSocket dashboard auth
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const secret = process.env.NEXTAUTH_SECRET;
    if (!secret) {
      return NextResponse.json({ error: 'Server misconfigured' }, { status: 500 });
    }

    // Create a short-lived token (5 minutes) for WebSocket authentication
    const token = jwt.sign(
      { sub: session.user.id, purpose: 'ws-auth' },
      secret,
      { algorithm: 'HS256', expiresIn: '5m' }
    );

    return NextResponse.json({ token });
  } catch (error) {
    console.error('WS token error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
