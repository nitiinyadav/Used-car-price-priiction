import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { requireSuperAdmin } from '@/lib/admin-auth';

export async function PUT(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const features = String(body.features || '')
      .split(/\r?\n/)
      .map((feature) => feature.trim())
      .filter(Boolean);

    const updated = await prisma.plan.update({
      where: { id: params.id },
      data: {
        name: String(body.name || '').trim(),
        priceMonthly: Math.max(0, Number(body.priceMonthly) || 0),
        priceYearly: Math.max(0, Number(body.priceYearly) || 0),
        priceMonthlyInr: Math.max(0, Number(body.priceMonthlyInr) || 0),
        priceYearlyInr: Math.max(0, Number(body.priceYearlyInr) || 0),
        maxSites: Math.max(1, Number(body.maxSites) || 1),
        maxStorageMB: Math.max(1, Number(body.maxStorageMB) || 1),
        maxSubmissions: Math.max(1, Number(body.maxSubmissions) || 1),
        customDomain: Boolean(body.customDomain),
        priority: Math.max(0, Number(body.priority) || 0),
        isActive: Boolean(body.isActive),
        features: JSON.stringify(features),
      },
    });

    return NextResponse.json({ plan: updated });
  } catch (error) {
    console.error('Update plan error:', error);
    return NextResponse.json(
      { error: 'Failed to update plan' },
      { status: 500 }
    );
  }
}
