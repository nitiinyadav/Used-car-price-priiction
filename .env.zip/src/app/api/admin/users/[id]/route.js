import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { deleteSiteFiles } from '@/lib/storage';
import { requireSuperAdmin } from '@/lib/admin-auth';
import { audit } from '@/lib/audit';

// PUT /api/admin/users/[id] - Update user
export async function PUT(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const user = await prisma.user.findUnique({ where: { id: params.id } });
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Prevent modifying other super admins
    if (user.role === 'superadmin' && user.id !== session.user.id) {
      return NextResponse.json({ error: 'Cannot modify other super admins' }, { status: 403 });
    }

    const body = await request.json();
    const updateData = {};

    if (body.plan && ['free', 'starter', 'pro', 'enterprise'].includes(body.plan)) {
      updateData.planSlug = body.plan;
    }

    if (body.role && ['user', 'superadmin'].includes(body.role)) {
      updateData.role = body.role;
    }

    if (body.name) {
      updateData.name = body.name.trim();
    }

    const updated = await prisma.user.update({
      where: { id: params.id },
      data: updateData,
    });

    // L-05: Audit admin user update
    audit('admin.update_user', {
      userId: session.user.id,
      target: params.id,
      details: updateData,
    });

    return NextResponse.json({ user: { id: updated.id, name: updated.name, role: updated.role, plan: updated.planSlug } });
  } catch (error) {
    console.error('Admin update user error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/admin/users/[id] - Delete user and all their data
export async function DELETE(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const user = await prisma.user.findUnique({
      where: { id: params.id },
      include: { sites: true },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    if (user.role === 'superadmin') {
      return NextResponse.json({ error: 'Cannot delete super admin accounts' }, { status: 403 });
    }

    // Delete all site files on disk
    for (const site of user.sites) {
      await deleteSiteFiles(site.id);
    }

    // Delete user (cascades to sites → submissions, and payments)
    await prisma.user.delete({ where: { id: params.id } });

    // L-05: Audit admin user deletion
    audit('admin.delete_user', {
      userId: session.user.id,
      target: params.id,
      details: { email: user.email, siteCount: user.sites.length },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Admin delete user error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
