import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

// GET /api/cart — Get current user's cart
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const items = await prisma.cartitem.findMany({
      where: { userId: session.user.id },
      include: { feature: true },
      orderBy: { createdAt: 'asc' },
    });

    // Filter out items for inactive features (BUG-23)
    const activeItems = items.filter(item => item.feature.isActive);

    // Clean up stale cart items in background
    const staleIds = items.filter(item => !item.feature.isActive).map(item => item.id);
    if (staleIds.length > 0) {
      prisma.cartitem.deleteMany({ where: { id: { in: staleIds } } }).catch(() => {});
    }

    return NextResponse.json({ items: activeItems });
  } catch (error) {
    console.error('Get cart error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/cart — Add/update item in cart
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const featureId = body.featureId;
    const quantity = Number(body.quantity);

    if (!featureId || typeof featureId !== 'string') {
      return NextResponse.json({ error: 'featureId is required and must be a string' }, { status: 400 });
    }

    if (!Number.isInteger(quantity) || quantity < 1) {
      return NextResponse.json({ error: 'quantity must be a positive integer' }, { status: 400 });
    }

    // Validate feature exists and is active
    const feature = await prisma.feature.findUnique({ where: { id: featureId } });
    if (!feature || !feature.isActive) {
      return NextResponse.json({ error: 'Feature not found or inactive' }, { status: 404 });
    }

    // Validate quantity constraints (guard against minQty > maxQty admin error)
    const effectiveMin = Math.min(feature.minQty, feature.maxQty);
    const effectiveMax = Math.max(feature.minQty, feature.maxQty);
    if (quantity < effectiveMin || quantity > effectiveMax) {
      return NextResponse.json(
        { error: `Quantity must be between ${effectiveMin} and ${effectiveMax}` },
        { status: 400 }
      );
    }

    if (quantity % feature.stepQty !== 0 && feature.stepQty > 1) {
      return NextResponse.json(
        { error: `Quantity must be in increments of ${feature.stepQty}` },
        { status: 400 }
      );
    }

    // Upsert cart item (unique per user+feature)
    const item = await prisma.cartitem.upsert({
      where: {
        userId_featureId: {
          userId: session.user.id,
          featureId,
        },
      },
      create: {
        userId: session.user.id,
        featureId,
        quantity,
      },
      update: {
        quantity,
      },
      include: { feature: true },
    });

    return NextResponse.json({ item });
  } catch (error) {
    console.error('Add to cart error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/cart — Remove item from cart (by featureId in body)
export async function DELETE(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { featureId, clearAll } = await request.json();

    if (clearAll) {
      await prisma.cartitem.deleteMany({ where: { userId: session.user.id } });
      return NextResponse.json({ success: true, message: 'Cart cleared' });
    }

    if (!featureId) {
      return NextResponse.json({ error: 'featureId is required' }, { status: 400 });
    }

    await prisma.cartitem.deleteMany({
      where: { userId: session.user.id, featureId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Remove from cart error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
