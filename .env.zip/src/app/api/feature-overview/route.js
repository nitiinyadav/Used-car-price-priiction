export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getUserFeatureOverview } from "@/lib/feature-access";

// GET /api/feature-overview — Get current user's feature usage overview
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const overview = await getUserFeatureOverview(session.user.id);
    return NextResponse.json({ overview });
  } catch (error) {
    console.error("Feature overview error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
