import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import prisma from '@/lib/prisma';
import { validatePassword } from '@/lib/password';
import { audit } from '@/lib/audit';

export async function POST(request) {
  try {
    const { token, password } = await request.json();

    if (!token || !password) {
      return NextResponse.json(
        { error: 'Token and new password are required' },
        { status: 400 }
      );
    }

    // H-03: Password complexity validation
    const passwordError = validatePassword(password);
    if (passwordError) {
      return NextResponse.json({ error: passwordError }, { status: 400 });
    }

    const resetToken = await prisma.passwordresettoken.findUnique({
      where: { token },
      include: { user: { select: { id: true, email: true } } },
    });

    if (!resetToken) {
      return NextResponse.json(
        { error: 'Invalid or expired reset link.' },
        { status: 400 }
      );
    }

    if (new Date() > resetToken.expiresAt) {
      await prisma.passwordresettoken.delete({ where: { id: resetToken.id } });
      return NextResponse.json(
        { error: 'This reset link has expired. Please request a new one.' },
        { status: 400 }
      );
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    await prisma.$transaction([
      prisma.user.update({
        where: { id: resetToken.userId },
        data: { password: hashedPassword },
      }),
      prisma.passwordresettoken.deleteMany({
        where: { userId: resetToken.userId },
      }),
    ]);

    // L-05: Audit password reset
    audit('password.reset', {
      userId: resetToken.userId,
      details: { email: resetToken.user.email },
    });

    return NextResponse.json({
      success: true,
      message: 'Password has been reset. You can now log in.',
    });
  } catch (error) {
    console.error('Password reset confirm error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
