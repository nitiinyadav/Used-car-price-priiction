import crypto from 'crypto';
import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import prisma from '@/lib/prisma';
import { detectPreferredCurrency } from '@/lib/currency';
import { detectCountry } from '@/lib/location';
import { env } from '@/lib/env';
import { validatePassword } from '@/lib/password';
import { sendEmail } from '@/lib/email';
import { verifyEmailTemplate, welcomeDripTemplate } from '@/lib/email-templates';

export async function POST(request) {
  try {
    const body = await request.json();
    const { email, password, name, phone } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // H-03: Password complexity validation
    const passwordError = validatePassword(password);
    if (passwordError) {
      return NextResponse.json({ error: passwordError }, { status: 400 });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please provide a valid email address' },
        { status: 400 }
      );
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'An account with this email already exists' },
        { status: 409 }
      );
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const trialEndsAt = new Date(Date.now() + env.TRIAL_DAYS * 24 * 60 * 60 * 1000);
    const billingCurrency = detectPreferredCurrency(request.headers);
    const { countryCode, countryName } = detectCountry(request.headers);

    const user = await prisma.user.create({
      data: {
        name: name ? name.trim() : email.split('@')[0],
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        phone: phone ? String(phone).trim() : null,
        countryCode,
        countryName,
        subscriptionStatus: 'trial',
        billingCurrency,
        trialEndsAt,
      },
    });

    // Send verification email automatically
    try {
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
      await prisma.emailverificationtoken.create({
        data: { userId: user.id, token, expiresAt },
      });
      const verificationUrl = `${env.APP_URL}/verify-email?token=${token}`;
      const { subject, html, text } = verifyEmailTemplate(user.name, verificationUrl);
      await sendEmail({ to: user.email, subject, html, text });
    } catch (err) {
      console.error('Failed to send verification email:', err);
    }

    // Send Day 0 welcome drip email
    try {
      const { subject, html, text } = welcomeDripTemplate(user.name);
      await sendEmail({ to: user.email, subject, html, text });
    } catch (err) {
      console.error('Failed to send welcome drip email:', err);
    }

    return NextResponse.json(
      {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          trialEndsAt: user.trialEndsAt,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
