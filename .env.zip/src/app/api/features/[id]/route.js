import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { invalidateFeatureCache } from '@/lib/feature-access';
import { requireSuperAdmin } from '@/lib/admin-auth';

// PUT /api/features/[id] — Admin update feature
export async function PUT(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();
    const { id } = params;

    const existing = await prisma.feature.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Feature not found' }, { status: 404 });
    }

    // If slug is being changed, check for conflicts
    if (body.slug && body.slug !== existing.slug) {
      const conflict = await prisma.feature.findUnique({ where: { slug: body.slug } });
      if (conflict) {
        return NextResponse.json({ error: 'Another feature with this slug already exists' }, { status: 409 });
      }
    }

    const feature = await prisma.feature.update({
      where: { id },
      data: body,
    });

    invalidateFeatureCache();
    return NextResponse.json({ feature });
  } catch (error) {
    console.error('Update feature error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE /api/features/[id] — Admin delete feature
export async function DELETE(request, { params }) {
  try {
    const session = await requireSuperAdmin();
    if (!session) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { id } = params;

    const existing = await prisma.feature.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Feature not found' }, { status: 404 });
    }

    // Check for active purchases before deleting
    const activePurchases = await prisma.featurepurchase.count({
      where: { featureId: id, status: 'active' },
    });

    if (activePurchases > 0) {
      return NextResponse.json(
        { error: `Cannot delete: ${activePurchases} active purchases exist. Deactivate instead.` },
        { status: 400 }
      );
    }

    await prisma.feature.delete({ where: { id } });
    invalidateFeatureCache();

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete feature error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
