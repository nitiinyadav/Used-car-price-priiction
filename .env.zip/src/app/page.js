import Navbar from '@/components/Navbar';
import LandingClient from '@/components/LandingClient';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 overflow-hidden">
      <Navbar />
      <LandingClient />
    </div>
  );
}