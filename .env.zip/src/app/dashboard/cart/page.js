'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import Script from 'next/script';

function formatPrice(cents, currency) {
  if (currency === 'INR') {
    return `₹${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
  }
  return `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}

export default function CartPage() {
  const { data: session } = useSession();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [removing, setRemoving] = useState(null);
  const [updating, setUpdating] = useState(null);
  const [checkingOut, setCheckingOut] = useState(false);
  const [currency, setCurrency] = useState('USD');
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [purchasedItems, setPurchasedItems] = useState([]);
  const [error, setError] = useState('');

  const loadCart = useCallback(async () => {
    try {
      const res = await fetch('/api/cart');
      const data = await res.json();
      setItems(data.items || []);
    } catch (err) {
      console.error('Load cart error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCart();
  }, [loadCart]);

  async function updateQuantity(featureId, newQty) {
    setUpdating(featureId);
    try {
      await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ featureId, quantity: newQty }),
      });
      await loadCart();
    } catch (err) {
      console.error('Update quantity error:', err);
    } finally {
      setUpdating(null);
    }
  }

  async function removeItem(featureId) {
    setRemoving(featureId);
    try {
      await fetch('/api/cart', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ featureId }),
      });
      await loadCart();
    } catch (err) {
      console.error('Remove item error:', err);
    } finally {
      setRemoving(null);
    }
  }

  async function clearCart() {
    try {
      await fetch('/api/cart', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clearAll: true }),
      });
      setItems([]);
    } catch (err) {
      console.error('Clear cart error:', err);
    }
  }

  async function handleCheckout() {
    setCheckingOut(true);
    setError('');

    try {
      const res = await fetch('/api/feature-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currency }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Checkout failed');
        setCheckingOut(false);
        return;
      }

      // Open Razorpay checkout
      const options = {
        key: data.keyId,
        amount: data.amount,
        currency: data.currency,
        name: 'LiveInSec',
        description: data.description,
        order_id: data.orderId,
        handler: async (response) => {
          try {
            const verifyRes = await fetch('/api/feature-checkout/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                orderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });

            const verifyData = await verifyRes.json();

            if (verifyData.success) {
              setPurchasedItems(verifyData.purchases || []);
              setPaymentSuccess(true);
              setItems([]);
            } else {
              setError(verifyData.error || 'Payment verification failed');
            }
          } catch {
            setError('Payment verification failed. Please contact support.');
          }
          setCheckingOut(false);
        },
        prefill: {
          name: session?.user?.name || '',
          email: session?.user?.email || '',
        },
        theme: {
          color: '#4F46E5',
        },
        modal: {
          ondismiss: () => {
            setCheckingOut(false);
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch {
      setError('Could not initiate checkout. Please try again.');
      setCheckingOut(false);
    }
  }

  // Calculate totals
  const total = items.reduce((sum, item) => {
    const unitPrice = currency === 'INR' ? item.feature.priceInr : item.feature.priceUsd;
    return sum + unitPrice * item.quantity;
  }, 0);

  // Currency label for display
  const currencyLabel = currency === 'INR' ? 'INR (₹)' : 'USD ($)';

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-32 bg-gray-200 dark:bg-gray-700 rounded" />
          <div className="h-24 bg-gray-200 dark:bg-gray-700 rounded-xl" />
          <div className="h-24 bg-gray-200 dark:bg-gray-700 rounded-xl" />
        </div>
      </div>
    );
  }

  if (paymentSuccess) {
    // Map feature slugs to their dashboard pages
    const featureLinks = {
      'submissions': '/dashboard/submissions',
      'analytics': '/dashboard/analytics',
      'custom-domain': '/dashboard/sites',
      'extra-storage': '/dashboard/sites',
      'team-members': '/dashboard/settings',
    };

    return (
      <div className="p-6 max-w-2xl mx-auto">
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-12 text-center">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Payment Successful!
          </h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            Your features are now active and ready to use. A receipt has been sent to your email.
          </p>

          {/* Purchased Features List */}
          {purchasedItems.length > 0 && (
            <div className="mb-6 text-left bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">What you got:</h3>
              <div className="space-y-2">
                {purchasedItems.map((p, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <svg className="w-4 h-4 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-sm text-gray-900 dark:text-white font-medium">
                        {p.feature} ×{p.quantity}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {p.expiresAt ? `Until ${new Date(p.expiresAt).toLocaleDateString()}` : 'Lifetime'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/dashboard/purchases"
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              View Purchases
            </Link>
            <Link
              href="/dashboard/store"
              className="px-5 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-900 dark:text-white text-sm font-medium rounded-lg transition-colors"
            >
              Back to Store
            </Link>
          </div>

          {/* Quick links to activated features */}
          {purchasedItems.length > 0 && (
            <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
              <p className="text-xs text-gray-400 mb-2">Quick links to your new features:</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {purchasedItems.map((p, i) => {
                  const slug = p.slug || p.feature.toLowerCase().replace(/\s+/g, '-');
                  const href = featureLinks[slug] || '/dashboard';
                  return (
                    <Link
                      key={i}
                      href={href}
                      className="text-xs px-3 py-1 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors"
                    >
                      {p.feature} →
                    </Link>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="lazyOnload" />

      <div className="p-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Shopping Cart</h1>
            <p className="mt-1 text-gray-500 dark:text-gray-400">
              {items.length} item{items.length !== 1 ? 's' : ''} in your cart
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-0.5">
              <button
                onClick={() => setCurrency('USD')}
                disabled={checkingOut}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors disabled:opacity-50 ${
                  currency === 'USD'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                USD $
              </button>
              <button
                onClick={() => setCurrency('INR')}
                disabled={checkingOut}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors disabled:opacity-50 ${
                  currency === 'INR'
                    ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                    : 'text-gray-500 dark:text-gray-400'
                }`}
              >
                INR ₹
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 rounded-lg text-sm flex items-center justify-between">
            <span>{error}</span>
            <button
              onClick={() => { setError(''); handleCheckout(); }}
              className="ml-3 px-3 py-1 bg-red-100 dark:bg-red-900/50 hover:bg-red-200 dark:hover:bg-red-800 text-red-800 dark:text-red-200 text-xs font-medium rounded transition-colors"
            >
              Retry
            </button>
          </div>
        )}

        {items.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-12 text-center">
            <svg className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
            </svg>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              Your cart is empty
            </h3>
            <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">
              Browse the feature store to find powerful add-ons for your sites.
            </p>
            <Link
              href="/dashboard/store"
              className="inline-flex items-center px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              Browse Store
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item) => {
                const unitPrice = currency === 'INR' ? item.feature.priceInr : item.feature.priceUsd;
                const itemTotal = unitPrice * item.quantity;

                return (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-5"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <span className="text-2xl">{item.feature.icon}</span>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 dark:text-white">
                            {item.feature.name}
                          </h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {formatPrice(unitPrice, currency)} / {item.feature.unitLabel || 'unit'}
                            {!item.feature.durationDays && item.feature.type !== 'duration' && (
                              <span className="text-green-600 dark:text-green-400 ml-2">· Lifetime</span>
                            )}
                            {item.feature.durationDays && (
                              <span className="text-blue-600 dark:text-blue-400 ml-2">
                                · {item.feature.durationDays * item.quantity} days
                              </span>
                            )}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => removeItem(item.featureId)}
                        disabled={removing === item.featureId}
                        className="text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors p-1"
                        title="Remove"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                      {/* Quantity */}
                      <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.featureId, Math.max(item.feature.minQty, item.quantity - item.feature.stepQty))}
                          disabled={item.quantity <= item.feature.minQty || updating === item.featureId}
                          className="px-3 py-1.5 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 transition-colors"
                        >
                          −
                        </button>
                        <span className="px-3 py-1.5 text-sm font-medium text-gray-900 dark:text-white min-w-[3rem] text-center">
                          {item.quantity} {item.feature.unitLabel || ''}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.featureId, Math.min(item.feature.maxQty, item.quantity + item.feature.stepQty))}
                          disabled={item.quantity >= item.feature.maxQty || updating === item.featureId}
                          className="px-3 py-1.5 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 transition-colors"
                        >
                          +
                        </button>
                      </div>

                      {/* Subtotal */}
                      <span className="text-lg font-bold text-gray-900 dark:text-white">
                        {formatPrice(itemTotal, currency)}
                      </span>
                    </div>
                  </div>
                );
              })}

              <div className="flex justify-between items-center pt-2">
                <button
                  onClick={clearCart}
                  className="text-sm text-red-600 dark:text-red-400 hover:underline"
                >
                  Clear cart
                </button>
                <Link
                  href="/dashboard/store"
                  className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  ← Continue shopping
                </Link>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 sticky top-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                  Order Summary
                </h3>

                <div className="space-y-3 mb-4">
                  {items.map((item) => {
                    const unitPrice = currency === 'INR' ? item.feature.priceInr : item.feature.priceUsd;
                    return (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">
                          {item.feature.icon} {item.feature.name} × {item.quantity}
                        </span>
                        <span className="text-gray-900 dark:text-white font-medium">
                          {formatPrice(unitPrice * item.quantity, currency)}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mb-6">
                  <div className="flex justify-between">
                    <span className="text-base font-semibold text-gray-900 dark:text-white">Total</span>
                    <span className="text-xl font-bold text-gray-900 dark:text-white">
                      {formatPrice(total, currency)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleCheckout}
                  disabled={checkingOut || items.length === 0}
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 text-white font-semibold rounded-lg transition-all text-sm"
                >
                  {checkingOut ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    `Pay ${formatPrice(total, currency)}`
                  )}
                </button>

                {/* Trust Signals */}
                <div className="mt-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                    <svg className="w-3.5 h-3.5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    Secure payment via Razorpay
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                    <svg className="w-3.5 h-3.5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Instant activation after payment
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                    <svg className="w-3.5 h-3.5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    Receipt sent to your email
                  </div>
                  <p className="text-xs text-gray-400 dark:text-gray-500 text-center pt-1">
                    Paying in {currencyLabel} — prices locked at checkout
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
