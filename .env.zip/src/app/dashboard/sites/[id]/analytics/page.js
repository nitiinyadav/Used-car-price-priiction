import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import Link from 'next/link';
import SiteTabs from '@/components/SiteTabs';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { getUserFeatureQuota } from '@/lib/feature-access';

export const metadata = {
  title: 'Site Analytics - LiveInSec',
};

export default async function SiteAnalyticsPage({ params }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, 'view_analytics')) {
    notFound();
  }

  // Check feature-based access
  let hasAnalyticsAccess = session.user.role === 'superadmin';
  let systemError = false;
  if (!hasAnalyticsAccess) {
    try {
      const quota = await getUserFeatureQuota(session.user.id, 'analytics');
      hasAnalyticsAccess = quota.hasAccess;
    } catch (err) {
      console.error('Feature quota check failed:', err.message);
      systemError = true;
    }
  }

  const site = await prisma.site.findFirst({
    where: { id: params.id, userId: workspace?.workspaceOwnerId || session.user.id },
    select: { id: true, name: true },
  });

  if (!site) {
    notFound();
  }

  if (systemError) {
    return (
      <div className="p-6">
        <div className="rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/30 p-8 text-center">
          <p className="text-lg font-semibold text-amber-800 dark:text-amber-300 mb-2">Something went wrong</p>
          <p className="text-amber-600 dark:text-amber-400 text-sm">We couldn&apos;t verify your feature access. Please refresh the page or contact support.</p>
        </div>
      </div>
    );
  }

  // Users without analytics feature see upgrade prompt
  if (!hasAnalyticsAccess) {
    return (
      <div>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Site Analytics</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Traffic trends, referrers, and visitor insights for {site.name}.
          </p>
        </div>
        <SiteTabs siteId={site.id} />
        <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-12 text-center">
          <div className="mx-auto w-16 h-16 bg-indigo-100 dark:bg-indigo-900/40 rounded-full flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Analytics Requires a Purchase</h2>
          <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
            Buy the Analytics feature to unlock detailed analytics — see page views, unique visitors,
            top pages, referrers, and visitor countries.
          </p>
          <Link
            href="/dashboard/store"
            className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
            </svg>
            Buy Analytics
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Site Analytics</h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          Traffic trends, referrers, and visitor insights for {site.name}.
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <AnalyticsDashboard siteId={site.id} />
    </div>
  );
}
