'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import FileUpload from '@/components/FileUpload';
import { parseAllowedOrigins } from '@/lib/site-security';

export default function SiteDetailClient({ site }) {
  const router = useRouter();
  const [siteName, setSiteName] = useState(site.name);
  const [customDomain, setCustomDomain] = useState(site.customDomain || '');
  const [allowedOrigins, setAllowedOrigins] = useState(
    parseAllowedOrigins(site.allowedOrigins).join('\n')
  );
  const [honeypotField, setHoneypotField] = useState(site.honeypotField || 'company');
  const [submissionRateLimit, setSubmissionRateLimit] = useState(
    site.submissionRateLimit || 10
  );
  const [isActive, setIsActive] = useState(site.isActive);
  const [savingSettings, setSavingSettings] = useState(false);
  const [redeployFile, setRedeployFile] = useState(null);
  const [redeploying, setRedeploying] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function handleSaveSettings() {
    setError('');
    setMessage('');
    setSavingSettings(true);

    try {
      const res = await fetch(`/api/sites/${site.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: siteName,
          customDomain,
          allowedOrigins,
          honeypotField,
          submissionRateLimit,
          isActive,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to save site settings');
        return;
      }

      setMessage('Site settings updated successfully.');
      setCustomDomain(data.site.customDomain || '');
      setAllowedOrigins(parseAllowedOrigins(data.site.allowedOrigins).join('\n'));
      setHoneypotField(data.site.honeypotField || 'company');
      setSubmissionRateLimit(data.site.submissionRateLimit || 10);
      setIsActive(data.site.isActive);
      setSiteName(data.site.name);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setSavingSettings(false);
    }
  }

  async function handleRedeploy() {
    if (!redeployFile) return;
    setError('');
    setMessage('');
    setRedeploying(true);

    try {
      const formData = new FormData();
      formData.append('file', redeployFile);

      const res = await fetch(`/api/sites/${site.id}/redeploy`, {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Redeploy failed');
        return;
      }

      setMessage('Site redeployed successfully!');
      setRedeployFile(null);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setRedeploying(false);
    }
  }

  async function handleDelete() {
    setError('');
    setDeleting(true);

    try {
      const res = await fetch(`/api/sites/${site.id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Delete failed');
        return;
      }

      router.push('/dashboard/sites');
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-6 max-w-3xl">
      {message && (
        <div className="bg-emerald-50 dark:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          {message}
        </div>
      )}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          {error}
        </div>
      )}

      {/* General */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">General</h3>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Site Name</label>
              <input type="text" value={siteName} onChange={(e) => setSiteName(e.target.value)} className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Custom Domain</label>
              <input type="text" value={customDomain} onChange={(e) => setCustomDomain(e.target.value)} placeholder="www.example.com" className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              <p className="mt-1 text-xs text-gray-400">CNAME your domain to LiveInSec to use a custom hostname.</p>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-xl border border-gray-200 dark:border-gray-700 px-4 py-3">
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Site status</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Inactive sites return a not-found page but keep their files.</p>
            </div>
            <button type="button" onClick={() => setIsActive(!isActive)} className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isActive ? 'bg-indigo-600' : 'bg-gray-300'}`}>
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isActive ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Form Protection */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Form Protection</h3>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Configure spam prevention for form submissions.</p>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Honeypot Field</label>
              <input type="text" value={honeypotField} onChange={(e) => setHoneypotField(e.target.value)} className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              <p className="mt-1 text-xs text-gray-400">Hidden field name that blocks bots when filled.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Rate Limit Per IP</label>
              <input type="number" min={1} max={100} value={submissionRateLimit} onChange={(e) => setSubmissionRateLimit(e.target.value)} className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              <p className="mt-1 text-xs text-gray-400">Max submissions from one IP per 10 minutes.</p>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Allowed Extra Origins</label>
            <textarea rows={3} value={allowedOrigins} onChange={(e) => setAllowedOrigins(e.target.value)} placeholder="www.example.com&#10;landing.example.com" className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-xl text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
            <p className="mt-1 text-xs text-gray-400">One hostname per line. Only these origins can submit forms.</p>
          </div>
        </div>
      </div>

      {/* Save button */}
      <div className="flex justify-end">
        <button type="button" onClick={handleSaveSettings} disabled={savingSettings} className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center gap-2">
          {savingSettings ? (
            <><svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>Saving...</>
          ) : (
            <><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>Save Settings</>
          )}
        </button>
      </div>

      {/* Update / Redeploy */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/50">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Update Website</h3>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Upload a new ZIP to replace the current deployment.</p>
        </div>
        <div className="p-6">
          <FileUpload onFileSelect={setRedeployFile} />
          {redeployFile && (
            <button type="button" onClick={handleRedeploy} disabled={redeploying} className="mt-4 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50">
              {redeploying ? 'Redeploying...' : 'Redeploy Site'}
            </button>
          )}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-red-200 dark:border-red-800/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-red-100 dark:border-red-800/50 bg-red-50/50 dark:bg-red-900/20">
          <h3 className="text-sm font-semibold text-red-700 dark:text-red-400">Danger Zone</h3>
          <p className="text-xs text-red-500 dark:text-red-400/70 mt-0.5">Irreversible actions that permanently affect this site.</p>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">Delete this site</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">Removes the site, all files, and form submissions permanently.</p>
            </div>
            {!showDelete ? (
              <button type="button" onClick={() => setShowDelete(true)} className="text-red-600 border border-red-200 px-4 py-2 rounded-xl text-sm font-medium hover:bg-red-50 transition-colors">
                Delete Site
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button type="button" onClick={handleDelete} disabled={deleting} className="bg-red-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-red-700 disabled:opacity-50 transition-colors">
                  {deleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
                <button type="button" onClick={() => setShowDelete(false)} className="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm">
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
