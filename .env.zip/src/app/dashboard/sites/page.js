import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import Link from "next/link";
import SiteCard from "@/components/SiteCard";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

export const metadata = {
  title: "My Sites - LiveInSec",
};

export default async function SitesPage() {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  const sites = await prisma.site.findMany({
    where: { userId: workspaceOwnerId },
    include: { _count: { select: { formsubmission: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Sites</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">Manage your deployed websites</p>
        </div>
        <Link
          href={
            hasPermission(workspace, "create_sites")
              ? "/dashboard/sites/new"
              : "/dashboard/sites"
          }
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
            hasPermission(workspace, "create_sites")
              ? "bg-indigo-600 text-white hover:bg-indigo-700"
              : "bg-gray-200 dark:bg-gray-800 text-gray-500 dark:text-gray-400 cursor-not-allowed"
          }`}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4v16m8-8H4"
            />
          </svg>
          <span>Deploy New</span>
        </Link>
      </div>

      {sites.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sites.map((site) => (
            <SiteCard key={site.id} site={site} />
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="p-8 sm:p-12 text-center">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-indigo-100 to-violet-100 dark:from-indigo-900/40 dark:to-violet-900/40 rounded-2xl flex items-center justify-center mb-5">
              <svg className="w-8 h-8 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">No sites yet</h3>
            <p className="mt-2 text-gray-500 dark:text-gray-400 max-w-sm mx-auto">
              Deploy your first website in under 60 seconds. Upload a ZIP or build from a template.
            </p>
          </div>

          {/* Quick start options */}
          <div className="border-t border-gray-100 dark:border-gray-800 grid sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-gray-100 dark:divide-gray-800">
            <Link
              href={hasPermission(workspace, "create_sites") ? "/dashboard/sites/new" : "/dashboard/sites"}
              className="p-6 flex items-center gap-4 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 transition-colors group"
            >
              <div className="flex-shrink-0 w-10 h-10 bg-indigo-100 dark:bg-indigo-900/40 rounded-lg flex items-center justify-center group-hover:bg-indigo-200 dark:group-hover:bg-indigo-900/60 transition-colors">
                <svg className="w-5 h-5 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
              </div>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white text-sm">Upload ZIP File</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Drag & drop your site files</p>
              </div>
            </Link>
            <Link
              href={hasPermission(workspace, "create_sites") ? "/dashboard/sites/new" : "/dashboard/sites"}
              className="p-6 flex items-center gap-4 hover:bg-violet-50 dark:hover:bg-violet-950/30 transition-colors group"
            >
              <div className="flex-shrink-0 w-10 h-10 bg-violet-100 dark:bg-violet-900/40 rounded-lg flex items-center justify-center group-hover:bg-violet-200 dark:group-hover:bg-violet-900/60 transition-colors">
                <svg className="w-5 h-5 text-violet-600 dark:text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
              </div>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white text-sm">Use Code Editor</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Build from templates in-browser</p>
              </div>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
