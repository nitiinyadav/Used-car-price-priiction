export const dynamic = "force-dynamic";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import Link from "next/link";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  const [sites, totalSubmissions] = await Promise.all([
    prisma.site.findMany({
      where: { userId: workspaceOwnerId },
      include: { _count: { select: { formsubmission: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.formSubmission.count({
      where: { site: { userId: workspaceOwnerId } },
    }),
  ]);

  const recentSubmissions = await prisma.formSubmission.findMany({
    where: { site: { userId: workspaceOwnerId } },
    include: { site: { select: { name: true, subdomain: true } } },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  const activeSites = sites.filter((s) => s.isActive).length;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back, {session.user.name}!
        </h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          Here&apos;s an overview of your deployed sites
        </p>
      </div>

      {/* Stats - 3 clean cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/40 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-indigo-600 dark:text-indigo-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {activeSites}
                <span className="text-sm font-normal text-gray-400 dark:text-gray-500">
                  /{sites.length}
                </span>
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Active Sites</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/40 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-purple-600 dark:text-purple-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                {totalSubmissions}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Form Submissions</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 dark:bg-green-900/40 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-green-600 dark:text-green-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white capitalize">
                {session.user.role === "superadmin" ? "Admin" : "Active"}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Account Status</p>
            </div>
          </div>
        </div>
      </div>

      {/* Onboarding Checklist — shown for new users */}
      {sites.length <= 1 && (
        <OnboardingChecklist
          hasSite={sites.length > 0}
          hasSubmission={totalSubmissions > 0}
          emailVerified={!!session.user.emailVerifiedAt}
        />
      )}

      {/* Quick Actions */}
      <div className="flex flex-wrap items-center gap-3 mb-8">
        {hasPermission(workspace, "create_sites") && (
          <Link
            href="/dashboard/sites/new"
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors flex items-center space-x-2"
          >
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4v16m8-8H4"
              />
            </svg>
            <span>Deploy New Site</span>
          </Link>
        )}
        <Link
          href="/dashboard/sites"
          className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 transition-colors"
        >
          View All Sites
        </Link>
        <Link
          href="/dashboard/submissions"
          className="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 dark:border-gray-700 hover:border-gray-400 dark:hover:border-gray-600 transition-colors"
        >
          Open Inbox
        </Link>
      </div>

      {/* Recent Submissions */}
      {recentSubmissions.length > 0 && (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-800">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recent Form Submissions
            </h2>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-800">
            {recentSubmissions.map((sub) => {
              const data = JSON.parse(sub.data);
              const preview = Object.entries(data)
                .slice(0, 3)
                .map(([k, v]) => `${k}: ${v}`)
                .join(", ");

              return (
                <div key={sub.id} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        {sub.site.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5 truncate max-w-md">
                        {preview}
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">
                      {new Date(sub.createdAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty state — 0 sites: Deploy in 30 seconds wizard */}
      {sites.length === 0 && (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
          <div className="bg-gradient-to-br from-indigo-50 to-violet-50 dark:from-indigo-950/40 dark:to-violet-950/40 p-8 sm:p-12 text-center">
            <div className="mx-auto w-16 h-16 bg-indigo-100 dark:bg-indigo-900/50 rounded-2xl flex items-center justify-center mb-6">
              <svg className="w-8 h-8 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Deploy in 30 Seconds</h3>
            <p className="mt-3 text-gray-600 dark:text-gray-400 max-w-md mx-auto">
              Get your website live in three easy steps. No server setup, no CLI — just drag, drop, and deploy.
            </p>
          </div>

          <div className="grid sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-gray-100 dark:divide-gray-800">
            <div className="p-6 text-center">
              <div className="mx-auto w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-sm mb-3">01</div>
              <h4 className="font-semibold text-gray-900 dark:text-white text-sm">Pick a Name</h4>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Choose your subdomain: yoursite.liveinsec.com</p>
            </div>
            <div className="p-6 text-center">
              <div className="mx-auto w-10 h-10 bg-violet-600 rounded-xl flex items-center justify-center text-white font-bold text-sm mb-3">02</div>
              <h4 className="font-semibold text-gray-900 dark:text-white text-sm">Upload or Code</h4>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Drag a ZIP file or use our editor with templates</p>
            </div>
            <div className="p-6 text-center">
              <div className="mx-auto w-10 h-10 bg-fuchsia-600 rounded-xl flex items-center justify-center text-white font-bold text-sm mb-3">03</div>
              <h4 className="font-semibold text-gray-900 dark:text-white text-sm">Go Live</h4>
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">Your site is live instantly with free SSL</p>
            </div>
          </div>

          <div className="p-6 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-100 dark:border-gray-800 text-center">
            <Link
              href="/dashboard/sites/new"
              className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
              Deploy Your First Site
            </Link>
            <p className="mt-3 text-xs text-gray-400 dark:text-gray-500">Free forever for small projects. No credit card needed.</p>
          </div>
        </div>
      )}

      {/* Empty submissions state — show embed snippet */}
      {sites.length > 0 && totalSubmissions === 0 && (
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6 mt-6">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-10 h-10 bg-violet-100 dark:bg-violet-900/40 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-violet-600 dark:text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Start collecting form submissions</h3>
              <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Add this form to any page on your site. Submissions appear here automatically.</p>
              <pre className="mt-3 bg-gray-900 text-green-400 rounded-lg p-4 text-xs overflow-x-auto leading-relaxed">
{`<form action="${process.env.NEXT_PUBLIC_APP_URL || 'https://liveinsec.com'}/api/forms/${sites[0]?.apiKey || 'YOUR_API_KEY'}" method="POST">
  <input name="name" placeholder="Your Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>
  <button type="submit">Send</button>
</form>`}
              </pre>
              <p className="mt-2 text-xs text-gray-400">Find each site&apos;s unique API key on the site detail page.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function OnboardingChecklist({ hasSite, hasSubmission, emailVerified }) {
  const steps = [
    {
      done: emailVerified,
      label: "Verify your email address",
      href: null,
    },
    {
      done: hasSite,
      label: "Deploy your first website",
      href: "/dashboard/sites/new",
    },
    {
      done: hasSubmission,
      label: "Receive your first form submission",
      href: null,
    },
  ];

  const completed = steps.filter((s) => s.done).length;
  const allDone = completed === steps.length;

  if (allDone) return null;

  return (
    <div className="mb-8 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/30 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Getting Started
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Complete these steps to get the most out of LiveInSec
          </p>
        </div>
        <span className="text-sm font-medium text-indigo-600">
          {completed}/{steps.length} done
        </span>
      </div>
      <div className="space-y-3">
        {steps.map((step, idx) => (
          <div key={idx} className="flex items-center gap-3">
            <div
              className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${
                step.done
                  ? "bg-green-500 text-white"
                  : "border-2 border-gray-300 dark:border-gray-600 text-gray-300 dark:text-gray-600"
              }`}
            >
              {step.done ? (
                <svg
                  className="h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2.5}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              ) : (
                <span className="text-xs font-bold">{idx + 1}</span>
              )}
            </div>
            {step.href && !step.done ? (
              <a
                href={step.href}
                className="text-sm font-medium text-indigo-600 hover:text-indigo-800"
              >
                {step.label}
              </a>
            ) : (
              <span
                className={`text-sm ${step.done ? "text-gray-400 dark:text-gray-500 line-through" : "text-gray-700 dark:text-gray-300"}`}
              >
                {step.label}
              </span>
            )}
          </div>
        ))}
      </div>
      <div className="mt-4 h-2 rounded-full bg-gray-200 dark:bg-gray-700">
        <div
          className="h-2 rounded-full bg-indigo-500 transition-all"
          style={{ width: `${(completed / steps.length) * 100}%` }}
        />
      </div>
    </div>
  );
}
