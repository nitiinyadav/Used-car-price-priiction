'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession } from 'next-auth/react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';

function formatPrice(cents, currency) {
  if (currency === 'INR') {
    return `₹${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
  }
  return `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}

export default function StorePage() {
  const { data: session } = useSession();
  const searchParams = useSearchParams();
  const [features, setFeatures] = useState([]);
  const [cartItems, setCartItems] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(null);
  const [currency, setCurrency] = useState('USD');
  const [overview, setOverview] = useState(null);
  const [activeCategory, setActiveCategory] = useState('all');
  const [highlightedSlug, setHighlightedSlug] = useState(null);
  const featureRefs = useRef({});

  useEffect(() => {
    loadData();
  }, []);

  // Deep-link: scroll to and highlight feature from ?feature=slug
  useEffect(() => {
    const featureSlug = searchParams.get('feature');
    if (featureSlug && !loading && features.length > 0) {
      setHighlightedSlug(featureSlug);
      const el = featureRefs.current[featureSlug];
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // Clear highlight after 3 seconds
        setTimeout(() => setHighlightedSlug(null), 3000);
      }
    }
  }, [loading, features, searchParams]);

  async function loadData() {
    try {
      const [featRes, cartRes, overviewRes] = await Promise.all([
        fetch('/api/features'),
        fetch('/api/cart'),
        fetch('/api/feature-overview'),
      ]);
      const featData = await featRes.json();
      const cartData = await cartRes.json();
      const overviewData = overviewRes.ok ? await overviewRes.json() : null;

      // Filter out features with public access (they are free and shouldn't show in store)
      const storeFeatures = (featData.features || []).filter(
        (f) => !f.publicAccessType || f.publicAccessType === 'none'
      );

      setFeatures(storeFeatures);
      setCartItems(cartData.items || []);
      if (overviewData) setOverview(overviewData.overview);

      // Initialize quantities to minQty
      const initQty = {};
      storeFeatures.forEach((f) => {
        initQty[f.id] = f.minQty;
      });
      setQuantities(initQty);
    } catch (err) {
      console.error('Load store data error:', err);
    } finally {
      setLoading(false);
    }
  }

  function isInCart(featureId) {
    return cartItems.some((ci) => ci.featureId === featureId);
  }

  function updateQuantity(featureId, feature, delta) {
    setQuantities((prev) => {
      const current = prev[featureId] || feature.minQty;
      const next = Math.max(feature.minQty, Math.min(feature.maxQty, current + delta * feature.stepQty));
      return { ...prev, [featureId]: next };
    });
  }

  async function addToCart(featureId) {
    setAdding(featureId);
    try {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ featureId, quantity: quantities[featureId] || 1 }),
      });
      if (res.ok) {
        const cartRes = await fetch('/api/cart');
        const cartData = await cartRes.json();
        setCartItems(cartData.items || []);
      }
    } catch (err) {
      console.error('Add to cart error:', err);
    } finally {
      setAdding(null);
    }
  }

  const cartCount = cartItems.length;

  // Derive unique categories from features
  const categories = ['all', ...new Set(features.map((f) => f.category || 'general'))];

  // Filter features by active category
  const filteredFeatures = activeCategory === 'all'
    ? features
    : features.filter((f) => (f.category || 'general') === activeCategory);

  // Recommended features: those running low or featured
  const recommendedFeatures = features.filter((f) => {
    const ov = overview?.[f.slug];
    if (!ov) return f.isFeatured;
    return f.isFeatured || (ov.total > 0 && ov.remaining <= Math.ceil(ov.total * 0.2));
  });

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 w-48 bg-gray-200 dark:bg-gray-700 rounded" />
          <div className="grid sm:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-64 bg-gray-200 dark:bg-gray-700 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Feature Store</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Power up your sites with premium features — pay only for what you need
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Currency Toggle */}
          <div className="flex bg-gray-100 dark:bg-gray-800 rounded-lg p-0.5">
            <button
              onClick={() => setCurrency('USD')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                currency === 'USD'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-gray-400'
              }`}
            >
              USD $
            </button>
            <button
              onClick={() => setCurrency('INR')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                currency === 'INR'
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
                  : 'text-gray-500 dark:text-gray-400'
              }`}
            >
              INR ₹
            </button>
          </div>

          {/* Cart button */}
          <Link
            href="/dashboard/cart"
            className="relative inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
            </svg>
            Cart
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </Link>
        </div>
      </div>

      {features.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-12 text-center">
          <p className="text-4xl mb-4">🏪</p>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Store coming soon
          </h3>
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            Premium features will appear here once the admin configures them.
          </p>
        </div>
      ) : (
        <>
          {/* Category Filter Tabs */}
          <div className="mb-6 flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-1.5 text-sm font-medium rounded-full transition-colors capitalize ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {cat === 'all' ? 'All Features' : cat}
              </button>
            ))}
          </div>

          {/* Recommended For You — only when showing all */}
          {activeCategory === 'all' && recommendedFeatures.length > 0 && (
            <div className="mb-8">
              <h2 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
                Recommended for you
              </h2>
              <div className="flex gap-3 overflow-x-auto pb-2">
                {recommendedFeatures.slice(0, 4).map((f) => {
                  const ov = overview?.[f.slug];
                  return (
                    <button
                      key={f.id}
                      onClick={() => {
                        const el = featureRefs.current[f.slug];
                        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        setHighlightedSlug(f.slug);
                        setTimeout(() => setHighlightedSlug(null), 3000);
                      }}
                      className="flex-shrink-0 flex items-center gap-2 px-4 py-2 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/30 transition-colors"
                    >
                      <span className="text-xl">{f.icon}</span>
                      <div className="text-left">
                        <p className="text-sm font-medium text-indigo-900 dark:text-indigo-200">{f.name}</p>
                        {ov && ov.total > 0 && ov.remaining <= Math.ceil(ov.total * 0.2) && (
                          <p className="text-xs text-red-600 dark:text-red-400">Running low — {ov.remaining} left</p>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-6">
            {filteredFeatures.map((feature) => {
            const highlights = (() => {
              try { return JSON.parse(feature.highlights || '[]'); } catch { return []; }
            })();
            const price = currency === 'INR' ? feature.priceInr : feature.priceUsd;
            const qty = quantities[feature.id] || feature.minQty;
            const total = price * qty;
            const inCart = isInCart(feature.id);
            const featureOverview = overview?.[feature.slug];

            return (
              <div
                key={feature.id}
                ref={(el) => { featureRefs.current[feature.slug] = el; }}
                id={`feature-${feature.slug}`}
                className={`bg-white dark:bg-gray-800 rounded-xl border overflow-hidden transition-all hover:shadow-lg ${
                  highlightedSlug === feature.slug
                    ? 'border-indigo-500 ring-2 ring-indigo-300 dark:ring-indigo-500/40 animate-pulse'
                    : feature.isFeatured
                    ? 'border-indigo-300 dark:border-indigo-500 ring-1 ring-indigo-100 dark:ring-indigo-500/20'
                    : 'border-gray-200 dark:border-gray-700'
                }`}
              >
                {/* Header */}
                <div className="p-6 pb-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{feature.icon}</span>
                      <div>
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                          {feature.name}
                        </h3>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                          {feature.type === 'quantity' ? 'Per unit' : feature.type === 'duration' ? 'Time-based' : 'Add-on'}
                          {!feature.durationDays && feature.type !== 'duration' && ' · Lifetime'}
                          {feature.durationDays && ` · ${feature.durationDays}d/unit`}
                        </span>
                      </div>
                    </div>
                    {feature.isFeatured && (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                        ⭐ Popular
                      </span>
                    )}
                  </div>

                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    {feature.description}
                  </p>

                  {/* Current Usage */}
                  {featureOverview && (
                    <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500 dark:text-gray-400">Your usage</span>
                        <span className="font-medium text-gray-900 dark:text-white">
                          {featureOverview.used} / {featureOverview.total} {feature.unitLabel || 'units'}
                        </span>
                      </div>
                      {featureOverview.total > 0 && (
                        <div className="mt-1.5 w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1.5">
                          <div
                            className={`h-1.5 rounded-full transition-all ${
                              featureOverview.remaining <= 0 ? 'bg-red-500' :
                              featureOverview.used / featureOverview.total > 0.8 ? 'bg-amber-500' :
                              'bg-indigo-500'
                            }`}
                            style={{ width: `${Math.min(100, (featureOverview.used / featureOverview.total) * 100)}%` }}
                          />
                        </div>
                      )}
                      {feature.freeQuota > 0 && (
                        <p className="text-xs text-gray-400 mt-1">
                          Includes {feature.freeQuota} free {feature.unitLabel || 'units'}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Highlights */}
                  {highlights.length > 0 && (
                    <ul className="space-y-1.5 mb-4">
                      {highlights.map((h, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                          <svg className="w-4 h-4 text-green-500 mt-0.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          {h}
                        </li>
                      ))}
                    </ul>
                  )}

                  {/* Price */}
                  <div className="flex items-baseline gap-1 mb-4">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                      {formatPrice(price, currency)}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      / {feature.unitLabel || 'unit'}
                    </span>
                  </div>
                </div>

                {/* Footer — Quantity + Cart */}
                <div className="px-6 pb-6 space-y-3">
                  {/* Quantity Selector — BUG-09: proper min/max/step */}
                  <div className="flex items-center gap-3">
                    <label className="text-sm text-gray-600 dark:text-gray-400">Qty:</label>
                    <div className="flex items-center bg-gray-100 dark:bg-gray-700 rounded-lg">
                      <button
                        onClick={() => updateQuantity(feature.id, feature, -1)}
                        disabled={qty <= feature.minQty}
                        className="px-3 py-1.5 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 transition-colors"
                      >
                        −
                      </button>
                      <input
                        type="number"
                        value={qty}
                        min={feature.minQty}
                        max={feature.maxQty}
                        step={feature.stepQty}
                        onChange={(e) => {
                          const v = parseInt(e.target.value);
                          if (!isNaN(v)) {
                            const clamped = Math.max(feature.minQty, Math.min(feature.maxQty, v));
                            setQuantities((prev) => ({ ...prev, [feature.id]: clamped }));
                          }
                        }}
                        className="w-16 text-center bg-transparent text-sm font-medium text-gray-900 dark:text-white py-1.5 focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <button
                        onClick={() => updateQuantity(feature.id, feature, 1)}
                        disabled={qty >= feature.maxQty}
                        className="px-3 py-1.5 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 transition-colors"
                      >
                        +
                      </button>
                    </div>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      = {formatPrice(total, currency)}
                    </span>
                  </div>

                  {/* Add to Cart */}
                  {inCart ? (
                    <Link
                      href="/dashboard/cart"
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      In Cart — View Cart
                    </Link>
                  ) : (
                    <button
                      onClick={() => addToCart(feature.id)}
                      disabled={adding === feature.id}
                      className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                        feature.isFeatured
                          ? 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                      } disabled:opacity-50`}
                    >
                      {adding === feature.id ? (
                        'Adding...'
                      ) : (
                        <>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
                          </svg>
                          Add to Cart
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
          </div>
        </>
      )}

      {/* Purchases CTA */}
      <div className="mt-8 text-center">
        <Link
          href="/dashboard/purchases"
          className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
        >
          View your active purchases →
        </Link>
      </div>
    </div>
  );
}
