import Link from 'next/link';
import Navbar from '@/components/Navbar';

export const metadata = {
  title: 'Documentation - LiveInSec',
  description: 'Learn how to deploy static websites, collect form submissions, set up custom domains, and use the LiveInSec platform.',
};

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      <Navbar />

      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-black text-gray-900 dark:text-white">Documentation</h1>
          <p className="mt-3 text-lg text-gray-500 dark:text-gray-400">
            Everything you need to deploy sites, collect leads, and grow your web presence.
          </p>
        </div>

        {/* Quick links */}
        <div className="grid sm:grid-cols-3 gap-4 mb-16">
          <a href="#deployment" className="group rounded-xl border border-gray-200 dark:border-gray-800 p-5 hover:border-indigo-300 dark:hover:border-indigo-700 hover:shadow-md transition-all">
            <div className="text-2xl mb-2">🚀</div>
            <h3 className="font-bold text-gray-900 dark:text-white text-sm group-hover:text-indigo-600">Deployment Guide</h3>
            <p className="text-xs text-gray-500 mt-1">Get your site live in 60 seconds</p>
          </a>
          <a href="#form-api" className="group rounded-xl border border-gray-200 dark:border-gray-800 p-5 hover:border-violet-300 dark:hover:border-violet-700 hover:shadow-md transition-all">
            <div className="text-2xl mb-2">📬</div>
            <h3 className="font-bold text-gray-900 dark:text-white text-sm group-hover:text-violet-600">Form API</h3>
            <p className="text-xs text-gray-500 mt-1">Collect leads with zero backend</p>
          </a>
          <a href="#custom-domain" className="group rounded-xl border border-gray-200 dark:border-gray-800 p-5 hover:border-emerald-300 dark:hover:border-emerald-700 hover:shadow-md transition-all">
            <div className="text-2xl mb-2">🌐</div>
            <h3 className="font-bold text-gray-900 dark:text-white text-sm group-hover:text-emerald-600">Custom Domains</h3>
            <p className="text-xs text-gray-500 mt-1">Connect your own domain</p>
          </a>
        </div>

        {/* ─── Deployment Guide ─────────────────────── */}
        <section id="deployment" className="mb-16 scroll-mt-24">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
            <span className="text-2xl">🚀</span> Deployment Guide
          </h2>

          <div className="space-y-8">
            <DocStep number="1" title="Create an Account">
              <p>Sign up at <Link href="/register" className="text-indigo-600 hover:underline font-medium">/register</Link> — it&apos;s free and takes 10 seconds. No credit card required.</p>
            </DocStep>

            <DocStep number="2" title="Start a New Deployment">
              <p>Go to <strong>Dashboard → Sites → Deploy New</strong>. Enter a name and choose your subdomain (e.g., <code className="bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded text-sm">mysite</code> → <code className="bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded text-sm">mysite.liveinsec.com</code>).</p>
            </DocStep>

            <DocStep number="3" title="Upload Files or Use the Editor">
              <p>You have two options:</p>
              <ul className="mt-2 space-y-1 text-sm text-gray-600 dark:text-gray-400 list-disc list-inside">
                <li><strong>ZIP Upload</strong> — Drag and drop a ZIP file containing your HTML, CSS, JS, and assets. Must include an <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded text-xs">index.html</code>.</li>
                <li><strong>Code Editor</strong> — Build from scratch or start from a template using our built-in Monaco editor with syntax highlighting.</li>
              </ul>
            </DocStep>

            <DocStep number="4" title="Review and Deploy">
              <p>Preview your site before deploying. Check the file list, warnings, and live preview. Click <strong>Deploy</strong> and your site goes live instantly on your chosen subdomain.</p>
            </DocStep>

            <div className="bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 rounded-xl p-5">
              <p className="text-sm font-medium text-indigo-800 dark:text-indigo-300">💡 Pro Tip</p>
              <p className="text-sm text-indigo-700 dark:text-indigo-400 mt-1">
                Make sure your ZIP has <code className="bg-indigo-100 dark:bg-indigo-900 px-1 py-0.5 rounded text-xs">index.html</code> at the root (not inside a subfolder). If your files are inside a single folder, we auto-detect that.
              </p>
            </div>
          </div>
        </section>

        {/* ─── Form API ────────────────────────────── */}
        <section id="form-api" className="mb-16 scroll-mt-24">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
            <span className="text-2xl">📬</span> Form Collection API
          </h2>

          <div className="space-y-6">
            <p className="text-gray-600 dark:text-gray-400">
              Every deployed site gets a unique API endpoint for form submissions. Point any HTML form to it and we capture every submission — with spam protection, rate limiting, and optional email alerts.
            </p>

            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">HTML Form Example</h3>
            <CodeBlock language="html">{`<form action="https://liveinsec.com/api/forms/YOUR_API_KEY" method="POST">
  <input name="name" placeholder="Your Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>

  <!-- Honeypot field (hidden, prevents spam bots) -->
  <input type="text" name="company" style="display:none"
         tabindex="-1" autocomplete="off" />

  <!-- Optional: redirect after submit -->
  <input type="hidden" name="_redirect"
         value="https://yoursite.com/thank-you" />

  <button type="submit">Send Message</button>
</form>`}</CodeBlock>

            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-8">JavaScript (AJAX) Example</h3>
            <CodeBlock language="javascript">{`const response = await fetch(
  "https://liveinsec.com/api/forms/YOUR_API_KEY",
  {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "John Doe",
      email: "john@example.com",
      message: "Hello from my website!"
    })
  }
);

const data = await response.json();
console.log(data);
// { success: true, message: "Submission received" }`}</CodeBlock>

            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-8">Special Fields</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden">
                <thead className="bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-300">Field</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-700 dark:text-gray-300">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                  <tr><td className="px-4 py-3 font-mono text-xs text-indigo-600 dark:text-indigo-400">_redirect</td><td className="px-4 py-3 text-gray-600 dark:text-gray-400">URL to redirect to after successful submission</td></tr>
                  <tr><td className="px-4 py-3 font-mono text-xs text-indigo-600 dark:text-indigo-400">_formName</td><td className="px-4 py-3 text-gray-600 dark:text-gray-400">Custom form name (default: &quot;default&quot;). Useful when you have multiple forms on one site</td></tr>
                  <tr><td className="px-4 py-3 font-mono text-xs text-indigo-600 dark:text-indigo-400">[honeypot]</td><td className="px-4 py-3 text-gray-600 dark:text-gray-400">Hidden field (default name: &quot;company&quot;). If filled, submission is silently rejected as spam</td></tr>
                </tbody>
              </table>
            </div>

            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-8">Response Format</h3>
            <CodeBlock language="json">{`// Success (200)
{ "success": true, "message": "Submission received" }

// Rate limited (429)
{ "error": "Rate limit exceeded. Try again later." }

// Invalid API key (404)
{ "error": "Site not found or inactive" }`}</CodeBlock>

            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-8">Built-in Protections</h3>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li className="flex items-start gap-2"><span className="text-green-500 mt-0.5">✓</span> <strong>Rate Limiting</strong> — Configurable per-IP rate limit (default: 10 requests per 10 minutes)</li>
              <li className="flex items-start gap-2"><span className="text-green-500 mt-0.5">✓</span> <strong>Honeypot Field</strong> — Hidden spam trap field (bots fill it, humans don&apos;t)</li>
              <li className="flex items-start gap-2"><span className="text-green-500 mt-0.5">✓</span> <strong>Origin Validation</strong> — Optional: restrict which domains can submit to your form</li>
              <li className="flex items-start gap-2"><span className="text-green-500 mt-0.5">✓</span> <strong>Payload Limits</strong> — Maximum 100KB per submission, 50 fields max</li>
            </ul>

            <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-5">
              <p className="text-sm font-medium text-amber-800 dark:text-amber-300">⚠️ Finding Your API Key</p>
              <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                Each site has a unique API key shown on the site detail page. Go to <strong>Dashboard → Sites → [Your Site]</strong> to find it.
              </p>
            </div>
          </div>
        </section>

        {/* ─── Custom Domain ─────────────────────────── */}
        <section id="custom-domain" className="mb-16 scroll-mt-24">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
            <span className="text-2xl">🌐</span> Custom Domain Setup
          </h2>

          <div className="space-y-6">
            <p className="text-gray-600 dark:text-gray-400">
              Connect your own domain to any deployed site. Custom domains include automatic SSL.
            </p>

            <div className="bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-800 rounded-xl p-5 mb-6">
              <p className="text-sm font-medium text-violet-800 dark:text-violet-300">💎 Premium Feature</p>
              <p className="text-sm text-violet-700 dark:text-violet-400 mt-1">
                Custom domains require the <strong>Custom Domain</strong> feature from the <Link href="/register" className="underline hover:text-violet-900">Feature Store</Link>.
              </p>
            </div>

            <DocStep number="1" title="Buy a Domain">
              <p>Purchase a domain from any registrar: Cloudflare, Namecheap, GoDaddy, Google Domains, etc.</p>
            </DocStep>

            <DocStep number="2" title="Configure DNS">
              <p>In your registrar&apos;s DNS settings, create a <strong>CNAME record</strong> pointing your domain to LiveInSec:</p>
              <div className="mt-3 overflow-x-auto">
                <table className="w-full text-sm border border-gray-200 dark:border-gray-800 rounded-lg overflow-hidden">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="px-4 py-2 text-left font-semibold text-gray-700 dark:text-gray-300">Type</th>
                      <th className="px-4 py-2 text-left font-semibold text-gray-700 dark:text-gray-300">Name</th>
                      <th className="px-4 py-2 text-left font-semibold text-gray-700 dark:text-gray-300">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td className="px-4 py-2 text-gray-600 dark:text-gray-400">CNAME</td><td className="px-4 py-2 font-mono text-xs text-gray-800 dark:text-gray-200">www</td><td className="px-4 py-2 font-mono text-xs text-indigo-600 dark:text-indigo-400">cname.liveinsec.com</td></tr>
                    <tr className="border-t border-gray-100 dark:border-gray-800"><td className="px-4 py-2 text-gray-600 dark:text-gray-400">A</td><td className="px-4 py-2 font-mono text-xs text-gray-800 dark:text-gray-200">@ (root)</td><td className="px-4 py-2 text-xs text-gray-500">Use your server IP for apex domains</td></tr>
                  </tbody>
                </table>
              </div>
            </DocStep>

            <DocStep number="3" title="Add Domain in Dashboard">
              <p>Go to <strong>Dashboard → Sites → [Your Site] → Settings</strong> and enter your custom domain (e.g., <code className="bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded text-sm">www.example.com</code>).</p>
            </DocStep>

            <DocStep number="4" title="Wait for DNS Propagation">
              <p>DNS changes can take up to 24-48 hours to propagate globally, though most complete within 30 minutes. Once propagated, visit your domain and it will serve your site.</p>
            </DocStep>

            <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-5">
              <p className="text-sm font-medium text-gray-800 dark:text-gray-200 mb-2">Common Issues</p>
              <ul className="space-y-1.5 text-sm text-gray-600 dark:text-gray-400">
                <li>• <strong>Apex/root domains</strong> (example.com without www): Use an A record or ALIAS record instead of CNAME.</li>
                <li>• <strong>SSL not working</strong>: Wait for DNS propagation to complete. SSL is provisioned automatically.</li>
                <li>• <strong>Domain shows wrong site</strong>: Make sure the domain is saved correctly in site settings (case-sensitive).</li>
              </ul>
            </div>
          </div>
        </section>

        {/* ─── FAQ ─────────────────────────────────── */}
        <section id="faq" className="mb-16 scroll-mt-24">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Frequently Asked Questions</h2>
          <div className="space-y-4">
            <FaqItem q="What file types are supported?">
              HTML, CSS, JavaScript, images (PNG, JPG, GIF, SVG, WebP), fonts, PDFs, and any other static assets. No server-side languages (PHP, Python, etc.).
            </FaqItem>
            <FaqItem q="What's the maximum file size?">
              Individual ZIP uploads can be up to 10 MB by default. The decompressed size limit is 100 MB with a maximum of 500 files.
            </FaqItem>
            <FaqItem q="Is there a free tier?">
              Yes! Free accounts get 3 sites, free subdomains, and basic form collection. Paid features like analytics, custom domains, and extended submissions are available in the Feature Store.
            </FaqItem>
            <FaqItem q="Can I use a custom domain?">
              Yes — purchase the Custom Domain feature from the Feature Store, then follow the <a href="#custom-domain" className="text-indigo-600 hover:underline">setup guide above</a>.
            </FaqItem>
            <FaqItem q="How do form submissions work?">
              Each site gets a unique API endpoint. Point any HTML form&apos;s <code className="bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded text-xs">action</code> attribute to it and submissions are captured automatically. See the <a href="#form-api" className="text-indigo-600 hover:underline">Form API docs</a>.
            </FaqItem>
            <FaqItem q="Is my data secure?">
              Yes. All sites include free SSL, IP-based analytics use SHA-256 hashing, and we enforce rate limiting, CORS controls, and honeypot spam protection on all form endpoints.
            </FaqItem>
          </div>
        </section>

        {/* CTA */}
        <div className="text-center py-12 border-t border-gray-100 dark:border-gray-800">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Ready to get started?</h2>
          <p className="mt-2 text-gray-500 dark:text-gray-400">Deploy your first site in under 60 seconds.</p>
          <Link
            href="/register"
            className="mt-6 inline-flex items-center gap-2 bg-indigo-600 text-white px-8 py-3 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-600/20"
          >
            Create Free Account
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
          </Link>
        </div>
      </div>
    </div>
  );
}

function DocStep({ number, title, children }) {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0 w-8 h-8 bg-indigo-100 dark:bg-indigo-900/40 rounded-lg flex items-center justify-center">
        <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{number}</span>
      </div>
      <div className="flex-1">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">{title}</h3>
        <div className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{children}</div>
      </div>
    </div>
  );
}

function CodeBlock({ children, language }) {
  return (
    <div className="relative rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      {language && (
        <div className="bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-4 py-2">
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">{language}</span>
        </div>
      )}
      <pre className="bg-gray-950 text-green-400 p-4 text-sm overflow-x-auto leading-relaxed">
        {children}
      </pre>
    </div>
  );
}

function FaqItem({ q, children }) {
  return (
    <details className="group rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      <summary className="cursor-pointer px-5 py-4 font-medium text-gray-900 dark:text-white text-sm hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors flex items-center justify-between">
        {q}
        <svg className="w-4 h-4 text-gray-400 transition-transform group-open:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
      </summary>
      <div className="px-5 pb-4 text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
        {children}
      </div>
    </details>
  );
}
