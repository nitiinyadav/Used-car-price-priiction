# LiveInSec — Feature Store: User Journey Analysis, Architecture Review & Money-Making Blueprint

> **Prepared by:** SaaS Architect | UX Strategist | Revenue Optimization
> **Date:** April 2, 2026
> **Classification:** Internal — Engineering & Product Team
> **References:** Shopify App Store, Vercel Marketplace, Figma Plugin Ecosystem, AWS Marketplace

---

## Executive Summary

The Feature Store is LiveInSec's **primary revenue engine** — an à-la-carte marketplace where users buy exactly the capabilities they need. This document analyzes the current purchase flow step-by-step, evaluates the architecture's extensibility for future features, and provides a **reference-backed blueprint** for maximizing revenue and developer velocity.

**Key Finding:** The current Feature Store architecture is **well-designed for 5-10 features** but will hit scaling walls at 20+ features. The user journey has **4 critical friction points** that are silently killing conversions. The fix is not rebuilding — it's **surgical improvements** to the existing architecture.

---

## Part 1: Current User Journey — Step-by-Step Audit

### 1.1 Complete Purchase Flow (As Built)

```
┌─────────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│ User hits a  │────►│ Sees     │────►│ Store    │────►│ Cart     │────►│ Razorpay │
│ paywall      │     │ "Buy Now"│     │ Page     │     │ Page     │     │ Checkout │
│ (e.g. inbox) │     │ link     │     │ Browse   │     │ Review   │     │ Payment  │
└─────────────┘     └──────────┘     │ features │     │ + qty    │     │ UI       │
                                      └──────────┘     └──────────┘     └──────────┘
                                                                              │
                                      ┌──────────┐     ┌──────────┐          │
                                      │ Feature  │◄────│ Verify   │◄─────────┘
                                      │ Active!  │     │ Signature│
                                      └──────────┘     └──────────┘
```

### 1.2 Step-by-Step Analysis with Friction Points

#### Step 1: User Encounters a Paywall

**Current Implementation:**
- User navigates to `/dashboard/submissions` → sees "Viewing Submission Details Requires a Purchase" 
- User navigates to `/dashboard/analytics` → sees "Analytics Requires a Purchase"
- User tries custom domain in site creation → sees "Custom Domain is a paid feature"

**Friction Analysis:**
| Aspect | Score | Issue |
|--------|-------|-------|
| Visual clarity | ⭐⭐⭐⭐ | Clear messaging, good CTA buttons |
| Emotional trigger | ⭐⭐ | No urgency, no FOMO, no preview of what they're missing |
| Path to purchase | ⭐⭐⭐ | Links to Store page — but user loses context |

🔴 **FRICTION POINT 1: No Value Preview**
The user sees "Buy Submissions" but has never seen what the submissions inbox looks like with data. They're asked to buy something they haven't experienced.

**Fix (Reference: Canva Pro):**
Canva shows you the pro feature working, then blurs it with a lock icon. You can see the value but not access it.

**Recommendation:**
```
BEFORE (current):
"Submission Details Requires a Purchase" → [Buy Submissions]

AFTER (recommended):
Show the ACTUAL submission data as blurred/redacted rows:
┌──────────────────────────────────────────┐
│ 📬 You have 12 new form submissions      │
│                                          │
│ John D████  │ john@████.com │ 2h ago     │
│ Sarah M████ │ s.m████@████  │ 5h ago     │
│ Mike ████   │ mike████████  │ Yesterday  │
│                                          │
│ 🔓 Unlock full submission details        │
│ [Buy Submissions — $5 for 1000]          │
└──────────────────────────────────────────┘
```

This leverages the **Curiosity Gap** — users can see they're receiving leads but can't read them. The pain of not knowing drives purchases.

#### Step 2: User Clicks "Buy" → Redirected to Feature Store

**Current Implementation:**
- User clicks CTA → lands on `/dashboard/store` (generic store page)
- Must find the specific feature among all listed features
- Must figure out quantity, review price, click "Add to Cart"

🔴 **FRICTION POINT 2: Context Break**
User wanted to buy "Submissions" but lands on a page showing ALL features. They must visually scan, find the right one, understand the quantity model, and add to cart. Each step is a potential drop-off.

**Fix (Reference: Shopify App Store):**
Direct buy links should DEEP-LINK to the feature and pre-select it:

```
/dashboard/store?feature=submissions&qty=1000&action=buy

→ Opens store page with submissions feature highlighted
→ Pre-fills quantity
→ Shows "Continue to Checkout" instead of "Add to Cart"
```

Even better: **In-context purchase modal** (like Figma plugins):
```
User is on /dashboard/submissions → Clicks "Unlock"
→ Modal opens with feature details + quantity selector + "Buy Now"
→ No page navigation needed
```

#### Step 3: Cart Page

**Current Implementation:**
- `/dashboard/cart` shows items with quantities and total
- Currency toggle (USD/INR) available
- "Proceed to Checkout" button creates Razorpay order

**Analysis:**
| Aspect | Score | Issue |
|--------|-------|-------|
| Cart clarity | ⭐⭐⭐⭐ | Clean UI, shows line items |
| Trust signals | ⭐⭐ | No money-back guarantee, no security badges, no "1,247 users purchased" |
| Cart abandonment | ⭐ | No recovery mechanism. If user leaves, cart persists but no email reminder |

🔴 **FRICTION POINT 3: No Trust Signals at Checkout**
The moment before payment is when users experience **Maximum Purchase Anxiety**. They need reassurance.

**Fix (Reference: Every successful e-commerce):**
Add to cart page:
- "🔒 Secure payment via Razorpay" badge
- "✅ Instant activation — feature available immediately after payment"
- "💬 Questions? Contact support@liveinsec.com"
- "📊 Purchased by X+ developers" (pull from DB: `COUNT(featurepurchase)`)

#### Step 4: Payment → Verification → Activation

**Current Implementation:**
- Razorpay opens payment modal
- On success: `POST /api/feature-checkout/verify`
- Server verifies HMAC-SHA256 signature
- Atomic transaction: Updates order → Creates purchases → Clears cart
- Feature immediately available

**Analysis:** ⭐⭐⭐⭐⭐ — This is well-implemented. The atomic transaction prevents double-purchase, signature verification prevents tampering, and instant activation provides gratification.

🔴 **FRICTION POINT 4: Weak Post-Purchase Experience**
After payment, the user is redirected to cart page which says "Payment successful!" — but there's no celebration, no onboarding for the purchased feature, and no confirmation email.

**Fix (Reference: Notion, Linear):**
```
Payment Success Screen:
┌──────────────────────────────────────────┐
│              🎉 You're all set!          │
│                                          │
│  ✅ Form Submissions — 1000 quota added  │
│  ✅ Site Analytics — Active for 30 days  │
│                                          │
│  What's Next:                            │
│  → [View Your Submissions Inbox]         │
│  → [Check Your Analytics Dashboard]      │
│                                          │
│  A receipt has been sent to your email.   │
└──────────────────────────────────────────┘
```

### 1.3 Journey Friction Score Summary

| Step | Current Score | Target Score | Fix Effort |
|------|-------------|-------------|------------|
| 1. Paywall encounter | 6/10 | 9/10 | 4 hrs (blurred preview) |
| 2. Store navigation | 5/10 | 9/10 | 6 hrs (deep links + modals) |
| 3. Cart checkout | 6/10 | 9/10 | 3 hrs (trust signals) |
| 4. Post-purchase | 4/10 | 9/10 | 4 hrs (success screen + email) |
| **Overall Journey** | **5.25/10** | **9/10** | **17 hrs total** |

---

## Part 2: Architecture Analysis for Future Features

### 2.1 Current Data Architecture

```
feature (defines what's available)
    │
    ├── cartitem (shopping cart, per user)
    │
    ├── orderitem ──► featureorder (payment record)
    │
    └── featurepurchase (active entitlement)
            │
            └── getUserFeatureQuota() ──► {hasAccess, used, remaining}
```

**Architecture Score: 8/10** — Well-designed for the current scale.

### 2.2 What Happens When You Add 10 More Features?

Let's say you want to add these features in the next 12 months:

| Future Feature | Type | Quota Model | Architecture Fit? |
|---------------|------|-------------|-------------------|
| Email notifications | duration | Monthly subscription | ✅ Works — type: 'duration' |
| Serverless functions | quantity | Per-invocation | ⚠️ Needs real-time metering |
| Custom SSL | quantity | Per-domain | ✅ Works — same as custom-domain |
| White-label branding | boolean | On/off per site | ⚠️ Needs per-site entitlement |
| Priority support | duration | Monthly subscription | ✅ Works |
| A/B testing | duration | Monthly per-site | ⚠️ Needs per-site entitlement |
| Scheduled deploys | quantity | Per-deploy | ⚠️ Needs event-based metering |
| API access | duration | Monthly + rate limit | ⚠️ Needs API key + rate limiting |
| Collaboration | quantity | Per-collaborator | ✅ Works — same as team-members |
| Site backups | quantity | Per-backup | ⚠️ Needs storage-aware quota |

### 2.3 Architecture Recommendations

#### Recommendation 1: Add Feature Categories & Tags

**Problem:** With 15+ features, the store page becomes a wall of cards. Users can't find what they need.

**Solution:** Add `category` and `tags` fields (already have `category` — leverage it):

```
Feature Store Layout:
┌──────────────────────────────────────────┐
│ [All] [Core] [Marketing] [Developer]     │
│                                          │
│ CORE                                     │
│ ├── Form Submissions                     │
│ ├── Custom Domains                       │
│ └── Extra Storage                        │
│                                          │
│ MARKETING                                │
│ ├── Site Analytics                       │
│ ├── A/B Testing                          │
│ └── SEO Tools                            │
│                                          │
│ DEVELOPER                                │
│ ├── API Access                           │
│ ├── Serverless Functions                 │
│ └── Scheduled Deploys                    │
└──────────────────────────────────────────┘
```

**Database change:** None needed — the `category` field already exists. Just populate it and add a filter UI.

#### Recommendation 2: Add Per-Site Feature Entitlement

**Problem:** Current architecture gives features to the USER globally. But some features (white-label, A/B testing) should be per-SITE.

**Current Model:**
```
featurepurchase.userId = "user1"
featurepurchase.featureId = "white-label"
→ Applies to ALL sites owned by user1
```

**Recommended Model:**
```sql
-- Add optional siteId column to featurepurchase
ALTER TABLE featurepurchase ADD COLUMN siteId VARCHAR(191) NULL;
ALTER TABLE featurepurchase ADD INDEX idx_site_feature (siteId, featureId);
```

```javascript
// Updated quota check:
getUserFeatureQuota(userId, featureSlug, siteId = null)
// If siteId is provided AND the feature type is 'per-site':
//   → Only count purchases for that specific site
// Otherwise:
//   → Global quota (current behavior)
```

**Impact:** Minimal — one optional column, one `if` statement in feature-access.js. But unlocks per-site monetization.

#### Recommendation 3: Add Usage Event Tracking

**Problem:** For features like "serverless functions" or "scheduled deploys", you need real-time usage metering, not just a static quota.

**Recommended Addition:**
```prisma
model featureusageevent {
  id        String   @id @default(cuid())
  userId    String
  featureId String
  siteId    String?
  quantity  Int      @default(1)
  metadata  String?  @db.Text  // JSON for event-specific data
  createdAt DateTime @default(now())

  user    user    @relation(fields: [userId], references: [id], onDelete: Cascade)
  feature feature @relation(fields: [featureId], references: [id], onDelete: Cascade)

  @@index([userId, featureId, createdAt])
  @@index([siteId, featureId])
}
```

**Instead of:**
```javascript
// Current: COUNT all submissions for quota
used = await prisma.formSubmission.count({ where: { site: { userId } } });
```

**Use:**
```javascript
// Future: COUNT usage events for the current billing period
used = await prisma.featureusageevent.count({
  where: {
    userId,
    featureId: feature.id,
    createdAt: { gte: billingPeriodStart }
  }
});
```

**Impact:** New table + change feature-access.js switch statement. Enables usage-based billing for any future feature.

#### Recommendation 4: Add Feature Dependencies

**Problem:** Some features require others. Example: "A/B Testing" requires "Analytics" to show results.

**Recommended Addition:**
```prisma
// Add to feature model:
model feature {
  // ... existing fields ...
  requiresFeatureSlug  String?  // null = no dependency
}
```

**In the Store UI:**
```
A/B Testing — $4.99/mo
⚠️ Requires: Site Analytics (active) ✅
[Add to Cart]

OR

A/B Testing — $4.99/mo  
⚠️ Requires: Site Analytics — [Buy Analytics First]
```

**Impact:** One optional column, UI logic in store page. Prevents broken feature states and guides users through the purchase funnel (increasing average cart value).

### 2.4 Recommended Future Architecture Diagram

```
                    ┌──────────────┐
                    │   feature    │
                    │   (catalog)  │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
      ┌───────▼──┐  ┌─────▼─────┐  ┌──▼──────────┐
      │ cartitem │  │ orderitem │  │ featureusage │
      │ (intent) │  │ (payment) │  │   event      │
      └──────────┘  └─────┬─────┘  │ (metering)   │
                          │        └──────────────┘
                    ┌─────▼─────┐
                    │ feature   │
                    │ purchase  │ ←── siteId (optional)
                    │ (entitle) │
                    └─────┬─────┘
                          │
                    ┌─────▼─────┐
                    │ feature   │
                    │ access.js │ ← getUserFeatureQuota()
                    └───────────┘
                          │
              ┌───────────┼───────────┐
              │           │           │
        ┌─────▼───┐ ┌────▼────┐ ┌───▼─────┐
        │ API     │ │ Page    │ │ Service │
        │ Routes  │ │ Guards  │ │ Workers │
        └─────────┘ └─────────┘ └─────────┘
```

---

## Part 3: Money-Making Blueprint (Reference-Based)

### 3.1 Lessons from Successful SaaS Feature Stores

#### Shopify App Store — $100M+ Annual Revenue

**What they do:**
- Apps listed by third parties (marketplace commission model)
- 80% of Shopify merchants install at least 1 app
- Average merchant spends $100/month on apps

**What LiveInSec can learn:**
- In the future, allow **third-party developers** to build features (plugins/integrations)
- Charge 20% commission on third-party feature sales
- This turns your Feature Store into a **platform**, not just a product

**Implementation (Phase 2, Month 6+):**
```
/api/v1/features/submit    — Developer submits a feature
/api/v1/features/review    — Admin approves/rejects
/api/v1/features/webhook   — Revenue split notification
```

#### Vercel — Marketplace Model

**What they do:**
- Free tier is generous (Hobby plan)
- Pro features unlock at predictable price points
- Usage-based billing above included amounts

**What LiveInSec can learn:**
- **Generous free tier is the marketing.** Every free site with "Powered by LiveInSec" is an ad
- When users exceed free quota, don't block — **warn and give a grace period.** Then bill
- Usage-based billing above the included amount is less stressful than hard limits

#### Canva — Feature Upsell Psychology

**What they do:**
- Show premium features alongside free ones (blurred/locked)
- "Try Canva Pro free for 30 days" — endowment effect
- After trial, users see their premium designs revert — loss aversion drives conversion

**What LiveInSec can learn:**
- **Show analytics data in the dashboard even for free users** — but limited (last 7 days, no export, no country breakdown)
- When the 7-day preview expires: "Your analytics history is waiting. Unlock it for $2.99/mo"
- Users who've SEEN their traffic data will pay to keep seeing it

### 3.2 The Revenue Maximization Playbook

#### Strategy 1: The Wedge Product (Immediate Revenue)

Your "wedge" is the **form submissions** feature. Here's why:
- Users deploy a site → they need a contact form → they need somewhere for submissions to go
- The value is immediately tangible (real leads from real people)
- It's the only feature where **NOT having it costs the user real money** (lost leads)

**Tactic:**
```
Step 1: Give 50 free submissions (enough to prove value)
Step 2: When they hit 40/50, email: "You've received 40 leads! 
        Your quota is almost full. Don't miss future leads."
Step 3: When they hit 50/50: "New submissions are being held. 
        Add 1000 more submissions for $5."
Step 4: After purchase: "Great! You now have 1000 submissions. 
        Set up email notifications so you never miss a lead."
```

This is how Mailchimp grew: free tier → prove value → upsell at pain point.

#### Strategy 2: The Bundle Hook (Higher Cart Value)

**Problem:** ARPU of $3-5/feature is low. Solution: Bundles.

```
STARTER BUNDLE — $9.99 (save $4.97)
├── 1000 Form Submissions ($5.00 value)
├── 3 months Analytics ($8.97 value)
└── 1 Custom Domain ($2.99 value)
    Total value: $16.96 → You pay: $9.99

GROWTH BUNDLE — $24.99 (save $12.96)
├── 5000 Form Submissions ($25.00 value)
├── 6 months Analytics ($17.94 value)
├── 3 Custom Domains ($8.97 value)
└── 2 Team Members ($9.98 value)
    Total value: $61.89 → You pay: $24.99
```

**Implementation:** Create a new feature type: `type: 'bundle'` that auto-creates multiple `featurepurchase` records on verification.

#### Strategy 3: The Recurring Revenue Engine (Long-Term Sustainability)

**Problem:** One-time purchases (custom domain: $2.99 lifetime) don't create MRR.

**Solution:** Make high-value features time-based with auto-renewal:

| Feature | Current | Recommended | Why |
|---------|---------|-------------|-----|
| Submissions | Lifetime qty | Monthly quota (reset) | Creates recurring need |
| Analytics | Monthly (good!) | Keep monthly | Already recurring ✅ |
| Custom Domain | Lifetime | Annual renewal ($2.99/yr) | Hosting cost exists |
| Team Members | Lifetime | Monthly per-member | Aligns with team growth |
| Storage | Lifetime | Monthly | Storage has ongoing cost |

**Revenue Impact:** Moving from 70% one-time / 30% recurring to 30% one-time / 70% recurring increases valuation 3-5x for investors.

#### Strategy 4: The Data-Driven Upsell Engine

Build this automated system:

```
┌─────────────────┐
│  Usage Tracker   │ ← Runs daily via cron
│  (background)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐     ┌─────────────────┐
│ 80% quota used? │────►│ Send "running   │
│                 │ Yes │ low" email       │
└────────┬────────┘     └─────────────────┘
         │ No
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Feature unused   │────►│ Send "did you   │
│ for 7+ days?     │ Yes │ know?" email    │
└────────┬────────┘     └─────────────────┘
         │ No
         ▼
┌─────────────────┐     ┌─────────────────┐
│ Trial expiring   │────►│ Send "X days    │
│ in 3 days?       │ Yes │ left" email     │
└──────────────────┘     └─────────────────┘
```

**Implementation:** A single cron route (`/api/cron/usage-alerts`) that runs daily and sends contextual emails based on usage patterns.

### 3.3 Complete Feature Store UX Redesign (Recommended)

#### Current Store Layout Issues

1. All features shown equally (no hierarchy)
2. Quantity selector is complex (min/max/step)
3. No "quick buy" option
4. No recommendations based on usage

#### Recommended Store Layout

```
┌─────────────────────────────────────────────────────────┐
│  FEATURE STORE                              [🛒 Cart 2] │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  📌 RECOMMENDED FOR YOU                                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 📬 Form Submissions                              │  │
│  │ You have 12 pending leads! Unlock to view them.  │  │
│  │ [Buy 1000 — $5]  [Custom amount]                 │  │
│  └──────────────────────────────────────────────────┘  │
│                                                         │
│  🔥 POPULAR                                             │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐       │
│  │ 📊 Analyt  │  │ 🌐 Custom  │  │ 👥 Team    │       │
│  │ $2.99/mo   │  │ $2.99/dom  │  │ $4.99/memb │       │
│  │ [Buy]      │  │ [Buy]      │  │ [Buy]      │       │
│  └────────────┘  └────────────┘  └────────────┘       │
│                                                         │
│  💰 SAVE WITH BUNDLES                                   │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Starter Bundle — $9.99 (save 41%)                │  │
│  │ Submissions + Analytics + 1 Domain               │  │
│  │ [Add Bundle to Cart]                              │  │
│  └──────────────────────────────────────────────────┘  │
│                                                         │
│  ALL FEATURES                                           │
│  [Core] [Marketing] [Developer] [Storage]               │
│  ... cards ...                                          │
└─────────────────────────────────────────────────────────┘
```

**Key UX Principles Applied:**
1. **Personalized recommendations** at the top (based on usage data)
2. **One-click buy** for common quantities
3. **Bundles** for higher cart value
4. **Category filters** for discoverability at scale
5. **Social proof** ("Popular" tag) for purchase confidence

---

## Part 4: Developer Experience for Adding New Features

### 4.1 Current Developer Flow (Adding a New Feature)

```
Step 1: Add feature to seed array in /api/features/route.js
Step 2: Add usage calculation case in feature-access.js
Step 3: Add UI gate in the relevant page
Step 4: Run seed API to create in database
Step 5: Configure via admin panel (prices, quotas)
```

**Developer Experience Score: 7/10** — Reasonable, but requires touching 3+ files and understanding the full flow.

### 4.2 Recommended Developer Flow (Future)

#### Create a Feature Registry Pattern

```javascript
// src/lib/features/registry.js

export const FEATURE_REGISTRY = {
  'submissions': {
    name: 'Form Submissions',
    type: 'quantity',
    usageCalculator: async (userId) => {
      return prisma.formSubmission.count({ where: { site: { userId } } });
    },
    paywallComponent: 'SubmissionsPaywall',
    sidebarConfig: { show: true, label: 'Inbox', icon: 'inbox', href: '/dashboard/submissions' },
  },
  'analytics': {
    name: 'Site Analytics',
    type: 'duration',
    usageCalculator: async () => 0, // duration-based, no usage count
    paywallComponent: 'AnalyticsPaywall',
    sidebarConfig: { show: true, label: 'Analytics', icon: 'chart', href: '/dashboard/analytics' },
  },
  // Adding a new feature = adding one object here
};
```

**Benefits:**
1. Single source of truth for all feature definitions
2. No more switch statement in feature-access.js
3. Paywall component is co-located with feature definition
4. New feature = one file change + one DB seed

### 4.3 Feature Development Checklist (For Engineers)

```markdown
## Adding a New Feature to LiveInSec

### Phase 1: Define (15 minutes)
- [ ] Choose a slug (lowercase, hyphenated: e.g., "email-notifications")
- [ ] Decide type: quantity | duration | boolean
- [ ] Define pricing (USD cents, INR paise)
- [ ] Define free quota (0 = paid only)
- [ ] Write 4 highlight bullets
- [ ] Choose emoji icon

### Phase 2: Backend (30-60 minutes)
- [ ] Add to seed defaults in /api/features/route.js
- [ ] Add usage calculator in feature-access.js switch statement
- [ ] Add API gating where the feature is consumed
- [ ] Write one integration test for quota calculation

### Phase 3: Frontend (30-60 minutes)
- [ ] Add paywall UI on the relevant page (copy existing pattern)
- [ ] Add deep link to store (?feature=your-slug)
- [ ] If sidebar feature: add sidebarLabel/Icon/Href in seed

### Phase 4: Activate (5 minutes)
- [ ] Call POST /api/features { seed: true } on production
- [ ] Set freeQuota via admin panel
- [ ] Test purchase flow end-to-end
```

---

## Part 5: Metrics to Track (Feature Store Health)

| Metric | How to Calculate | Target |
|--------|-----------------|--------|
| **Store Visit Rate** | Users who visit /store / Total active users | >30% |
| **Add-to-Cart Rate** | Cart additions / Store visits | >15% |
| **Checkout Completion** | Paid orders / Cart + checkout initiated | >60% |
| **Feature Adoption** | Users with ≥1 purchase / Total users | >10% |
| **ARPU (Avg Revenue Per User)** | Total revenue / Paying users | >$8/mo |
| **Feature-Level Conversion** | Purchases per feature / Views of that paywall | Per-feature |
| **Bundle Attach Rate** | Bundle purchases / Total orders | >25% |
| **Cart Abandonment Rate** | Abandoned carts / Total carts created | <40% |
| **Time to First Purchase** | Median days from signup to first purchase | <14 days |
| **Repeat Purchase Rate** | Users with 2+ purchases / Total purchasing users | >30% |

**Build an Admin Dashboard card** that shows these metrics. This tells you what's working and what's not.

---

## Part 6: Summary of Architectural Changes

### Must-Do (Before Scaling to 10+ Features)

| Change | Effort | Impact |
|--------|--------|--------|
| Add per-site `siteId` to featurepurchase | 2 hrs | Enables per-site features |
| Add feature categories UI filter | 3 hrs | Store becomes navigable at scale |
| Add deep-link buy URLs (?feature=X) | 2 hrs | Removes context-break friction |
| Add post-purchase success screen | 3 hrs | Immediate gratification + activation |
| Add purchase confirmation email | 2 hrs | Trust building + receipt |

### Should-Do (Month 2-3)

| Change | Effort | Impact |
|--------|--------|--------|
| Add featureusageevent table | 4 hrs | Enables usage-based billing |
| Add feature dependency field | 1 hr | Prevents broken states |
| Add bundle feature type | 6 hrs | Increases ARPU by 40%+ |
| Build in-context purchase modal | 6 hrs | 2x conversion vs page redirect |
| Add cart abandonment email | 3 hrs | Recovers 10-15% of lost carts |

### Nice-to-Have (Month 4-6)

| Change | Effort | Impact |
|--------|--------|--------|
| Feature registry pattern | 8 hrs | Developer velocity 3x |
| Third-party feature API | 20 hrs | Marketplace model unlock |
| A/B testing for feature pricing | 8 hrs | Optimized revenue |
| Recommendation engine | 12 hrs | Personalized upsells |

---

*"The best feature stores don't feel like stores — they feel like the natural next step in the user's journey. Every paywall should feel less like a wall and more like a door with a clear view of what's on the other side."*

---
**End of Document 2 of 3**
