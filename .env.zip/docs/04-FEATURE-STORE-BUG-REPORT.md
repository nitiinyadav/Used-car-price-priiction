# LiveInSec — Feature Store Bug Report

> **Prepared by:** QA & Architecture Review
> **Date:** April 2, 2026
> **Scope:** Feature Store end-to-end — catalog, cart, checkout, payment verification, quota calculation, gating UI
> **Classification:** Internal — Engineering Team

---

## Summary

| Severity | Count |
|----------|-------|
| 🔴 Critical | 4 |
| 🟠 High | 5 |
| 🟡 Medium | 7 |
| 🟢 Low | 7 |
| **Total** | **23** |

---

## 🔴 Critical Bugs

### BUG-01: Client-Side JWT Update Can Bypass Feature Gating

**File:** `src/lib/auth.js` — JWT callback (~line 165)

Several feature-gating pages check `session.user.role === 'superadmin'` before consulting the database. The JWT update callback allows ANY session field to be set from the client:

```javascript
if (trigger === 'update' && session) {
  if (session.plan) token.plan = session.plan;
  if (session.subscriptionStatus !== undefined) {
    token.subscriptionStatus = session.subscriptionStatus;
  }
  if (session.ownerId !== undefined) {
    token.ownerId = session.ownerId;
  }
}
```

**Impact:** While `role` is not in the updatable list (good), the `ownerId` field IS — meaning a user can call `update({ ownerId: null })` to appear as a workspace owner and unlock team management features. The `subscriptionStatus` and `plan` fields are also updatable, which can confuse any remaining code that reads them.

**Fix:** Remove `plan`, `subscriptionStatus`, `billingPeriod`, `currentPeriodEndsAt`, `trialEndsAt`, and `ownerId` from the client-updatable fields. Only allow: `name`, `phone`, `countryCode`, `countryName`, `emailVerifiedAt`, `billingCurrency`.

---

### BUG-02: Currency Switch Mid-Checkout Creates Payment Mismatch

**File:** `src/app/dashboard/cart/page.js` (~line 47-68, 189-193)

The cart page has a currency toggle (USD/INR). When the user switches currency:

1. The displayed total recalculates instantly using `item.feature.priceInr` or `item.feature.priceUsd`
2. The checkout API call sends the *current* currency state
3. The backend creates a Razorpay order with the switched currency amounts

**The bug:** Prices in USD and INR are set independently by the admin (e.g., `priceUsd: 299` = $2.99, `priceInr: 249` = ₹249). These are NOT exchange-rate linked. A user who adds items seeing USD prices, then switches to INR at checkout, gets charged ₹249 instead of the USD-equivalent ~₹250 ($2.99 × ₹84). This is an **~90% discount**.

**Scenario:**
```
1. User browsing in USD: Analytics = $2.99 × 6 months = $17.94
2. User toggles to INR at cart page
3. Checkout sends INR: Analytics = ₹249 × 6 months = ₹1,494 (~$17.78) ← close
4. But for other features with larger discrepancy:
   Extra Storage: $0.99 USD vs ₹49 INR (₹49 ≈ $0.58 — 41% cheaper in INR)
```

**Fix:** Lock the currency at cart-add time, or re-validate prices server-side at checkout using the currency the items were added with. Better: store the currency per cart item.

---

### BUG-03: Extra Storage Quota Uses Hardcoded Estimate (10MB/site)

**File:** `src/lib/feature-access.js` (~line 101-105)

```javascript
case 'extra-storage': {
  const siteCount = await prisma.site.count({ where: { userId } });
  used = siteCount * 10; // 10MB per site estimate
  break;
}
```

**Impact:**
- User with 1 site of 500MB → shows `used: 10MB` → has infinite apparent quota
- User with 50 small sites (1MB each) → shows `used: 500MB` → falsely blocked
- The TODO in a live system means storage limits are completely non-functional

**Compounding issue:** The `freeQuota` is in MB (200) but purchased quantity follows `minQty: 1, maxQty: 100` with description "extra storage" — it's unclear if purchased units are MB or GB. If GB, then `totalQuota = 200 + 5` when user buys 5 units is 205 (200MB + 5GB?) — unit mismatch.

**Fix:**
```javascript
case 'extra-storage': {
  const sites = await prisma.site.findMany({
    where: { userId },
    select: { id: true }
  });
  let totalBytes = 0;
  for (const site of sites) {
    totalBytes += await getSiteSize(site.id); // Already exists in storage.js
  }
  used = Math.ceil(totalBytes / (1024 * 1024)); // Convert to MB
  break;
}
```
Also: Standardize all storage quota units to MB everywhere (seed, freeQuota, purchased quantity).

---

### BUG-04: Duration Feature Quantity Stored as 1 — Audit Trail Lost

**File:** `src/app/api/feature-checkout/verify/route.js` (~line 88-94)

```javascript
await tx.featurepurchase.create({
  data: {
    userId: session.user.id,
    featureId: oi.featureId,
    quantity: oi.durationDays ? 1 : oi.quantity,  // ← Always 1 for duration
    expiresAt,
    amountPaid: oi.totalPrice,
    currency: order.currency,
  },
});
```

If a user buys 6 months of Analytics (quantity=6, durationDays=30):
- `expiresAt` = now + 180 days ✅ (correct)
- `quantity` = 1 ❌ (should be 6)
- `amountPaid` = 6 × $2.99 = $17.94 ✅ (correct)

**Impact:**
- Admin panel shows purchase of "1" but amount is $17.94 — confusing
- If renewal logic is ever added, it won't know to renew for 6 months
- Refund calculations are wrong (quantity 1 × unit price ≠ amount paid)
- Audit/compliance: the record doesn't match what was purchased

**Fix:**
```javascript
quantity: oi.quantity,  // Always store actual purchased quantity
```

---

## 🟠 High Bugs

### BUG-05: Feature Access Silent Failure Blocks Legitimate Users

**Files:** `src/app/dashboard/submissions/page.js` (line ~22-29), `src/app/dashboard/analytics/page.js`, `src/app/dashboard/sites/[id]/submissions/page.js`, `src/app/dashboard/sites/[id]/analytics/page.js`

Pattern repeated in all gating pages:

```javascript
try {
  const quota = await getUserFeatureQuota(session.user.id, 'submissions');
  hasSubmissionAccess = quota.hasAccess;
} catch (err) {
  console.error('Feature quota check failed:', err.message);
  hasSubmissionAccess = false;  // ← DB error = "you haven't purchased"
}
```

**Impact:** If MySQL is slow or the `feature` table has a transient issue, ALL paying users see "Buy this feature" instead of their data. No distinction between "not purchased" and "system error."

**Fix:**
```javascript
} catch (err) {
  console.error('Feature quota check failed:', err.message);
  // Return a system error page, not a paywall
  return (
    <div>Something went wrong checking your access. Please try again or contact support.</div>
  );
}
```

---

### BUG-06: Sidebar Shows All Features Regardless of Purchase Status

**File:** `src/components/Sidebar.js` (~line 69-98)

The sidebar renders feature links for ALL features where `showInSidebar: true`:

```javascript
{sidebarFeatures.map((feature) => {
  const href = feature.sidebarHref || `/dashboard/${feature.slug}`;
  return (
    <Link key={feature.id} href={href} ...>
      {feature.sidebarLabel || feature.name}
    </Link>
  );
})}
```

**Impact:** Non-paying users see "Inbox", "Analytics" in the sidebar, click them, and hit a paywall. This creates frustration — the sidebar promises features that aren't accessible.

**Two valid approaches:**
1. **Show but mark locked** — add a 🔒 icon next to unpurchased features (drives awareness + upsell)
2. **Hide until purchased** — only show sidebar items for features the user has bought (cleaner UX)

Recommended: Option 1 (drives awareness), but the current implementation does neither — it shows them as if they're available.

---

### BUG-07: Boolean Feature Type Documented but Never Implemented

**File:** `prisma/schema.prisma` (line ~215), `src/lib/feature-access.js`

The schema comments say the `type` field supports `'boolean'` (on/off features), but:
- No seeded feature uses type `'boolean'`
- `getUserFeatureQuota()` has no boolean case in the switch — it hits the default
- The default case returns `hasAccess: totalQuota > 0` which works accidentally, but `used` and `remaining` are meaningless for boolean

**Impact:** If an admin creates a boolean feature (e.g., "white-label branding"), the quota response will show `used: 0, remaining: 1` but never actually track if the feature is "on." Any quantity > 0 grants access, which is accidentally correct for boolean, but the semantics are wrong.

**Fix:** Add explicit boolean handling:
```javascript
case 'boolean-feature-slug': {
  used = 0; // Boolean features don't have measurable usage
  break;
}
// Or add a generic handler for type === 'boolean'
```

---

### BUG-08: Team Member Feature — Team Members Can See "Buy" Prompt

**File:** `src/app/dashboard/settings/page.js` (line ~12-20), `src/app/dashboard/settings/SettingsClient.js`

```javascript
let canManageTeam = false;
if (session.user.role === 'superadmin') {
  canManageTeam = true;
} else if (!session.user.ownerId) {
  const quota = await getUserFeatureQuota(session.user.id, 'team-members');
  canManageTeam = quota.hasAccess;
}
```

When `session.user.ownerId` is set (meaning the user IS a team member, not an owner), `canManageTeam` stays false. The settings page passes `canManageTeam: false` to SettingsClient, which shows "Buy Team Members" prompt.

**Impact:** A team member sees "Buy Team Members" — but they CAN'T buy it because they're not the account owner. Clicking "Buy" takes them to the Feature Store where it would be purchased under their OWN account, not the team owner's. This creates billing confusion and wasted purchases.

**Fix:** Pass a `isTeamMember` prop and show: "Team management is handled by your workspace owner [owner-name]."

---

### BUG-09: No maxQty Validation on Frontend Quantity Selector

**File:** `src/app/dashboard/store/page.js` (StoreClient)

The quantity selector buttons (`+`/`-`) enforce `minQty` and `stepQty`, but a user can type any number directly into the input field. while the cart API validates server-side, the UX is broken:

1. User types `99999` in the quantity field
2. Clicks "Add to Cart"
3. API returns error: "Quantity must be between 1 and 100"
4. No inline validation on the input — user doesn't know why it failed until after the API call

**Fix:** Add `min`, `max`, and `step` attributes to the `<input>` element and client-side validation before the API call.

---

## 🟡 Medium Bugs

### BUG-10: Cart POST is Used for Both Create and Update

**File:** `src/app/api/cart/route.js`

The cart API uses POST for both adding new items AND updating existing item quantities (upsert pattern). While functional, this violates REST conventions and causes an issue:

When a user clicks "Add to Cart" on a feature they already have in their cart, it **silently changes the quantity** to the store page's current quantity selector value, which may be different from what's in the cart.

**Scenario:**
1. User adds Analytics × 3 months to cart
2. User goes back to store
3. Quantity selector resets to default (1)
4. User clicks "Add to Cart" again
5. Cart now has Analytics × 1 — the original 3 is overwritten

**Fix:** POST should only create; add PUT for updates. Or: if item exists, show "Update Cart" button instead of "Add to Cart."

---

### BUG-11: Feature Seed Doesn't Update Existing Features

**File:** `src/app/api/features/route.js` (line ~52-113)

```javascript
const existing = await prisma.feature.findUnique({ where: { slug: feat.slug } });
if (!existing) {
  await prisma.feature.create({ data: feat });
  created++;
}
```

If you update a feature's price, description, or highlights in the seed defaults and re-run `POST /api/features { seed: true }`, **nothing happens** — the feature already exists.

**Impact:** Deployments with updated feature metadata require manual admin panel updates. The seed is not a reliable deployment tool.

**Fix:** Use `upsert` instead of find + conditional create:
```javascript
await prisma.feature.upsert({
  where: { slug: feat.slug },
  create: feat,
  update: { /* only update non-price fields, or all fields */ },
});
```

---

### BUG-12: No Deduplication Protection for Concurrent Cart Adds

**File:** `src/app/api/cart/route.js`

If a user double-clicks "Add to Cart" fast enough, two concurrent POST requests could:
1. Both check `findFirst` → no existing item
2. Both `create` a new cart item
3. Cart now has TWO entries for the same feature

The checkout flow would then create two separate purchases for the same feature.

**Fix:** Add a unique constraint in the schema:
```prisma
model cartitem {
  // ... existing fields ...
  @@unique([userId, featureId])  // Prevent duplicates
}
```

---

### BUG-13: Razorpay Order Amount Not Cross-Validated at Verification

**File:** `src/app/api/feature-checkout/verify/route.js`

At verification time, the code checks the Razorpay signature and order status, but NEVER validates that the amount paid matches the order total. Razorpay's signature covers `orderId|paymentId`, not the amount.

**Scenario:** If Razorpay has a bug or a man-in-the-middle alters the payment amount (e.g., ₹1 instead of ₹1494), the signature would still verify because it doesn't include the amount.

**Fix:** After signature verification, call Razorpay's `payments.fetch(razorpayPaymentId)` API and verify `payment.amount === order.totalAmount`.

---

### BUG-14: Admin-Set minQty > maxQty Breaks Feature Entirely

**File:** `src/app/api/cart/route.js` (line ~51-55)

```javascript
if (quantity < feature.minQty || quantity > feature.maxQty) {
  return NextResponse.json(
    { error: `Quantity must be between ${feature.minQty} and ${feature.maxQty}` },
    { status: 400 }
  );
}
```

If an admin accidentally sets `minQty: 100` and `maxQty: 10`, NO quantity passes this check. The feature becomes permanently un-purchasable, and the error message says "must be between 100 and 10" — nonsensical.

**Fix:** Add validation in admin panel and/or the seed:
```javascript
if (feature.minQty > feature.maxQty) {
  // Use maxQty as the constraint (or reject the admin update)
}
```

---

### BUG-15: Custom Domain Feature Check Has No Loading State

**File:** `src/app/dashboard/sites/new/page.js` (~line 179-193)

```javascript
const [loadingDomainAccess, setLoadingDomainAccess] = useState(true);
```

The `loadingDomainAccess` state is tracked but never reflected in the UI. While the API call runs, the custom domain field is silently disabled with no spinner or "checking access..." text. On slow connections, the field appears broken.

**Fix:** Show a loading skeleton or "Checking feature access..." text while `loadingDomainAccess` is true.

---

### BUG-16: Feature Cache Invalidation Timing Gap

**File:** `src/app/api/features/route.js`, `src/lib/feature-access.js`

Features are cached with a 1-minute TTL. When an admin updates a feature price:
1. Admin saves new price (database updated)
2. Cache still shows old price for up to 60 seconds
3. User adds to cart during cache window → sees old price
4. Checkout creates order with new price (from DB) → price mismatch from what user saw

**Fix:** Call `invalidateFeatureCache()` on all admin feature update endpoints, and use the cache-busted price at display AND checkout time.

---

### BUG-17: Store Page Quantity Fallback to 1 Ignores minQty

**File:** `src/app/dashboard/store/page.js` (~line 49)

```javascript
body: JSON.stringify({ featureId, quantity: quantities[featureId] || 1 }),
```

If `quantities[featureId]` is undefined (page refresh, state loss), the fallback is `1`. If the feature's `minQty` is `10`, this sends `quantity: 1` to the API, which rejects it. The user gets a generic error with no context.

**Fix:** Initialize `quantities` state with each feature's `minQty`:
```javascript
const initialQuantities = {};
features.forEach(f => { initialQuantities[f.id] = f.minQty || 1; });
const [quantities, setQuantities] = useState(initialQuantities);
```

---

## 🟢 Low Bugs

### BUG-18: No Index on formSubmission.formName

**File:** `prisma/schema.prisma`

The `formSubmission` model has no index on `formName`. The submissions page filters by form name, which performs a full table scan on large datasets.

**Fix:** `@@index([siteId, formName])`

---

### BUG-19: Feature Type Field Has No Enum Constraint

**File:** `prisma/schema.prisma` (line ~215)

```prisma
type String @default("quantity")
```

Any string value is accepted. If admin enters `type: 'quntity'` (typo), the quota calculation hits the switch default and returns `used: 0`, granting unlimited access.

**Fix:** Validate type on write:
```javascript
if (!['quantity', 'duration', 'boolean'].includes(body.type)) {
  return NextResponse.json({ error: 'Invalid feature type' }, { status: 400 });
}
```

---

### BUG-20: featurepurchase Missing updatedAt Field

**File:** `prisma/schema.prisma` (featurepurchase model)

No `updatedAt` timestamp. If a purchase is ever modified (extension, refund, admin override), there's no record of when.

**Fix:** Add `updatedAt DateTime @updatedAt`

---

### BUG-21: No Purchase Success Logging

**File:** `src/app/api/feature-checkout/verify/route.js`

Only errors are logged (`console.error`). Successful purchases produce no log output. In production, you can't answer "did user X's purchase go through?" without querying the database.

**Fix:** Add `console.log` for successful purchases:
```javascript
console.log(`[PURCHASE] User ${session.user.id} purchased features: ${order.orderitem.map(oi => oi.feature.slug).join(', ')} — Amount: ${order.totalAmount} ${order.currency}`);
```

---

### BUG-22: Razorpay Key Secret Not Length-Validated

**File:** `src/app/api/feature-checkout/verify/route.js` (line ~33)

The check is `if (!razorpayKeySecret)` — only checks existence, not validity. A truncated or corrupted key would cause silent HMAC failures, rejected as "Payment signature verification failed" — the user sees a payment failure with no useful error.

**Fix:** Add minimum length check: `if (!razorpayKeySecret || razorpayKeySecret.length < 10)`

---

### BUG-23: Cart Not Cleared on Feature Deactivation

**File:** No handling exists

If an admin deactivates a feature (`isActive: false`) while a user has it in their cart:
1. Cart still shows the item
2. At checkout, the code checks `if (!item.feature.isActive)` and rejects — good
3. But the cart item remains, confusing the user

**Fix:** Either run a background cleanup when a feature is deactivated, or filter inactive items from the cart GET response.

---

## Summary Table — All Bugs by Priority

| ID | Severity | Component | Bug | Effort |
|----|----------|-----------|-----|--------|
| 01 | 🔴 Critical | Auth / JWT | Client-side ownerId update bypasses team gating | 15 min |
| 02 | 🔴 Critical | Cart / Checkout | Currency switch creates payment mismatch | 2 hrs |
| 03 | 🔴 Critical | Feature Access | Storage quota uses fake 10MB/site estimate | 2 hrs |
| 04 | 🔴 Critical | Verify / Purchase | Duration quantity stored as 1, audit trail lost | 15 min |
| 05 | 🟠 High | Gating Pages | Silent catch treats DB errors as "not purchased" | 1 hr |
| 06 | 🟠 High | Sidebar | Shows all features regardless of purchase | 1 hr |
| 07 | 🟠 High | Feature Access | Boolean feature type undocumented default path | 30 min |
| 08 | 🟠 High | Settings / Team | Team members see "Buy" prompt they can't use | 30 min |
| 09 | 🟠 High | Store UI | No frontend maxQty enforcement on input | 30 min |
| 10 | 🟡 Medium | Cart API | POST upsert silently overwrites cart quantities | 1 hr |
| 11 | 🟡 Medium | Feature Seed | Seed doesn't update existing features | 30 min |
| 12 | 🟡 Medium | Cart API | Concurrent adds can create duplicate cart items | 30 min |
| 13 | 🟡 Medium | Verify | Razorpay amount not cross-validated at verify | 2 hrs |
| 14 | 🟡 Medium | Admin | minQty > maxQty makes feature un-purchasable | 30 min |
| 15 | 🟡 Medium | Site Creation | Custom domain check has no loading UI | 20 min |
| 16 | 🟡 Medium | Cache | Feature cache gap causes price mismatch | 30 min |
| 17 | 🟡 Medium | Store UI | Quantity fallback to 1 ignores minQty | 20 min |
| 18 | 🟢 Low | Schema | Missing index on formSubmission.formName | 5 min |
| 19 | 🟢 Low | Schema | Feature type has no enum constraint | 15 min |
| 20 | 🟢 Low | Schema | featurepurchase missing updatedAt | 5 min |
| 21 | 🟢 Low | Verify | No success logging for purchases | 10 min |
| 22 | 🟢 Low | Verify | Razorpay secret not length-validated | 5 min |
| 23 | 🟢 Low | Cart | Cart not cleared when feature deactivated | 30 min |

**Total estimated fix time: ~15 hours**

---

## Recommended Fix Order

### Sprint 1 — Revenue-Critical (Day 1-2)

| Bug | Why First |
|-----|-----------|
| BUG-02 | Users exploiting currency mismatch = direct revenue loss |
| BUG-04 | Every duration purchase is recording wrong data |
| BUG-01 | ownerId manipulation is a security + billing hole |
| BUG-03 | Storage feature is non-functional in production |

### Sprint 2 — UX-Critical (Day 3-4)

| Bug | Why Next |
|-----|----------|
| BUG-05 | DB hiccup locks out paying users |
| BUG-08 | Team members confused by "Buy" prompt |
| BUG-06 | Sidebar sets wrong expectations |
| BUG-09 | Quantity validation only server-side |
| BUG-17 | Quantity fallback breaks add-to-cart |

### Sprint 3 — Integrity & Polish (Day 5-7)

| Bug | Why |
|-----|-----|
| BUG-10 | Cart overwrite surprise |
| BUG-12 | Duplicate cart items on double-click |
| BUG-13 | Payment amount cross-validation |
| BUG-14 | Admin config error bricks features |
| All Low | Schema, logging, cache cleanup |

---

*"Every bug in a payment flow is a trust-breaking event. Users who experience a checkout bug don't file a bug report — they leave and never come back."*

---
**End of Document 4 of 4**
