// Your JavaScript here
console.log('Site loaded');