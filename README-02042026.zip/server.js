// Custom server that runs Next.js + WebSocket server for live visitor tracking
const { createServer } = require("http");
const { parse } = require("url");
const next = require("next");
const { WebSocketServer } = require("ws");

const dev = process.env.NODE_ENV !== "production";
const hostname = process.env.HOSTNAME || "0.0.0.0";
const port = process.env.PORT ? parseInt(process.env.PORT) : 4000;

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

// Track live visitors per site: Map<siteSubdomain, Set<ws>>
const liveVisitors = new Map();
// Track dashboard listeners: Map<siteId, Set<ws>>
const dashboardListeners = new Map();

function getLiveCount(key) {
  return liveVisitors.get(key)?.size || 0;
}

function broadcastToListeners(siteId) {
  const listeners = dashboardListeners.get(siteId);
  if (!listeners) return;
  const count = getLiveCount(siteId);
  const msg = JSON.stringify({ type: "live_count", siteId, count });
  for (const ws of listeners) {
    if (ws.readyState === 1) ws.send(msg);
  }
}

app.prepare().then(() => {
  const server = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url, true);
      await handle(req, res, parsedUrl);
    } catch (err) {
      console.error("Error handling request:", err);
      res.statusCode = 500;
      res.end("Internal server error");
    }
  });

  const wss = new WebSocketServer({ server, path: "/ws/live" });

  wss.on("connection", (ws, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const role = url.searchParams.get("role"); // 'visitor' or 'dashboard'
    const siteId = url.searchParams.get("site");

    if (!siteId) {
      ws.close(4001, "Missing site parameter");
      return;
    }

    if (role === "visitor") {
      // Visitor on a hosted site
      if (!liveVisitors.has(siteId)) liveVisitors.set(siteId, new Set());
      liveVisitors.get(siteId).add(ws);
      broadcastToListeners(siteId);

      ws.on("close", () => {
        const set = liveVisitors.get(siteId);
        if (set) {
          set.delete(ws);
          if (set.size === 0) liveVisitors.delete(siteId);
        }
        broadcastToListeners(siteId);
      });

      // Keep alive ping every 30s
      const interval = setInterval(() => {
        if (ws.readyState === 1) ws.ping();
      }, 30000);
      ws.on("close", () => clearInterval(interval));
    } else if (role === "dashboard") {
      // Dashboard user watching live count
      if (!dashboardListeners.has(siteId))
        dashboardListeners.set(siteId, new Set());
      dashboardListeners.get(siteId).add(ws);

      // Send initial count
      const count = getLiveCount(siteId);
      ws.send(JSON.stringify({ type: "live_count", siteId, count }));

      ws.on("close", () => {
        const set = dashboardListeners.get(siteId);
        if (set) {
          set.delete(ws);
          if (set.size === 0) dashboardListeners.delete(siteId);
        }
      });
    } else {
      ws.close(4002, "Invalid role");
    }
  });

  server.listen(port, hostname, () => {
    console.log(`> LiveInSec ready on http://${hostname}:${port}`);
    console.log(
      `> WebSocket live tracking on ws://${hostname}:${port}/ws/live`,
    );
  });
});
