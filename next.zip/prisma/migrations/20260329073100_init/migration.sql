-- CreateTable
CREATE TABLE `appconfig` (
    `id` VARCHAR(191) NOT NULL DEFAULT 'platform',
    `enabledOnboardingFields` TEXT NOT NULL,
    `occupationOptions` TEXT NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `emailverificationtoken` (
    `id` VARCHAR(191) NOT NULL,
    `token` VARCHAR(191) NOT NULL,
    `expiresAt` DATETIME(3) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `emailverificationtoken_token_key`(`token`),
    INDEX `emailverificationtoken_expiresAt_idx`(`expiresAt`),
    INDEX `emailverificationtoken_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `FormSubmission` (
    `id` VARCHAR(191) NOT NULL,
    `formName` VARCHAR(191) NOT NULL DEFAULT 'default',
    `data` TEXT NOT NULL,
    `ipAddress` VARCHAR(191) NULL,
    `userAgent` VARCHAR(191) NULL,
    `siteId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `FormSubmission_siteId_createdAt_idx`(`siteId`, `createdAt`),
    INDEX `FormSubmission_siteId_idx`(`siteId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `passwordresettoken` (
    `id` VARCHAR(191) NOT NULL,
    `token` VARCHAR(191) NOT NULL,
    `expiresAt` DATETIME(3) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `passwordresettoken_token_key`(`token`),
    INDEX `passwordresettoken_expiresAt_idx`(`expiresAt`),
    INDEX `passwordresettoken_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `payment` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `planSlug` VARCHAR(191) NOT NULL,
    `amount` INTEGER NOT NULL,
    `currency` VARCHAR(191) NOT NULL DEFAULT 'USD',
    `status` VARCHAR(191) NOT NULL DEFAULT 'pending',
    `billingPeriod` VARCHAR(191) NOT NULL DEFAULT 'monthly',
    `provider` VARCHAR(191) NOT NULL DEFAULT 'razorpay',
    `providerOrderId` VARCHAR(191) NULL,
    `providerPaymentId` VARCHAR(191) NULL,
    `providerSignature` VARCHAR(191) NULL,
    `invoiceUrl` VARCHAR(191) NULL,
    `startsAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `expiresAt` DATETIME(3) NOT NULL,
    `transactionId` VARCHAR(191) NULL,
    `notes` TEXT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `payment_providerOrderId_key`(`providerOrderId`),
    UNIQUE INDEX `payment_providerPaymentId_key`(`providerPaymentId`),
    INDEX `payment_planSlug_idx`(`planSlug`),
    INDEX `payment_status_idx`(`status`),
    INDEX `payment_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `plan` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `slug` VARCHAR(191) NOT NULL,
    `priceMonthly` INTEGER NOT NULL DEFAULT 0,
    `priceYearly` INTEGER NOT NULL DEFAULT 0,
    `priceMonthlyInr` INTEGER NOT NULL DEFAULT 0,
    `priceYearlyInr` INTEGER NOT NULL DEFAULT 0,
    `maxSites` INTEGER NOT NULL DEFAULT 3,
    `maxStorageMB` INTEGER NOT NULL DEFAULT 10,
    `maxSubmissions` INTEGER NOT NULL DEFAULT 1000,
    `maxFileSizeMB` INTEGER NOT NULL DEFAULT 10,
    `customDomain` BOOLEAN NOT NULL DEFAULT false,
    `formEmails` BOOLEAN NOT NULL DEFAULT false,
    `webhooks` BOOLEAN NOT NULL DEFAULT false,
    `analytics` BOOLEAN NOT NULL DEFAULT false,
    `teamMembers` INTEGER NOT NULL DEFAULT 0,
    `priority` INTEGER NOT NULL DEFAULT 0,
    `isActive` BOOLEAN NOT NULL DEFAULT true,
    `features` TEXT NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `plan_name_key`(`name`),
    UNIQUE INDEX `plan_slug_key`(`slug`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `site` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `subdomain` VARCHAR(191) NOT NULL,
    `customDomain` VARCHAR(191) NULL,
    `customDomainVerified` BOOLEAN NOT NULL DEFAULT false,
    `apiKey` VARCHAR(191) NOT NULL,
    `deployPath` VARCHAR(191) NOT NULL,
    `isActive` BOOLEAN NOT NULL DEFAULT true,
    `allowedOrigins` VARCHAR(191) NOT NULL DEFAULT '[]',
    `honeypotField` VARCHAR(191) NOT NULL DEFAULT 'company',
    `submissionRateLimit` INTEGER NOT NULL DEFAULT 10,
    `webhookUrl` VARCHAR(191) NULL,
    `notifyEmail` VARCHAR(191) NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `site_subdomain_key`(`subdomain`),
    UNIQUE INDEX `site_customDomain_key`(`customDomain`),
    UNIQUE INDEX `site_apiKey_key`(`apiKey`),
    INDEX `site_apiKey_idx`(`apiKey`),
    INDEX `site_customDomain_idx`(`customDomain`),
    INDEX `site_subdomain_idx`(`subdomain`),
    INDEX `site_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `sitevisit` (
    `id` VARCHAR(191) NOT NULL,
    `path` VARCHAR(191) NOT NULL,
    `ipHash` VARCHAR(191) NOT NULL,
    `countryCode` VARCHAR(191) NULL,
    `referrer` VARCHAR(191) NULL,
    `userAgent` VARCHAR(191) NULL,
    `siteId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `sitevisit_createdAt_idx`(`createdAt`),
    INDEX `sitevisit_siteId_createdAt_idx`(`siteId`, `createdAt`),
    INDEX `sitevisit_siteId_idx`(`siteId`),
    INDEX `sitevisit_siteId_path_idx`(`siteId`, `path`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `user` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NOT NULL,
    `email` VARCHAR(191) NOT NULL,
    `password` VARCHAR(191) NULL,
    `phone` VARCHAR(191) NULL,
    `occupation` VARCHAR(191) NULL,
    `image` VARCHAR(191) NULL,
    `phoneVerifiedAt` DATETIME(3) NULL,
    `countryCode` VARCHAR(191) NULL,
    `countryName` VARCHAR(191) NULL,
    `emailVerifiedAt` DATETIME(3) NULL,
    `onboardingCompletedAt` DATETIME(3) NULL,
    `isBlocked` BOOLEAN NOT NULL DEFAULT false,
    `role` VARCHAR(191) NOT NULL DEFAULT 'user',
    `planId` VARCHAR(191) NULL,
    `planSlug` VARCHAR(191) NOT NULL DEFAULT 'free',
    `subscriptionStatus` VARCHAR(191) NOT NULL DEFAULT 'trial',
    `billingPeriod` VARCHAR(191) NULL,
    `billingCurrency` VARCHAR(191) NOT NULL DEFAULT 'USD',
    `currentPeriodEndsAt` DATETIME(3) NULL,
    `trialEndsAt` DATETIME(3) NULL,
    `ownerId` VARCHAR(191) NULL,
    `memberPermissions` VARCHAR(191) NOT NULL DEFAULT '[]',
    `provider` VARCHAR(191) NOT NULL DEFAULT 'credentials',
    `providerAccountId` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `user_email_key`(`email`),
    INDEX `user_email_idx`(`email`),
    INDEX `user_ownerId_idx`(`ownerId`),
    INDEX `user_planId_idx`(`planId`),
    INDEX `user_planSlug_idx`(`planSlug`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `emailverificationtoken` ADD CONSTRAINT `emailverificationtoken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `FormSubmission` ADD CONSTRAINT `FormSubmission_siteId_fkey` FOREIGN KEY (`siteId`) REFERENCES `site`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `passwordresettoken` ADD CONSTRAINT `passwordresettoken_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `payment` ADD CONSTRAINT `payment_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `site` ADD CONSTRAINT `site_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `sitevisit` ADD CONSTRAINT `sitevisit_siteId_fkey` FOREIGN KEY (`siteId`) REFERENCES `site`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `user` ADD CONSTRAINT `user_ownerId_fkey` FOREIGN KEY (`ownerId`) REFERENCES `user`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `user` ADD CONSTRAINT `user_planId_fkey` FOREIGN KEY (`planId`) REFERENCES `plan`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;
