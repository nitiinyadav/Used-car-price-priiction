# Architecture

## System Overview

```
┌─────────────────────────────────────────────────────┐
│                    Client Browser                     │
│                                                       │
│  ┌──────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Landing   │  │  Dashboard   │  │  Deployed    │  │
│  │ Page      │  │  (Auth'd)    │  │  Sites       │  │
│  └──────────┘  └──────────────┘  └──────────────┘  │
└───────────────────────┬─────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│                  Next.js Application                  │
│                                                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │ Middleware   │  │ App Router  │  │ API Routes  │ │
│  │ (Subdomain  │  │ (Pages &    │  │ (REST API)  │ │
│  │  Routing)   │  │  Layouts)   │  │             │ │
│  └─────────────┘  └─────────────┘  └─────────────┘ │
│                                                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │ NextAuth    │  │ Prisma ORM  │  │ Storage     │ │
│  │ (JWT Auth)  │  │ (Database)  │  │ (Files)     │ │
│  └─────────────┘  └─────────────┘  └─────────────┘ │
└───────────────────────┬───────────────┬─────────────┘
                        │               │
                        ▼               ▼
                  ┌──────────┐   ┌──────────┐
                  │  SQLite  │   │  uploads/ │
                  │ Database │   │  (files)  │
                  └──────────┘   └──────────┘
```

## Request Flow

### 1. Landing Page & Dashboard
```
Browser → Next.js Middleware → App Router → Server Component → Prisma → DB
```

### 2. Site Deployment (Upload)
```
Browser → POST /api/sites (FormData)
  → Auth check (getServerSession)
  → Validate inputs (subdomain, file)
  → Create Site record (Prisma)
  → Extract ZIP (AdmZip → uploads/{siteId}/)
  → Return site details
```

### 3. Serving Deployed Sites
```
Browser → mysite.staticdrop.com/page.html
  → Middleware detects subdomain
  → Rewrites to /api/serve/mysite/page.html
  → Looks up site in DB by subdomain
  → Reads file from uploads/{siteId}/page.html
  → Returns with correct Content-Type
```

For local development (no subdomains):
```
Browser → localhost:3000/site/mysite
  → Redirects to /api/serve/mysite/
  → Same file serving logic
```

For local development with real subdomain-style testing:
```
Browser → mysite.localhost:3000
  → Middleware detects subdomain
  → Rewrites to /api/serve/mysite/
  → Same file serving logic
```

For a connected custom domain:
```
Browser → www.example.com
  → Middleware treats hostname as custom domain
  → Rewrites to /api/serve/_custom?domain=www.example.com
  → Looks up site in DB by customDomain
  → Serves files from uploads/{siteId}/
```

### 4. Form Submission
```
User's website visitor submits form
  → POST /api/forms/{apiKey}
  → Look up site by API key
  → Parse form data (JSON or form-encoded)
  → Store in FormSubmission table
  → Return success (JSON or HTML redirect)
```

## Database Schema

### User
| Field     | Type     | Notes               |
|-----------|----------|---------------------|
| id        | String   | CUID primary key    |
| name      | String   | Display name        |
| email     | String   | Unique, login email |
| password  | String   | bcrypt hash         |
| plan      | String   | "free" default      |
| createdAt | DateTime | Auto-set            |
| updatedAt | DateTime | Auto-updated        |

### Site
| Field        | Type     | Notes                      |
|--------------|----------|----------------------------|
| id           | String   | CUID primary key           |
| name         | String   | Display name               |
| subdomain    | String   | Unique, used in URL        |
| customDomain | String?  | Optional custom domain     |
| apiKey       | String   | Unique, for form API       |
| deployPath   | String   | Path to extracted files    |
| isActive     | Boolean  | Toggle site on/off         |
| userId       | String   | Foreign key to User        |
| createdAt    | DateTime | Auto-set                   |
| updatedAt    | DateTime | Auto-updated               |

### FormSubmission
| Field     | Type     | Notes                      |
|-----------|----------|----------------------------|
| id        | String   | CUID primary key           |
| formName  | String   | Default "default"          |
| data      | String   | JSON stringified form data |
| ipAddress | String?  | Submitter's IP             |
| userAgent | String?  | Submitter's browser        |
| siteId    | String   | Foreign key to Site        |
| createdAt | DateTime | Auto-set                   |

## File Storage

Deployed sites are stored in the `uploads/` directory:

```
uploads/
├── {siteId1}/
│   ├── index.html
│   ├── styles.css
│   ├── script.js
│   └── images/
│       └── logo.png
├── {siteId2}/
│   ├── index.html
│   └── ...
```

### ZIP Extraction Logic

1. Accept ZIP file upload
2. Detect if ZIP has a single root folder (common when zipping a folder)
3. If single root folder: extract contents from inside it
4. If no root folder: extract directly
5. Skip hidden files (`.DS_Store`, etc.) and `__MACOSX` folders
6. Validate paths to prevent directory traversal attacks
7. Write files to `uploads/{siteId}/`

## Authentication

- **Provider**: NextAuth.js with Credentials provider
- **Strategy**: JWT (stateless)
- **Password**: bcrypt with 12 salt rounds
- **Session**: JWT token in httpOnly cookie

## Security

- **Path traversal prevention**: All file paths are normalized and validated
- **Auth on all dashboard/API routes**: `getServerSession()` checks
- **CORS on form API**: Open CORS for form submissions only
- **Input validation**: Subdomain format, email format, file type/size
- **SQL injection protection**: Prisma ORM with parameterized queries
- **XSS protection**: React's built-in escaping + security headers on served files
- **CSRF**: NextAuth handles CSRF tokens
- **Open redirect prevention**: Redirect URLs validated for http/https protocol

## Scaling Considerations

For production deployment beyond SQLite + local files:

1. **Database**: Migrate from SQLite to PostgreSQL (change Prisma datasource)
2. **File Storage**: Move from local filesystem to S3/R2/Cloudflare
3. **CDN**: Put deployed sites behind a CDN (Cloudflare, CloudFront)
4. **Wildcard SSL**: Use a wildcard certificate for `*.staticdrop.com`
5. **Rate Limiting**: Add rate limiting on form submission API
6. **Queue**: Use a job queue for ZIP extraction (for large files)
