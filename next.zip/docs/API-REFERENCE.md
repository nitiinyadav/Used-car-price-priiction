# API Reference

All API endpoints are under `/api/`. Authentication is via NextAuth.js JWT cookies (automatic when logged in via the dashboard).

## Authentication

### Register
```
POST /api/auth/register
Content-Type: application/json
```

**Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepassword"
}
```

**Response (201):**
```json
{
  "user": {
    "id": "clx...",
    "name": "John Doe",
    "email": "john@example.com"
  }
}
```

**Errors:**
- `400` — Missing fields or password too short
- `409` — Email already registered

### Login
```
POST /api/auth/callback/credentials
Content-Type: application/json
```

Handled by NextAuth. Use the `signIn('credentials', { email, password })` method on the client.

### Update Profile
```
PUT /api/auth/profile
Content-Type: application/json
Authorization: Session cookie (automatic)
```

**Body:**
```json
{
  "name": "New Name"
}
```

### Change Password
```
PUT /api/auth/password
Content-Type: application/json
Authorization: Session cookie (automatic)
```

**Body:**
```json
{
  "currentPassword": "oldpassword",
  "newPassword": "newsecurepassword"
}
```

---

## Sites

### List Sites
```
GET /api/sites
Authorization: Session cookie
```

**Response:**
```json
{
  "sites": [
    {
      "id": "clx...",
      "name": "My Portfolio",
      "subdomain": "my-portfolio",
      "customDomain": null,
      "apiKey": "sd_abc123...",
      "isActive": true,
      "createdAt": "2024-01-15T...",
      "updatedAt": "2024-01-15T...",
      "_count": { "submissions": 12 }
    }
  ]
}
```

### Create Site (Deploy)
```
POST /api/sites
Content-Type: multipart/form-data
Authorization: Session cookie
```

**FormData fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Display name for the site |
| subdomain | string | Yes | Subdomain (lowercase, 3-63 chars) |
| customDomain | string | No | Custom domain (e.g., www.example.com) |
| file | File | Yes | ZIP file containing website files |

**Response (201):**
```json
{
  "site": {
    "id": "clx...",
    "name": "My Portfolio",
    "subdomain": "my-portfolio",
    "apiKey": "sd_abc123...",
    ...
  }
}
```

**Errors:**
- `400` — Invalid input or ZIP file
- `403` — Site limit reached
- `409` — Subdomain or domain already taken

### Get Site Details
```
GET /api/sites/{id}
Authorization: Session cookie
```

### Update Site
```
PUT /api/sites/{id}
Content-Type: application/json
Authorization: Session cookie
```

**Body (all fields optional):**
```json
{
  "name": "New Name",
  "customDomain": "www.example.com",
  "isActive": false
}
```

### Delete Site
```
DELETE /api/sites/{id}
Authorization: Session cookie
```

Permanently deletes the site, all files, and all form submissions.

### Redeploy Site
```
POST /api/sites/{id}/redeploy
Content-Type: multipart/form-data
Authorization: Session cookie
```

**FormData fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| file | File | Yes | New ZIP file |

Replaces all existing site files with the new upload.

---

## Form Submissions API

### Submit Form Data (Public)
```
POST /api/forms/{apiKey}
```

This endpoint is **public** (no authentication required) and supports CORS. It's designed to be called from deployed websites.

**Supported Content Types:**
- `application/json`
- `application/x-www-form-urlencoded`
- `multipart/form-data`

**JSON Example:**
```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "message": "Hello!",
  "_formName": "contact",
  "_redirect": "https://mysite.com/thanks"
}
```

**HTML Form Example:**
```html
<form action="https://staticdrop.com/api/forms/sd_abc123" method="POST">
  <input name="name" required />
  <input name="email" type="email" required />
  <textarea name="message"></textarea>
  <input type="hidden" name="_redirect" value="https://mysite.com/thanks" />
  <button type="submit">Send</button>
</form>
```

**Special Fields (prefixed with `_`):**
| Field | Description |
|-------|-------------|
| `_redirect` | URL to redirect to after submission (HTML forms) |
| `_formName` | Label for organizing submissions (default: "default") |

**JSON Response (201):**
```json
{
  "success": true,
  "message": "Form submitted successfully",
  "id": "clx..."
}
```

**HTML Form Response:**
- If `_redirect` is set: HTTP 303 redirect to the URL
- Otherwise: Shows a "Thank You" success page

**Errors:**
- `404` — Invalid API key
- `403` — Site is inactive
- `429` — Submission limit reached

### Get Submissions (Authenticated)
```
GET /api/submissions/{siteId}?page=1&limit=50
Authorization: Session cookie
```

**Response:**
```json
{
  "submissions": [
    {
      "id": "clx...",
      "formName": "contact",
      "data": "{\"name\":\"Jane\",\"email\":\"jane@example.com\"}",
      "ipAddress": "1.2.3.4",
      "userAgent": "Mozilla/5.0...",
      "createdAt": "2024-01-15T..."
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 123,
    "totalPages": 3
  }
}
```

---

## Static File Serving

### Serve Site Files
```
GET /api/serve/{subdomain}/{...path}
```

Public endpoint. Serves static files from deployed sites with correct MIME types and caching headers.

- Defaults to `index.html` for directory paths
- Tries `.html` extension if exact file not found
- Returns 404 page for missing files
