# StaticDrop — Complete Idea & Vision

## The Problem

Millions of people know how to build websites with HTML, CSS, and JavaScript. They create beautiful portfolios, landing pages, personal blogs, and small business websites. But when it comes to putting that website online, they hit a wall:

1. **Server complexity** — Setting up hosting, configuring web servers (Nginx, Apache), managing SSL certificates
2. **Overkill solutions** — Buying a VPS or shared hosting for a single-page portfolio is expensive and wasteful
3. **CLI barriers** — Tools like Netlify CLI or Vercel CLI require terminal comfort that not all developers have
4. **Cost** — Traditional hosting costs $5-15/month for what might be a simple 3-file website

## The Solution: StaticDrop

StaticDrop is a web-based platform where users can:

1. **Register** for a free account
2. **Upload** a ZIP file containing their HTML/CSS/JS website
3. **Get a live URL** instantly (`yoursite.staticdrop.com`)
4. **Optionally** connect their own custom domain
5. **Collect form data** using a built-in form API (no backend needed)
6. **Manage** everything through a clean dashboard

### Target Audience

- **Students** deploying portfolio websites for job applications
- **Freelancers** showcasing their work
- **Small business owners** who had someone build them a static website
- **Developers** who want zero-config deployment for small projects
- **Anyone** with an HTML file who wants it online

## Core Features

### 1. One-Click Deployment
Upload a ZIP file containing your website (HTML, CSS, JS, images, etc.) and it's live in seconds. No build steps, no configuration, no CLI tools.

### 2. Free Subdomain
Every site gets a free subdomain: `your-site-name.staticdrop.com`. Users choose their subdomain during deployment.

### 3. Custom Domain Support
Users can connect their own registered domain by pointing a CNAME record to StaticDrop. The platform detects the custom domain and serves the correct site.

### 4. Form Collection API
Every deployed site gets a unique API key. Users can add a form action pointing to `https://staticdrop.com/api/forms/YOUR_API_KEY` and all form submissions are collected and viewable in the dashboard. This solves the #1 problem with static sites — "how do I handle my contact form?"

Supports:
- Standard HTML form POST
- AJAX/fetch JSON submissions
- Redirect after submit (configurable)
- CSV export of submissions

### 5. Dashboard
A clean admin panel where users can:
- See all their deployed sites
- View form submissions for each site
- Re-deploy sites with new files
- Manage custom domains
- Export submissions to CSV
- Delete sites

### 6. Site Management
- **Re-deploy**: Upload a new ZIP to update the site without changing the URL
- **Activate/Deactivate**: Toggle a site on/off without deleting it
- **Delete**: Remove a site and all its data permanently

## Business Model

### Free Tier
- 3 sites
- 10MB per site
- 1,000 form submissions per site
- Free subdomain

### Pro Tier (Future)
- Unlimited sites
- 100MB per site
- 100,000 form submissions per site
- Custom domains with auto-SSL
- Priority support
- Remove StaticDrop branding
- Analytics

### Enterprise Tier (Future)
- Self-hosted option
- Custom branding
- Team management
- API access
- SLA

## Competitive Landscape

| Feature | StaticDrop | Netlify | GitHub Pages | Vercel |
|---------|-----------|---------|-------------|--------|
| Upload ZIP (no CLI) | ✅ | ❌ (drag-drop but limited) | ❌ | ❌ |
| Built-in form collection | ✅ | ✅ (paid) | ❌ | ❌ |
| No Git required | ✅ | ❌ | ❌ | ❌ |
| Free subdomain | ✅ | ✅ | ✅ | ✅ |
| Custom domain | ✅ | ✅ | ✅ | ✅ |
| Target: non-technical | ✅ | ❌ | ❌ | ❌ |

## Technical Architecture

- **Framework**: Next.js 14 (App Router, JavaScript)
- **Database**: SQLite via Prisma (PostgreSQL for production)
- **Authentication**: NextAuth.js with credentials
- **File Storage**: Local filesystem (S3/R2 for production)
- **Styling**: Tailwind CSS

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed technical documentation.

## Future Roadmap

### Phase 1 (MVP) ✅
- User registration and authentication
- ZIP upload and deployment
- Free subdomain
- Form collection API
- Dashboard with site management
- Form submissions viewer with CSV export

### Phase 2
- Custom domain with auto-SSL (Let's Encrypt)
- Site analytics (page views, unique visitors)
- Multiple environment variables support
- File browser (view deployed files)

### Phase 3
- Team collaboration
- GitHub integration (auto-deploy on push)
- Custom 404 pages
- Password-protected sites
- A/B testing

### Phase 4
- Self-service billing (Stripe)
- CDN for global performance
- Webhooks for form submissions
- API for programmatic deployment
- White-label option

npm install
npx prisma db push
npm run db:seed    # optional: creates demo user
npm run dev