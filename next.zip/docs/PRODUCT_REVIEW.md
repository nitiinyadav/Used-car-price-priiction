# 🧾 SaaS Application Review & Improvement Plan

**Product:** StaticDrop  
**Review Date:** March 26, 2026  
**Reviewer Perspective:** Senior SaaS Product Expert, UX Strategist & Growth Consultant

---

## 1. 🔍 Application Overview

**What it does:**  
StaticDrop is a static website hosting SaaS that allows users to deploy plain HTML/CSS/JS websites by uploading a ZIP file or building directly in a browser-based code editor. Each site gets a free subdomain (`yoursite.staticdrop.com`), optional custom domain support, and a built-in form collection API so static sites can receive contact form submissions without a backend.

**Target Audience (inferred):**
- Students building portfolios for job applications
- Freelancers and designers showcasing work
- Small business owners with a static site someone built for them
- Hobbyist developers wanting zero-config hosting for small projects
- Non-technical users who know basic HTML but not servers

**Core Value Proposition:**  
"Deploy a website in seconds without CLI tools, Git, servers, or any DevOps knowledge — just upload a ZIP."

---

## 2. 👤 Target Audience Analysis

### Who benefits most?
| Segment | Fit | Why |
|---------|-----|-----|
| **CS students / bootcamp grads** | ⭐⭐⭐⭐⭐ | Need to deploy portfolio fast, don't want to learn hosting |
| **Freelance designers** | ⭐⭐⭐⭐ | Quick showcase for client work, no DevOps knowledge needed |
| **Small business owners** | ⭐⭐⭐⭐ | Someone built them a site, they just need it online |
| **Experienced developers** | ⭐⭐ | Already use Vercel/Netlify/Cloudflare Pages — StaticDrop offers less |
| **Agencies** | ⭐⭐⭐ | Could use for quick client landing pages, but would need white-label |

### Audience Mismatches

1. **3-day free trial is too aggressive.** Your primary audience (students, freelancers) needs time to evaluate. They'll upload a portfolio, share it in a job application, and then find out it goes dark after 3 days. This will generate resentment, not conversions. Netlify gives unlimited free hosting. You're competing against *free permanent hosting* with a 3-day trial.

2. **Enterprise plan ($99/month) targets a completely different audience** than students uploading portfolios. The jump from "student portfolio" to "enterprise with 500 sites and team management" is enormous. There's no product-market fit for both in a single offering without segmented messaging.

3. **The "Build Here" editor targets developers**, but the marketing copy targets non-technical users ("No CLI tools, no complex setup"). These audiences want different things — designers want Canva-like simplicity, not a VS Code clone.

### Recommendations
- Extend the free tier to be **permanent** (like Netlify/Vercel) with hard limits, not time-limited. Make the trial a trial of *paid features* (custom domains, analytics), not of basic hosting.
- Create **separate landing page messaging** for "Student/Portfolio" vs "Freelancer/Agency" vs "Small Business" segments.
- Drop the "Build Here" editor from marketing messaging (keep it as a power-user feature); lead with the dead-simple ZIP upload.

---

## 3. 💡 Value Proposition Evaluation

### What's Clear and Compelling
- **"Upload ZIP → Live website"** — This is genuinely the fastest path from local files to a deployed website. Faster than Netlify's CLI, faster than GitHub Pages' Git workflow. This is your moat for non-developers.
- **Built-in form collection** — This is underrated. Static site users universally ask "how do I add a contact form?" You solve this natively. Formspree charges $8/month. You bundle it for free.
- **No Git/CLI required** — For the target audience, this is the real differentiator. Vercel/Netlify assume Git literacy.

### What's Weak or Missing
1. **No SSL/HTTPS** — Not mentioned anywhere, and the middleware serves over HTTP. In 2026, this is a dealbreaker. Chrome marks HTTP sites as "Not Secure". Any user sharing their portfolio link looks unprofessional.
2. **No CDN** — Sites are served from a single server's filesystem. A portfolio shared on LinkedIn that gets 500 clicks simultaneously will be slow or crash.
3. **SQLite in production** — The architecture doc mentions "PostgreSQL for production" but the actual codebase only has SQLite. This isn't production-ready for concurrent writes.
4. **Local filesystem storage** — Not durable, not scalable. One server crash = all sites gone. S3/R2 is mentioned as future but not implemented.
5. **No preview before deploy** — User uploads ZIP and hopes it works. There's no preview step to visually verify the site before it goes live on their subdomain.

### Value Proposition Verdict
The core idea is **strong and differentiated** for non-technical users. But the **infrastructure is not production-ready**, which means the value proposition can't actually be delivered reliably to paying customers yet.

---

## 4. ⚙️ Feature Review

### Feature: ZIP Upload & Deploy
- 👍 Fast, simple, exactly what the audience needs
- 👍 Handles single-folder ZIPs correctly (flattens root directories)
- 👎 No preview/staging step before going live
- 👎 10MB limit is tight (a few high-res images and you're done)
- 🚀 Add a "Preview" step showing the deployed site in an iframe before committing. Increase free tier to 25MB.

### Feature: Build Here Editor (VS Code-like)
- 👍 Looks impressive, starter templates are a nice touch
- 👍 Dark theme with file tree, tabs, and line numbers feels polished
- 👎 No syntax highlighting (just monochrome text in a textarea)
- 👎 No live preview pane — user types code blind and has to deploy to see it
- 👎 No auto-save, no undo history, no keyboard shortcuts (Ctrl+S)
- 🚀 Add a split-pane live preview (left: code, right: rendered output). Add Ctrl+S shortcut for saving. Consider using Monaco Editor (VS Code's actual editor) for proper syntax highlighting.

### Feature: Subdomain Hosting
- 👍 Works well with middleware rewriting
- 👍 Subdomain validation is solid (reserved subdomains, format checks)
- 👎 No HTTPS — subdomains served over HTTP only
- 👎 Subdomain squatting — anyone can register `google.staticdrop.com` with no abuse detection
- 🚀 Implement HTTPS (via Caddy or Let's Encrypt). Add a subdomain moderation/blocklist beyond just reserved words.

### Feature: Custom Domain
- 👍 CNAME detection logic in middleware is clean
- 👎 No automated SSL for custom domains
- 👎 No DNS verification step — user has no way to confirm their CNAME is correct from the dashboard
- 👎 No wildcard domain support
- 🚀 Add a "Verify DNS" button in site settings. Implement auto-SSL via Let's Encrypt or Caddy.

### Feature: Form Collection API
- 👍 Brilliant differentiator — solves a real pain point
- 👍 Honeypot spam protection, rate limiting, CORS origin control
- 👍 Supports both HTML form POST and JSON AJAX
- 👍 CSV export capability
- 👎 No email notifications when a form is submitted
- 👎 No webhook integration (can't push data to Zapier, Slack, etc.)
- 👎 No file upload support in forms
- 👎 No auto-responder (can't send confirmation email to submitter)
- 🚀 **Email notifications are the #1 missing feature.** Every form submission tool (Formspree, Basin, Getform) sends email alerts. Without this, users must manually check the dashboard, which they won't do. Add webhook support as a paid-tier feature for Zapier/Slack integration.

### Feature: Analytics
- 👍 Basic visit tracking with country detection
- 👍 IP hashing for privacy
- 👎 No time-series charts (user can't see trends)
- 👎 No referrer tracking (where did visitors come from?)
- 👎 No page-level breakdown (which pages are most popular?)
- 🚀 Add a simple chart showing visits over time (last 7/30 days). Add referrer tracking. These make analytics actually *useful* rather than just a number.

### Feature: Multi-Step Registration + Onboarding
- 👍 Clean two-step flow (email/password → profile onboarding)
- 👍 Skip option for onboarding is good
- 👎 No social login (Google, GitHub) — your audience is students and devs who expect this
- 👎 Email verification flow generates a link you have to copy — no actual email is sent
- 🚀 Add Google OAuth and GitHub OAuth. Implement actual email sending (SendGrid/Resend) for verification.

### Feature: Upgrade/Payment (Razorpay)
- 👍 Clean UPI support for Indian users
- 👍 Currency auto-detection (INR vs USD) is smart
- 👍 Billing period toggle (monthly/yearly)
- 👎 Only Razorpay — no Stripe for international users. A US/EU student can't pay.
- 👎 No receipt emails after payment
- 🚀 Add Stripe for international payments. Send receipt/invoice emails after successful payment.

### Feature: Team Management (Enterprise)
- 👍 Granular permission system (view_submissions, create_sites, edit_files, etc.)
- 👎 No way to remove a team member after creation
- 👎 No way for team members to change their password independently
- 👎 No audit log of team member actions
- 🚀 Add team member deletion and password reset. Consider if this feature is actually needed at MVP — it adds complexity for a feature few will use.

### Feature: Admin Panel (Superadmin)
- 👍 Revenue tracking, user management, plan editing
- 👍 Can block users, change plans
- 👎 No platform health monitoring (error rates, storage usage)
- 👎 No content moderation tools (sites hosting malicious content)
- 🚀 Add site content scanning/flagging and abuse reporting.

---

## 5. 🧠 User Experience (UX) & User Journey

### Onboarding Flow
```
Landing → Register (email+password) → Onboarding (name/country/occupation) → Dashboard
```
**Assessment:** Clean and fast. The simplified email+password step is good. The onboarding step with skip option respects user time. **Score: 8/10**

### First-Time Use (Deploy First Site)
```
Dashboard → "Deploy New Site" → Step 1: Name/Subdomain → Step 2: Upload or Build → Step 3: Review → Deploy
```
**Assessment:** The multi-step wizard is much better than a single form. The choice between "Upload ZIP" and "Build Here" is clear. However:
- No guidance on what "ZIP" means for non-technical users (show an example?)
- No sample site to deploy instantly ("Deploy our demo portfolio in one click")
- After deploy, user lands on site detail page but doesn't see their actual live site
- **Friction point:** User has to mentally figure out their site URL. Show the live URL prominently with a big "Visit Your Site" button.

**Score: 6/10**

### Core Workflow (Managing Sites)
```
Dashboard → My Sites → Click Site → Tabs: Overview | Submissions | Analytics | Files | Settings
```
**Assessment:** The tab navigation is logical. However:
- Site overview page doesn't show the site itself (no screenshot/preview)
- Submissions inbox lacks real-time indicators (no "New" badge)
- File editor is powerful but disconnected from the live site (edit → save → manually visit URL to check)

**Score: 7/10**

### Retention Loop
**This is the weakest link.** Currently there is:
- ❌ No email notifications for form submissions
- ❌ No weekly digest email ("Your sites got 34 visitors this week")
- ❌ No "new submission" indicator on the dashboard
- ❌ No mobile experience consideration
- ❌ No integrations (webhook, Zapier) that would embed StaticDrop into workflows

After the initial excitement of deploying, users have **zero reason to return to the dashboard** unless they manually decide to check form submissions. This is a retention death spiral.

**Score: 3/10**

### Key Friction Points
1. **Dead end after deploy** — No celebration, no "share your site" prompt, no social sharing
2. **3-day trial creates panic, not value** — User deploys portfolio Monday, shares link Tuesday, link dies Wednesday
3. **No notifications** — The product is silent after deployment
4. **Settings page has "Manage plan →" but billing is on separate `/upgrade` page** — Navigation split
5. **No "Getting Started" checklist** — New users don't know about form collection, custom domains, analytics

### UX Improvements
1. **Post-deploy celebration screen** — Show confetti, show the live URL, "Share on LinkedIn/Twitter" buttons, "Add a form to your site" tutorial link
2. **Getting Started checklist on dashboard** — "✅ Deploy first site / ⬜ Add a contact form / ⬜ Connect custom domain / ⬜ View your analytics"
3. **New submission badge** — Show unread submission count in sidebar
4. **Weekly email digest** — "Your sites received X visitors and Y form submissions this week"

---

## 6. 🧪 Functionality & Logic Testing

### Critical Issues Found

1. **Trial expiry kills live sites without warning email.** The billing.js auto-downgrades expired subscriptions, and site-security.js `isAccessSuspended()` blocks access. A student's portfolio link in a job application goes dead silently. **This will generate negative word-of-mouth and potentially destroy the product's reputation.**

2. **No actual email sending.** The email verification generates a URL but doesn't send it. This means:
   - Email verification is effectively fake (user must manually copy the URL)
   - No password reset flow exists
   - No form submission notifications
   - No payment receipts

3. **Payment verified but no receipt.** After Razorpay payment succeeds, the user's plan is upgraded but there's no email confirmation, no downloadable invoice, no receipt page. In India, businesses need GST invoices. This is a legal compliance issue.

4. **Race condition in site creation.** Between checking subdomain availability with `findUnique` and creating the site with `prisma.site.create`, another request could claim the same subdomain. Needs a unique constraint try/catch.

5. **Editor files have no size limit.** The ZIP upload checks `MAX_UPLOAD_SIZE_MB`, but the "Build Here" editor files bypass this completely. A user could paste megabytes of text into the editor.

6. **No password reset flow.** If a user forgets their password, they're locked out permanently. This is a basic auth requirement missing entirely.

7. **Redeploy doesn't preserve form submissions.** The redeploy replaces all files, which is correct. But the UX doesn't make this clear — users might think redeploy deletes their form data too (it doesn't, but anxiety exists).

8. **Team member passwords are set by the owner.** There's no flow for team members to set their own passwords. The owner knows everyone's passwords. This is a security issue for enterprise users.

### Edge Cases Missing
- What happens when a user deletes their account? (No account deletion exists)
- What happens when storage quota is exceeded mid-upload?
- What if a user uploads a ZIP with 10,000 tiny files? (Potential filesystem issue)
- Custom domain pointed but site deleted — returns error instead of friendly message
- Concurrent file edits by team members — last-write-wins with no conflict detection

### Redundant Steps
- The register API detects country from request headers, but the onboarding step asks for country again. Either auto-fill it or don't ask twice.
- Settings page shows "Country: Not set" with a disabled field — if auto-detected at registration, why is it empty?

---

## 7. 💰 Monetization & Pricing Strategy

### Current Pricing
| Plan | Monthly (USD) | Monthly (INR) | Sites | Storage | Submissions |
|------|---------------|---------------|-------|---------|-------------|
| Free | $0 | ₹0 | 3 | 10 MB | 1,000 |
| Starter | $9 | ₹799 | 10 | 50 MB | 10,000 |
| Pro | $29 | ₹1,999 | 50 | 200 MB | 100,000 |
| Enterprise | $99 | ₹5,999 | 500 | 1 GB | 1,000,000 |

### Is This Product Easy to Sell?
**Not yet.** Here's why:

1. **Free alternatives exist.** Netlify, Vercel, and GitHub Pages all offer free static hosting with HTTPS, CDN, and custom domains. StaticDrop's free tier is *worse* (3-day trial, no HTTPS, no CDN) while the paid tiers offer *less* than what competitors give for free.

2. **No HTTPS = no trust.** Users won't share a portfolio link that Chrome flags as "Not Secure." This alone prevents word-of-mouth growth.

3. **The form API is the money-maker, not hosting.** Hosting is commoditized. Form collection is where the value is. But it's marketed as a secondary feature.

### Recommended Pricing Strategy

**Flip the model: Make hosting free forever, monetize the form API and premium features.**

| Plan | Price | What's Included |
|------|-------|-----------------|
| **Free (forever)** | $0 | 3 sites, 50 MB/site, HTTPS, 100 form submissions/month, StaticDrop branding |
| **Pro** | $9/month | 20 sites, 200 MB/site, 10,000 submissions/month, custom domain, no branding, email notifications, basic analytics |
| **Business** | $29/month | 100 sites, 500 MB/site, 100K submissions/month, webhooks, CSV export, priority support, team (3 seats) |
| **Enterprise** | Custom | Unlimited, white-label, API access, dedicated support, SLA |

### What Users Would Pay For vs Expect Free
| Expect Free | Would Pay For |
|-------------|---------------|
| Basic hosting | Custom domains with SSL |
| Free subdomain | Remove branding |
| 100 submissions/month | Email notifications on submissions |
| Basic file management | Webhook integrations (Zapier, Slack) |
| Community support | Priority/email support |

---

## 8. 🚀 Growth & Conversion Optimization

### User Activation
**Current:** User registers → deploys site → ... then what?  
**Problem:** No "aha moment" is engineered.

**Recommendations:**
1. **One-click demo deploy** — On the "Deploy New Site" page, add a "Deploy our sample portfolio" button. Gets user to live site in 10 seconds. The feeling of "I have a website live" is the aha moment.
2. **Interactive demo without registration** — On the landing page, let visitors paste an HTML snippet and see it rendered. Taste the product before committing.
3. **Post-deploy CTA chain:** Deploy → "Share your site" → "Add a contact form" → "View your first submission" → hooked.

### Retention
1. **Email notifications for form submissions** — This is the #1 retention driver. Every time someone submits a form, the user returns to the dashboard.
2. **Weekly analytics email** — "Your portfolio got 47 views from 8 countries this week." This keeps users engaged even if they don't log in.
3. **Expiry-driven urgency (done right)** — Don't let sites go dark. Instead: "Your free plan allows 100 submissions. You've used 87. Upgrade to keep collecting."

### Conversion to Paid
1. **Usage-based gates, not time-based gates.** Don't expire the trial after 3 days. Let users hit the submission limit, storage limit, or site limit naturally. When they hit the wall, show an upgrade prompt *in context*.
2. **"This form submission was blocked" email** — When a free user's site exceeds 100 submissions, email them: "Your contact form received a submission but it was blocked because you've reached your free plan limit. Upgrade to capture it."
3. **Custom domain as the upgrade hook** — Many users will want `www.myportfolio.com` instead of `mysite.staticdrop.com`. This is the natural upgrade trigger.

### Trust-Building
1. **Show live customer count** — "2,340 sites deployed on StaticDrop"
2. **Uptime guarantee** — Even 99.9% is a signal of professionalism
3. **Testimonials** — Even fake/demo ones initially (with disclosure)
4. **Open-source the client libraries** — Builds developer trust
5. **Security page** — Document your data practices (GDPR compliance, data location)

### Psychological Triggers
- **Loss aversion:** "Your site received 3 form submissions while on the free plan. Upgrade to make sure you never miss one."
- **Social proof:** "Join 500+ creators who've deployed their sites on StaticDrop"
- **Endowment effect:** Let users experience premium features during a 14-day trial, then downgrade. They'll feel the loss.
- **Anchoring:** Show Enterprise price first on pricing page, making Pro look cheap

---

## 9. 🧩 Feature Enhancement Ideas

### High Impact / Low Effort
| # | Feature | Impact | Why |
|---|---------|--------|-----|
| 1 | **Email notifications on form submission** | 🔥🔥🔥🔥🔥 | #1 requested feature for any form tool. Uses SendGrid/Resend, straightforward to build. Directly drives retention. |
| 2 | **Password reset flow** | 🔥🔥🔥🔥 | Basic auth requirement that's completely missing. Blocks every user who forgets their password. |
| 3 | **Post-deploy celebration + share screen** | 🔥🔥🔥🔥 | Drives word-of-mouth. Show confetti, live URL, social share buttons. 30 minutes to build, massive growth impact. |
| 4 | **Google/GitHub OAuth login** | 🔥🔥🔥🔥 | Reduces registration friction by 80% for your target audience (students, devs). |
| 5 | **Getting Started dashboard checklist** | 🔥🔥🔥 | Guides activation: "Deploy site ✓ → Add form → Connect domain → View analytics." |
| 6 | **One-click demo site deploy** | 🔥🔥🔥 | Pre-built portfolio template deploys instantly. Shows value in 10 seconds. |

### High Impact / High Effort
| # | Feature | Impact | Why |
|---|---------|--------|-----|
| 7 | **HTTPS/SSL via Let's Encrypt** | 🔥🔥🔥🔥🔥 | Non-negotiable for production. Without HTTPS, the product cannot be taken seriously. |
| 8 | **CDN integration (Cloudflare/R2)** | 🔥🔥🔥🔥🔥 | Sites must load fast globally. Current single-origin filesystem won't survive real traffic. |
| 9 | **Webhook notifications (Zapier/Slack/Discord)** | 🔥🔥🔥🔥 | Paid-tier differentiator. "Get a Slack message when someone fills your contact form." |
| 10 | **Stripe integration for global payments** | 🔥🔥🔥🔥 | Razorpay-only blocks all non-Indian customers from paying. |

---

## 10. ⚠️ Risks & Weaknesses

### Biggest Product Risks

1. **Infrastructure is not production-ready.** SQLite, local filesystem, no HTTPS, no CDN. A single server failure loses all customer sites permanently. You cannot charge money for this level of reliability.

2. **Competing against free.** Netlify/Vercel/Cloudflare Pages offer free static hosting with HTTPS, CDN, CI/CD, and serverless functions. Your free tier offers *less* than their free tier. Your differentiation (ZIP upload + form API) is your only leverage — and it might not be enough to justify payment.

3. **3-day trial will kill word-of-mouth.** Students share portfolio links in resumes. When the interviewer clicks and sees a dead site 4 days later, StaticDrop's reputation is damaged. This single decision could kill the product.

4. **No email infrastructure.** Without transactional email (verification, notifications, receipts), the product feels unfinished and untrustworthy.

5. **Abuse potential.** No content moderation means StaticDrop could host phishing pages, malware landing pages, or illegal content. The subdomain system makes this especially dangerous — `bank-login.staticdrop.com` looks convincing.

### Why Users May NOT Pay
- "Netlify does this for free with HTTPS and CDN"
- "My site went down after 3 days — I'm not paying for a platform that holds my portfolio hostage"
- "I can't pay because there's no Stripe and I don't have Razorpay"
- "There's no HTTPS so Chrome shows 'Not Secure' on my site — looks unprofessional"
- "I never know when someone fills out my form because there are no notifications"

### Competitive Threats
| Competitor | Threat Level | Why |
|------------|-------------|-----|
| **Netlify** | 🔴 Critical | Free tier includes everything StaticDrop charges for (hosting, HTTPS, forms, CDN) |
| **Vercel** | 🟡 Medium | Free static hosting + serverless, but requires Git (your audience may not use Git) |
| **Cloudflare Pages** | 🔴 Critical | Free tier with unlimited bandwidth, HTTPS, and CDN |
| **GitHub Pages** | 🟡 Medium | Free but requires Git knowledge — your audience gap |
| **Tiiny.host** | 🟠 High | Nearly identical concept (upload ZIP, get URL), has HTTPS and free tier |
| **Surge.sh** | 🟡 Medium | CLI-based, but free unlimited hosting |

---

## 11. 🏆 Final Recommendations

### Top 5 Most Important Improvements — Implement Immediately

1. **🔴 Replace the 3-day trial with a permanent free tier.**  
   Make hosting free forever with hard limits (3 sites, 100 submissions/month). Monetize form volume, custom domains, and premium features. This single change transforms the product from "hostile" to "generous" and enables word-of-mouth growth.

2. **🔴 Add HTTPS support.**  
   Without HTTPS, deployed sites show "Not Secure" in browsers. No user will share a portfolio with that warning. Use Caddy as a reverse proxy (automatic HTTPS) or integrate Let's Encrypt.

3. **🟠 Implement transactional email (SendGrid/Resend).**  
   This unlocks: email verification (real), password reset, form submission notifications, payment receipts, and weekly digests. Email is the backbone of every SaaS — it's not optional.

4. **🟠 Add email notifications for form submissions.**  
   This is the single highest-impact feature for retention. When a user gets an email saying "Someone filled out your contact form!", they'll open the dashboard, feel the value, and eventually upgrade.

5. **🟡 Build a post-deploy celebration + social sharing screen.**  
   After deploying, show the live URL prominently, add "Visit My Site" and "Share on LinkedIn" buttons. This drives organic growth and creates the "aha moment" that activates users.

---

## 📊 Product Ratings

| Dimension | Score | Notes |
|-----------|-------|-------|
| **Market Readiness** | 3/10 | No HTTPS, no CDN, SQLite, no email — not ready for paying customers |
| **UX Quality** | 7/10 | Clean design, professional UI, good multi-step wizard. VS Code editor is impressive. But weak onboarding, no retention loops, trial model is hostile |
| **Monetization Potential** | 6/10 | Form API is a genuine revenue driver. But pricing competes against free alternatives. Need to flip model: free hosting + paid form features |
| **Overall Product Strength** | 4/10 | Strong idea, good execution on UX, but critical infrastructure gaps (HTTPS, email, scalability) prevent it from being a real product. It's a well-built prototype, not a production SaaS yet |

### The Honest Bottom Line

StaticDrop has a **genuinely differentiated idea** — "Upload ZIP, get a website with built-in forms" targets an underserved audience that competitors ignore. The UI redesign work is excellent, and the VS Code-like editors are impressive.

However, the product is trying to **charge money for less than what competitors give for free**. The 3-day trial is the single most damaging design decision in the product — it punishes the exact users who would become evangelists (students sharing portfolios).

**The path forward:**
1. Make basic hosting **free forever** (compete on convenience, not price)
2. Invest in infrastructure (HTTPS, email, CDN, PostgreSQL)
3. Monetize the **form API** as the premium differentiator (notifications, webhooks, volume)
4. Build retention through **email notifications** — this turns a deploy-and-forget tool into a daily-value product
5. Then, and only then, start optimizing for conversion
