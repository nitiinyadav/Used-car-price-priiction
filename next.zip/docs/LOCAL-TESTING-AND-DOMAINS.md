# Local Testing and Domains

## 1. Test a site on localhost

Start the app:

```bash
npm install
npx prisma db push
npm run db:seed
npm run dev
```

Open `http://localhost:3000`, sign in, and deploy a ZIP file.

Your ZIP should contain `index.html` at the site root after extraction:

```text
my-site/
  index.html
  styles.css
  script.js
  images/
    logo.png
```

These ZIP shapes work:
- The files are directly inside the ZIP
- The files are inside one top-level folder in the ZIP

These ZIP shapes do not work:
- `index.html` is missing
- `index.html` is buried under extra nested folders like `project/dist/index.html`

## 2. Open the deployed site locally

StaticDrop now supports two local access patterns:

```text
http://your-site.lvh.me:3000
http://your-site.localhost:3000
http://localhost:3000/site/your-site
```

Use `your-site.lvh.me:3000` for the most reliable subdomain testing on Windows.
Use `.localhost` when your environment resolves it correctly.
Use the `/site/your-site` URL as a fallback preview path.

## 3. Connect a real custom domain

Custom domains only make sense after you deploy StaticDrop itself on a public server with a real domain.

Example production setup:
- StaticDrop app domain: `staticdrop.yourcompany.com`
- Customer site subdomain: `portfolio.staticdrop.yourcompany.com`
- Customer custom domain: `www.customer-site.com`

## 4. What the user must do to buy a domain

The user buys the domain outside the app from a registrar such as:
- Cloudflare Registrar
- Namecheap
- GoDaddy
- Porkbun

Inside the registrar they choose and purchase a domain, for example `example.com`.

## 5. What the user must do in DNS

If the user wants `www.example.com` to show their StaticDrop site:

1. Add `www.example.com` in the site settings inside StaticDrop.
2. In the registrar DNS panel, create a `CNAME` record:

```text
Type:   CNAME
Name:   www
Target: your StaticDrop root domain
```

Example:

```text
Type:   CNAME
Name:   www
Target: staticdrop.yourcompany.com
```

If the user wants the apex domain `example.com`:

1. Point `www` by `CNAME` as above.
2. Use domain forwarding or an `ALIAS` / `ANAME` / `A` record for the apex, depending on the DNS provider.
3. A common pattern is to redirect `example.com` to `www.example.com`.

## 6. What you must do as the app owner

For custom domains to work in production, the StaticDrop owner must:

1. Deploy the Next.js app on a public server.
2. Put the app behind Nginx, Caddy, or another reverse proxy.
3. Configure the proxy to forward the original `Host` header.
4. Set wildcard DNS for the StaticDrop root domain.
5. Set SSL for the main domain and wildcard subdomains.

Example DNS for the StaticDrop platform:

```text
A     @    <server-ip>
A     *    <server-ip>
```

## 7. End-to-end working flow

1. User signs in to StaticDrop.
2. User uploads a ZIP with `index.html`.
3. StaticDrop extracts the ZIP into `uploads/<siteId>/`.
4. User tests locally at `http://site-name.localhost:3000`.
5. App owner deploys StaticDrop publicly.
6. User buys a domain from a registrar.
7. User enters `www.example.com` in StaticDrop site settings.
8. User adds the DNS record at the registrar.
9. Middleware receives the request by hostname and serves the correct site.
