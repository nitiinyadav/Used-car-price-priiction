'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { formatMoney } from '@/lib/currency';

export default function PricingPlansClient({ plans, preferredCurrency }) {
  const { data: session } = useSession();
  const [billingPeriod, setBillingPeriod] = useState('monthly');

  return (
    <div>
      {/* Billing toggle */}
      <div className="mx-auto mb-8 flex max-w-xs items-center justify-center rounded-2xl border border-gray-200 dark:border-gray-800 bg-gray-100 dark:bg-gray-900 p-1 shadow-sm">
        <button
          type="button"
          onClick={() => setBillingPeriod('monthly')}
          className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${
            billingPeriod === 'monthly'
              ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
          }`}
        >
          Monthly
        </button>
        <button
          type="button"
          onClick={() => setBillingPeriod('yearly')}
          className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all relative ${
            billingPeriod === 'yearly'
              ? 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
          }`}
        >
          Yearly
          <span className="ml-1.5 inline-flex items-center rounded-full bg-emerald-100 dark:bg-emerald-900/40 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700 dark:text-emerald-400">Save</span>
        </button>
      </div>

      {/* Currency notice */}
      <div className="mx-auto mb-10 max-w-2xl rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50 px-5 py-3 text-center text-sm text-gray-500 dark:text-gray-400">
        Prices shown in <strong className="text-gray-700 dark:text-gray-300">{preferredCurrency}</strong>. New users start with a 3-day free trial. Payments via Razorpay from Settings.
      </div>

      {/* Plan cards */}
      <div className="mx-auto grid max-w-6xl gap-6 md:grid-cols-2 lg:grid-cols-4">
        {plans.map((plan) => {
          const isPopular = plan.slug === 'pro';
          const features = plan.features ? JSON.parse(plan.features) : [];
          const amount =
            preferredCurrency === 'INR'
              ? billingPeriod === 'yearly'
                ? plan.priceYearlyInr
                : plan.priceMonthlyInr
              : billingPeriod === 'yearly'
                ? plan.priceYearly
                : plan.priceMonthly;

          return (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-2xl border bg-white dark:bg-gray-900 p-7 transition-all hover:shadow-lg hover:-translate-y-1 ${
                isPopular
                  ? 'border-indigo-500 dark:border-indigo-500 shadow-xl shadow-indigo-200/40 dark:shadow-indigo-900/30 ring-1 ring-indigo-500'
                  : 'border-gray-200 dark:border-gray-800'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span className="rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-white shadow-lg">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="mb-6">
                <div className={`mb-3 inline-flex rounded-lg px-3 py-1 text-xs font-bold uppercase tracking-[0.15em] ${
                  isPopular
                    ? 'bg-indigo-100 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400'
                }`}>
                  {plan.name}
                </div>
                <div className="flex items-end gap-1">
                  <span className="text-4xl font-black tracking-tight text-gray-900 dark:text-white">
                    {formatMoney(amount, preferredCurrency)}
                  </span>
                  <span className="pb-1 text-sm text-gray-500 dark:text-gray-400">
                    /{billingPeriod === 'yearly' ? 'yr' : 'mo'}
                  </span>
                </div>
                {plan.slug === 'free' ? (
                  <p className="mt-3 text-xs leading-5 text-gray-500 dark:text-gray-400">Free forever. No credit card needed.</p>
                ) : (
                  <p className="mt-3 text-xs leading-5 text-gray-500 dark:text-gray-400">Managed billing from your Settings page.</p>
                )}
              </div>

              <ul className="mb-8 flex-1 space-y-3">
                <FeatureItem label={`${plan.maxSites} websites`} />
                <FeatureItem label={`${plan.maxStorageMB} MB storage / site`} />
                <FeatureItem label={`${plan.maxSubmissions.toLocaleString()} form submissions`} />
                <FeatureItem label="Custom domain" included={plan.customDomain} />
                {features.map((feature, index) => (
                  <FeatureItem key={index} label={feature} />
                ))}
              </ul>

              {!session ? (
                <Link
                  href="/register"
                  className={`block rounded-xl px-5 py-3 text-center text-sm font-bold transition-all ${
                    isPopular
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/25'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {plan.slug === 'free' ? 'Start Free' : 'Create Account'}
                </Link>
              ) : (
                <Link
                  href="/dashboard/settings"
                  className={`block rounded-xl px-5 py-3 text-center text-sm font-bold transition-all ${
                    isPopular
                      ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/25'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  Manage in Settings
                </Link>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FeatureItem({ label, included = true }) {
  return (
    <li className="flex items-start gap-3 text-sm">
      {included ? (
        <svg className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      ) : (
        <svg className="mt-0.5 h-4 w-4 shrink-0 text-gray-300 dark:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      )}
      <span className={included ? 'text-gray-700 dark:text-gray-300' : 'text-gray-400 dark:text-gray-600'}>{label}</span>
    </li>
  );
}
