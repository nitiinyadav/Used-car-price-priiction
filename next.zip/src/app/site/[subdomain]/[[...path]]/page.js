import { redirect } from 'next/navigation';

// This page redirects to the API serve route
// In production with subdomains, the middleware handles routing
// In development, users can access sites via /site/[subdomain]
export default function SitePreviewPage({ params, searchParams }) {
  const { subdomain } = params;
  const pathSegments = params.path || [];
  const filePath = pathSegments.join('/');

  // Redirect to the serve API
  const servePath = filePath
    ? `/api/serve/${subdomain}/${filePath}`
    : `/api/serve/${subdomain}/`;

  redirect(servePath);
}
