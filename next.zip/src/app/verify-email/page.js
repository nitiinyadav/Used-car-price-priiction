import VerifyEmailClient from './VerifyEmailClient';

export default function VerifyEmailPage({ searchParams }) {
  return <VerifyEmailClient token={searchParams?.token || ''} />;
}
