import { headers } from "next/headers";
import Navbar from "@/components/Navbar";
import prisma from "@/lib/prisma";
import PricingPlansClient from "@/components/PricingPlansClient";
import { detectPreferredCurrency } from "@/lib/currency";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function PricingPage() {
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: { priority: "asc" },
  });
  const preferredCurrency = detectPreferredCurrency(headers());

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      <Navbar />

      <section className="relative overflow-hidden py-24">
        {/* Ambient gradient */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[800px] h-[500px] rounded-full bg-gradient-to-br from-indigo-400/20 via-violet-400/10 to-fuchsia-400/10 dark:from-indigo-600/15 dark:via-violet-600/10 dark:to-fuchsia-600/5 blur-3xl" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto mb-16 max-w-3xl text-center">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/50 px-4 py-1.5">
              <svg className="w-4 h-4 text-indigo-600 dark:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              <span className="text-xs font-semibold uppercase tracking-[0.15em] text-indigo-700 dark:text-indigo-300">Transparent Pricing. No Surprises.</span>
            </div>
            <h1 className="text-4xl font-black tracking-tight text-gray-900 dark:text-white sm:text-5xl">
              Choose Your Plan
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-gray-600 dark:text-gray-400">
              Start free, upgrade when you need more. All plans include SSL, instant deploys, and our built-in code editor.
            </p>
          </div>

          <PricingPlansClient
            plans={plans}
            preferredCurrency={preferredCurrency}
          />

          {/* Trust cards */}
          <div className="mx-auto mt-24 grid max-w-5xl gap-6 md:grid-cols-3">
            <TrustCard
              icon="🔒"
              title="Secure Payments"
              description="All transactions go through Razorpay with server-side signature verification. Your data is always protected."
            />
            <TrustCard
              icon="📌"
              title="Locked Billing"
              description="Once you choose a plan, it stays locked to that billing cycle. No random plan switching or surprise charges."
            />
            <TrustCard
              icon="🔔"
              title="Renewal Alerts"
              description="We'll notify you before your subscription ends. Renew on your terms — no auto-charges, no surprises."
            />
          </div>

          {/* FAQ */}
          <div className="mx-auto mt-24 max-w-3xl">
            <h2 className="text-2xl font-black text-center text-gray-900 dark:text-white mb-10">Frequently Asked Questions</h2>
            <div className="space-y-4">
              <FaqItem
                title="Where does payment happen?"
                description="The public pricing page is for comparison. Logged-in users complete checkout from Dashboard → Settings so billing stays intentional and controlled."
              />
              <FaqItem
                title="Can I switch plans anytime?"
                description="No. The first paid plan and billing period become your locked subscription. Renewals continue from Settings when the renewal window opens."
              />
              <FaqItem
                title="What happens when my subscription expires?"
                description="You'll receive a renewal notification before the current billing period ends. If not renewed, your account moves to the free plan. No data is deleted."
              />
              <FaqItem
                title="How are prices shown?"
                description={`Indian visitors see INR pricing by default. Other visitors see USD pricing. Your detected currency: ${preferredCurrency}.`}
              />
              <FaqItem
                title="Is there a free plan?"
                description="Yes! The free plan includes up to 3 sites with free subdomains. No credit card required, no time limit."
              />
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="mt-24 text-center">
            <h3 className="text-2xl font-black text-gray-900 dark:text-white">Ready to get started?</h3>
            <p className="mt-3 text-gray-500 dark:text-gray-400">Deploy your first site in under 60 seconds.</p>
            <Link href="/register" className="mt-6 inline-flex items-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/25 dark:shadow-indigo-600/15">
              Start Free
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950 py-12 text-gray-500 dark:text-gray-400">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 text-sm sm:flex-row sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-indigo-600 rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
            </div>
            <span className="font-semibold text-gray-900 dark:text-white">LiveInSec</span>
          </div>
          <span>
            &copy; {new Date().getFullYear()} LiveInSec. All rights reserved.
          </span>
        </div>
      </footer>
    </div>
  );
}

function TrustCard({ icon, title, description }) {
  return (
    <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-7 transition-all hover:shadow-lg hover:-translate-y-1">
      <div className="text-2xl mb-3">{icon}</div>
      <h3 className="text-base font-bold text-gray-900 dark:text-white">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-gray-500 dark:text-gray-400">{description}</p>
    </div>
  );
}

function FaqItem({ title, description }) {
  return (
    <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-6">
      <h3 className="font-bold text-gray-900 dark:text-white text-sm">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-gray-500 dark:text-gray-400">{description}</p>
    </div>
  );
}
