import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import { getBillingSnapshot } from '@/lib/billing';
import SettingsClient from './SettingsClient';

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const billing = await getBillingSnapshot(session.user.id);
  const canManageTeam = billing?.planSlug === 'enterprise' && !session.user.ownerId;

  const teamMembers = canManageTeam
    ? await prisma.user.findMany({
        where: { ownerId: session.user.id },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          memberPermissions: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      })
    : [];

  return (
    <SettingsClient
      sessionUser={session.user}
      billing={billing}
      teamMembers={teamMembers}
      canManageTeam={canManageTeam}
    />
  );
}
