import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import Link from 'next/link';
import SiteTabs from '@/components/SiteTabs';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { getUserLimits } from '@/lib/plans';

export const metadata = {
  title: 'Site Analytics - LiveInSec',
};

export default async function SiteAnalyticsPage({ params }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, 'view_analytics')) {
    notFound();
  }

  const limits = await getUserLimits(session.user.id);

  const site = await prisma.site.findFirst({
    where: { id: params.id, userId: workspace?.workspaceOwnerId || session.user.id },
    select: { id: true, name: true },
  });

  if (!site) {
    notFound();
  }

  // Free plan users cannot access analytics
  if (!limits?.analytics && session.user.role !== 'superadmin') {
    return (
      <div>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Site Analytics</h1>
          <p className="mt-1 text-gray-500">
            Traffic trends, referrers, and visitor insights for {site.name}.
          </p>
        </div>
        <SiteTabs siteId={site.id} />
        <div className="rounded-2xl border border-gray-200 bg-white p-12 text-center">
          <div className="mx-auto w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Analytics is a Premium Feature</h2>
          <p className="text-gray-500 mb-6 max-w-md mx-auto">
            Upgrade your plan to unlock detailed analytics — see page views, unique visitors,
            top pages, referrers, and visitor countries.
          </p>
          <Link
            href="/dashboard/upgrade"
            className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
            Upgrade Plan
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Site Analytics</h1>
        <p className="mt-1 text-gray-500">
          Traffic trends, referrers, and visitor insights for {site.name}.
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <AnalyticsDashboard siteId={site.id} />
    </div>
  );
}
