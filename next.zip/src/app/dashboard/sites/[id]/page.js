import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { notFound } from "next/navigation";
import Link from "next/link";
import {
  getCustomDomainTarget,
  getSiteAccessUrls,
  getRootDomain,
  isLocalHost,
} from "@/lib/utils";
import SiteTabs from "@/components/SiteTabs";
import { parseAllowedOrigins } from "@/lib/site-security";
import { getWorkspaceContext } from "@/lib/workspace";

export async function generateMetadata({ params }) {
  return { title: "Site Details - LiveInSec" };
}

export default async function SiteDetailPage({ params }) {
  const session = await getServerSession(authOptions);
  const { id } = params;
  const workspace = await getWorkspaceContext(session.user.id);

  const site = await prisma.site.findFirst({
    where: { id, userId: workspace?.workspaceOwnerId || session.user.id },
    include: {
      _count: { select: { formsubmission: true } },
    },
  });

  if (!site) {
    notFound();
  }

  const accessUrls = getSiteAccessUrls(site);
  const rootDomain = getRootDomain();
  const formEndpoint = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/forms/${site.apiKey}`;
  const customDomainTarget = getCustomDomainTarget();
  const isLocalRootDomain = isLocalHost(rootDomain);

  return (
    <div>
      <div className="mb-8">
        <Link
          href="/dashboard/sites"
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to Sites</span>
        </Link>

        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{site.name}</h1>
            <p className="mt-1 text-gray-500">
              {site.subdomain}.{rootDomain.replace(/^https?:\/\//, "")}
              {site.customDomain && ` | ${site.customDomain}`}
            </p>
          </div>
          <span
            className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              site.isActive
                ? "bg-green-100 text-green-800"
                : "bg-gray-100 text-gray-800"
            }`}
          >
            {site.isActive ? "Active" : "Inactive"}
          </span>
        </div>
      </div>

      <SiteTabs siteId={site.id} />

      {/* Site Info Cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {/* Visit Site */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-3">
            Primary URL
          </h3>
          <a
            href={accessUrls.primaryUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-600 hover:text-indigo-500 font-medium break-all"
          >
            {accessUrls.primaryUrl}
          </a>
          <div className="mt-4 space-y-2 text-sm text-gray-600">
            <p>
              Subdomain URL:{" "}
              <a
                href={accessUrls.subdomainUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-500 break-all"
              >
                {accessUrls.subdomainUrl}
              </a>
            </p>
            <p>
              Preview URL:{" "}
              <a
                href={accessUrls.previewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:text-indigo-500 break-all"
              >
                {accessUrls.previewUrl}
              </a>
            </p>
            {site.customDomain && (
              <p>
                Custom domain:{" "}
                <a
                  href={accessUrls.customDomainUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:text-indigo-500 break-all"
                >
                  {accessUrls.customDomainUrl}
                </a>
              </p>
            )}
          </div>
          <div className="mt-4">
            <a
              href={accessUrls.primaryUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
            >
              <span>Visit Site</span>
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </a>
          </div>
        </div>

        {/* Submissions */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-3">
            Form Submissions
          </h3>
          <p className="text-3xl font-bold text-gray-900">
            {site._count.submissions}
          </p>
          <div className="mt-4">
            <Link
              href={`/dashboard/sites/${site.id}/submissions`}
              className="inline-flex items-center space-x-2 text-indigo-600 hover:text-indigo-500 text-sm font-medium"
            >
              <span>View Submissions</span>
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </Link>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-3">Site Tools</h3>
          <p className="text-sm text-gray-600">
            Review analytics, browse deployed files, and make quick content
            edits directly inside LiveInSec.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link
              href={`/dashboard/sites/${site.id}/analytics`}
              className="inline-flex items-center rounded-lg border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:border-gray-400"
            >
              Analytics
            </Link>
            <Link
              href={`/dashboard/sites/${site.id}/files`}
              className="inline-flex items-center rounded-lg border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:border-gray-400"
            >
              Files
            </Link>
          </div>
        </div>
      </div>

      {/* Form API Key & Embed Code */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Form Collection API
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Use this endpoint in your HTML forms to collect submissions. All data
          will appear in your dashboard.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">
              API Key
            </label>
            <div className="flex items-center space-x-2">
              <code className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono text-gray-800 break-all">
                {site.apiKey}
              </code>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">
              Form Endpoint
            </label>
            <code className="block bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono text-gray-800 break-all">
              {formEndpoint}
            </code>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">
              HTML Example
            </label>
            <pre className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm overflow-x-auto">
              {`<form action="${formEndpoint}" method="POST">
  <input name="name" placeholder="Your Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>
  <input type="text" name="${site.honeypotField}" style="display:none" tabindex="-1" autocomplete="off" />

  <!-- Optional: redirect after submit -->
  <input type="hidden" name="_redirect" value="${accessUrls.primaryUrl}" />

  <button type="submit">Send</button>
</form>`}
            </pre>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">
              JavaScript (AJAX) Example
            </label>
            <pre className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm overflow-x-auto">
              {`fetch("${formEndpoint}", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    name: "John",
    email: "john@example.com",
    message: "Hello!"
  })
})
.then(res => res.json())
.then(data => console.log("Submitted!", data));`}
            </pre>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Custom Domain Setup
        </h3>
        <div className="space-y-3 text-sm text-gray-600">
          <p>
            1. Buy a domain from a registrar like Cloudflare, Namecheap,
            GoDaddy, or Google Domains.
          </p>
          <p>
            2. In your registrar DNS settings, point the hostname you want to
            use to{" "}
            <code className="bg-gray-100 px-1 py-0.5 rounded">
              {customDomainTarget}
            </code>
            .
          </p>
          <p>
            3. Save that exact hostname in the field below, for example{" "}
            <code className="bg-gray-100 px-1 py-0.5 rounded">
              www.example.com
            </code>
            .
          </p>
          <p>
            4. Wait for DNS propagation, then open the domain in your browser.
          </p>
          <p className="text-xs text-gray-500">
            For apex/root domains like{" "}
            <code className="bg-gray-100 px-1 py-0.5 rounded">example.com</code>
            , use an A/ALIAS/ANAME record to your server instead of a CNAME if
            your DNS provider requires it.
          </p>
          {isLocalRootDomain && (
            <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
              Localhost can preview subdomains, but real custom domains only
              work after you deploy LiveInSec on a public server with a real
              domain.
            </p>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Form Protection
        </h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Honeypot Field
            </p>
            <p className="mt-1 text-sm font-semibold text-gray-900">
              {site.honeypotField}
            </p>
          </div>
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Rate Limit
            </p>
            <p className="mt-1 text-sm font-semibold text-gray-900">
              {site.submissionRateLimit} requests / 10 min / IP
            </p>
          </div>
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              Allowed Extra Origins
            </p>
            <p className="mt-1 text-sm font-semibold text-gray-900">
              {parseAllowedOrigins(site.allowedOrigins).length || 0}
            </p>
          </div>
        </div>
        <p className="mt-4 text-sm text-gray-500">
          Static form endpoints are public by nature, so protection comes from
          origin checks, honeypot fields, and rate limits instead of hiding the
          API key.
        </p>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Next Step</h3>
            <p className="mt-1 text-sm text-gray-500">
              Fine-tune form protection, domains, and deployment controls in the
              site settings tab.
            </p>
          </div>
          <Link
            href={`/dashboard/sites/${site.id}/settings`}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Open Settings
          </Link>
        </div>
      </div>
    </div>
  );
}
