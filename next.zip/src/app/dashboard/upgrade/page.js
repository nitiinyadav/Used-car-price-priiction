import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getBillingSnapshot } from '@/lib/billing';
import { detectPreferredCurrency } from '@/lib/currency';
import { headers } from 'next/headers';
import UpgradePlanClient from './UpgradePlanClient';

export const metadata = {
  title: 'Upgrade Plan - LiveInSec',
};

export default async function UpgradePlanPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  if (session.user.role === 'superadmin') {
    redirect('/dashboard');
  }

  const [plans, billing] = await Promise.all([
    prisma.plan.findMany({
      where: { isActive: true },
      orderBy: { priority: 'asc' },
    }),
    getBillingSnapshot(session.user.id),
  ]);

  const preferredCurrency = detectPreferredCurrency(headers());

  return (
    <UpgradePlanClient
      sessionUser={session.user}
      plans={plans}
      billing={billing}
      preferredCurrency={
        billing?.hasPurchasedBefore ? billing.billingCurrency : preferredCurrency
      }
    />
  );
}
