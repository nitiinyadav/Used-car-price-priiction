import Link from 'next/link';
import Navbar from '@/components/Navbar';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950 overflow-hidden">
      <Navbar />

      {/* ══════════════════════════════════════════════
          HERO — Urgency + Social Proof + Value Prop
         ══════════════════════════════════════════════ */}
      <section className="relative isolate">
        {/* Ambient gradient blobs */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[900px] h-[600px] rounded-full bg-gradient-to-br from-indigo-400/30 via-violet-400/20 to-fuchsia-400/20 dark:from-indigo-600/20 dark:via-violet-600/15 dark:to-fuchsia-600/10 blur-3xl" />
          <div className="absolute top-20 right-0 w-[400px] h-[400px] rounded-full bg-gradient-to-l from-sky-300/20 to-transparent dark:from-sky-600/10 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-[300px] h-[300px] rounded-full bg-gradient-to-r from-amber-200/20 to-transparent dark:from-amber-500/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-24 pt-20 lg:pb-32 lg:pt-28">
          <div className="mx-auto max-w-4xl text-center">
            {/* Social proof badge — Bandwagon Effect */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/50 px-4 py-1.5">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-green-500" />
              </span>
              <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">2,400+ websites deployed this month</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black tracking-tight text-gray-900 dark:text-white leading-[1.08]">
              Your Website, Live in
              <span className="relative whitespace-nowrap">
                <span className="relative bg-gradient-to-r from-indigo-600 via-violet-600 to-fuchsia-600 bg-clip-text text-transparent"> 30 Seconds</span>
              </span>
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg sm:text-xl leading-8 text-gray-600 dark:text-gray-400">
              Drop a ZIP. Pick a subdomain. Done. No terminal, no DevOps, no waiting.<br className="hidden sm:block" />
              <strong className="text-gray-900 dark:text-white">Free forever</strong> for small projects. Scale when you&apos;re ready.
            </p>

            {/* CTA cluster — Loss Aversion ("Free" emphasis) */}
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/register"
                className="group relative w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/25 dark:shadow-indigo-600/15"
              >
                Start Deploying — It&apos;s Free
                <svg className="w-5 h-5 transition-transform group-hover:translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              </Link>
              <Link
                href="#how-it-works"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 text-gray-700 dark:text-gray-300 px-6 py-4 rounded-2xl text-lg font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                See How It Works
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
              </Link>
            </div>

            {/* Trust indicators — Authority Bias */}
            <div className="mt-10 flex items-center justify-center gap-6 text-xs font-medium text-gray-500 dark:text-gray-500">
              <span className="flex items-center gap-1.5"><svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>SSL Included</span>
              <span className="flex items-center gap-1.5"><svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>No Credit Card</span>
              <span className="flex items-center gap-1.5"><svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>Instant Deploy</span>
            </div>
          </div>

          {/* Browser mockup — Visualization Effect */}
          <div className="relative mx-auto mt-16 max-w-5xl">
            <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-2xl shadow-gray-300/40 dark:shadow-black/40 overflow-hidden">
              {/* Chrome bar */}
              <div className="flex items-center gap-2 border-b border-gray-200 dark:border-gray-800 px-4 py-3 bg-gray-50 dark:bg-gray-900/80">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400" />
                  <div className="w-3 h-3 rounded-full bg-amber-400" />
                  <div className="w-3 h-3 rounded-full bg-green-400" />
                </div>
                <div className="flex-1 mx-4 bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-1.5 text-xs text-gray-400 font-mono">
                  yoursite.liveinsec.com
                </div>
              </div>
              {/* Dashboard preview illustration */}
              <div className="grid grid-cols-12 gap-4 p-6 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950 min-h-[260px] sm:min-h-[320px]">
                {/* Sidebar skeleton */}
                <div className="col-span-3 hidden sm:block space-y-3">
                  <div className="h-6 w-24 rounded-lg bg-indigo-200/60 dark:bg-indigo-800/40" />
                  <div className="h-4 w-full rounded bg-gray-200 dark:bg-gray-800" />
                  <div className="h-4 w-3/4 rounded bg-gray-200 dark:bg-gray-800" />
                  <div className="h-4 w-5/6 rounded bg-indigo-100 dark:bg-indigo-900/40" />
                  <div className="h-4 w-2/3 rounded bg-gray-200 dark:bg-gray-800" />
                </div>
                {/* Main content skeleton */}
                <div className="col-span-12 sm:col-span-9 space-y-4">
                  <div className="flex gap-3">
                    <div className="flex-1 h-20 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4">
                      <div className="h-3 w-16 rounded bg-gray-200 dark:bg-gray-700 mb-2" />
                      <div className="h-6 w-12 rounded bg-indigo-200 dark:bg-indigo-800" />
                    </div>
                    <div className="flex-1 h-20 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4">
                      <div className="h-3 w-16 rounded bg-gray-200 dark:bg-gray-700 mb-2" />
                      <div className="h-6 w-12 rounded bg-emerald-200 dark:bg-emerald-800" />
                    </div>
                    <div className="flex-1 h-20 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4 hidden sm:block">
                      <div className="h-3 w-16 rounded bg-gray-200 dark:bg-gray-700 mb-2" />
                      <div className="h-6 w-12 rounded bg-violet-200 dark:bg-violet-800" />
                    </div>
                  </div>
                  <div className="h-36 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4">
                    <div className="h-3 w-24 rounded bg-gray-200 dark:bg-gray-700 mb-4" />
                    <div className="grid grid-cols-3 gap-3 h-20">
                      <div className="rounded-lg bg-gradient-to-t from-indigo-400/20 to-indigo-400/5 dark:from-indigo-600/20 dark:to-indigo-600/5" />
                      <div className="rounded-lg bg-gradient-to-t from-indigo-400/30 to-indigo-400/5 dark:from-indigo-600/30 dark:to-indigo-600/5" />
                      <div className="rounded-lg bg-gradient-to-t from-indigo-400/50 to-indigo-400/10 dark:from-indigo-600/50 dark:to-indigo-600/10" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Glow effect */}
            <div className="absolute -inset-4 -z-10 bg-gradient-to-b from-indigo-100/50 via-transparent to-transparent dark:from-indigo-900/20 rounded-3xl blur-2xl" />
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          LOGOS / CREDIBILITY BAR — Authority Bias
         ══════════════════════════════════════════════ */}
      <section className="border-y border-gray-100 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-900/50 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs font-semibold uppercase tracking-[0.2em] text-gray-400 dark:text-gray-600 mb-6">Trusted by developers & businesses worldwide</p>
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 text-gray-300 dark:text-gray-700">
            <span className="text-2xl font-black tracking-tight">Portfolio<span className="text-indigo-400">Hub</span></span>
            <span className="text-2xl font-black tracking-tight">Launch<span className="text-emerald-400">Kit</span></span>
            <span className="text-2xl font-black tracking-tight">Site<span className="text-violet-400">Forge</span></span>
            <span className="text-2xl font-black tracking-tight">Pixel<span className="text-amber-400">Labs</span></span>
            <span className="text-2xl font-black tracking-tight">Web<span className="text-rose-400">Shift</span></span>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          FEATURES — Anchoring + Concrete Benefits
         ══════════════════════════════════════════════ */}
      <section className="py-28" id="features">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-20">
            <span className="text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400">Platform</span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Everything to Ship Fast</h2>
            <p className="mt-4 text-lg text-gray-500 dark:text-gray-400">Stop spending hours on servers. Start building the product.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: '⚡', title: 'One-Click Deploy', desc: 'Upload a ZIP or use our built-in code editor. Your site goes live in seconds — no CLI, no build step, no config.', gradient: 'from-amber-500/10 to-orange-500/10 dark:from-amber-500/5 dark:to-orange-500/5', border: 'border-amber-200/60 dark:border-amber-800/40' },
              { icon: '🌐', title: 'Free Subdomain + Custom Domain', desc: 'Get yoursite.liveinsec.com instantly, or connect your own domain with automatic SSL.', gradient: 'from-sky-500/10 to-cyan-500/10 dark:from-sky-500/5 dark:to-cyan-500/5', border: 'border-sky-200/60 dark:border-sky-800/40' },
              { icon: '📬', title: 'Form Collection API', desc: 'Add forms to your site and collect leads without writing backend code. View in dashboard, export to CSV.', gradient: 'from-violet-500/10 to-purple-500/10 dark:from-violet-500/5 dark:to-purple-500/5', border: 'border-violet-200/60 dark:border-violet-800/40' },
              { icon: '📊', title: 'Real-Time Analytics', desc: 'See who visits your site right now. Page views, unique visitors, and live visitor count — all built in.', gradient: 'from-emerald-500/10 to-teal-500/10 dark:from-emerald-500/5 dark:to-teal-500/5', border: 'border-emerald-200/60 dark:border-emerald-800/40' },
              { icon: '✏️', title: 'Built-in Code Editor', desc: 'Write HTML, CSS, and JS directly in your browser with syntax highlighting, live preview, and auto-save.', gradient: 'from-rose-500/10 to-pink-500/10 dark:from-rose-500/5 dark:to-pink-500/5', border: 'border-rose-200/60 dark:border-rose-800/40' },
              { icon: '🔒', title: 'Enterprise Security', desc: 'SSL on every site, rate limiting, IP blocking, CORS control, honeypot spam protection built in.', gradient: 'from-indigo-500/10 to-blue-500/10 dark:from-indigo-500/5 dark:to-blue-500/5', border: 'border-indigo-200/60 dark:border-indigo-800/40' },
            ].map((f) => (
              <div key={f.title} className={`group relative rounded-2xl border ${f.border} bg-gradient-to-br ${f.gradient} p-7 transition-all hover:shadow-lg hover:-translate-y-1`}>
                <div className="text-3xl mb-4">{f.icon}</div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{f.title}</h3>
                <p className="text-sm leading-6 text-gray-600 dark:text-gray-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          HOW IT WORKS — Clarity / Cognitive Ease
         ══════════════════════════════════════════════ */}
      <section className="py-28 bg-gray-50 dark:bg-gray-900/50" id="how-it-works">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-20">
            <span className="text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400">Simple</span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Three Steps. That&apos;s It.</h2>
            <p className="mt-4 text-lg text-gray-500 dark:text-gray-400">No learning curve. If you can zip a folder, you can deploy a website.</p>
          </div>

          <div className="relative grid md:grid-cols-3 gap-8 lg:gap-12">
            {/* Connector line (desktop) */}
            <div className="hidden md:block absolute top-16 left-[16.67%] right-[16.67%] h-0.5 bg-gradient-to-r from-indigo-300 via-violet-300 to-fuchsia-300 dark:from-indigo-700 dark:via-violet-700 dark:to-fuchsia-700" />

            {[
              { num: '01', title: 'Sign Up Free', desc: 'Create an account in 10 seconds. No credit card, no commitment. Start your free trial instantly.', color: 'bg-indigo-600' },
              { num: '02', title: 'Upload or Code', desc: 'Drag & drop a ZIP file of your site, or use our built-in code editor to build from scratch.', color: 'bg-violet-600' },
              { num: '03', title: 'Live Instantly', desc: 'Your site is live on a free subdomain. Share it, add forms, connect a custom domain — all from your dashboard.', color: 'bg-fuchsia-600' },
            ].map((s) => (
              <div key={s.num} className="relative text-center">
                <div className={`relative z-10 mx-auto w-16 h-16 ${s.color} rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg`}>
                  {s.num}
                </div>
                <h3 className="mt-6 text-lg font-bold text-gray-900 dark:text-white">{s.title}</h3>
                <p className="mt-3 text-sm leading-6 text-gray-500 dark:text-gray-400 max-w-xs mx-auto">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          FORM API SHOWCASE — Show, Don't Tell
         ══════════════════════════════════════════════ */}
      <section className="py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-sm font-bold uppercase tracking-[0.2em] text-violet-600 dark:text-violet-400">No Backend Needed</span>
              <h2 className="mt-3 text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Collect Leads with<br />Zero Code</h2>
              <p className="mt-4 text-lg text-gray-500 dark:text-gray-400">
                Every deployed site gets a unique API endpoint. Point your HTML form to it, and we capture every submission — with spam protection, rate limiting, and email alerts.
              </p>
              <ul className="mt-8 space-y-4">
                {[
                  'Works with standard HTML forms',
                  'Supports AJAX / fetch submissions',
                  'View & export in your dashboard',
                  'Spam protection + honeypot built in',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-gray-700 dark:text-gray-300">
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-100 dark:bg-green-900/40 flex items-center justify-center">
                      <svg className="w-3 h-3 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <span className="text-sm font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative">
              <div className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-gray-950 p-6 text-sm font-mono shadow-2xl shadow-gray-400/20 dark:shadow-black/40">
                <div className="flex items-center space-x-2 mb-5">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-xs text-gray-500 ml-3 font-sans">index.html</span>
                </div>
                <pre className="text-green-400 overflow-x-auto leading-6 text-xs sm:text-sm">
{`<!-- Just add your form endpoint -->
<form
  action="https://liveinsec.com/api/forms/YOUR_KEY"
  method="POST"
>
  <input name="name" placeholder="Name" />
  <input name="email" type="email"
         placeholder="Email" />
  <textarea name="message"
    placeholder="Message"></textarea>

  <input type="hidden" name="_redirect"
    value="https://yoursite.com/thanks" />

  <button type="submit">Send</button>
</form>`}
                </pre>
              </div>
              <div className="absolute -inset-3 -z-10 rounded-3xl bg-gradient-to-br from-violet-200/40 to-fuchsia-200/40 dark:from-violet-800/20 dark:to-fuchsia-800/20 blur-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          STATS BAR — Social Proof / Authority
         ══════════════════════════════════════════════ */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900/50 border-y border-gray-100 dark:border-gray-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: '12K+', label: 'Sites Deployed' },
              { value: '99.9%', label: 'Uptime Guaranteed' },
              { value: '<1s', label: 'Deploy Time' },
              { value: '4.9/5', label: 'User Rating' },
            ].map((s) => (
              <div key={s.label}>
                <div className="text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">{s.value}</div>
                <div className="mt-1 text-sm text-gray-500 dark:text-gray-400">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          TESTIMONIALS — Social Proof
         ══════════════════════════════════════════════ */}
      <section className="py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <span className="text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400">Testimonials</span>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Loved by Builders</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { quote: "I deployed my portfolio in literally 30 seconds. I couldn't believe it was that simple. Beat every other platform I've tried.", name: 'Arjun Mehra', role: 'Freelance Developer' },
              { quote: 'The form collection API saved us 2 weeks of backend work. We launched our lead gen site in a single afternoon.', name: 'Sarah Chen', role: 'Marketing Lead, LaunchKit' },
              { quote: 'We moved 15 client landing pages to LiveInSec. The custom domain setup was painless. Support is excellent.', name: 'Rahul Sharma', role: 'Agency Owner' },
            ].map((t) => (
              <div key={t.name} className="rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 p-7">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                  ))}
                </div>
                <p className="text-sm leading-6 text-gray-600 dark:text-gray-400 mb-5">&ldquo;{t.quote}&rdquo;</p>
                <div>
                  <p className="text-sm font-bold text-gray-900 dark:text-white">{t.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-500">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          PRICING CTA — Anchoring + Scarcity
         ══════════════════════════════════════════════ */}
      <section className="py-24 bg-gray-50 dark:bg-gray-900/50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-sm font-bold uppercase tracking-[0.2em] text-indigo-600 dark:text-indigo-400">Pricing</span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-black text-gray-900 dark:text-white">Plans For Every Project</h2>
          <p className="mt-4 text-lg text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
            Start free with 3 sites. Upgrade anytime to unlock more sites, storage, custom domains, and priority support.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/pricing" className="inline-flex items-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-2xl text-lg font-bold hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-600/25 dark:shadow-indigo-600/15">
              View All Plans
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
            </Link>
            <Link href="/register" className="text-gray-700 dark:text-gray-300 px-6 py-4 rounded-2xl text-lg font-semibold hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              Start Free Trial &rarr;
            </Link>
          </div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          FINAL CTA — Urgency + FOMO
         ══════════════════════════════════════════════ */}
      <section className="relative py-28 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600" />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIxIiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDgpIi8+PC9zdmc+')] opacity-50" />
        </div>
        <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-5xl font-black text-white leading-tight">
            Stop Overthinking Hosting.<br />
            <span className="text-white/80">Just Ship It.</span>
          </h2>
          <p className="mt-6 max-w-xl mx-auto text-lg text-white/70">
            Join thousands of developers, freelancers, and businesses who deploy their websites here. Your first site is free — forever.
          </p>
          <Link
            href="/register"
            className="mt-10 inline-flex items-center gap-2 bg-white text-indigo-700 px-10 py-4 rounded-2xl text-lg font-black hover:bg-gray-50 transition-colors shadow-xl shadow-black/10"
          >
            Create Free Account
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
          </Link>
          <p className="mt-4 text-sm text-white/50">No credit card required. Deploy in under 60 seconds.</p>
        </div>
      </section>

      {/* ══════════════════════════════════════════════
          FOOTER
         ══════════════════════════════════════════════ */}
      <footer className="bg-gray-950 text-gray-400 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                </div>
                <span className="text-white font-bold text-lg">LiveInSec</span>
              </div>
              <p className="text-sm text-gray-500">Deploy static websites instantly. No servers required.</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="#features" className="hover:text-white transition-colors">Features</Link></li>
                <li><Link href="/pricing" className="hover:text-white transition-colors">Pricing</Link></li>
                <li><Link href="#how-it-works" className="hover:text-white transition-colors">How It Works</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Account</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/login" className="hover:text-white transition-colors">Sign In</Link></li>
                <li><Link href="/register" className="hover:text-white transition-colors">Create Account</Link></li>
                <li><Link href="/dashboard" className="hover:text-white transition-colors">Dashboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
                <li><Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} LiveInSec. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
