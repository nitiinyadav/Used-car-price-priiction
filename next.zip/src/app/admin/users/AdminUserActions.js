'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminUserActions({ user }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  async function changePlan(newPlan) {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/users/' + user.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: newPlan }),
      });
      if (res.ok) router.refresh();
    } finally {
      setLoading(false);
      setShowMenu(false);
    }
  }

  async function changeRole(newRole) {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/users/' + user.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      });
      if (res.ok) router.refresh();
    } finally {
      setLoading(false);
      setShowMenu(false);
    }
  }

  async function deleteUser() {
    if (!confirm(`Permanently delete ${user.name} (${user.email})? This removes all their sites and data.`)) return;
    setLoading(true);
    try {
      const res = await fetch('/api/admin/users/' + user.id, {
        method: 'DELETE',
      });
      if (res.ok) router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (user.role === 'superadmin') {
    return <span className="text-xs text-gray-600">Protected</span>;
  }

  return (
    <div className="relative">
      <button
        onClick={() => setShowMenu(!showMenu)}
        disabled={loading}
        className="text-gray-400 hover:text-white p-1 rounded disabled:opacity-50"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
        </svg>
      </button>

      {showMenu && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
          <div className="absolute right-0 mt-1 w-48 bg-gray-700 rounded-lg shadow-xl z-20 border border-gray-600 py-1">
            <div className="px-3 py-2 text-xs text-gray-400 border-b border-gray-600">
              Change Plan
            </div>
            {['free', 'starter', 'pro', 'enterprise'].map((plan) => (
              <button
                key={plan}
                onClick={() => changePlan(plan)}
                className={`block w-full text-left px-3 py-1.5 text-sm hover:bg-gray-600 ${
                  user.planSlug === plan ? 'text-indigo-400' : 'text-gray-300'
                }`}
              >
                {plan.charAt(0).toUpperCase() + plan.slice(1)}
                {user.planSlug === plan && ' (current)'}
              </button>
            ))}

            <div className="px-3 py-2 text-xs text-gray-400 border-b border-t border-gray-600 mt-1">
              Change Role
            </div>
            <button
              onClick={() => changeRole(user.role === 'user' ? 'superadmin' : 'user')}
              className="block w-full text-left px-3 py-1.5 text-sm text-yellow-400 hover:bg-gray-600"
            >
              {user.role === 'user' ? 'Promote to Admin' : 'Demote to User'}
            </button>

            <div className="border-t border-gray-600 mt-1">
              <button
                onClick={deleteUser}
                className="block w-full text-left px-3 py-1.5 text-sm text-red-400 hover:bg-gray-600"
              >
                Delete User
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
