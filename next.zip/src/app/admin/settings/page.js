'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminSettingsPage() {
  const router = useRouter();
  const [message, setMessage] = useState('');

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Admin Settings</h1>
        <p className="mt-1 text-gray-400">
          Platform configuration
        </p>
      </div>

      <div className="max-w-2xl space-y-8">
        {/* Environment Info */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Current Configuration
          </h2>
          <div className="space-y-3">
            <div className="flex justify-between text-sm py-2 border-b border-gray-700">
              <span className="text-gray-400">App URL</span>
              <span className="text-white font-mono text-xs">
                {process.env.NEXT_PUBLIC_APP_URL || 'Not set'}
              </span>
            </div>
            <div className="flex justify-between text-sm py-2 border-b border-gray-700">
              <span className="text-gray-400">Root Domain</span>
              <span className="text-white font-mono text-xs">
                {process.env.NEXT_PUBLIC_ROOT_DOMAIN || 'Not set'}
              </span>
            </div>
            <div className="flex justify-between text-sm py-2 border-b border-gray-700">
              <span className="text-gray-400">Max Upload Size</span>
              <span className="text-white">
                {process.env.MAX_UPLOAD_SIZE_MB || '10'} MB
              </span>
            </div>
            <div className="flex justify-between text-sm py-2">
              <span className="text-gray-400">Environment</span>
              <span className="text-white">
                {process.env.NODE_ENV || 'development'}
              </span>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Quick Guides
          </h2>
          <div className="space-y-3 text-sm text-gray-400">
            <p>
              <strong className="text-gray-200">Change plan pricing:</strong>{' '}
              Open the Pricing Plans admin page and edit plans directly from the UI.
            </p>
            <p>
              <strong className="text-gray-200">Add payment gateway:</strong>{' '}
              Integrate Stripe or Razorpay in the <code className="text-xs bg-gray-700 px-1 py-0.5 rounded">/api/payments/checkout</code> route. Payment records will auto-appear in the Revenue dashboard.
            </p>
            <p>
              <strong className="text-gray-200">Custom domain SSL:</strong>{' '}
              Set up a wildcard certificate and Nginx reverse proxy. See DEPLOYMENT.md for details.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
