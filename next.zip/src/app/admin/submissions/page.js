import prisma from '@/lib/prisma';

export default async function AdminSubmissionsPage() {
  const submissions = await prisma.formSubmission.findMany({
    include: {
      site: { select: { name: true, subdomain: true, user: { select: { name: true } } } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">All Form Submissions</h1>
        <p className="mt-1 text-gray-400">
          Latest {submissions.length} submissions across all sites
        </p>
      </div>

      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-700/50">
              <tr className="text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                <th className="px-6 py-3">Site</th>
                <th className="px-6 py-3">Owner</th>
                <th className="px-6 py-3">Form</th>
                <th className="px-6 py-3">Data</th>
                <th className="px-6 py-3">IP</th>
                <th className="px-6 py-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {submissions.map((sub) => {
                const data = JSON.parse(sub.data);
                const preview = Object.entries(data)
                  .slice(0, 2)
                  .map(([k, v]) => `${k}: ${v}`)
                  .join(', ');

                return (
                  <tr key={sub.id} className="hover:bg-gray-700/30">
                    <td className="px-6 py-4">
                      <p className="text-sm text-white">{sub.site.name}</p>
                      <p className="text-xs text-gray-500">{sub.site.subdomain}</p>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      {sub.site.user.name}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      {sub.formName}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400 max-w-xs truncate">
                      {preview}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 font-mono text-xs">
                      {sub.ipAddress || '-'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      {new Date(sub.createdAt).toLocaleDateString('en-US', {
                        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                  </tr>
                );
              })}
              {submissions.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                    No form submissions yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
