'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminPlanActions({ plan }) {
  const router = useRouter();
  const [form, setForm] = useState({
    name: plan.name,
    priceMonthly: plan.priceMonthly,
    priceYearly: plan.priceYearly,
    priceMonthlyInr: plan.priceMonthlyInr,
    priceYearlyInr: plan.priceYearlyInr,
    maxSites: plan.maxSites,
    maxStorageMB: plan.maxStorageMB,
    maxSubmissions: plan.maxSubmissions,
    customDomain: plan.customDomain,
    priority: plan.priority,
    isActive: plan.isActive,
    features: JSON.parse(plan.features || '[]').join('\n'),
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function updateField(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function savePlan() {
    setSaving(true);
    setMessage('');
    setError('');

    try {
      const res = await fetch(`/api/admin/plans/${plan.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to update plan');
        return;
      }

      setMessage('Plan updated');
      router.refresh();
    } catch (err) {
      setError('Unexpected error while updating the plan');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mt-4 rounded-lg border border-gray-700 bg-gray-900/40 p-4 space-y-4">
      {error && (
        <div className="rounded-lg border border-red-900/60 bg-red-950/50 px-3 py-2 text-xs text-red-200">
          {error}
        </div>
      )}
      {message && (
        <div className="rounded-lg border border-green-900/60 bg-green-950/50 px-3 py-2 text-xs text-green-200">
          {message}
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Plan Name
          </span>
          <input
            value={form.name}
            onChange={(e) => updateField('name', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Priority
          </span>
          <input
            type="number"
            value={form.priority}
            onChange={(e) => updateField('priority', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Monthly Price USD (cents)
          </span>
          <input
            type="number"
            value={form.priceMonthly}
            onChange={(e) => updateField('priceMonthly', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Yearly Price USD (cents)
          </span>
          <input
            type="number"
            value={form.priceYearly}
            onChange={(e) => updateField('priceYearly', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Monthly Price INR (paise)
          </span>
          <input
            type="number"
            value={form.priceMonthlyInr}
            onChange={(e) => updateField('priceMonthlyInr', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Yearly Price INR (paise)
          </span>
          <input
            type="number"
            value={form.priceYearlyInr}
            onChange={(e) => updateField('priceYearlyInr', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Max Sites
          </span>
          <input
            type="number"
            value={form.maxSites}
            onChange={(e) => updateField('maxSites', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Storage MB
          </span>
          <input
            type="number"
            value={form.maxStorageMB}
            onChange={(e) => updateField('maxStorageMB', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>

        <label className="text-sm text-gray-300">
          <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
            Max Submissions
          </span>
          <input
            type="number"
            value={form.maxSubmissions}
            onChange={(e) => updateField('maxSubmissions', e.target.value)}
            className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
          />
        </label>
      </div>

      <label className="block text-sm text-gray-300">
        <span className="mb-1 block text-xs uppercase tracking-wide text-gray-500">
          Features
        </span>
        <textarea
          rows={5}
          value={form.features}
          onChange={(e) => updateField('features', e.target.value)}
          className="w-full rounded-lg border border-gray-600 bg-gray-800 px-3 py-2 text-white"
        />
      </label>

      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm text-gray-300">
          <input
            type="checkbox"
            checked={form.customDomain}
            onChange={(e) => updateField('customDomain', e.target.checked)}
          />
          Custom domains included
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-300">
          <input
            type="checkbox"
            checked={form.isActive}
            onChange={(e) => updateField('isActive', e.target.checked)}
          />
          Plan active
        </label>
      </div>

      <button
        type="button"
        onClick={savePlan}
        disabled={saving}
        className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
      >
        {saving ? 'Saving...' : 'Save Plan'}
      </button>
    </div>
  );
}
