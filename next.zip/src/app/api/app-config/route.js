import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET() {
  try {
    const config = await prisma.appconfig.findUnique({
      where: { id: "platform" },
    });

    if (!config) {
      return NextResponse.json({
        enabledOnboardingFields: ["fullName", "country", "occupation"],
        occupationOptions: [
          "Agency Owner",
          "Designer",
          "Developer",
          "Freelancer",
          "Founder",
          "Marketer",
          "Photographer",
          "Student",
        ],
      });
    }

    return NextResponse.json({
      enabledOnboardingFields: JSON.parse(config.enabledOnboardingFields),
      occupationOptions: JSON.parse(config.occupationOptions),
    });
  } catch (error) {
    console.error("App config error:", error);
    return NextResponse.json({
      enabledOnboardingFields: ["fullName", "country", "occupation"],
      occupationOptions: [],
    });
  }
}
