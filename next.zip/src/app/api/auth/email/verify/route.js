import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(request) {
  try {
    const { token } = await request.json();

    if (!token) {
      return NextResponse.json({ error: 'Missing token' }, { status: 400 });
    }

    const verification = await prisma.emailVerificationToken.findUnique({
      where: { token },
      include: { user: { select: { id: true } } },
    });

    if (!verification || verification.expiresAt <= new Date()) {
      return NextResponse.json(
        { error: 'Verification link is invalid or expired.' },
        { status: 400 }
      );
    }

    await prisma.$transaction([
      prisma.user.update({
        where: { id: verification.user.id },
        data: { emailVerifiedAt: new Date() },
      }),
      prisma.emailVerificationToken.delete({
        where: { id: verification.id },
      }),
    ]);

    return NextResponse.json({
      success: true,
      message: 'Email verified successfully.',
    });
  } catch (error) {
    console.error('Verify email error:', error);
    return NextResponse.json(
      { error: 'Failed to verify email' },
      { status: 500 }
    );
  }
}
