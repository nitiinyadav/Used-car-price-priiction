import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { verifyEmailTemplate } from '@/lib/email-templates';
import { env } from '@/lib/env';

export async function POST() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { name: true, email: true, emailVerifiedAt: true },
    });

    if (user?.emailVerifiedAt) {
      return NextResponse.json({
        success: true,
        message: 'Your email is already verified.',
      });
    }

    await prisma.emailVerificationToken.deleteMany({
      where: { userId: session.user.id },
    });

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    await prisma.emailVerificationToken.create({
      data: {
        userId: session.user.id,
        token,
        expiresAt,
      },
    });

    const verificationUrl = `${env.APP_URL}/verify-email?token=${token}`;

    const { subject, html, text } = verifyEmailTemplate(user.name, verificationUrl);
    const emailResult = await sendEmail({ to: user.email, subject, html, text });

    if (!emailResult.success) {
      console.error('Failed to send verification email:', emailResult.error);
    }

    return NextResponse.json({
      success: true,
      message: env.hasEmail
        ? 'Verification email sent. Check your inbox.'
        : 'Verification link generated (email not configured).',
      // Only expose URL in dev mode for testing
      verificationUrl: env.isProduction ? undefined : verificationUrl,
    });
  } catch (error) {
    console.error('Request verification error:', error);
    return NextResponse.json(
      { error: 'Failed to create verification link' },
      { status: 500 }
    );
  }
}
