import crypto from 'crypto';
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { passwordResetTemplate } from '@/lib/email-templates';
import { env } from '@/lib/env';
import { checkRateLimit } from '@/lib/rate-limit';

export async function POST(request) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Rate limit: 3 requests per email per 15 minutes
    const key = `pwd-reset:${email.toLowerCase()}`;
    if (!checkRateLimit(key, 3, 15 * 60 * 1000)) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429 }
      );
    }

    // Always return success to prevent email enumeration
    const successResponse = NextResponse.json({
      success: true,
      message: 'If an account exists with that email, a reset link has been sent.',
    });

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      select: { id: true, name: true, email: true, provider: true },
    });

    if (!user) {
      return successResponse;
    }

    // Don't allow password reset for OAuth-only accounts
    if (user.provider !== 'credentials') {
      return successResponse;
    }

    // Delete any existing tokens
    await prisma.passwordresettoken.deleteMany({
      where: { userId: user.id },
    });

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordresettoken.create({
      data: {
        id: crypto.randomUUID(),
        userId: user.id,
        token,
        expiresAt,
      },
    });

    const resetUrl = `${env.APP_URL}/reset-password?token=${token}`;
    const { subject, html, text } = passwordResetTemplate(user.name, resetUrl);
    const emailResult = await sendEmail({ to: user.email, subject, html, text });

    if (!emailResult.success) {
      console.error('Failed to send password reset email:', emailResult.error);
    }

    if (process.env.NODE_ENV !== 'production') {
      return NextResponse.json({
        success: true,
        message: 'If an account exists with that email, a reset link has been sent.',
        resetUrl,
      });
    }

    return successResponse;
  } catch (error) {
    console.error('Password reset request error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
