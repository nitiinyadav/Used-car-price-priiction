import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import prisma from '@/lib/prisma';
import { detectPreferredCurrency } from '@/lib/currency';
import { detectCountry } from '@/lib/location';
import { env } from '@/lib/env';

export async function POST(request) {
  try {
    const body = await request.json();
    const { email, password, name, phone } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: 'Password must be at least 8 characters' },
        { status: 400 }
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please provide a valid email address' },
        { status: 400 }
      );
    }

    const existingUser = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'An account with this email already exists' },
        { status: 409 }
      );
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const trialEndsAt = new Date(Date.now() + env.TRIAL_DAYS * 24 * 60 * 60 * 1000);
    const billingCurrency = detectPreferredCurrency(request.headers);
    const { countryCode, countryName } = detectCountry(request.headers);

    const user = await prisma.user.create({
      data: {
        name: name ? name.trim() : email.split('@')[0],
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        phone: phone ? String(phone).trim() : null,
        countryCode,
        countryName,
        subscriptionStatus: 'trial',
        billingCurrency,
        trialEndsAt,
      },
    });

    return NextResponse.json(
      {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          trialEndsAt: user.trialEndsAt,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
