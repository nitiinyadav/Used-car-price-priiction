import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, country, occupation } = await request.json();

    const updateData = {};
    if (name && name.trim()) updateData.name = name.trim();
    if (country && country.trim()) updateData.countryName = country.trim();
    if (occupation && occupation.trim()) updateData.occupation = occupation.trim();
    updateData.onboardingCompletedAt = new Date();

    await prisma.user.update({
      where: { id: session.user.id },
      data: updateData,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Onboarding error:', error);
    return NextResponse.json(
      { error: 'Failed to save onboarding data' },
      { status: 500 }
    );
  }
}
