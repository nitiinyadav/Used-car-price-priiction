import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { env } from '@/lib/env';

export async function POST(request) {
  if (!env.hasStripe || !env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Stripe not configured' }, { status: 500 });
  }

  const stripe = (await import('stripe')).default(env.STRIPE_SECRET_KEY);
  const body = await request.text();
  const signature = request.headers.get('stripe-signature');

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Stripe webhook signature verification failed:', err.message);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { userId, planSlug, billingPeriod } = session.metadata || {};

    if (!userId || !planSlug) {
      console.error('Stripe webhook: missing metadata', session.metadata);
      return NextResponse.json({ received: true });
    }

    const payment = await prisma.payment.findFirst({
      where: {
        providerOrderId: session.id,
        userId,
      },
    });

    if (!payment) {
      console.error('Stripe webhook: payment not found for session', session.id);
      return NextResponse.json({ received: true });
    }

    if (payment.status === 'completed') {
      return NextResponse.json({ received: true });
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { currentPeriodEndsAt: true },
    });

    const now = new Date();
    const startsAt =
      user?.currentPeriodEndsAt && new Date(user.currentPeriodEndsAt) > now
        ? new Date(user.currentPeriodEndsAt)
        : now;
    const expiresAt = new Date(startsAt);
    if (billingPeriod === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    }

    await prisma.$transaction([
      prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: 'completed',
          startsAt,
          expiresAt,
          providerPaymentId: session.payment_intent,
          transactionId: session.payment_intent,
        },
      }),
      prisma.user.update({
        where: { id: userId },
        data: {
          planSlug,
          subscriptionStatus: 'active',
          billingPeriod,
          billingCurrency: (session.currency || 'usd').toUpperCase(),
          currentPeriodEndsAt: expiresAt,
          trialEndsAt: null,
        },
      }),
    ]);

    console.log(`Stripe: activated ${planSlug} for user ${userId}`);
  }

  return NextResponse.json({ received: true });
}
