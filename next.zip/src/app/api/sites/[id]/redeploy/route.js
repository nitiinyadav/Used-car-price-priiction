import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { extractZip } from "@/lib/storage";
import { isZipFile } from "@/lib/utils";
import { getUserLimits } from "@/lib/plans";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

// POST /api/sites/[id]/redeploy - Upload new files for existing site
export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, "manage_sites")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
    });

    if (!site) {
      return NextResponse.json({ error: "Site not found" }, { status: 404 });
    }

    const limits = await getUserLimits(
      workspace?.workspaceOwnerId || session.user.id,
    );
    if (limits?.trialExpired) {
      return NextResponse.json(
        {
          error:
            "Your 3-day free trial has ended. Upgrade a plan to redeploy this site.",
        },
        { status: 403 },
      );
    }

    const formData = await request.formData();
    const file = formData.get("file");

    if (!file) {
      return NextResponse.json({ error: "File is required" }, { status: 400 });
    }

    if (!file?.name || !isZipFile(file.name)) {
      return NextResponse.json(
        { error: "Only ZIP files are accepted" },
        { status: 400 },
      );
    }

    const maxSize =
      parseInt(process.env.MAX_UPLOAD_SIZE_MB || "10", 10) * 1024 * 1024;
    if (file.size > maxSize) {
      return NextResponse.json(
        {
          error: `File size exceeds the maximum of ${process.env.MAX_UPLOAD_SIZE_MB || 10}MB`,
        },
        { status: 400 },
      );
    }

    try {
      const buffer = Buffer.from(await file.arrayBuffer());
      const deployPath = await extractZip(buffer, site.id);

      await prisma.site.update({
        where: { id: site.id },
        data: { deployPath, updatedAt: new Date() },
      });
    } catch (extractError) {
      console.error("ZIP extraction error:", extractError);
      return NextResponse.json(
        {
          error:
            extractError instanceof Error
              ? extractError.message
              : "Failed to extract ZIP file",
        },
        { status: 400 },
      );
    }

    const updated = await prisma.site.findUnique({
      where: { id: site.id },
      include: { _count: { select: { formsubmission: true } } },
    });

    return NextResponse.json({ site: updated });
  } catch (error) {
    console.error("Redeploy error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
