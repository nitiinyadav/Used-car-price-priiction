import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

// DELETE /api/team/members/[id] — remove a team member
export async function DELETE(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const memberId = params.id;
    if (!memberId) {
      return NextResponse.json({ error: 'Member ID required' }, { status: 400 });
    }

    // Verify the member belongs to the current user's team
    const member = await prisma.user.findUnique({
      where: { id: memberId },
      select: { id: true, ownerId: true, name: true, email: true },
    });

    if (!member) {
      return NextResponse.json({ error: 'Member not found' }, { status: 404 });
    }

    if (member.ownerId !== session.user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Delete the team member
    await prisma.user.delete({ where: { id: memberId } });

    return NextResponse.json({ success: true, message: `Team member ${member.name} removed.` });
  } catch (error) {
    console.error('Delete team member error:', error);
    return NextResponse.json(
      { error: 'Failed to remove team member.' },
      { status: 500 }
    );
  }
}

// PATCH /api/team/members/[id] — update member permissions
export async function PATCH(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const memberId = params.id;
    const member = await prisma.user.findUnique({
      where: { id: memberId },
      select: { id: true, ownerId: true },
    });

    if (!member || member.ownerId !== session.user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { permissions } = await request.json();
    const { serializePermissions, WORKSPACE_PERMISSIONS } = await import('@/lib/workspace');

    const selectedPermissions = Array.isArray(permissions)
      ? permissions.filter((p) => WORKSPACE_PERMISSIONS.includes(p))
      : [];

    const updated = await prisma.user.update({
      where: { id: memberId },
      data: { memberPermissions: serializePermissions(selectedPermissions) },
      select: { id: true, name: true, email: true, memberPermissions: true },
    });

    return NextResponse.json({ member: updated });
  } catch (error) {
    console.error('Update team member error:', error);
    return NextResponse.json(
      { error: 'Failed to update team member.' },
      { status: 500 }
    );
  }
}
