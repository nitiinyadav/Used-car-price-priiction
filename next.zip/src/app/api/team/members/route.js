import bcrypt from 'bcryptjs';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { serializePermissions, WORKSPACE_PERMISSIONS } from '@/lib/workspace';
import { getCurrencyForCountry } from '@/lib/location';

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const owner = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, role: true, planSlug: true, ownerId: true, countryCode: true, countryName: true },
    });

    if (!owner || owner.ownerId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    if (owner.role !== 'superadmin' && owner.planSlug !== 'enterprise') {
      return NextResponse.json(
        { error: 'Team member management is available on Enterprise plans only.' },
        { status: 403 }
      );
    }

    const { name, email, phone, password, permissions } = await request.json();

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: 'Name, email, and password are required.' },
        { status: 400 }
      );
    }

    const existing = await prisma.user.findUnique({
      where: { email: String(email).toLowerCase().trim() },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'A user with this email already exists.' },
        { status: 409 }
      );
    }

    const selectedPermissions = Array.isArray(permissions)
      ? permissions.filter((permission) => WORKSPACE_PERMISSIONS.includes(permission))
      : [];

    const hashedPassword = await bcrypt.hash(password, 12);

    const member = await prisma.user.create({
      data: {
        name: String(name).trim(),
        email: String(email).toLowerCase().trim(),
        phone: String(phone || '').trim() || null,
        password: hashedPassword,
        ownerId: owner.id,
        planSlug: owner.planSlug,
        subscriptionStatus: 'active',
        billingCurrency: getCurrencyForCountry(owner.countryCode),
        countryCode: owner.countryCode,
        countryName: owner.countryName,
        memberPermissions: serializePermissions(selectedPermissions),
        trialEndsAt: null,
      },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        memberPermissions: true,
        createdAt: true,
      },
    });

    return NextResponse.json({ member });
  } catch (error) {
    console.error('Create team member error:', error);
    return NextResponse.json(
      { error: 'Failed to create team member.' },
      { status: 500 }
    );
  }
}
