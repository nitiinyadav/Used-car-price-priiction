import { NextResponse } from 'next/server';

export function middleware(request) {
  const hostname = request.headers.get('host') || '';
  const rootDomain = process.env.NEXT_PUBLIC_ROOT_DOMAIN || 'localhost:3000';

  const hostnameWithoutPort = hostname.split(':')[0];
  const rootDomainWithoutPort = rootDomain.split(':')[0];

  const { pathname } = request.nextUrl;

  // Skip internal Next.js routes, API routes, and app routes
  if (
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/api/') ||
    pathname.startsWith('/login') ||
    pathname.startsWith('/register') ||
    pathname.startsWith('/dashboard') ||
    pathname.startsWith('/admin') ||
    pathname.startsWith('/pricing') ||
    pathname.startsWith('/site/') ||
    pathname === '/favicon.ico'
  ) {
    return NextResponse.next();
  }

  // In production, handle subdomain routing
  // If the hostname is not the root domain or localhost, it's a subdomain or custom domain
  if (
    hostnameWithoutPort !== rootDomainWithoutPort &&
    hostnameWithoutPort !== 'localhost' &&
    hostnameWithoutPort !== '127.0.0.1' &&
    hostnameWithoutPort !== 'www.' + rootDomainWithoutPort
  ) {
    // Try to extract subdomain
    const subdomain = hostnameWithoutPort.replace(
      `.${rootDomainWithoutPort}`,
      ''
    );

    if (subdomain && subdomain !== hostnameWithoutPort) {
      // It's a subdomain - rewrite to serve API
      const url = request.nextUrl.clone();
      url.pathname = `/api/serve/${subdomain}${pathname === '/' ? '/' : pathname}`;
      return NextResponse.rewrite(url);
    }

    // It might be a custom domain - rewrite using hostname as lookup
    // The serve route will need to handle custom domain lookup
    const url = request.nextUrl.clone();
    url.pathname = `/api/serve/_custom${pathname === '/' ? '/' : pathname}`;
    url.searchParams.set('domain', hostnameWithoutPort);
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
