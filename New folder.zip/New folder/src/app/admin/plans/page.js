import prisma from '@/lib/prisma';
import AdminPlanActions from './AdminPlanActions';

export default async function AdminPlansPage() {
  const plans = await prisma.plan.findMany({
    orderBy: { priority: 'asc' },
  });

  // Count users per plan
  const userCounts = await prisma.user.groupBy({
    by: ['plan'],
    _count: { plan: true },
  });
  const countMap = {};
  userCounts.forEach((u) => { countMap[u.plan] = u._count.plan; });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Pricing Plans</h1>
        <p className="mt-1 text-gray-400">
          Manage subscription plans and pricing
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {plans.map((plan) => {
          const features = JSON.parse(plan.features || '[]');
          const subscriberCount = countMap[plan.slug] || 0;

          return (
            <div
              key={plan.id}
              className={`bg-gray-800 rounded-xl border p-6 ${
                plan.slug === 'pro'
                  ? 'border-indigo-500'
                  : 'border-gray-700'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                  <p className="text-sm text-gray-400">{subscriberCount} subscribers</p>
                </div>
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    plan.isActive
                      ? 'bg-green-900/50 text-green-300'
                      : 'bg-gray-700 text-gray-400'
                  }`}
                >
                  {plan.isActive ? 'Active' : 'Disabled'}
                </span>
              </div>

              <div className="flex items-baseline space-x-2 mb-4">
                <span className="text-3xl font-bold text-white">
                  ${(plan.priceMonthly / 100).toFixed(0)}
                </span>
                <span className="text-gray-400">/month</span>
                {plan.priceYearly > 0 && (
                  <span className="text-sm text-gray-500">
                    (${(plan.priceYearly / 100).toFixed(0)}/year)
                  </span>
                )}
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Max Sites</span>
                  <span className="text-white">{plan.maxSites}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Max Storage</span>
                  <span className="text-white">{plan.maxStorageMB} MB/site</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Max Submissions</span>
                  <span className="text-white">{plan.maxSubmissions.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Custom Domain</span>
                  <span className={plan.customDomain ? 'text-green-400' : 'text-gray-500'}>
                    {plan.customDomain ? 'Yes' : 'No'}
                  </span>
                </div>
              </div>

              {features.length > 0 && (
                <div className="space-y-1 pt-3 border-t border-gray-700">
                  {features.map((feature, i) => (
                    <div key={i} className="flex items-center space-x-2 text-sm">
                      <svg className="w-4 h-4 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4 pt-4 border-t border-gray-700">
                <div className="bg-gray-700/50 rounded-lg p-3">
                  <p className="text-xs text-gray-400">
                    <strong className="text-gray-300">Revenue potential:</strong>{' '}
                    {subscriberCount > 0
                      ? `$${((subscriberCount * plan.priceMonthly) / 100).toFixed(2)}/mo from ${subscriberCount} subscribers`
                      : 'No subscribers yet'}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
