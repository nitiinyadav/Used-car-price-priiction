// Placeholder - plan editing can be expanded later
export default function AdminPlanActions({ plan }) {
  return null;
}
