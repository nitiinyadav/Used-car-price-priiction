import prisma from '@/lib/prisma';
import Link from 'next/link';

export default async function AdminSitesPage() {
  const sites = await prisma.site.findMany({
    include: {
      user: { select: { name: true, email: true } },
      _count: { select: { submissions: true } },
    },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">All Deployed Sites</h1>
        <p className="mt-1 text-gray-400">
          {sites.length} sites across all users
        </p>
      </div>

      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-700/50">
              <tr className="text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                <th className="px-6 py-3">Site</th>
                <th className="px-6 py-3">Owner</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Submissions</th>
                <th className="px-6 py-3">Deployed</th>
                <th className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {sites.map((site) => (
                <tr key={site.id} className="hover:bg-gray-700/30">
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-white">{site.name}</p>
                    <p className="text-xs text-indigo-400">{site.subdomain}.staticdrop.com</p>
                    {site.customDomain && (
                      <p className="text-xs text-gray-500">{site.customDomain}</p>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-gray-300">{site.user.name}</p>
                    <p className="text-xs text-gray-500">{site.user.email}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        site.isActive
                          ? 'bg-green-900/50 text-green-300'
                          : 'bg-gray-700 text-gray-400'
                      }`}
                    >
                      {site.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-400">
                    {site._count.submissions}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-400">
                    {new Date(site.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <a
                      href={`${process.env.NEXT_PUBLIC_APP_URL}/site/${site.subdomain}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-indigo-400 hover:text-indigo-300"
                    >
                      Visit &rarr;
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
