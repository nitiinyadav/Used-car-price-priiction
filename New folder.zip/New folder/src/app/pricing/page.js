import Link from 'next/link';
import Navbar from '@/components/Navbar';
import prisma from '@/lib/prisma';

export const dynamic = 'force-dynamic';

export default async function PricingPage() {
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: { priority: 'asc' },
  });

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight">
              Simple, Transparent Pricing
            </h1>
            <p className="mt-4 text-xl text-gray-500 max-w-2xl mx-auto">
              Start free, scale as you grow. No hidden fees, no surprises.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {plans.map((plan) => {
              const isPopular = plan.slug === 'pro';
              const features = plan.features ? JSON.parse(plan.features) : [];

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-2xl border-2 p-8 flex flex-col ${
                    isPopular
                      ? 'border-indigo-600 shadow-xl shadow-indigo-100'
                      : 'border-gray-200'
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="bg-indigo-600 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wide">
                        Most Popular
                      </span>
                    </div>
                  )}

                  <div className="mb-6">
                    <h3 className="text-lg font-bold text-gray-900">
                      {plan.name}
                    </h3>
                    <div className="mt-4">
                      <span className="text-4xl font-extrabold text-gray-900">
                        ${(plan.priceMonthly / 100).toFixed(0)}
                      </span>
                      <span className="text-gray-500 ml-1">/mo</span>
                    </div>
                    {plan.priceYearly > 0 && (
                      <p className="mt-1 text-sm text-gray-400">
                        ${(plan.priceYearly / 100).toFixed(0)}/yr (save{' '}
                        {Math.round(
                          (1 - plan.priceYearly / (plan.priceMonthly * 12)) *
                            100
                        )}
                        %)
                      </p>
                    )}
                  </div>

                  <ul className="space-y-3 mb-8 flex-1">
                    <li className="flex items-start space-x-3 text-sm text-gray-600">
                      <svg
                        className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                      <span>
                        <strong>{plan.maxSites}</strong> website
                        {plan.maxSites > 1 ? 's' : ''}
                      </span>
                    </li>
                    <li className="flex items-start space-x-3 text-sm text-gray-600">
                      <svg
                        className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                      <span>
                        <strong>{plan.maxStorageMB} MB</strong> storage per site
                      </span>
                    </li>
                    <li className="flex items-start space-x-3 text-sm text-gray-600">
                      <svg
                        className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                      <span>
                        <strong>
                          {plan.maxSubmissions.toLocaleString()}
                        </strong>{' '}
                        form submissions
                      </span>
                    </li>
                    <li className="flex items-start space-x-3 text-sm text-gray-600">
                      {plan.customDomain ? (
                        <svg
                          className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                      ) : (
                        <svg
                          className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      )}
                      <span
                        className={
                          plan.customDomain ? '' : 'text-gray-400'
                        }
                      >
                        Custom domain
                      </span>
                    </li>

                    {features.map((feature, i) => (
                      <li
                        key={i}
                        className="flex items-start space-x-3 text-sm text-gray-600"
                      >
                        <svg
                          className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M5 13l4 4L19 7"
                          />
                        </svg>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link
                    href={
                      plan.slug === 'free'
                        ? '/register'
                        : `/register?plan=${plan.slug}`
                    }
                    className={`block w-full text-center py-3 rounded-lg font-semibold transition-colors ${
                      isPopular
                        ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    {plan.slug === 'free' ? 'Get Started' : 'Start Free Trial'}
                  </Link>
                </div>
              );
            })}
          </div>

          {/* FAQ */}
          <div className="mt-24 max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">
              Frequently Asked Questions
            </h2>
            <div className="space-y-8">
              <div>
                <h3 className="font-semibold text-gray-900">
                  Can I upgrade or downgrade at any time?
                </h3>
                <p className="mt-2 text-gray-500">
                  Yes! You can change your plan from your dashboard settings at
                  any time. Upgrades take effect immediately.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  What happens when I hit my site limit?
                </h3>
                <p className="mt-2 text-gray-500">
                  You&apos;ll need to upgrade to a higher plan or delete an existing
                  site before deploying a new one.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  Do you offer refunds?
                </h3>
                <p className="mt-2 text-gray-500">
                  Yes, we offer a 14-day money-back guarantee on all paid plans.
                  No questions asked.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">
                  Is there a free plan?
                </h3>
                <p className="mt-2 text-gray-500">
                  Absolutely! Our free plan includes 3 sites, 10 MB storage per
                  site, and 1,000 form submissions. No credit card required.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  />
                </svg>
              </div>
              <span className="text-white font-bold">StaticDrop</span>
            </div>
            <p className="text-sm">
              &copy; {new Date().getFullYear()} StaticDrop. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
