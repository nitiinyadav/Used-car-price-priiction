'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import FileUpload from '@/components/FileUpload';

export default function SiteDetailClient({ site }) {
  const router = useRouter();
  const [redeployFile, setRedeployFile] = useState(null);
  const [redeploying, setRedeploying] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function handleRedeploy() {
    if (!redeployFile) return;
    setError('');
    setMessage('');
    setRedeploying(true);

    try {
      const formData = new FormData();
      formData.append('file', redeployFile);

      const res = await fetch(`/api/sites/${site.id}/redeploy`, {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Redeploy failed');
        return;
      }

      setMessage('Site redeployed successfully!');
      setRedeployFile(null);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setRedeploying(false);
    }
  }

  async function handleDelete() {
    setError('');
    setDeleting(true);

    try {
      const res = await fetch(`/api/sites/${site.id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Delete failed');
        return;
      }

      router.push('/dashboard/sites');
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-6">
      {message && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
          {message}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      {/* Redeploy */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Update Website
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Upload a new ZIP file to replace the current website files.
        </p>
        <FileUpload onFileSelect={setRedeployFile} />
        {redeployFile && (
          <button
            onClick={handleRedeploy}
            disabled={redeploying}
            className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
          >
            {redeploying ? 'Redeploying...' : 'Redeploy Site'}
          </button>
        )}
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-xl border border-red-200 p-6">
        <h3 className="text-lg font-semibold text-red-600 mb-2">
          Danger Zone
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Permanently delete this site and all its form submissions. This action
          cannot be undone.
        </p>

        {!showDelete ? (
          <button
            onClick={() => setShowDelete(true)}
            className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors border border-red-200"
          >
            Delete Site
          </button>
        ) : (
          <div className="flex items-center space-x-3">
            <button
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              {deleting ? 'Deleting...' : 'Yes, Delete Permanently'}
            </button>
            <button
              onClick={() => setShowDelete(false)}
              className="text-gray-500 hover:text-gray-700 px-4 py-2 text-sm"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
