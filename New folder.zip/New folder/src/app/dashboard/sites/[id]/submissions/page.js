import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SubmissionsTable from '@/components/SubmissionsTable';

export async function generateMetadata({ params }) {
  return { title: 'Form Submissions - StaticDrop' };
}

export default async function SubmissionsPage({ params }) {
  const session = await getServerSession(authOptions);
  const { id } = params;

  const site = await prisma.site.findUnique({
    where: { id, userId: session.user.id },
  });

  if (!site) {
    notFound();
  }

  const submissions = await prisma.formSubmission.findMany({
    where: { siteId: site.id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return (
    <div>
      <div className="mb-8">
        <Link
          href={`/dashboard/sites/${site.id}`}
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to {site.name}</span>
        </Link>

        <h1 className="text-2xl font-bold text-gray-900">Form Submissions</h1>
        <p className="mt-1 text-gray-500">
          Submissions collected from forms on {site.name}
        </p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <SubmissionsTable submissions={submissions} siteName={site.name} />
      </div>
    </div>
  );
}
