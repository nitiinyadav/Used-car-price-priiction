import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SiteDetailClient from './SiteDetailClient';

export async function generateMetadata({ params }) {
  return { title: 'Site Details - StaticDrop' };
}

export default async function SiteDetailPage({ params }) {
  const session = await getServerSession(authOptions);
  const { id } = params;

  const site = await prisma.site.findUnique({
    where: { id, userId: session.user.id },
    include: {
      _count: { select: { submissions: true } },
    },
  });

  if (!site) {
    notFound();
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
  const rootDomain =
    process.env.NEXT_PUBLIC_ROOT_DOMAIN?.replace(':3000', '') || 'staticdrop.com';
  const siteUrl = `${appUrl}/site/${site.subdomain}`;
  const formEndpoint = `${appUrl}/api/forms/${site.apiKey}`;

  return (
    <div>
      <div className="mb-8">
        <Link
          href="/dashboard/sites"
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to Sites</span>
        </Link>

        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{site.name}</h1>
            <p className="mt-1 text-gray-500">
              {site.subdomain}.{rootDomain}
              {site.customDomain && ` | ${site.customDomain}`}
            </p>
          </div>
          <span
            className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
              site.isActive
                ? 'bg-green-100 text-green-800'
                : 'bg-gray-100 text-gray-800'
            }`}
          >
            {site.isActive ? 'Active' : 'Inactive'}
          </span>
        </div>
      </div>

      {/* Site Info Cards */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Visit Site */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-3">Site URL</h3>
          <a
            href={siteUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-600 hover:text-indigo-500 font-medium break-all"
          >
            {siteUrl}
          </a>
          <div className="mt-4">
            <a
              href={siteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
            >
              <span>Visit Site</span>
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </a>
          </div>
        </div>

        {/* Submissions */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-sm font-medium text-gray-500 mb-3">
            Form Submissions
          </h3>
          <p className="text-3xl font-bold text-gray-900">
            {site._count.submissions}
          </p>
          <div className="mt-4">
            <Link
              href={`/dashboard/sites/${site.id}/submissions`}
              className="inline-flex items-center space-x-2 text-indigo-600 hover:text-indigo-500 text-sm font-medium"
            >
              <span>View Submissions</span>
              <svg
                className="w-4 h-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5l7 7-7 7"
                />
              </svg>
            </Link>
          </div>
        </div>
      </div>

      {/* Form API Key & Embed Code */}
      <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Form Collection API
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Use this endpoint in your HTML forms to collect submissions. All data
          will appear in your dashboard.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">
              API Key
            </label>
            <div className="flex items-center space-x-2">
              <code className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono text-gray-800 break-all">
                {site.apiKey}
              </code>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-1">
              Form Endpoint
            </label>
            <code className="block bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono text-gray-800 break-all">
              {formEndpoint}
            </code>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">
              HTML Example
            </label>
            <pre className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm overflow-x-auto">
{`<form action="${formEndpoint}" method="POST">
  <input name="name" placeholder="Your Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message"></textarea>

  <!-- Optional: redirect after submit -->
  <input type="hidden" name="_redirect" value="${siteUrl}" />

  <button type="submit">Send</button>
</form>`}
            </pre>
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-500 mb-2">
              JavaScript (AJAX) Example
            </label>
            <pre className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm overflow-x-auto">
{`fetch("${formEndpoint}", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    name: "John",
    email: "john@example.com",
    message: "Hello!"
  })
})
.then(res => res.json())
.then(data => console.log("Submitted!", data));`}
            </pre>
          </div>
        </div>
      </div>

      {/* Site Management */}
      <SiteDetailClient site={site} />
    </div>
  );
}
