import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { deleteSiteFiles } from '@/lib/storage';

// GET /api/sites/[id] - Get site details
export async function GET(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const site = await prisma.site.findUnique({
      where: { id: params.id, userId: session.user.id },
      include: { _count: { select: { submissions: true } } },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    return NextResponse.json({ site });
  } catch (error) {
    console.error('Get site error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT /api/sites/[id] - Update site settings
export async function PUT(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const site = await prisma.site.findUnique({
      where: { id: params.id, userId: session.user.id },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const body = await request.json();
    const updateData = {};

    if (body.name !== undefined) {
      updateData.name = body.name.trim();
    }

    if (body.customDomain !== undefined) {
      if (body.customDomain) {
        // Check if custom domain is already in use by another site
        const existing = await prisma.site.findUnique({
          where: { customDomain: body.customDomain },
        });
        if (existing && existing.id !== site.id) {
          return NextResponse.json(
            { error: 'This custom domain is already in use' },
            { status: 409 }
          );
        }
        updateData.customDomain = body.customDomain.toLowerCase().trim();
      } else {
        updateData.customDomain = null;
      }
    }

    if (body.isActive !== undefined) {
      updateData.isActive = Boolean(body.isActive);
    }

    const updated = await prisma.site.update({
      where: { id: site.id },
      data: updateData,
      include: { _count: { select: { submissions: true } } },
    });

    return NextResponse.json({ site: updated });
  } catch (error) {
    console.error('Update site error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE /api/sites/[id] - Delete site
export async function DELETE(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const site = await prisma.site.findUnique({
      where: { id: params.id, userId: session.user.id },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    // Delete files
    deleteSiteFiles(site.id);

    // Delete database record (cascades to submissions)
    await prisma.site.delete({ where: { id: site.id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete site error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
