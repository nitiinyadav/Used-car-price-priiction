import { NextResponse } from 'next/server';
import mime from 'mime-types';
import prisma from '@/lib/prisma';
import { getFile } from '@/lib/storage';

// GET /api/serve/[subdomain]/[[...path]] - Serve static files for a deployed site
export async function GET(request, { params }) {
  try {
    const { subdomain } = params;
    const pathSegments = params.path || [];
    const filePath = pathSegments.join('/') || 'index.html';

    // Look up site by subdomain
    const site = await prisma.site.findUnique({
      where: { subdomain },
    });

    if (!site || !site.isActive) {
      return new NextResponse(notFoundPage(subdomain), {
        status: 404,
        headers: { 'Content-Type': 'text/html' },
      });
    }

    // Get the file
    const fileContent = getFile(site.id, filePath);

    if (!fileContent) {
      // Try with .html extension
      const htmlContent = getFile(site.id, filePath + '.html');
      if (htmlContent) {
        return new NextResponse(htmlContent, {
          status: 200,
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'public, max-age=300',
          },
        });
      }

      // Try index.html in the path as directory
      const indexContent = getFile(site.id, filePath + '/index.html');
      if (indexContent) {
        return new NextResponse(indexContent, {
          status: 200,
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'public, max-age=300',
          },
        });
      }

      return new NextResponse(notFoundPage(subdomain), {
        status: 404,
        headers: { 'Content-Type': 'text/html' },
      });
    }

    // Determine content type
    const contentType = mime.lookup(filePath) || 'application/octet-stream';
    const charset = mime.charset(contentType);

    const headers = {
      'Content-Type': charset
        ? `${contentType}; charset=${charset}`
        : contentType,
      'Content-Length': String(fileContent.length),
      'Cache-Control': 'public, max-age=3600',
    };

    // Add security headers
    if (contentType === 'text/html') {
      headers['X-Content-Type-Options'] = 'nosniff';
      headers['X-Frame-Options'] = 'SAMEORIGIN';
      headers['Cache-Control'] = 'public, max-age=300';
    }

    return new NextResponse(fileContent, {
      status: 200,
      headers,
    });
  } catch (error) {
    console.error('Serve error:', error);
    return new NextResponse('Internal Server Error', {
      status: 500,
      headers: { 'Content-Type': 'text/plain' },
    });
  }
}

function notFoundPage(subdomain) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Site Not Found</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f9fafb; color: #374151; }
    .container { text-align: center; padding: 48px; }
    h1 { font-size: 48px; font-weight: 700; color: #111827; margin: 0 0 8px; }
    p { font-size: 18px; color: #6b7280; margin: 8px 0 0; }
    a { color: #4f46e5; text-decoration: none; display: inline-block; margin-top: 24px; font-weight: 500; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="container">
    <h1>404</h1>
    <p>The site <strong>${subdomain}</strong> was not found or is inactive.</p>
    <a href="${process.env.NEXT_PUBLIC_APP_URL || '/'}">Go to StaticDrop</a>
  </div>
</body>
</html>`;
}
