import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { v4 as uuidv4 } from 'uuid';

// POST /api/payments/checkout — upgrade user plan
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { planSlug, billingPeriod } = await request.json();

    if (!planSlug || !['monthly', 'yearly'].includes(billingPeriod)) {
      return NextResponse.json(
        { error: 'Invalid plan or billing period' },
        { status: 400 }
      );
    }

    // Look up the plan
    const plan = await prisma.plan.findUnique({
      where: { slug: planSlug },
    });

    if (!plan || !plan.isActive) {
      return NextResponse.json(
        { error: 'Plan not found or inactive' },
        { status: 404 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Prevent re-buying same plan
    if (user.plan === planSlug) {
      return NextResponse.json(
        { error: 'You are already on this plan' },
        { status: 400 }
      );
    }

    // For free plan — just downgrade, no payment
    if (plan.priceMonthly === 0) {
      await prisma.user.update({
        where: { id: user.id },
        data: { plan: 'free' },
      });

      return NextResponse.json({
        success: true,
        message: 'Downgraded to Free plan',
        plan: 'free',
      });
    }

    // Calculate amount
    const amount =
      billingPeriod === 'yearly' ? plan.priceYearly : plan.priceMonthly;

    // Calculate billing period dates
    const startsAt = new Date();
    const expiresAt = new Date();
    if (billingPeriod === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    }

    // Create a payment record (simulated — replace with Stripe/Razorpay in production)
    const payment = await prisma.payment.create({
      data: {
        userId: user.id,
        planSlug: plan.slug,
        amount,
        currency: 'USD',
        status: 'succeeded',
        billingPeriod,
        startsAt,
        expiresAt,
        transactionId: `txn_${uuidv4().replace(/-/g, '').slice(0, 20)}`,
      },
    });

    // Upgrade user plan
    await prisma.user.update({
      where: { id: user.id },
      data: { plan: plan.slug },
    });

    return NextResponse.json({
      success: true,
      message: `Upgraded to ${plan.name} plan`,
      plan: plan.slug,
      paymentId: payment.id,
      expiresAt: expiresAt.toISOString(),
    });
  } catch (error) {
    console.error('Checkout error:', error);
    return NextResponse.json(
      { error: 'Failed to process payment' },
      { status: 500 }
    );
  }
}
