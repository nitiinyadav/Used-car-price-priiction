'use client';

import { useState } from 'react';

export default function SubmissionsTable({ submissions, siteName }) {
  const [expandedRow, setExpandedRow] = useState(null);

  if (!submissions || submissions.length === 0) {
    return (
      <div className="text-center py-12">
        <svg
          className="mx-auto h-12 w-12 text-gray-400"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
          />
        </svg>
        <h3 className="mt-2 text-sm font-medium text-gray-900">
          No form submissions yet
        </h3>
        <p className="mt-1 text-sm text-gray-500">
          Form submissions from your website will appear here.
        </p>
      </div>
    );
  }

  function exportCSV() {
    const allKeys = new Set();
    submissions.forEach((sub) => {
      const data = JSON.parse(sub.data);
      Object.keys(data).forEach((key) => allKeys.add(key));
    });

    const headers = ['Date', 'Form', ...allKeys, 'IP Address'];
    const rows = submissions.map((sub) => {
      const data = JSON.parse(sub.data);
      return [
        new Date(sub.createdAt).toISOString(),
        sub.formName,
        ...[...allKeys].map((key) => data[key] || ''),
        sub.ipAddress || '',
      ];
    });

    const csv = [headers, ...rows]
      .map((row) =>
        row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')
      )
      .join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${siteName || 'submissions'}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <p className="text-sm text-gray-500">
          {submissions.length} submission{submissions.length !== 1 ? 's' : ''}
        </p>
        <button
          onClick={exportCSV}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500 flex items-center space-x-1"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <span>Export CSV</span>
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Form
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Data
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                IP
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {submissions.map((sub, index) => {
              const data = JSON.parse(sub.data);
              const isExpanded = expandedRow === index;
              const preview = Object.entries(data)
                .slice(0, 2)
                .map(([k, v]) => `${k}: ${v}`)
                .join(', ');

              return (
                <tr
                  key={sub.id}
                  className="hover:bg-gray-50 cursor-pointer"
                  onClick={() => setExpandedRow(isExpanded ? null : index)}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(sub.createdAt).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {sub.formName}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {isExpanded ? (
                      <div className="space-y-1">
                        {Object.entries(data).map(([key, value]) => (
                          <div key={key}>
                            <span className="font-medium text-gray-700">
                              {key}:
                            </span>{' '}
                            {String(value)}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="truncate block max-w-xs">
                        {preview}
                        {Object.keys(data).length > 2 && '...'}
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {sub.ipAddress || '-'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
