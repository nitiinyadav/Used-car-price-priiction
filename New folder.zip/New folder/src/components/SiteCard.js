import Link from 'next/link';

export default function SiteCard({ site }) {
  const siteUrl = `${process.env.NEXT_PUBLIC_APP_URL}/site/${site.subdomain}`;

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <h3 className="text-lg font-semibold text-gray-900 truncate">
            {site.name}
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            {site.subdomain}.{process.env.NEXT_PUBLIC_ROOT_DOMAIN?.replace(':3000', '') || 'staticdrop.com'}
          </p>
          {site.customDomain && (
            <p className="text-sm text-indigo-600 mt-0.5">{site.customDomain}</p>
          )}
        </div>
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            site.isActive
              ? 'bg-green-100 text-green-800'
              : 'bg-gray-100 text-gray-800'
          }`}
        >
          {site.isActive ? 'Active' : 'Inactive'}
        </span>
      </div>

      <div className="mt-4 flex items-center space-x-4 text-sm text-gray-500">
        <span className="flex items-center space-x-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <span>{site._count?.submissions ?? 0} submissions</span>
        </span>
        <span>
          Deployed {new Date(site.createdAt).toLocaleDateString()}
        </span>
      </div>

      <div className="mt-4 flex items-center space-x-3">
        <Link
          href={`/dashboard/sites/${site.id}`}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
        >
          Manage
        </Link>
        <a
          href={siteUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-sm font-medium text-gray-600 hover:text-gray-500"
        >
          Visit Site &rarr;
        </a>
      </div>
    </div>
  );
}
