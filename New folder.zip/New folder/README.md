# StaticDrop

**Deploy static HTML/CSS/JS websites instantly.** No server management, no CLI tools, no configuration. Just upload a ZIP file and your site is live.

## What is StaticDrop?

StaticDrop is a SaaS platform that lets anyone deploy static websites by simply uploading a ZIP file. It's built for developers who know how to build websites but don't want the hassle of managing servers — especially for small portfolio sites, landing pages, and personal projects.

### Key Features

- **One-Click Deploy** — Upload a ZIP, get a live website
- **Free Subdomains** — Every site gets `yoursite.staticdrop.com`
- **Custom Domains** — Connect your own domain via CNAME
- **Form Collection API** — Collect form submissions without a backend
- **Dashboard** — Manage sites, view submissions, export data
- **Re-deploy** — Update your site by uploading a new ZIP

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up the database
npx prisma db push

# 3. (Optional) Seed demo user
npm run db:seed

# 4. Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and register an account or use the demo credentials:
- **Email:** demo@staticdrop.com
- **Password:** password123

## Tech Stack

- **Next.js 14** (App Router, JavaScript)
- **Prisma** + SQLite (database)
- **NextAuth.js** (authentication)
- **Tailwind CSS** (styling)
- **AdmZip** (ZIP extraction)

## Project Structure

```
├── prisma/                  # Database schema & seed
├── src/
│   ├── app/
│   │   ├── (auth)/          # Login & register pages
│   │   ├── dashboard/       # Dashboard pages
│   │   ├── api/             # API routes
│   │   │   ├── auth/        # Authentication endpoints
│   │   │   ├── sites/       # Site CRUD + redeploy
│   │   │   ├── forms/       # Form submission endpoint
│   │   │   ├── submissions/ # View submissions
│   │   │   └── serve/       # Static file serving
│   │   └── site/            # Site preview routes
│   ├── components/          # React components
│   ├── lib/                 # Utilities & config
│   └── middleware.js        # Subdomain routing
├── uploads/                 # Deployed site files (gitignored)
└── docs/                    # Documentation
```

## Documentation

- [Complete Idea & Vision](docs/IDEA.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Setup Guide](docs/SETUP.md)
- [API Reference](docs/API-REFERENCE.md)
- [User Guide](docs/USER-GUIDE.md)
- [Deployment](docs/DEPLOYMENT.md)

## License

MIT
