# User Guide

## Getting Started

### 1. Create an Account

Visit the StaticDrop homepage and click **"Get Started Free"**. Fill in your name, email, and a password (minimum 8 characters).

### 2. Deploy Your First Website

After signing in, you'll see the dashboard. Click **"Deploy New Site"**.

#### Prepare Your Files

Your website should be a standard HTML/CSS/JS project. At minimum, you need an `index.html` file. Example structure:

```
my-website/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
└── images/
    └── photo.jpg
```

**ZIP the folder** using your operating system's built-in zip tool or any archive utility.

> **Tip:** You can ZIP the folder itself or just the files inside. StaticDrop automatically detects if there's a single root folder and extracts correctly either way.

#### Fill in the Details

- **Site Name**: A friendly label for your site (only you see this)
- **Subdomain**: The URL for your site. If you enter `my-portfolio`, your site will be at `my-portfolio.staticdrop.com`
- **Custom Domain** (optional): If you own a domain, enter it here

#### Upload & Deploy

Click the upload area or drag your ZIP file in. Then click **"Deploy Site"**. Your site will be live within seconds!

### 3. Visit Your Site

After deployment, you'll see your site's details page with the live URL. Click **"Visit Site"** to see it in action.

In local development, sites are accessible at:
```
http://localhost:3000/site/your-subdomain
```

In production with a configured domain:
```
https://your-subdomain.staticdrop.com
```

---

## Adding Forms to Your Website

StaticDrop includes a built-in form collection API. You can add forms to your website that submit data directly to your dashboard — no backend code needed.

### Method 1: Standard HTML Form

Add a form with the `action` pointing to your site's form endpoint:

```html
<form action="https://staticdrop.com/api/forms/YOUR_API_KEY" method="POST">
  <label>
    Name
    <input name="name" type="text" required />
  </label>

  <label>
    Email
    <input name="email" type="email" required />
  </label>

  <label>
    Message
    <textarea name="message" required></textarea>
  </label>

  <!-- Optional: redirect after submission -->
  <input type="hidden" name="_redirect" value="https://your-site.com/thank-you.html" />

  <button type="submit">Send Message</button>
</form>
```

When someone submits this form:
1. Data is saved to your StaticDrop dashboard
2. User is redirected to the `_redirect` URL (or shown a "Thank You" page)

### Method 2: JavaScript (AJAX)

For a more dynamic experience without page reload:

```html
<form id="contactForm">
  <input name="name" placeholder="Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message" required></textarea>
  <button type="submit">Send</button>
  <div id="status"></div>
</form>

<script>
  document.getElementById('contactForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);

    const status = document.getElementById('status');
    status.textContent = 'Sending...';

    try {
      const response = await fetch('https://staticdrop.com/api/forms/YOUR_API_KEY', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        status.textContent = 'Message sent successfully!';
        e.target.reset();
      } else {
        status.textContent = 'Failed to send. Please try again.';
      }
    } catch (error) {
      status.textContent = 'Network error. Please try again.';
    }
  });
</script>
```

### Finding Your API Key

1. Go to **Dashboard → My Sites**
2. Click **Manage** on your site
3. Scroll to **Form Collection API** section
4. Copy the API key or the full endpoint URL

### Special Form Fields

| Field Name | Purpose |
|------------|---------|
| `_redirect` | URL to redirect to after form submission |
| `_formName` | Label to categorize submissions (e.g., "contact", "newsletter") |

> Fields starting with `_` are processed by StaticDrop and not stored in the submission data.

---

## Managing Your Sites

### Viewing Submissions

1. Go to **Dashboard → My Sites**
2. Click **Manage** on a site
3. Click **View Submissions**

You can:
- Click any row to expand and see all fields
- Export all submissions to CSV

### Updating Your Website

To update a deployed site with new files:

1. Go to the site's detail page
2. Scroll to **Update Website**
3. Upload a new ZIP file
4. Click **Redeploy Site**

The URL stays the same — only the files are replaced.

### Deleting a Site

1. Go to the site's detail page
2. Scroll to **Danger Zone**
3. Click **Delete Site** and confirm

> **Warning:** This permanently deletes the site, all files, and all form submissions. This cannot be undone.

---

## Custom Domains

### Setting Up a Custom Domain

1. During site creation (or in site settings), enter your custom domain (e.g., `www.mydomain.com`)
2. Go to your domain registrar's DNS settings
3. Add a **CNAME record**:
   - **Name/Host:** `www` (or your subdomain)
   - **Value/Target:** `staticdrop.com`
   - **TTL:** 3600 (or default)

4. Wait for DNS propagation (usually 5-30 minutes, can take up to 48 hours)
5. Visit your custom domain — it should show your site!

### DNS Example

| Type  | Name | Value            | TTL  |
|-------|------|------------------|------|
| CNAME | www  | staticdrop.com   | 3600 |

> **Note:** For root/apex domains (e.g., `mydomain.com` without `www`), you may need to use your registrar's specific method (some support ALIAS or ANAME records).

---

## Account Settings

### Changing Your Name

1. Go to **Dashboard → Settings**
2. Update your name
3. Click **Save Changes**

### Changing Your Password

1. Go to **Dashboard → Settings**
2. Scroll to **Change Password**
3. Enter your current password and new password
4. Click **Change Password**
