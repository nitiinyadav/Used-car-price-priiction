# Deployment Guide

## Prerequisites

- A server or cloud platform (VPS, DigitalOcean, Railway, Render, etc.)
- Node.js 18+
- A domain name (for production subdomain routing)

## Option 1: Deploy to a VPS (DigitalOcean, Linode, AWS EC2)

### 1. Prepare the Server

```bash
# Update packages
sudo apt update && sudo apt upgrade -y

# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node -v  # Should be 18+
npm -v
```

### 2. Clone and Set Up

```bash
git clone <your-repo-url> /var/www/staticdrop
cd /var/www/staticdrop

# Install dependencies
npm install --production

# Set up environment
cp .env.example .env
nano .env
```

Update `.env` for production:

```env
DATABASE_URL="file:./prod.db"
NEXTAUTH_SECRET="<generate-a-long-random-string>"
NEXTAUTH_URL="https://staticdrop.com"
NEXT_PUBLIC_ROOT_DOMAIN="staticdrop.com"
NEXT_PUBLIC_APP_NAME="StaticDrop"
NEXT_PUBLIC_APP_URL="https://staticdrop.com"
MAX_UPLOAD_SIZE_MB=10
MAX_SITES_FREE=3
MAX_SUBMISSIONS_FREE=1000
```

### 3. Initialize Database

```bash
npx prisma db push
```

### 4. Build and Start

```bash
npm run build
npm run start
```

### 5. Set Up Nginx Reverse Proxy

```nginx
# /etc/nginx/sites-available/staticdrop
server {
    listen 80;
    server_name staticdrop.com *.staticdrop.com;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable and restart:

```bash
sudo ln -s /etc/nginx/sites-available/staticdrop /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. SSL with Certbot

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d staticdrop.com -d *.staticdrop.com
```

> **Note:** Wildcard SSL requires DNS validation. Use `--preferred-challenges dns` and add the TXT record to your DNS.

### 7. Process Manager (PM2)

```bash
npm install -g pm2

# Start the app
pm2 start npm --name staticdrop -- start

# Save process list
pm2 save

# Auto-start on reboot
pm2 startup
```

### 8. DNS Configuration

At your domain registrar, add:

| Type  | Name | Value              |
|-------|------|--------------------|
| A     | @    | `<your-server-ip>` |
| A     | *    | `<your-server-ip>` |

The wildcard `*` record routes all subdomains to your server.

---

## Option 2: Deploy to Railway

[Railway](https://railway.app) provides easy Node.js hosting.

1. Push your code to GitHub
2. Create a new project on Railway
3. Connect your GitHub repo
4. Add environment variables in Railway's dashboard
5. Railway auto-detects Next.js and deploys

For subdomain routing, you'll need a custom domain with wildcard configured.

---

## Option 3: Deploy to Render

1. Create a **Web Service** on [Render](https://render.com)
2. Connect to your GitHub repo
3. Set:
   - **Build Command:** `npm install && npx prisma generate && npm run build`
   - **Start Command:** `npm run start`
4. Add environment variables
5. Deploy

---

## Production Database

For production, consider switching from SQLite to PostgreSQL:

### 1. Update Prisma Schema

In `prisma/schema.prisma`, change:

```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

### 2. Update DATABASE_URL

```env
DATABASE_URL="postgresql://user:password@host:5432/staticdrop"
```

### 3. Migrate

```bash
npx prisma db push
```

---

## Production File Storage

For production, consider moving file storage to S3 or Cloudflare R2:

1. Replace local filesystem operations in `src/lib/storage.js` with S3 SDK calls
2. Update the serve route to read from S3 instead of local disk
3. This enables horizontal scaling (multiple servers)

---

## Production Checklist

- [ ] Set a strong `NEXTAUTH_SECRET` (at least 32 random characters)
- [ ] Use PostgreSQL instead of SQLite
- [ ] Set up SSL (HTTPS)
- [ ] Configure wildcard DNS (`*.yourdomain.com`)
- [ ] Set `NODE_ENV=production`
- [ ] Configure `client_max_body_size` in Nginx for file uploads
- [ ] Set up regular database backups
- [ ] Set up file storage backups (or use S3)
- [ ] Configure a process manager (PM2) for auto-restart
- [ ] Set up monitoring/alerting
- [ ] Review and adjust rate limits
- [ ] Test form API CORS from deployed sites
