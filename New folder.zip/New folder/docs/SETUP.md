# Setup Guide

## Prerequisites

- **Node.js** 18 or later
- **npm** (comes with Node.js)

## Installation

### 1. Clone / Download the Project

```bash
cd staticdrop
```

### 2. Install Dependencies

```bash
npm install
```

This will also run `prisma generate` automatically (via the `postinstall` script).

### 3. Set Up Environment Variables

Copy the example env file:

```bash
cp .env.example .env
```

Edit `.env` with your settings:

```env
# Database (SQLite for development)
DATABASE_URL="file:./dev.db"

# NextAuth — CHANGE THIS in production!
NEXTAUTH_SECRET="generate-a-random-32-char-string"
NEXTAUTH_URL="http://localhost:3000"

# App Config
NEXT_PUBLIC_ROOT_DOMAIN="localhost:3000"
NEXT_PUBLIC_APP_NAME="StaticDrop"
NEXT_PUBLIC_APP_URL="http://localhost:3000"

# Limits
MAX_UPLOAD_SIZE_MB=10
MAX_SITES_FREE=3
MAX_SUBMISSIONS_FREE=1000
```

To generate a secure `NEXTAUTH_SECRET`:

```bash
# On Linux/Mac:
openssl rand -base64 32

# On Windows (PowerShell):
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Maximum 256 }) -as [byte[]])
```

### 4. Set Up the Database

Push the Prisma schema to create the SQLite database:

```bash
npx prisma db push
```

### 5. (Optional) Seed Demo Data

Create a demo user for testing:

```bash
npm run db:seed
```

This creates:
- **Email:** demo@staticdrop.com
- **Password:** password123

### 6. Start the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Useful Commands

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run start` | Start production server |
| `npm run db:push` | Push schema changes to database |
| `npm run db:seed` | Seed demo data |
| `npm run db:studio` | Open Prisma Studio (DB browser) |

## Testing Your Setup

1. Open `http://localhost:3000` — you should see the landing page
2. Click "Get Started" to register a new account
3. After registration, you'll be redirected to the dashboard
4. Click "Deploy New Site" to deploy your first website

### Creating a Test Website ZIP

Create a folder with a simple website:

```
my-site/
├── index.html
├── style.css
└── script.js
```

**index.html:**
```html
<!DOCTYPE html>
<html>
<head>
  <title>My Test Site</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello from StaticDrop!</h1>
  <p>This site was deployed by uploading a ZIP file.</p>
  <script src="script.js"></script>
</body>
</html>
```

ZIP the folder and upload it through the dashboard.

## Troubleshooting

### "prisma: command not found"
Run `npm install` first. Prisma is installed as a dev dependency.

### "NEXTAUTH_SECRET must be set"
Make sure you have a `.env` file with `NEXTAUTH_SECRET` defined.

### Database errors after schema change
Run `npx prisma db push` to sync the schema, then restart the dev server.

### Port 3000 already in use
Change the port: `npm run dev -- -p 3001` and update `NEXTAUTH_URL` and `NEXT_PUBLIC_APP_URL` accordingly.
