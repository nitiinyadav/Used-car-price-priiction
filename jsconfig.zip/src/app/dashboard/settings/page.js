import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import { getUserFeatureQuota } from '@/lib/feature-access';
import SettingsClient from './SettingsClient';

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  // Check team feature access
  let canManageTeam = false;
  if (session.user.role === 'superadmin') {
    canManageTeam = true;
  } else if (!session.user.ownerId) {
    try {
      const quota = await getUserFeatureQuota(session.user.id, 'team-members');
      canManageTeam = quota.hasAccess;
    } catch (err) {
      console.error('Team feature check failed:', err.message);
    }
  }

  const teamMembers = canManageTeam
    ? await prisma.user.findMany({
        where: { ownerId: session.user.id },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          memberPermissions: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
      })
    : [];

  return (
    <SettingsClient
      sessionUser={session.user}
      teamMembers={teamMembers}
      canManageTeam={canManageTeam}
    />
  );
}
