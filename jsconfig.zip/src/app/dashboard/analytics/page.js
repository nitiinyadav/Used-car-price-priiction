import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import Link from 'next/link';
import { getWorkspaceContext } from '@/lib/workspace';
import { getUserFeatureQuota } from '@/lib/feature-access';
import ConsolidatedAnalytics from './ConsolidatedAnalytics';

export const metadata = {
  title: 'Analytics - LiveInSec',
};

export default async function AnalyticsDashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  // Check feature-based access
  let hasAnalyticsAccess = session.user.role === 'superadmin';
  if (!hasAnalyticsAccess) {
    try {
      const quota = await getUserFeatureQuota(session.user.id, 'analytics');
      hasAnalyticsAccess = quota.hasAccess;
    } catch (err) {
      console.error('Feature quota check failed:', err.message);
      hasAnalyticsAccess = false;
    }
  }

  // Users without analytics feature see purchase prompt
  if (!hasAnalyticsAccess) {
    return (
      <div>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="mt-1 text-gray-500">Consolidated traffic insights across all your sites.</p>
        </div>
        <div className="rounded-2xl border border-gray-200 bg-white p-12 text-center">
          <div className="mx-auto w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Analytics Requires a Purchase</h2>
          <p className="text-gray-500 mb-6 max-w-md mx-auto">
            Buy the Analytics feature to unlock detailed visitor tracking, page views,
            referrer insights, and live visitor counts across all your sites.
          </p>
          <Link
            href="/dashboard/store"
            className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
            </svg>
            Buy Analytics
          </Link>
        </div>
      </div>
    );
  }

  // Fetch all sites for the user
  const sites = await prisma.site.findMany({
    where: { userId: workspaceOwnerId },
    select: { id: true, name: true, subdomain: true },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
        <p className="mt-1 text-gray-500">
          Consolidated traffic insights across all your sites.
        </p>
      </div>

      <ConsolidatedAnalytics sites={sites} />
    </div>
  );
}
