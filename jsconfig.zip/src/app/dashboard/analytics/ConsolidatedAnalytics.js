'use client';

import { useState } from 'react';
import Link from 'next/link';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';

export default function ConsolidatedAnalytics({ sites }) {
  const [selectedSiteId, setSelectedSiteId] = useState(null);

  if (sites.length === 0) {
    return (
      <div className="rounded-2xl border border-gray-200 bg-white p-12 text-center">
        <p className="text-4xl mb-4">📊</p>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No Sites Yet</h3>
        <p className="text-gray-500 text-sm mb-4">Deploy a site first to start tracking analytics.</p>
        <Link
          href="/dashboard/sites/new"
          className="inline-flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors"
        >
          Deploy a Site
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Site selector */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedSiteId(null)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              selectedSiteId === null
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All Sites
          </button>
          {sites.map((site) => (
            <button
              key={site.id}
              onClick={() => setSelectedSiteId(site.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedSiteId === site.id
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {site.name}
            </button>
          ))}
        </div>
      </div>

      {/* Analytics content */}
      {selectedSiteId ? (
        <AnalyticsDashboard siteId={selectedSiteId} />
      ) : (
        <div className="space-y-8">
          {sites.map((site) => (
            <div key={site.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">{site.name}</h3>
                <Link
                  href={`/dashboard/sites/${site.id}/analytics`}
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  View Details →
                </Link>
              </div>
              <AnalyticsDashboard siteId={site.id} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
