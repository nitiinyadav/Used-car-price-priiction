import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SubmissionsTable from '@/components/SubmissionsTable';
import SiteTabs from '@/components/SiteTabs';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';
import { getUserFeatureQuota } from '@/lib/feature-access';

export async function generateMetadata({ params }) {
  return { title: 'Form Submissions - LiveInSec' };
}

export default async function SubmissionsPage({ params, searchParams }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const { id } = params;
  if (!hasPermission(workspace, 'view_submissions')) {
    notFound();
  }

  // Check feature-based access
  let hasSubmissionAccess = session.user.role === 'superadmin';
  if (!hasSubmissionAccess) {
    try {
      const quota = await getUserFeatureQuota(session.user.id, 'submissions');
      hasSubmissionAccess = quota.hasAccess;
    } catch (err) {
      console.error('Feature quota check failed:', err.message);
      hasSubmissionAccess = false;
    }
  }

  const site = await prisma.site.findFirst({
    where: { id, userId: workspace?.workspaceOwnerId || session.user.id },
  });

  if (!site) {
    notFound();
  }

  // Users without submission feature see analytics-only view
  if (!hasSubmissionAccess) {
    const [totalSubmissions, recentCount] = await Promise.all([
      prisma.formSubmission.count({ where: { siteId: site.id } }),
      prisma.formSubmission.count({
        where: { siteId: site.id, createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
      }),
    ]);
    return (
      <div>
        <div className="mb-8">
          <Link href={`/dashboard/sites/${site.id}`} className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            <span>Back to {site.name}</span>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Submission Analytics</h1>
          <p className="mt-1 text-gray-500">Form submission overview for {site.name}</p>
        </div>
        <SiteTabs siteId={site.id} />

        <div className="mb-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm text-gray-500">Total Submissions</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">{totalSubmissions}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm text-gray-500">Last 7 Days</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
          </div>
        </div>

        <div className="rounded-2xl border border-gray-200 bg-white p-8 text-center">
          <div className="mx-auto w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <svg className="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">Viewing Submission Details Requires a Purchase</h2>
          <p className="text-gray-500 mb-6 max-w-md mx-auto text-sm">
            Buy the Form Submissions feature to read individual submissions, export data, and receive email notifications for new leads.
          </p>
          <Link href="/dashboard/store" className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" /></svg>
            Buy Submissions
          </Link>
        </div>
      </div>
    );
  }

  const page = Math.max(1, Number(searchParams?.page || 1));
  const query = String(searchParams?.q || '').trim();
  const pageSize = 10;

  const where = {
    siteId: site.id,
    ...(query
      ? {
          OR: [
            { formName: { contains: query } },
            { data: { contains: query } },
          ],
        }
      : {}),
  };

  const [submissions, total, recentCount] = await Promise.all([
    prisma.formSubmission.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.formSubmission.count({ where }),
    prisma.formSubmission.count({
      where: {
        siteId: site.id,
        createdAt: {
          gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        },
      },
    }),
  ]);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="mb-8">
        <Link
          href={`/dashboard/sites/${site.id}`}
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to {site.name}</span>
        </Link>

        <h1 className="text-2xl font-bold text-gray-900">Form Submissions</h1>
        <p className="mt-1 text-gray-500">
          Submissions collected from forms on {site.name}
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Total Submissions</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Last 7 Days</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Current Page</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">
            {page} / {totalPages}
          </p>
        </div>
      </div>

      <form className="mb-4 rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="Search by form name or submission content"
            className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Search
          </button>
        </div>
      </form>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <SubmissionsTable
          submissions={submissions}
          siteName={site.name}
          totalCount={total}
          page={page}
          totalPages={totalPages}
          basePath={`/dashboard/sites/${site.id}/submissions`}
          searchQuery={query}
        />
      </div>
    </div>
  );
}
