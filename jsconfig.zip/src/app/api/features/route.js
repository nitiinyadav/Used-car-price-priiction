import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { invalidateFeatureCache } from '@/lib/feature-access';

// GET /api/features — List all active features (public for store)
export async function GET() {
  try {
    const features = await prisma.feature.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });
    return NextResponse.json({ features });
  } catch (error) {
    console.error('List features error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/features — Admin: create or seed features
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'superadmin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await request.json();

    // Seed mode: initialize default features
    if (body.seed) {
      const defaults = [
        {
          slug: 'submissions',
          name: 'Form Submissions',
          description: 'Collect form submissions from your deployed sites. Includes spam protection, rate limiting, and CSV export.',
          icon: '📬',
          category: 'core',
          type: 'quantity',
          unitLabel: 'submissions',
          freeQuota: 0,
          priceUsd: 500,   // $5 per 1000
          priceInr: 40000,  // ₹400 per 1000
          minQty: 100,
          maxQty: 100000,
          stepQty: 100,
          durationDays: null,
          isFeatured: true,
          sortOrder: 1,
          showInSidebar: true,
          sidebarLabel: 'Inbox',
          sidebarIcon: 'inbox',
          sidebarHref: '/dashboard/submissions',
          highlights: JSON.stringify([
            'Collect leads from any HTML form',
            'Built-in spam protection & honeypot',
            'Export submissions to CSV',
            'Email notifications for new leads',
          ]),
        },
        {
          slug: 'custom-domain',
          name: 'Custom Domains',
          description: 'Connect your own domain to any deployed site. Includes automatic SSL certificate and DNS verification.',
          icon: '🌐',
          category: 'core',
          type: 'quantity',
          unitLabel: 'domains',
          freeQuota: 0,
          priceUsd: 299,    // $2.99 per domain
          priceInr: 24900,   // ₹249 per domain
          minQty: 1,
          maxQty: 50,
          stepQty: 1,
          durationDays: null, // lifetime
          isFeatured: true,
          sortOrder: 2,
          showInSidebar: false,
          highlights: JSON.stringify([
            'Connect any domain you own',
            'Automatic SSL certificate',
            'DNS verification wizard',
            'Lifetime — no recurring fees',
          ]),
        },
        {
          slug: 'analytics',
          name: 'Site Analytics',
          description: 'Real-time visitor tracking, page views, unique visitors, referrers, and live visitor count for all your sites.',
          icon: '📊',
          category: 'core',
          type: 'duration',
          unitLabel: 'months',
          freeQuota: 0,
          priceUsd: 299,    // $2.99/month
          priceInr: 24900,   // ₹249/month
          minQty: 1,
          maxQty: 24,
          stepQty: 1,
          durationDays: 30, // per month
          isFeatured: true,
          sortOrder: 3,
          showInSidebar: true,
          sidebarLabel: 'Analytics',
          sidebarIcon: 'chart',
          sidebarHref: '/dashboard/analytics',
          highlights: JSON.stringify([
            'Real-time visitor tracking',
            'Page views & unique visitors',
            'Referrer & country breakdown',
            'Live visitor count on dashboard',
          ]),
        },
        {
          slug: 'extra-storage',
          name: 'Extra Storage',
          description: 'Add more storage space for your sites beyond the free 200 MB. Each unit adds 1 GB of additional storage.',
          icon: '💾',
          category: 'core',
          type: 'quantity',
          unitLabel: 'GB',
          freeQuota: 200, // 200 MB free (stored as MB)
          priceUsd: 99,     // $0.99 per GB
          priceInr: 7900,    // ₹79 per GB
          minQty: 1,
          maxQty: 100,
          stepQty: 1,
          durationDays: null, // lifetime
          isFeatured: false,
          sortOrder: 4,
          showInSidebar: false,
          highlights: JSON.stringify([
            'Expand your storage capacity',
            '1 GB per unit purchased',
            'Lifetime — no recurring fees',
            'Works across all your sites',
          ]),
        },
        {
          slug: 'team-members',
          name: 'Team Members',
          description: 'Add team members to your workspace. Each member gets their own login with configurable permissions.',
          icon: '👥',
          category: 'core',
          type: 'quantity',
          unitLabel: 'members',
          freeQuota: 0,
          priceUsd: 499,     // $4.99 per member
          priceInr: 39900,    // ₹399 per member
          minQty: 1,
          maxQty: 50,
          stepQty: 1,
          durationDays: null, // lifetime
          isFeatured: true,
          sortOrder: 5,
          showInSidebar: false,
          highlights: JSON.stringify([
            'Add team members to your workspace',
            'Configurable permissions per member',
            'Separate login for each member',
            'Lifetime — no recurring fees',
          ]),
        },
      ];

      let created = 0;
      for (const feat of defaults) {
        const existing = await prisma.feature.findUnique({ where: { slug: feat.slug } });
        if (!existing) {
          await prisma.feature.create({ data: feat });
          created++;
        }
      }

      invalidateFeatureCache();
      return NextResponse.json({ success: true, created, message: `Seeded ${created} features` });
    }

    // Normal create
    const { slug, name, description, ...rest } = body;
    if (!slug || !name) {
      return NextResponse.json({ error: 'slug and name are required' }, { status: 400 });
    }

    const existing = await prisma.feature.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: 'Feature with this slug already exists' }, { status: 409 });
    }

    const feature = await prisma.feature.create({
      data: { slug, name, description: description || '', ...rest },
    });

    invalidateFeatureCache();
    return NextResponse.json({ feature });
  } catch (error) {
    console.error('Create feature error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
