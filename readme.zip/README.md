# StaticDrop

**Deploy static HTML, CSS, and JavaScript websites instantly.** Upload a ZIP, publish to a subdomain, collect leads, and upgrade customers into paid plans from one product.

## What Is StaticDrop?

StaticDrop is a SaaS platform for developers, agencies, and small businesses that want to launch static sites without managing servers. It supports instant ZIP deployment, form collection, local wildcard testing, plan-based billing, and custom domains.

## Key Features

- **One-click deploy** - Upload a ZIP and publish in seconds
- **Free subdomains** - Every site gets a generated subdomain
- **Custom domains** - Connect customer domains through DNS
- **Secure form collection** - Origin protection, honeypot filtering, and per-IP rate limiting
- **Submission inbox** - Review leads across all sites from one dashboard
- **Per-site management tabs** - Overview, Submissions, and Settings flows
- **3-day free trial** - New accounts can test the lowest plan before upgrading
- **Dynamic pricing admin** - Superadmins can edit plan pricing and limits in the app
- **Re-deploy** - Replace site files without changing the public URL

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Sync the database schema
npx prisma db push

# 3. Generate the Prisma client
npx prisma generate

# 4. Seed demo data
npm run db:seed

# 5. Start development server
npm run dev
```

Open `http://localhost:3000` and sign in with the demo account:

- **Email:** `demo@staticdrop.com`
- **Password:** `password123`

## Local Testing

After deploying a ZIP, test the published site locally with:

- `http://your-site.lvh.me:3000`
- `http://your-site.localhost:3000`
- `http://localhost:3000/site/your-site`

The ZIP must contain `index.html` at the deploy root after extraction. StaticDrop also auto-flattens common single-folder ZIPs.

## Product Flow

### User Journey

1. Register a new account and begin the 3-day free trial.
2. Deploy a static site from a ZIP file.
3. Open the site overview page and copy the form endpoint.
4. Add the protected form snippet, including the honeypot field, to the frontend.
5. Review leads in the global **Submission Inbox** or the site-specific **Submissions** tab.
6. Upgrade from the pricing page when the customer needs more capacity.
7. Add a custom domain in the site **Settings** tab and point DNS from the registrar.

### Business Controls

- Trial-expired free sites stop serving traffic until upgraded.
- Trial-expired sites also stop accepting new form submissions.
- Superadmins can update plan pricing, limits, and features from the admin area.
- Site owners can configure allowed form origins, honeypot field name, and rate limits per site.

## Tech Stack

- **Next.js 14** (App Router, JavaScript)
- **Prisma** with SQLite
- **NextAuth.js** for authentication
- **Tailwind CSS**
- **AdmZip** for ZIP extraction

## Project Structure

```text
prisma/                  # Database schema and seed data
src/
|-- app/
|   |-- (auth)/          # Login and registration
|   |-- dashboard/       # User dashboard pages
|   |-- admin/           # Superadmin tools
|   |-- api/             # Auth, site, form, billing, and serve routes
|   `-- site/            # Local preview routes
|-- components/          # UI components
|-- lib/                 # Utilities, auth, plans, storage, security
`-- middleware.js        # Subdomain and custom-domain routing
uploads/                 # Deployed site files (gitignored)
docs/                    # Product and technical documentation
```

## Documentation

- [Complete Idea & Vision](docs/IDEA.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Setup Guide](docs/SETUP.md)
- [API Reference](docs/API-REFERENCE.md)
- [User Guide](docs/USER-GUIDE.md)
- [Deployment](docs/DEPLOYMENT.md)
- [Local Testing & Domains](docs/LOCAL-TESTING-AND-DOMAINS.md)

## License

MIT
