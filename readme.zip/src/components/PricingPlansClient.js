'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { formatMoney } from '@/lib/currency';

export default function PricingPlansClient({ plans, preferredCurrency }) {
  const { data: session } = useSession();
  const [billingPeriod, setBillingPeriod] = useState('monthly');

  return (
    <div>
      <div className="mx-auto mb-10 flex max-w-sm items-center justify-center rounded-full border border-gray-200 bg-white p-1 shadow-sm">
        <button
          type="button"
          onClick={() => setBillingPeriod('monthly')}
          className={`flex-1 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
            billingPeriod === 'monthly'
              ? 'bg-gray-900 text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          Monthly
        </button>
        <button
          type="button"
          onClick={() => setBillingPeriod('yearly')}
          className={`flex-1 rounded-full px-4 py-2 text-sm font-medium transition-colors ${
            billingPeriod === 'yearly'
              ? 'bg-gray-900 text-white'
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          Yearly
        </button>
      </div>

      <div className="mx-auto mb-8 max-w-3xl rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm text-emerald-900">
        Plans are shown in {preferredCurrency}. New users start with a 3-day trial.
        Secure payments are completed from the Settings billing screen through Razorpay.
      </div>

      <div className="mx-auto grid max-w-6xl gap-8 md:grid-cols-2 lg:grid-cols-4">
        {plans.map((plan) => {
          const isPopular = plan.slug === 'pro';
          const features = plan.features ? JSON.parse(plan.features) : [];
          const amount =
            preferredCurrency === 'INR'
              ? billingPeriod === 'yearly'
                ? plan.priceYearlyInr
                : plan.priceMonthlyInr
              : billingPeriod === 'yearly'
                ? plan.priceYearly
                : plan.priceMonthly;

          return (
            <div
              key={plan.id}
              className={`relative flex flex-col rounded-[28px] border bg-white p-8 shadow-sm ${
                isPopular
                  ? 'border-gray-900 shadow-xl shadow-gray-200'
                  : 'border-gray-200'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="rounded-full bg-amber-400 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-gray-900">
                    Best Value
                  </span>
                </div>
              )}

              <div className="mb-6">
                <div className="mb-3 inline-flex rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-gray-500">
                  {plan.name}
                </div>
                <div className="flex items-end gap-2">
                    <span className="text-4xl font-black tracking-tight text-gray-900">
                    {formatMoney(amount, preferredCurrency)}
                  </span>
                  <span className="pb-1 text-sm text-gray-500">
                    /{billingPeriod === 'yearly' ? 'year' : 'month'}
                  </span>
                </div>
                <p className="mt-3 text-sm leading-6 text-gray-500">
                  {plan.slug === 'free'
                    ? 'Use the full onboarding trial before choosing a paid plan.'
                    : 'Purchase and renewal are handled from Settings for a controlled billing experience.'}
                </p>
              </div>

              <ul className="mb-8 flex-1 space-y-3">
                <FeatureItem label={`${plan.maxSites} websites`} />
                <FeatureItem label={`${plan.maxStorageMB} MB storage per site`} />
                <FeatureItem
                  label={`${plan.maxSubmissions.toLocaleString()} form submissions`}
                />
                <FeatureItem
                  label="Custom domain"
                  included={plan.customDomain}
                />
                {features.map((feature, index) => (
                  <FeatureItem key={index} label={feature} />
                ))}
              </ul>

              {!session ? (
                <Link
                  href="/register"
                  className={`block rounded-2xl px-5 py-3 text-center font-semibold transition-colors ${
                    isPopular
                      ? 'bg-gray-900 text-white hover:bg-black'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  {plan.slug === 'free' ? 'Start 3-Day Trial' : 'Create Account'}
                </Link>
              ) : (
                <Link
                  href="/dashboard/settings"
                  className={`block rounded-2xl px-5 py-3 text-center font-semibold transition-colors ${
                    isPopular
                      ? 'bg-gray-900 text-white hover:bg-black'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}
                >
                  Manage Billing in Settings
                </Link>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FeatureItem({ label, included = true }) {
  return (
    <li className="flex items-start gap-3 text-sm text-gray-600">
      <FeatureIcon included={included} />
      <span className={included ? '' : 'text-gray-400'}>{label}</span>
    </li>
  );
}

function FeatureIcon({ included }) {
  if (included) {
    return (
      <svg
        className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M5 13l4 4L19 7"
        />
      </svg>
    );
  }

  return (
    <svg
      className="mt-0.5 h-4 w-4 shrink-0 text-gray-300"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M6 18L18 6M6 6l12 12"
      />
    </svg>
  );
}
