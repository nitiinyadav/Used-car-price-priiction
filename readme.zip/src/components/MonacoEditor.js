'use client';

import { useRef, useEffect, useCallback } from 'react';

// Language detection from file extension
function getLanguage(filePath) {
  const ext = (filePath || '').split('.').pop()?.toLowerCase();
  const map = {
    html: 'html', htm: 'html',
    css: 'css', scss: 'scss', less: 'less',
    js: 'javascript', jsx: 'javascript', mjs: 'javascript',
    ts: 'typescript', tsx: 'typescript',
    json: 'json',
    md: 'markdown', mdx: 'markdown',
    xml: 'xml', svg: 'xml',
    yaml: 'yaml', yml: 'yaml',
    sh: 'shell', bash: 'shell',
    py: 'python',
    sql: 'sql',
    txt: 'plaintext',
  };
  return map[ext] || 'plaintext';
}

/**
 * Monaco Editor wrapper that loads from CDN.
 * @param {{ value: string, onChange: (v: string) => void, filePath: string, className?: string }} props
 */
export default function MonacoEditor({ value, onChange, filePath, className = '' }) {
  const containerRef = useRef(null);
  const editorRef = useRef(null);
  const monacoRef = useRef(null);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  const initMonaco = useCallback(() => {
    if (typeof window === 'undefined') return;

    // Prevent double-init
    if (monacoRef.current) return;

    const script = document.getElementById('monaco-loader');
    if (!script) {
      const s = document.createElement('script');
      s.id = 'monaco-loader';
      s.src = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs/loader.js';
      s.onload = () => configureMonaco();
      document.head.appendChild(s);
    } else if (window.require) {
      configureMonaco();
    }

    function configureMonaco() {
      window.require.config({
        paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' },
      });
      window.require(['vs/editor/editor.main'], (monaco) => {
        monacoRef.current = monaco;
        createEditor(monaco);
      });
    }
  }, []);

  function createEditor(monaco) {
    if (!containerRef.current || editorRef.current) return;

    // Define a theme that matches the dark VS Code look
    monaco.editor.defineTheme('staticdrop-dark', {
      base: 'vs-dark',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#111827',
        'editor.lineHighlightBackground': '#1f2937',
        'editorLineNumber.foreground': '#4b5563',
        'editorLineNumber.activeForeground': '#9ca3af',
      },
    });

    const editor = monaco.editor.create(containerRef.current, {
      value: value || '',
      language: getLanguage(filePath),
      theme: 'staticdrop-dark',
      fontSize: 13,
      lineHeight: 20,
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      wordWrap: 'on',
      automaticLayout: true,
      tabSize: 2,
      renderLineHighlight: 'line',
      overviewRulerBorder: false,
      hideCursorInOverviewRuler: true,
      scrollbar: {
        verticalScrollbarSize: 8,
        horizontalScrollbarSize: 8,
      },
      padding: { top: 8 },
    });

    editor.onDidChangeModelContent(() => {
      onChangeRef.current?.(editor.getValue());
    });

    editorRef.current = editor;
  }

  // Initialize once
  useEffect(() => {
    initMonaco();

    return () => {
      if (editorRef.current) {
        editorRef.current.dispose();
        editorRef.current = null;
      }
    };
  }, [initMonaco]);

  // Update value externally (e.g., switching files)
  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco) return;

    const currentValue = editor.getValue();
    if (value !== currentValue) {
      editor.setValue(value || '');
    }

    const model = editor.getModel();
    if (model) {
      monaco.editor.setModelLanguage(model, getLanguage(filePath));
    }
  }, [value, filePath]);

  return (
    <div
      ref={containerRef}
      className={`flex-1 ${className}`}
      style={{ minHeight: 200 }}
    />
  );
}
