import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SubmissionsTable from '@/components/SubmissionsTable';
import SiteTabs from '@/components/SiteTabs';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export async function generateMetadata({ params }) {
  return { title: 'Form Submissions - StaticDrop' };
}

export default async function SubmissionsPage({ params, searchParams }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const { id } = params;
  if (!hasPermission(workspace, 'view_submissions')) {
    notFound();
  }
  const page = Math.max(1, Number(searchParams?.page || 1));
  const query = String(searchParams?.q || '').trim();
  const pageSize = 10;

  const site = await prisma.site.findFirst({
    where: { id, userId: workspace?.workspaceOwnerId || session.user.id },
  });

  if (!site) {
    notFound();
  }

  const where = {
    siteId: site.id,
    ...(query
      ? {
          OR: [
            { formName: { contains: query } },
            { data: { contains: query } },
          ],
        }
      : {}),
  };

  const [submissions, total, recentCount] = await Promise.all([
    prisma.formSubmission.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.formSubmission.count({ where }),
    prisma.formSubmission.count({
      where: {
        siteId: site.id,
        createdAt: {
          gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        },
      },
    }),
  ]);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="mb-8">
        <Link
          href={`/dashboard/sites/${site.id}`}
          className="text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1 mb-4"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to {site.name}</span>
        </Link>

        <h1 className="text-2xl font-bold text-gray-900">Form Submissions</h1>
        <p className="mt-1 text-gray-500">
          Submissions collected from forms on {site.name}
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Total Submissions</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Last 7 Days</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Current Page</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">
            {page} / {totalPages}
          </p>
        </div>
      </div>

      <form className="mb-4 rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="Search by form name or submission content"
            className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Search
          </button>
        </div>
      </form>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <SubmissionsTable
          submissions={submissions}
          siteName={site.name}
          totalCount={total}
          page={page}
          totalPages={totalPages}
          basePath={`/dashboard/sites/${site.id}/submissions`}
          searchQuery={query}
        />
      </div>
    </div>
  );
}
