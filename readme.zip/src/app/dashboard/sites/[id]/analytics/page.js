import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import SiteTabs from '@/components/SiteTabs';
import AnalyticsDashboard from '@/components/AnalyticsDashboard';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export const metadata = {
  title: 'Site Analytics - StaticDrop',
};

export default async function SiteAnalyticsPage({ params }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, 'view_analytics')) {
    notFound();
  }

  const site = await prisma.site.findFirst({
    where: { id: params.id, userId: workspace?.workspaceOwnerId || session.user.id },
    select: { id: true, name: true },
  });

  if (!site) {
    notFound();
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Site Analytics</h1>
        <p className="mt-1 text-gray-500">
          Traffic trends, referrers, and visitor insights for {site.name}.
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <AnalyticsDashboard siteId={site.id} />
    </div>
  );
}
