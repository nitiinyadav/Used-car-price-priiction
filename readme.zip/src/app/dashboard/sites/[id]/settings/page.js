import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import SiteDetailClient from '../SiteDetailClient';
import SiteTabs from '@/components/SiteTabs';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export const metadata = {
  title: 'Site Settings - StaticDrop',
};

export default async function SiteSettingsPage({ params }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  if (!hasPermission(workspace, 'manage_sites')) {
    notFound();
  }
  const site = await prisma.site.findFirst({
    where: {
      id: params.id,
      userId: workspace?.workspaceOwnerId || session.user.id,
    },
  });

  if (!site) {
    notFound();
  }

  return (
    <div>
      <div className="mb-8">
        <Link
          href="/dashboard/sites"
          className="mb-4 flex items-center space-x-1 text-sm text-gray-500 hover:text-gray-700"
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          <span>Back to Sites</span>
        </Link>

        <h1 className="text-2xl font-bold text-gray-900">{site.name}</h1>
        <p className="mt-1 text-gray-500">
          Manage domains, deployment controls, and form protection for this site.
        </p>
      </div>

      <SiteTabs siteId={site.id} />
      <SiteDetailClient site={site} />
    </div>
  );
}
