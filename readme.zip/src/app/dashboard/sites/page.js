import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import Link from "next/link";
import SiteCard from "@/components/SiteCard";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";

export const metadata = {
  title: "My Sites - StaticDrop",
};

export default async function SitesPage() {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  const sites = await prisma.site.findMany({
    where: { userId: workspaceOwnerId },
    include: { _count: { select: { formsubmission: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Sites</h1>
          <p className="mt-1 text-gray-500">Manage your deployed websites</p>
        </div>
        <Link
          href={
            hasPermission(workspace, "create_sites")
              ? "/dashboard/sites/new"
              : "/dashboard/sites"
          }
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
            hasPermission(workspace, "create_sites")
              ? "bg-indigo-600 text-white hover:bg-indigo-700"
              : "bg-gray-200 text-gray-500 cursor-not-allowed"
          }`}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4v16m8-8H4"
            />
          </svg>
          <span>Deploy New</span>
        </Link>
      </div>

      {sites.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sites.map((site) => (
            <SiteCard key={site.id} site={site} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M12 4v16m8-8H4"
            />
          </svg>
          <h3 className="mt-4 text-lg font-medium text-gray-900">
            No sites yet
          </h3>
          <p className="mt-2 text-gray-500">
            Deploy your first website to get started
          </p>
          <Link
            href={
              hasPermission(workspace, "create_sites")
                ? "/dashboard/sites/new"
                : "/dashboard/sites"
            }
            className={`mt-6 inline-block px-6 py-2 rounded-lg text-sm font-medium transition-colors ${
              hasPermission(workspace, "create_sites")
                ? "bg-indigo-600 text-white hover:bg-indigo-700"
                : "bg-gray-200 text-gray-500 cursor-not-allowed"
            }`}
          >
            Deploy Your First Site
          </Link>
        </div>
      )}
    </div>
  );
}
