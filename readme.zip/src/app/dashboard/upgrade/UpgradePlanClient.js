'use client';

import { useMemo, useState } from 'react';
import Script from 'next/script';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatMoney, getPlanAmount } from '@/lib/currency';
import { isPremiumMemberHealthy, shouldShowUpgradePrompt } from '@/lib/billing';

export default function UpgradePlanClient({
  sessionUser,
  plans,
  billing,
  preferredCurrency,
}) {
  const { update } = useSession();
  const router = useRouter();

  const paidPlans = useMemo(
    () => plans.filter((plan) => plan.slug !== 'free'),
    [plans]
  );

  const [selectedPlanSlug, setSelectedPlanSlug] = useState(
    paidPlans[1]?.slug || paidPlans[0]?.slug || 'pro'
  );
  const [billingPeriod, setBillingPeriod] = useState('monthly');
  const [currency, setCurrency] = useState(preferredCurrency || 'USD');
  const [paymentMethod, setPaymentMethod] = useState(
    preferredCurrency === 'INR' ? 'upi' : 'card'
  );
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const selectedPlan =
    plans.find((plan) => plan.slug === selectedPlanSlug) || paidPlans[0] || null;
  const selectedAmount = getPlanAmount(selectedPlan, currency, billingPeriod);
  const showUpgrade = shouldShowUpgradePrompt(billing, sessionUser?.role);
  const healthyPremium = isPremiumMemberHealthy(billing, sessionUser?.role);

  async function handleCheckout() {
    if (!selectedPlan) return;

    if (typeof window === 'undefined' || !window.Razorpay) {
      setError('Secure checkout could not be loaded. Refresh the page and try again.');
      return;
    }

    setCheckoutLoading(true);
    setError('');
    setSuccess('');

    try {
      const orderRes = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planSlug: selectedPlan.slug,
          billingPeriod,
          currency,
        }),
      });
      const orderData = await orderRes.json();

      if (!orderRes.ok) {
        setError(orderData.error || 'Failed to start checkout.');
        return;
      }

      const razorpay = new window.Razorpay({
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'StaticDrop',
        description: orderData.description,
        order_id: orderData.orderId,
        prefill: {
          name: sessionUser.name,
          email: sessionUser.email,
          contact: sessionUser.phone || '',
        },
        theme: { color: '#4f46e5' },
        modal: {
          ondismiss: () => setCheckoutLoading(false),
        },
        handler: async (response) => {
          try {
            const verifyRes = await fetch('/api/payments/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                orderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });
            const verifyData = await verifyRes.json();

            if (!verifyRes.ok) {
              setError(verifyData.error || 'Payment completed but verification failed.');
              return;
            }

            setSuccess(verifyData.message || 'Plan upgraded successfully.');
            await update({
              plan: verifyData.plan,
              subscriptionStatus: 'active',
              billingCurrency: verifyData.billingCurrency,
              billingPeriod: verifyData.billingPeriod,
              currentPeriodEndsAt: verifyData.expiresAt,
              trialEndsAt: null,
            });
            router.refresh();
          } catch {
            setError('Payment completed but confirmation failed.');
          } finally {
            setCheckoutLoading(false);
          }
        },
        method: paymentMethod === 'upi' ? { upi: true } : undefined,
      });

      razorpay.on('payment.failed', (response) => {
        setError(response?.error?.description || 'Payment was not completed.');
        setCheckoutLoading(false);
      });

      razorpay.open();
    } catch {
      setError('Unable to start checkout right now.');
      setCheckoutLoading(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto">
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          {showUpgrade ? 'Upgrade Your Plan' : 'Membership Status'}
        </h1>
        <p className="mt-1 text-gray-500">
          {showUpgrade
            ? 'Billing only appears when your trial is ending or your subscription is within 3 days of expiry.'
            : 'Your account already has premium access and is using the best of our services.'}
        </p>
      </div>

      {error && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}
      {success && (
        <div className="mb-6 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
          {success}
        </div>
      )}

      {!showUpgrade && healthyPremium && (
        <div className="rounded-[28px] border border-emerald-200 bg-[linear-gradient(135deg,#ecfdf5_0%,#ffffff_62%,#eff6ff_100%)] p-8 shadow-sm">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="inline-flex rounded-full border border-emerald-200 bg-white px-3 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-emerald-700">
                Premium Member
              </div>
              <h2 className="mt-4 text-3xl font-black tracking-tight text-gray-900">
                You are already a premium member.
              </h2>
              <p className="mt-3 max-w-2xl text-sm leading-7 text-gray-600">
                Your subscription is active and healthy, so there is nothing you need to
                change right now. We only show upgrade controls when payment action is
                actually needed.
              </p>
            </div>

            <div className="rounded-3xl border border-white bg-white/90 p-6 shadow-sm lg:min-w-[280px]">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gray-400">
                Current Plan
              </p>
              <p className="mt-2 text-2xl font-black capitalize text-gray-900">
                {billing?.plan || 'Premium'}
              </p>
              <p className="mt-2 text-sm text-gray-600">
                Renewal on{' '}
                <span className="font-semibold text-gray-900">
                  {billing?.currentPeriodEndsAt
                    ? new Date(billing.currentPeriodEndsAt).toLocaleDateString()
                    : 'Active'}
                </span>
              </p>
              <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
                Thanks for being with us. You are already using the best of StaticDrop.
              </p>
            </div>
          </div>
        </div>
      )}

      {showUpgrade && (
        <>
          <div className="mb-8 flex flex-wrap items-center gap-4">
            <div className="inline-flex rounded-full border border-gray-200 bg-white p-1">
              {['monthly', 'yearly'].map((period) => (
                <button
                  key={period}
                  type="button"
                  onClick={() => setBillingPeriod(period)}
                  className={`rounded-full px-5 py-2 text-sm font-medium transition-colors ${
                    billingPeriod === period
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  {period === 'monthly' ? 'Monthly' : 'Yearly (save ~17%)'}
                </button>
              ))}
            </div>

            <div className="inline-flex rounded-full border border-gray-200 bg-white p-1">
              {['USD', 'INR'].map((cur) => (
                <button
                  key={cur}
                  type="button"
                  onClick={() => {
                    setCurrency(cur);
                    if (cur !== 'INR' && paymentMethod === 'upi') {
                      setPaymentMethod('card');
                    }
                  }}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                    currency === cur
                      ? 'bg-gray-900 text-white shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  {cur}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-8 grid gap-6 lg:grid-cols-3">
            {paidPlans.map((plan) => {
              const amount = getPlanAmount(plan, currency, billingPeriod);
              const isSelected = selectedPlanSlug === plan.slug;
              const isPopular = plan.slug === 'pro';
              const features = plan.features ? JSON.parse(plan.features) : [];

              return (
                <button
                  key={plan.id}
                  type="button"
                  onClick={() => setSelectedPlanSlug(plan.slug)}
                  className={`relative rounded-2xl border-2 p-6 text-left transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 shadow-lg shadow-indigo-100'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  {isPopular && (
                    <span className="absolute -top-3 left-5 rounded-full bg-indigo-600 px-3 py-1 text-xs font-bold text-white">
                      Most Popular
                    </span>
                  )}

                  <div className="mb-4 flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">{plan.name}</h3>
                      <div className="mt-2">
                        <span className="text-3xl font-extrabold text-gray-900">
                          {formatMoney(amount, currency)}
                        </span>
                        <span className="ml-1 text-sm text-gray-500">
                          /{billingPeriod === 'yearly' ? 'yr' : 'mo'}
                        </span>
                      </div>
                    </div>
                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded-full border-2 ${
                        isSelected ? 'border-indigo-600 bg-indigo-600' : 'border-gray-300'
                      }`}
                    >
                      {isSelected && (
                        <svg className="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path
                            fillRule="evenodd"
                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                            clipRule="evenodd"
                          />
                        </svg>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2 text-sm text-gray-600">
                    <p className="font-medium">
                      {plan.maxSites} sites · {plan.maxStorageMB} MB each
                    </p>
                    <p>{plan.maxSubmissions.toLocaleString()} form submissions</p>
                    {plan.customDomain && (
                      <p className="font-medium text-indigo-600">Custom domain support</p>
                    )}
                    {features.map((feature, index) => (
                      <p key={index} className="flex items-center space-x-2">
                        <svg className="h-4 w-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>{feature}</span>
                      </p>
                    ))}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="grid gap-6 lg:grid-cols-[1fr_0.8fr]">
            <div className="rounded-2xl border border-gray-200 bg-white p-6">
              <h3 className="mb-4 text-lg font-semibold text-gray-900">
                Payment Method
              </h3>
              <div className="space-y-3">
                <label
                  className={`flex cursor-pointer items-center gap-4 rounded-xl border p-4 transition-colors ${
                    paymentMethod === 'card'
                      ? 'border-indigo-600 bg-indigo-50/50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="card"
                    checked={paymentMethod === 'card'}
                    onChange={() => setPaymentMethod('card')}
                    className="accent-indigo-600"
                  />
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Card / Netbanking / Wallet</p>
                    <p className="text-sm text-gray-500">
                      Visa, Mastercard, Rupay, netbanking, and wallets
                    </p>
                  </div>
                </label>

                {currency === 'INR' && (
                  <label
                    className={`flex cursor-pointer items-center gap-4 rounded-xl border p-4 transition-colors ${
                      paymentMethod === 'upi'
                        ? 'border-indigo-600 bg-indigo-50/50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="upi"
                      checked={paymentMethod === 'upi'}
                      onChange={() => setPaymentMethod('upi')}
                      className="accent-indigo-600"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">UPI</p>
                      <p className="text-sm text-gray-500">
                        Google Pay, PhonePe, Paytm, and BHIM
                      </p>
                    </div>
                    <span className="rounded bg-green-100 px-2 py-0.5 text-xs font-medium text-green-700">
                      UPI
                    </span>
                  </label>
                )}
              </div>
            </div>

            <div className="rounded-2xl border border-gray-200 bg-white p-6">
              <h3 className="mb-4 text-lg font-semibold text-gray-900">
                Order Summary
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>Plan</span>
                  <span className="font-medium text-gray-900">{selectedPlan?.name}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Billing</span>
                  <span className="font-medium capitalize text-gray-900">{billingPeriod}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Currency</span>
                  <span className="font-medium text-gray-900">{currency}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Payment</span>
                  <span className="font-medium text-gray-900">
                    {paymentMethod === 'upi' ? 'UPI' : 'Card / Other'}
                  </span>
                </div>
                <div className="flex justify-between border-t border-gray-200 pt-3">
                  <span className="font-semibold text-gray-900">Total</span>
                  <span className="text-xl font-bold text-gray-900">
                    {selectedPlan ? formatMoney(selectedAmount, currency) : '-'}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCheckout}
                disabled={checkoutLoading || !selectedPlan}
                className="mt-6 w-full rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {checkoutLoading
                  ? 'Opening secure checkout...'
                  : `Pay ${selectedPlan ? formatMoney(selectedAmount, currency) : ''}`}
              </button>

              <p className="mt-3 text-center text-xs text-gray-400">
                Secured by Razorpay. Billing appears only when action is needed.
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
