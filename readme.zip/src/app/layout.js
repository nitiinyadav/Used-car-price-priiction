import { Inter } from 'next/font/google';
import './globals.css';
import Providers from '@/components/Providers';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'StaticDrop - Deploy Static Websites Instantly',
  description:
    'Upload your HTML/CSS/JS website and get it live in seconds. No server management required. Free subdomains, form collection API, and more.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
