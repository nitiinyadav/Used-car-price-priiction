import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getBillingSnapshot, shouldShowUpgradePrompt } from '@/lib/billing';
import { getPlanAmount } from '@/lib/currency';
import { env } from '@/lib/env';

const RAZORPAY_ORDERS_URL = 'https://api.razorpay.com/v1/orders';

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { planSlug, billingPeriod, currency, provider: requestedProvider } = await request.json();

    // Determine payment provider
    const paymentProvider = requestedProvider === 'stripe' && env.hasStripe
      ? 'stripe'
      : env.hasRazorpay
        ? 'razorpay'
        : null;

    if (!paymentProvider) {
      return NextResponse.json(
        { error: 'No payment provider configured.' },
        { status: 500 }
      );
    }

    if (
      !planSlug ||
      !['monthly', 'yearly'].includes(billingPeriod) ||
      !['USD', 'INR'].includes(currency)
    ) {
      return NextResponse.json(
        { error: 'Invalid plan, billing period, or currency' },
        { status: 400 }
      );
    }

    if (planSlug === 'free') {
      return NextResponse.json(
        {
          error:
            'Free access is only available during the onboarding trial. Paid checkout is only for Starter, Pro, or Enterprise.',
        },
        { status: 400 }
      );
    }

    const [plan, billing] = await Promise.all([
      prisma.plan.findUnique({ where: { slug: planSlug } }),
      getBillingSnapshot(session.user.id),
    ]);

    if (!plan || !plan.isActive) {
      return NextResponse.json(
        { error: 'Plan not found or inactive' },
        { status: 404 }
      );
    }

    if (!billing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    if (!shouldShowUpgradePrompt(billing, session.user.role)) {
      return NextResponse.json(
        {
          error:
            'Your premium membership is already active. Upgrade controls open only when you are on free access or within 3 days of renewal.',
        },
        { status: 400 }
      );
    }

    const amount = getPlanAmount(plan, currency, billingPeriod);
    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: 'This plan is not available for the selected currency.' },
        { status: 400 }
      );
    }

    const razorpayKeyId = env.RAZORPAY_KEY_ID;
    const razorpayKeySecret = env.RAZORPAY_KEY_SECRET;

    if (paymentProvider === 'stripe') {
      // ── Stripe Checkout Session ──
      const stripe = (await import('stripe')).default(env.STRIPE_SECRET_KEY);

      const stripeSession = await stripe.checkout.sessions.create({
        mode: 'payment',
        payment_method_types: ['card'],
        line_items: [{
          price_data: {
            currency: currency.toLowerCase(),
            product_data: {
              name: `${plan.name} Plan — ${billingPeriod}`,
              description: `StaticDrop ${plan.name} subscription`,
            },
            unit_amount: amount,
          },
          quantity: 1,
        }],
        metadata: {
          userId: session.user.id,
          planSlug,
          billingPeriod,
        },
        success_url: `${env.APP_URL}/dashboard?payment=success`,
        cancel_url: `${env.APP_URL}/dashboard/upgrade?payment=cancelled`,
      });

      const startsAt = new Date();
      const expiresAt = new Date(startsAt);
      if (billingPeriod === 'yearly') {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      } else {
        expiresAt.setMonth(expiresAt.getMonth() + 1);
      }

      await prisma.payment.create({
        data: {
          userId: session.user.id,
          planSlug: plan.slug,
          amount,
          currency,
          status: 'pending',
          billingPeriod,
          provider: 'stripe',
          providerOrderId: stripeSession.id,
          startsAt,
          expiresAt,
          notes: JSON.stringify({
            checkoutPhase: billing.plan === 'free' ? 'first_purchase' : 'renewal',
          }),
        },
      });

      return NextResponse.json({
        success: true,
        provider: 'stripe',
        sessionUrl: stripeSession.url,
        sessionId: stripeSession.id,
      });
    }

    // ── Razorpay Order ──
    if (!razorpayKeyId || !razorpayKeySecret) {
      return NextResponse.json(
        { error: 'Razorpay credentials are not configured.' },
        { status: 500 }
      );
    }

    const receipt = `plan_${session.user.id.slice(-8)}_${Date.now()}`;
    const authHeader = Buffer.from(
      `${razorpayKeyId}:${razorpayKeySecret}`
    ).toString('base64');

    const orderResponse = await fetch(RAZORPAY_ORDERS_URL, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount,
        currency,
        receipt,
        notes: {
          userId: session.user.id,
          planSlug,
          billingPeriod,
        },
      }),
      cache: 'no-store',
    });

    const order = await orderResponse.json();

    if (!orderResponse.ok) {
      return NextResponse.json(
        {
          error:
            order?.error?.description ||
            'Failed to create a Razorpay order for this purchase.',
        },
        { status: 502 }
      );
    }

    const startsAt = new Date();
    const expiresAt = new Date(startsAt);
    if (billingPeriod === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    }

    await prisma.payment.create({
      data: {
        userId: session.user.id,
        planSlug: plan.slug,
        amount,
        currency,
        status: 'pending',
        billingPeriod,
        provider: 'razorpay',
        providerOrderId: order.id,
        startsAt,
        expiresAt,
        notes: JSON.stringify({
          checkoutPhase: billing.plan === 'free' ? 'first_purchase' : 'renewal',
          receipt,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      keyId: razorpayKeyId,
      orderId: order.id,
      amount,
      currency,
      planSlug: plan.slug,
      planName: plan.name,
      billingPeriod,
      description: `${plan.name} plan - ${billingPeriod}`,
    });
  } catch (error) {
    console.error('Checkout error:', error);
    return NextResponse.json(
      { error: 'Failed to start secure checkout' },
      { status: 500 }
    );
  }
}
