import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { trialExpiringTemplate } from '@/lib/email-templates';

// POST /api/cron/trial-reminders
// Call daily via cron job or Vercel Cron. Protected by CRON_SECRET.
export async function POST(request) {
  const authHeader = request.headers.get('authorization');
  const cronSecret = process.env.CRON_SECRET;

  if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const now = new Date();
    // Find users whose trial ends in 1-3 days and haven't been notified
    const threeDaysFromNow = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);

    const expiringUsers = await prisma.user.findMany({
      where: {
        trialEndsAt: {
          gte: now,
          lte: threeDaysFromNow,
        },
        subscriptionStatus: { not: 'active' },
        planSlug: 'free',
      },
      select: { id: true, name: true, email: true, trialEndsAt: true },
    });

    let sent = 0;
    for (const user of expiringUsers) {
      const daysLeft = Math.ceil(
        (new Date(user.trialEndsAt).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );

      try {
        await sendEmail({
          to: user.email,
          subject: `Your StaticDrop trial expires in ${daysLeft} day${daysLeft !== 1 ? 's' : ''}`,
          html: trialExpiringTemplate({
            userName: user.name,
            daysLeft,
            upgradeUrl: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/dashboard/upgrade`,
          }),
        });
        sent++;
      } catch (err) {
        console.error(`Failed to send trial reminder to ${user.email}:`, err);
      }
    }

    return NextResponse.json({
      success: true,
      checked: expiringUsers.length,
      sent,
    });
  } catch (error) {
    console.error('Trial reminder cron error:', error);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}
