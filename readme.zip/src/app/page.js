import Link from 'next/link';
import Navbar from '@/components/Navbar';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="text-center">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 tracking-tight">
              Deploy Your Website
              <span className="block text-indigo-600">In Seconds</span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-500">
              Upload a ZIP file of your HTML, CSS &amp; JS website and get it live instantly.
              No servers to manage, no complex setup. Perfect for portfolios,
              landing pages, and small projects.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/register"
                className="w-full sm:w-auto bg-indigo-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
              >
                Get Started Free
              </Link>
              <Link
                href="#how-it-works"
                className="w-full sm:w-auto text-gray-600 px-8 py-3 rounded-lg text-lg font-semibold hover:text-gray-900 transition-colors"
              >
                How It Works &rarr;
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -z-10 w-full max-w-5xl">
          <div className="aspect-[16/9] rounded-3xl bg-gradient-to-br from-indigo-100 via-white to-purple-100 opacity-60 blur-3xl" />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gray-50" id="features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">
              Everything You Need
            </h2>
            <p className="mt-4 text-lg text-gray-500">
              Simple tools for deploying and managing static websites
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900">
                One-Click Deploy
              </h3>
              <p className="mt-2 text-gray-500">
                Upload a ZIP file containing your website and it goes live
                instantly. No build steps, no CLI tools, no configuration needed.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900">
                Free Subdomain
              </h3>
              <p className="mt-2 text-gray-500">
                Get a free subdomain like <code className="text-sm bg-gray-100 px-1 py-0.5 rounded">yoursite.staticdrop.com</code> or
                connect your own custom domain.
              </p>
            </div>

            <div className="bg-white rounded-xl p-8 shadow-sm border border-gray-100">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900">
                Form Collection API
              </h3>
              <p className="mt-2 text-gray-500">
                Add forms to your website and collect submissions without a backend.
                View all responses in your dashboard and export to CSV.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24" id="how-it-works">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">
              How It Works
            </h2>
            <p className="mt-4 text-lg text-gray-500">
              Three simple steps to get your website online
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-indigo-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto">
                1
              </div>
              <h3 className="mt-6 text-lg font-semibold text-gray-900">
                Create an Account
              </h3>
              <p className="mt-2 text-gray-500">
                Sign up for free in seconds. No credit card required.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-indigo-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto">
                2
              </div>
              <h3 className="mt-6 text-lg font-semibold text-gray-900">
                Upload Your Website
              </h3>
              <p className="mt-2 text-gray-500">
                ZIP your HTML, CSS, and JS files and upload them through the dashboard.
                Choose a subdomain or connect your own domain.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-indigo-600 text-white rounded-2xl flex items-center justify-center text-2xl font-bold mx-auto">
                3
              </div>
              <h3 className="mt-6 text-lg font-semibold text-gray-900">
                You&apos;re Live!
              </h3>
              <p className="mt-2 text-gray-500">
                Your website is immediately accessible. Share the link, add form
                collection, and manage everything from your dashboard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Form API Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">
                Built-in Form Collection
              </h2>
              <p className="mt-4 text-lg text-gray-500">
                Every deployed site gets a unique API endpoint. Just point your
                HTML form&apos;s action to it, and we&apos;ll collect all submissions for you.
                No backend code needed.
              </p>
              <ul className="mt-6 space-y-3">
                <li className="flex items-center space-x-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Works with standard HTML forms</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Supports AJAX/fetch submissions</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>View submissions in your dashboard</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Export data to CSV</span>
                </li>
              </ul>
            </div>
            <div className="bg-gray-900 rounded-xl p-6 text-sm font-mono">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <pre className="text-green-400 overflow-x-auto">
{`<!-- Just add your API key to the form action -->
<form
  action="https://staticdrop.com/api/forms/YOUR_API_KEY"
  method="POST"
>
  <input name="name" placeholder="Name" />
  <input name="email" type="email"
    placeholder="Email" />
  <textarea name="message"
    placeholder="Message"></textarea>

  <!-- Optional: redirect after submit -->
  <input type="hidden" name="_redirect"
    value="https://yoursite.com/thanks" />

  <button type="submit">Send</button>
</form>`}
              </pre>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Plans For Every Project
          </h2>
          <p className="mt-4 text-lg text-gray-500 max-w-2xl mx-auto">
            Start free with 3 sites and 1,000 form submissions. Upgrade anytime
            to unlock more sites, storage, custom domains, and priority support.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/pricing"
              className="bg-indigo-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
            >
              View Pricing
            </Link>
            <Link
              href="/register"
              className="text-gray-600 px-8 py-3 rounded-lg text-lg font-semibold hover:text-gray-900 transition-colors"
            >
              Start Deploying Free &rarr;
            </Link>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">
            Ready to Deploy?
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Get your website online in under a minute. No credit card required.
          </p>
          <Link
            href="/register"
            className="mt-8 inline-block bg-indigo-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
          >
            Start Deploying Free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <span className="text-white font-bold">StaticDrop</span>
            </div>
            <p className="text-sm">
              &copy; {new Date().getFullYear()} StaticDrop. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
