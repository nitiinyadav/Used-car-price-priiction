import { headers } from "next/headers";
import Navbar from "@/components/Navbar";
import prisma from "@/lib/prisma";
import PricingPlansClient from "@/components/PricingPlansClient";
import { detectPreferredCurrency } from "@/lib/currency";

export const dynamic = "force-dynamic";

export default async function PricingPage() {
  const plans = await prisma.plan.findMany({
    where: { isActive: true },
    orderBy: { priority: "asc" },
  });
  const preferredCurrency = detectPreferredCurrency(headers());

  return (
    <div className="min-h-screen bg-[linear-gradient(180deg,#fff9ef_0%,#ffffff_28%,#f8fafc_100%)]">
      <Navbar />

      <section className="relative overflow-hidden py-24">
        <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_top,_rgba(245,158,11,0.22),_transparent_58%)]" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto mb-16 max-w-3xl text-center">
            <div className="mb-4 inline-flex rounded-full border border-amber-300 bg-amber-50 px-4 py-1 text-xs font-semibold uppercase tracking-[0.22em] text-amber-800">
              Clear Pricing. Controlled Billing.
            </div>
            <h1 className="text-4xl font-black tracking-tight text-gray-900 sm:text-5xl">
              Choose Once. Renew Calmly.
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-gray-600">
              StaticDrop is designed for trust. Customers compare plans here,
              start with a free trial, and complete billing securely from their
              Settings screen.
            </p>
          </div>

          <PricingPlansClient
            plans={plans}
            preferredCurrency={preferredCurrency}
          />

          <div className="mx-auto mt-20 grid max-w-5xl gap-6 md:grid-cols-3">
            <TrustCard
              title="Secure Checkout"
              description="Payments are routed through Razorpay and activated only after server-side signature verification."
            />
            <TrustCard
              title="No Random Plan Switching"
              description="Once a customer purchases a paid plan, billing stays locked to that plan and billing cycle until renewal time."
            />
            <TrustCard
              title="Expiry Warnings"
              description="Customers are notified before subscription end dates so they can renew without surprise interruptions."
            />
          </div>

          <div className="mx-auto mt-24 max-w-3xl rounded-[32px] border border-gray-200 bg-white p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-gray-900">
              Frequently Asked Questions
            </h2>
            <div className="mt-8 space-y-6 text-sm leading-7 text-gray-600">
              <FaqItem
                title="Where does payment happen?"
                description="The public pricing page is for comparison. Logged-in users complete checkout from Dashboard Settings so billing stays intentional and controlled."
              />
              <FaqItem
                title="Can a customer keep switching plans?"
                description="No. The first paid plan and billing period become the locked subscription choice. Renewals continue from Settings when the renewal window opens."
              />
              <FaqItem
                title="What if a subscription is about to expire?"
                description="StaticDrop shows a renewal notification before the current billing period ends, then moves the account out of active paid status if payment is not renewed."
              />
              <FaqItem
                title="How are prices shown?"
                description={`Indian visitors see INR pricing by default. Other visitors see USD pricing. Current detected currency: ${preferredCurrency}.`}
              />
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-gray-200 bg-white py-12 text-gray-500">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 text-sm sm:flex-row sm:px-6 lg:px-8">
          <span>StaticDrop</span>
          <span>
            &copy; {new Date().getFullYear()} StaticDrop. All rights reserved.
          </span>
        </div>
      </footer>
    </div>
  );
}

function TrustCard({ title, description }) {
  return (
    <div className="rounded-[24px] border border-gray-200 bg-white p-6 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
      <p className="mt-3 text-sm leading-6 text-gray-600">{description}</p>
    </div>
  );
}

function FaqItem({ title, description }) {
  return (
    <div>
      <h3 className="font-semibold text-gray-900">{title}</h3>
      <p className="mt-2">{description}</p>
    </div>
  );
}
