# StaticDrop

**Deploy static HTML, CSS, and JavaScript websites instantly.** Upload a ZIP, publish to a subdomain, collect leads, and upgrade customers into paid plans from one product.

## What Is StaticDrop?

StaticDrop is a SaaS platform for developers, agencies, and small businesses that want to launch static sites without managing servers. It supports instant ZIP deployment, form collection, local wildcard testing, plan-based billing, and custom domains.

## Key Features

- **One-click deploy** - Upload a ZIP and publish in seconds
- **Free subdomains** - Every site gets a generated subdomain
- **Custom domains** - Connect customer domains through DNS
- **Secure form collection** - Origin protection, honeypot filtering, and per-IP rate limiting
- **Submission inbox** - Review leads across all sites from one dashboard
- **Per-site management tabs** - Overview, Submissions, and Settings flows
- **3-day free trial** - New accounts can test the lowest plan before upgrading
- **Dynamic pricing admin** - Superadmins can edit plan pricing and limits in the app
- **Re-deploy** - Replace site files without changing the public URL

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Sync the database schema
npx prisma db push

# 3. Generate the Prisma client
npx prisma generate

# 4. Seed demo data
npm run db:seed

# 5. Start development server
npm run dev
```

Open `http://localhost:3000` and sign in with the demo account:

- **Email:** `demo@staticdrop.com`
- **Password:** `password123`

## Local Testing

After deploying a ZIP, test the published site locally with:

- `http://your-site.lvh.me:3000`
- `http://your-site.localhost:3000`
- `http://localhost:3000/site/your-site`

The ZIP must contain `index.html` at the deploy root after extraction. StaticDrop also auto-flattens common single-folder ZIPs.

## Product Flow

### User Journey

1. Register a new account and begin the 3-day free trial.
2. Deploy a static site from a ZIP file.
3. Open the site overview page and copy the form endpoint.
4. Add the protected form snippet, including the honeypot field, to the frontend.
5. Review leads in the global **Submission Inbox** or the site-specific **Submissions** tab.
6. Upgrade from the pricing page when the customer needs more capacity.
7. Add a custom domain in the site **Settings** tab and point DNS from the registrar.

### Business Controls

- Trial-expired free sites stop serving traffic until upgraded.
- Trial-expired sites also stop accepting new form submissions.
- Superadmins can update plan pricing, limits, and features from the admin area.
- Site owners can configure allowed form origins, honeypot field name, and rate limits per site.

## Tech Stack

- **Next.js 14** (App Router, JavaScript)
- **Prisma** with SQLite
- **NextAuth.js** for authentication
- **Tailwind CSS**
- **AdmZip** for ZIP extraction

## Project Structure

```text
prisma/                  # Database schema and seed data
src/
|-- app/
|   |-- (auth)/          # Login and registration
|   |-- dashboard/       # User dashboard pages
|   |-- admin/           # Superadmin tools
|   |-- api/             # Auth, site, form, billing, and serve routes
|   `-- site/            # Local preview routes
|-- components/          # UI components
|-- lib/                 # Utilities, auth, plans, storage, security
`-- middleware.js        # Subdomain and custom-domain routing
uploads/                 # Deployed site files (gitignored)
docs/                    # Product and technical documentation
```

## Documentation

- [Complete Idea & Vision](docs/IDEA.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Setup Guide](docs/SETUP.md)
- [API Reference](docs/API-REFERENCE.md)
- [User Guide](docs/USER-GUIDE.md)
- [Deployment](docs/DEPLOYMENT.md)
- [Local Testing & Domains](docs/LOCAL-TESTING-AND-DOMAINS.md)

## License

MIT

Page URL Problem Improvement
dashboard /dashboard "1. I am seeing a trial status block there on dashbaord no need of it only a bar on the top id have 3 days trial and then there will be a option will visible in side bar most bottem which bar to upgrade the subscribption plan
when the user click on that upgrade plan then a new route will open /upgradeplan and user can update there the subscrition plan. also for super admin no need to seee any payment notification or information that he need to pay or super admin have subscride any plan 2. i also want that the sidebar and nevbar should be static dont move when the user is scroling"
sidebar sidebar component There is no need of option deploy new site in side bar user can go to sites to deploy a new site
Deploy New Site dashboard/sites/new "The new site adding machinism is very boring looking it lookis like a simple form not user impressive
when a user enters the name and domain information about the site then there should be a next button there which takes the user to next component of that space user have two choices either he will upload the zip file there or he will create the files on the applications manually by creating new files this should look like similar to vscode and comperision of old and new is also present there by green and red color so that user come to know that where he have made changes then after user can save the pages and then deploy the site with this much advance user juerny"
settings dashboard/settings "this page is not looking professional no need of billing information here
also it si looking like soo many forms on cards which is not professional
it should be interective ui user have choices n which setting component a user wants to go to make any changes
user have choice to chaneg his country also user ia able to see dropdown when signup to select the country
also if the email of a user is not verified then user dont have right to create the sight currently also in future i want otp verification for mobile numbers also and user have freedom to login with mobile number or email also currently the email verification process is not working fine
in settings i dont want each things on a single page i want multiple components in it to select for a particular setting it should look professional
for enterprice mode the new user adding funcanality is not looking professional and have each and every option to manage that user like block and the options to add new user should be professional and looking good user juerney"
payment component i want a upi payment method also for indian peoples
site files dashboard/sites/cmn6633qk000rlcz8dcqnm57l/files This page should be more like vscode like ui for insertion and updation and creation of file folder etc also maintain the space in mb which is assigned to users subscribtion should be maintained currently user experience of this page is not good looking like a noob ui/ux developer decide and make this page it should be more professional
site settings dashboard/sites/cmn6633qk000rlcz8dcqnm57l/settings this page looks like designed by noob developer user experience is not good of this page not good desigining planing it should represent this info more advance ui to users instead of two simple forms
register form /register this is also looking like complex form i need only email and password for registration to a new user and if the new user then send the registration email to his provided email for register and authenticate that user and then if user auth is complete then ask him basic buisness questions which will be better for future of the app and country,full name , occupation, these are things are dynamically managed by super admin what things need to ask and what deopdown is shown to user about ocupation and country dropdown should contains all country of worrld and ocupation contains all ocupations registered by super admin along wit custom other ocupation make this processmore professional
