# User Guide

## Getting Started

### 1. Create an Account

Visit the StaticDrop homepage and click **Get Started Free**. New users begin on the entry plan with a **3-day free trial** so they can test deployment, forms, and the dashboard before upgrading.

### 2. Deploy Your First Website

After signing in, open the dashboard and click **Deploy New Site**.

#### Prepare Your Files

Your website should be a normal static HTML, CSS, and JavaScript project. At minimum, the deployed root must contain an `index.html` file.

Example project:

```text
my-website/
|-- index.html
|-- css/
|   `-- style.css
|-- js/
|   `-- main.js
`-- images/
    `-- photo.jpg
```

Zip the project with your operating system zip tool or any archive utility.

Tip: You can zip the folder itself or just the files inside. StaticDrop automatically flattens the common single-folder zip structure during deployment.

#### Fill in the Details

- **Site Name**: Internal name visible in your dashboard
- **Subdomain**: Public site URL, for example `my-portfolio`
- **Custom Domain**: Optional hostname such as `www.mydomain.com`

#### Upload and Deploy

Upload the zip and click **Deploy Site**. StaticDrop validates the archive, extracts it, and publishes the site in seconds.

### 3. Visit Your Site

After deployment, the site overview page shows your live URL and quick links.

In local development, sites are available at:

```text
http://your-subdomain.lvh.me:3000
http://your-subdomain.localhost:3000
http://localhost:3000/site/your-subdomain
```

In production:

```text
https://your-subdomain.staticdrop.com
```

## Working With Forms

StaticDrop includes built-in form collection so portfolio sites, landing pages, and business sites can collect leads without a backend.

### Important Security Improvement

Do not hardcode a public form URL in a way that can be posted from any random website. StaticDrop now protects forms with:

- **Allowed origin checks** so only your deployed domain, local preview domain, and approved custom domains can submit
- **Honeypot spam protection** with a hidden field
- **Per-IP rate limiting** to slow abuse and spam bursts
- **Trial and plan enforcement** so suspended sites stop collecting submissions

Configure these controls in **Site Settings** for each site.

### Method 1: Standard HTML Form

```html
<form action="https://staticdrop.com/api/forms/YOUR_API_KEY" method="POST">
  <label>
    Name
    <input name="name" type="text" required />
  </label>

  <label>
    Email
    <input name="email" type="email" required />
  </label>

  <label>
    Message
    <textarea name="message" required></textarea>
  </label>

  <input type="hidden" name="_formName" value="contact" />
  <input type="hidden" name="company" value="" />
  <input type="hidden" name="_redirect" value="https://your-site.com/thank-you.html" />

  <button type="submit">Send Message</button>
</form>
```

Notes:

- `company` is the default honeypot field. Keep it hidden and empty.
- `_formName` helps separate different forms like `contact`, `quote`, or `newsletter`.
- `_redirect` sends the visitor to a thank-you page after a successful submit.

### Method 2: JavaScript Form

```html
<form id="contactForm">
  <input name="name" placeholder="Name" required />
  <input name="email" type="email" placeholder="Email" required />
  <textarea name="message" placeholder="Message" required></textarea>
  <input type="hidden" name="_formName" value="contact" />
  <input type="hidden" name="company" value="" />
  <button type="submit">Send</button>
  <div id="status"></div>
</form>

<script>
  document.getElementById('contactForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    const status = document.getElementById('status');

    status.textContent = 'Sending...';

    try {
      const response = await fetch('https://staticdrop.com/api/forms/YOUR_API_KEY', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        status.textContent = result.message || 'Message sent successfully!';
        form.reset();
      } else {
        status.textContent = result.error || 'Failed to send. Please try again.';
      }
    } catch (error) {
      status.textContent = 'Network error. Please try again.';
    }
  });
</script>
```

### Finding Your API Key

1. Open **Dashboard -> Sites**
2. Choose a site
3. Open the **Overview** tab
4. Copy the API key from the **Form Collection API** section

### Special Form Fields

| Field Name | Purpose |
|------------|---------|
| `_redirect` | Redirect URL after a successful submission |
| `_formName` | Label to group submissions by form |

Fields starting with `_` are processed by StaticDrop and are not stored in submission data.

## Managing Your Sites

Each site now has clear tabs so users do not need to keep hunting through one long settings page.

### Overview Tab

Use the overview tab to:

- See the public URL
- Copy the form API endpoint
- Review deployment details
- Redeploy a new zip

### Submissions Tab

Use the submissions tab to:

- View submissions for that site only
- Search by form name or content
- Move through paginated results
- Export the current table to CSV

### Settings Tab

Use the settings tab to update:

- Site name
- Subdomain
- Custom domain
- Allowed form origins
- Honeypot field name
- Submission rate limit
- Active or inactive status

## Submission Inbox

The dashboard also includes a global **Submission Inbox** so site owners can review leads from all sites in one place.

This is the main business-friendly workflow for agencies and clients:

1. Open **Dashboard -> Submission Inbox**
2. Search by site name, form name, or message text
3. Review the latest leads across every deployed site
4. Export results when needed

This removes the need to open each site settings screen just to check what customers submitted.

## Updating or Deleting a Site

### Redeploy a Site

1. Open the site **Overview** tab
2. Go to **Update Website**
3. Upload a new zip
4. Click **Redeploy Site**

The URL stays the same. StaticDrop replaces the deployed files.

### Delete a Site

1. Open the site **Settings** tab
2. Go to **Danger Zone**
3. Click **Delete Site**

Warning: Deleting a site permanently removes the site, uploaded files, and submissions.

## Billing and Trial

### Free Trial

- New accounts begin with a 3-day free trial on the entry plan
- During the trial, users can deploy sites and test form collection
- When the trial ends, free sites stop serving traffic and forms stop accepting new submissions until the account upgrades

### Upgrading

1. Open **Pricing**
2. Choose a paid plan
3. Confirm the checkout action
4. Return to the dashboard and continue using the upgraded limits immediately

Dashboard banners show trial status so users always know when to upgrade.

## Custom Domains

### How a Customer Connects a Domain

1. Buy a domain from a registrar like Cloudflare, Namecheap, GoDaddy, or Porkbun
2. In StaticDrop, open the site **Settings** tab
3. Enter the hostname to use, for example `www.mydomain.com`
4. In the registrar DNS panel, add a **CNAME** record:
   - **Host**: `www`
   - **Target**: your StaticDrop platform root domain, for example `staticdrop.com`
5. Wait for DNS propagation
6. Visit the domain and confirm the site loads

### Apex Domain Note

For a root domain like `mydomain.com`, use:

- `ALIAS` or `ANAME` if your DNS provider supports it, or
- An `A` record and reverse proxy setup on your platform, or
- Forward `mydomain.com` to `www.mydomain.com`

## Account Settings

### Profile

In **Dashboard -> Settings**, users can update their name and password.

### Billing Visibility

The settings page also shows:

- Current plan
- Trial end date for free accounts
- A shortcut to the pricing page

## Superadmin Pricing Control

Superadmins can manage plan pricing dynamically without editing code.

1. Open **Admin -> Pricing Plans**
2. Update prices, limits, features, or active state
3. Save the plan

Changes apply to the pricing page immediately.
