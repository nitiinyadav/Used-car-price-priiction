import prisma from '@/lib/prisma';

export default async function AdminRevenuePage() {
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
  const oneYearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);

  const [
    allPayments,
    totalRevenue,
    monthlyRevenue,
    quarterlyRevenue,
    yearlyRevenue,
    revenueByPlan,
    payingUsers,
    totalUsers,
  ] = await Promise.all([
    prisma.payment.findMany({
      include: { user: { select: { name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: { status: 'completed' },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      _count: true,
      where: { status: 'completed', createdAt: { gte: thirtyDaysAgo } },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      _count: true,
      where: { status: 'completed', createdAt: { gte: ninetyDaysAgo } },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      _count: true,
      where: { status: 'completed', createdAt: { gte: oneYearAgo } },
    }),
    prisma.payment.groupBy({
      by: ['planSlug'],
      _sum: { amount: true },
      _count: true,
      where: { status: 'completed' },
    }),
    prisma.user.count({ where: { plan: { not: 'free' } } }),
    prisma.user.count(),
  ]);

  const totalAmount = totalRevenue._sum.amount || 0;
  const monthlyAmount = monthlyRevenue._sum.amount || 0;
  const quarterlyAmount = quarterlyRevenue._sum.amount || 0;
  const yearlyAmount = yearlyRevenue._sum.amount || 0;

  // Calculate projected annual revenue based on MRR
  const projectedAnnual = monthlyAmount * 12;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Revenue & Business</h1>
        <p className="mt-1 text-gray-400">
          Financial overview and payment history
        </p>
      </div>

      {/* Revenue Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">Lifetime Revenue</p>
          <p className="text-2xl font-bold text-green-400 mt-1">
            ${(totalAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">This Month (MRR)</p>
          <p className="text-2xl font-bold text-green-400 mt-1">
            ${(monthlyAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">{monthlyRevenue._count} transactions</p>
        </div>
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">This Quarter</p>
          <p className="text-2xl font-bold text-white mt-1">
            ${(quarterlyAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">{quarterlyRevenue._count} transactions</p>
        </div>
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">Projected Annual (ARR)</p>
          <p className="text-2xl font-bold text-yellow-400 mt-1">
            ${(projectedAnnual / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-gray-500 mt-1">Based on current MRR</p>
        </div>
      </div>

      {/* Business Metrics */}
      <div className="grid lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Key Business Metrics
          </h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-sm text-gray-400">Paying Customers</span>
              <span className="text-sm font-medium text-white">{payingUsers}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-sm text-gray-400">Free Users</span>
              <span className="text-sm font-medium text-white">{totalUsers - payingUsers}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-sm text-gray-400">Conversion Rate</span>
              <span className="text-sm font-medium text-green-400">
                {totalUsers > 0 ? ((payingUsers / totalUsers) * 100).toFixed(1) : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-sm text-gray-400">ARPU (All Users)</span>
              <span className="text-sm font-medium text-white">
                ${totalUsers > 0 ? ((totalAmount / 100) / totalUsers).toFixed(2) : '0.00'}/user
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-sm text-gray-400">ARPU (Paying Only)</span>
              <span className="text-sm font-medium text-white">
                ${payingUsers > 0 ? ((totalAmount / 100) / payingUsers).toFixed(2) : '0.00'}/user
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-sm text-gray-400">Avg Transaction</span>
              <span className="text-sm font-medium text-white">
                ${yearlyRevenue._count > 0 ? ((yearlyAmount / 100) / yearlyRevenue._count).toFixed(2) : '0.00'}
              </span>
            </div>
          </div>
        </div>

        {/* Revenue by Plan */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Revenue by Plan
          </h2>
          {revenueByPlan.length > 0 ? (
            <div className="space-y-4">
              {revenueByPlan.map((item) => {
                const amount = item._sum.amount || 0;
                const percentage = totalAmount > 0 ? ((amount / totalAmount) * 100).toFixed(1) : 0;
                const colors = {
                  starter: { bg: 'bg-blue-500', text: 'text-blue-300' },
                  pro: { bg: 'bg-indigo-500', text: 'text-indigo-300' },
                  enterprise: { bg: 'bg-purple-500', text: 'text-purple-300' },
                };
                const color = colors[item.planSlug] || { bg: 'bg-gray-500', text: 'text-gray-300' };

                return (
                  <div key={item.planSlug}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className={`${color.text} capitalize font-medium`}>{item.planSlug}</span>
                      <span className="text-gray-400">
                        ${(amount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })} ({percentage}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                      <div
                        className={`${color.bg} h-2.5 rounded-full transition-all`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{item._count} payments</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No revenue data yet</p>
          )}

          <div className="mt-6 p-4 bg-gray-700/50 rounded-lg">
            <p className="text-xs text-gray-400">
              <strong className="text-gray-300">Profit Tip:</strong> The Enterprise plan has the highest margin.
              Focus on converting Pro users to Enterprise for maximum revenue growth.
            </p>
          </div>
        </div>
      </div>

      {/* Recent Payments Table */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">Payment History</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-700/50">
              <tr className="text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                <th className="px-6 py-3">Customer</th>
                <th className="px-6 py-3">Plan</th>
                <th className="px-6 py-3">Amount</th>
                <th className="px-6 py-3">Billing</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Date</th>
                <th className="px-6 py-3">Expires</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {allPayments.length > 0 ? (
                allPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-gray-700/30">
                    <td className="px-6 py-4">
                      <p className="text-sm text-white">{payment.user.name}</p>
                      <p className="text-xs text-gray-500">{payment.user.email}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-300 capitalize">{payment.planSlug}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-green-400">
                        ${(payment.amount / 100).toFixed(2)}
                      </span>
                      <span className="text-xs text-gray-500 ml-1">{payment.currency}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400 capitalize">
                      {payment.billingPeriod}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          payment.status === 'completed'
                            ? 'bg-green-900/50 text-green-300'
                            : payment.status === 'pending'
                            ? 'bg-yellow-900/50 text-yellow-300'
                            : 'bg-red-900/50 text-red-300'
                        }`}
                      >
                        {payment.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      {new Date(payment.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      {new Date(payment.expiresAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    No payments recorded yet. Revenue will appear here when users upgrade their plans.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
