import prisma from '@/lib/prisma';
import Link from 'next/link';

export default async function AdminDashboardPage() {
  // Gather all analytics data
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const [
    totalUsers,
    totalSites,
    totalSubmissions,
    totalPayments,
    newUsersToday,
    newUsersWeek,
    newUsersMonth,
    newSitesWeek,
    recentPayments,
    usersByPlan,
    activeSites,
    totalRevenue,
    monthlyRevenue,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.site.count(),
    prisma.formSubmission.count(),
    prisma.payment.count(),
    prisma.user.count({ where: { createdAt: { gte: todayStart } } }),
    prisma.user.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    prisma.user.count({ where: { createdAt: { gte: thirtyDaysAgo } } }),
    prisma.site.count({ where: { createdAt: { gte: sevenDaysAgo } } }),
    prisma.payment.findMany({
      include: { user: { select: { name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    prisma.user.groupBy({
      by: ['plan'],
      _count: { plan: true },
    }),
    prisma.site.count({ where: { isActive: true } }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: { status: 'completed' },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: {
        status: 'completed',
        createdAt: { gte: thirtyDaysAgo },
      },
    }),
  ]);

  const totalRevenueAmount = totalRevenue._sum.amount || 0;
  const monthlyRevenueAmount = monthlyRevenue._sum.amount || 0;

  // Recent users for activity feed
  const recentUsers = await prisma.user.findMany({
    orderBy: { createdAt: 'desc' },
    take: 5,
    select: { id: true, name: true, email: true, plan: true, createdAt: true },
  });

  // Plan distribution map
  const planMap = {};
  usersByPlan.forEach((p) => {
    planMap[p.plan] = p._count.plan;
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="mt-1 text-gray-400">
          Platform overview and business analytics
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Revenue</p>
              <p className="text-2xl font-bold text-green-400">
                ${(totalRevenueAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div className="w-10 h-10 bg-green-900/50 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <p className="mt-2 text-xs text-gray-500">
            This month: ${(monthlyRevenueAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
        </div>

        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Users</p>
              <p className="text-2xl font-bold text-white">{totalUsers}</p>
            </div>
            <div className="w-10 h-10 bg-indigo-900/50 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
          </div>
          <p className="mt-2 text-xs text-gray-500">
            +{newUsersToday} today &middot; +{newUsersWeek} this week &middot; +{newUsersMonth} this month
          </p>
        </div>

        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Deployed Sites</p>
              <p className="text-2xl font-bold text-white">{totalSites}</p>
            </div>
            <div className="w-10 h-10 bg-blue-900/50 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
            </div>
          </div>
          <p className="mt-2 text-xs text-gray-500">
            {activeSites} active &middot; +{newSitesWeek} this week
          </p>
        </div>

        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Form Submissions</p>
              <p className="text-2xl font-bold text-white">{totalSubmissions}</p>
            </div>
            <div className="w-10 h-10 bg-purple-900/50 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
          <p className="mt-2 text-xs text-gray-500">{totalPayments} total payments</p>
        </div>
      </div>

      {/* Two-column layout */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Plan Distribution */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            Users by Plan
          </h2>
          <div className="space-y-3">
            {['free', 'starter', 'pro', 'enterprise'].map((plan) => {
              const count = planMap[plan] || 0;
              const percentage = totalUsers > 0 ? ((count / totalUsers) * 100).toFixed(1) : 0;
              const colors = {
                free: 'bg-gray-500',
                starter: 'bg-blue-500',
                pro: 'bg-indigo-500',
                enterprise: 'bg-purple-500',
              };

              return (
                <div key={plan}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-300 capitalize">{plan}</span>
                    <span className="text-gray-400">
                      {count} ({percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className={`${colors[plan]} h-2 rounded-full transition-all`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-4 pt-4 border-t border-gray-700">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Conversion Rate (Free &rarr; Paid)</span>
              <span className="text-green-400 font-medium">
                {totalUsers > 0
                  ? (
                      (((totalUsers - (planMap['free'] || 0)) / totalUsers) * 100).toFixed(1)
                    )
                  : 0}%
              </span>
            </div>
          </div>
        </div>

        {/* Recent Payments */}
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-white">
              Recent Payments
            </h2>
            <Link
              href="/admin/revenue"
              className="text-sm text-indigo-400 hover:text-indigo-300"
            >
              View All &rarr;
            </Link>
          </div>
          {recentPayments.length > 0 ? (
            <div className="space-y-3">
              {recentPayments.map((payment) => (
                <div
                  key={payment.id}
                  className="flex items-center justify-between py-2 border-b border-gray-700 last:border-0"
                >
                  <div>
                    <p className="text-sm text-white">{payment.user.name}</p>
                    <p className="text-xs text-gray-500">
                      {payment.planSlug} &middot;{' '}
                      {new Date(payment.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <span className="text-sm font-medium text-green-400">
                    +${(payment.amount / 100).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No payments yet</p>
          )}
        </div>
      </div>

      {/* Recent Users */}
      <div className="mt-8 bg-gray-800 rounded-xl border border-gray-700 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">
            Recent Signups
          </h2>
          <Link
            href="/admin/users"
            className="text-sm text-indigo-400 hover:text-indigo-300"
          >
            All Users &rarr;
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <th className="pb-3">User</th>
                <th className="pb-3">Plan</th>
                <th className="pb-3">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {recentUsers.map((user) => (
                <tr key={user.id}>
                  <td className="py-3">
                    <p className="text-sm font-medium text-white">{user.name}</p>
                    <p className="text-xs text-gray-500">{user.email}</p>
                  </td>
                  <td className="py-3">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        user.plan === 'free'
                          ? 'bg-gray-700 text-gray-300'
                          : user.plan === 'starter'
                          ? 'bg-blue-900/50 text-blue-300'
                          : user.plan === 'pro'
                          ? 'bg-indigo-900/50 text-indigo-300'
                          : 'bg-purple-900/50 text-purple-300'
                      }`}
                    >
                      {user.plan}
                    </span>
                  </td>
                  <td className="py-3 text-sm text-gray-400">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Business Metrics */}
      <div className="mt-8 grid sm:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">Avg Revenue Per User (ARPU)</p>
          <p className="text-xl font-bold text-white mt-1">
            ${totalUsers > 0 ? ((totalRevenueAmount / 100) / totalUsers).toFixed(2) : '0.00'}
          </p>
        </div>
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">Monthly Recurring Revenue (MRR)</p>
          <p className="text-xl font-bold text-green-400 mt-1">
            ${(monthlyRevenueAmount / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="bg-gray-800 rounded-xl border border-gray-700 p-6">
          <p className="text-sm text-gray-400">Sites per User</p>
          <p className="text-xl font-bold text-white mt-1">
            {totalUsers > 0 ? (totalSites / totalUsers).toFixed(1) : '0'}
          </p>
        </div>
      </div>
    </div>
  );
}
