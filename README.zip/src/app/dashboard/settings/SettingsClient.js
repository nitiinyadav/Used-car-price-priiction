'use client';

import { useMemo, useState } from 'react';
import Script from 'next/script';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatMoney, getPlanAmount } from '@/lib/currency';

export default function SettingsClient({
  sessionUser,
  plans,
  billing,
  teamMembers,
  preferredCurrency,
}) {
  const { update } = useSession();
  const router = useRouter();

  const paidPlans = useMemo(
    () => plans.filter((plan) => plan.slug !== 'free'),
    [plans]
  );
  const lockedPlan =
    plans.find((plan) => plan.slug === billing?.lockedPlanSlug) || null;

  const [name, setName] = useState(sessionUser?.name || '');
  const [phone, setPhone] = useState(sessionUser?.phone || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [verificationLink, setVerificationLink] = useState('');
  const [memberName, setMemberName] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [memberPhone, setMemberPhone] = useState('');
  const [memberPassword, setMemberPassword] = useState('');
  const [memberPermissions, setMemberPermissions] = useState([
    'view_submissions',
    'view_analytics',
  ]);
  const [selectedPlanSlug, setSelectedPlanSlug] = useState(
    billing?.lockedPlanSlug || paidPlans[0]?.slug || 'starter'
  );
  const [billingPeriod, setBillingPeriod] = useState(
    billing?.lockedBillingPeriod || 'monthly'
  );
  const [currency] = useState(
    billing?.hasPurchasedBefore ? billing?.billingCurrency : preferredCurrency
  );

  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');
  const [profileLoading, setProfileLoading] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [billingError, setBillingError] = useState('');
  const [billingSuccess, setBillingSuccess] = useState('');
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [verificationLoading, setVerificationLoading] = useState(false);
  const [memberLoading, setMemberLoading] = useState(false);
  const [memberError, setMemberError] = useState('');
  const [memberSuccess, setMemberSuccess] = useState('');

  const selectedPlan =
    plans.find((plan) => plan.slug === selectedPlanSlug) || paidPlans[0] || null;
  const selectedAmount = getPlanAmount(selectedPlan, currency, billingPeriod);
  const isBillingLocked = billing?.hasPurchasedBefore;
  const canPurchaseSelection = billing?.hasPurchasedBefore
    ? billing?.canRenewLockedPlan
    : Boolean(selectedPlan);
  const showBillingActions =
    billing?.plan === 'free' ||
    billing?.subscriptionStatus === 'expired' ||
    billing?.expiringSoon;
  const canManageTeam = billing?.plan === 'enterprise' && !sessionUser?.ownerId;

  async function handleProfileUpdate(e) {
    e.preventDefault();
    setProfileError('');
    setProfileSuccess('');
    setProfileLoading(true);

    try {
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone }),
      });

      const data = await res.json();

      if (!res.ok) {
        setProfileError(data.error || 'Update failed');
        return;
      }

      setProfileSuccess('Profile updated successfully');
      await update({ name, phone });
      router.refresh();
    } catch {
      setProfileError('An unexpected error occurred');
    } finally {
      setProfileLoading(false);
    }
  }

  async function requestVerificationLink() {
    setVerificationLoading(true);
    setProfileError('');
    setProfileSuccess('');
    setVerificationLink('');

    try {
      const res = await fetch('/api/auth/email/request-verification', {
        method: 'POST',
      });
      const data = await res.json();

      if (!res.ok) {
        setProfileError(data.error || 'Failed to generate verification link.');
        return;
      }

      setProfileSuccess(data.message || 'Verification link generated.');
      if (data.verificationUrl) {
        setVerificationLink(data.verificationUrl);
      }
    } catch {
      setProfileError('Failed to generate verification link.');
    } finally {
      setVerificationLoading(false);
    }
  }

  async function handlePasswordChange(e) {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      setPasswordError('Password must be at least 8 characters');
      return;
    }

    setPasswordLoading(true);

    try {
      const res = await fetch('/api/auth/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      const data = await res.json();

      if (!res.ok) {
        setPasswordError(data.error || 'Password change failed');
        return;
      }

      setPasswordSuccess('Password changed successfully');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch {
      setPasswordError('An unexpected error occurred');
    } finally {
      setPasswordLoading(false);
    }
  }

  async function handleCheckout() {
    if (!selectedPlan) return;

    if (typeof window === 'undefined' || !window.Razorpay) {
      setBillingError(
        'Secure checkout could not be loaded. Refresh the page and try again.'
      );
      return;
    }

    setCheckoutLoading(true);
    setBillingError('');
    setBillingSuccess('');

    try {
      const orderRes = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planSlug: selectedPlan.slug,
          billingPeriod,
          currency,
        }),
      });
      const orderData = await orderRes.json();

      if (!orderRes.ok) {
        setBillingError(orderData.error || 'Failed to start checkout.');
        return;
      }

      const razorpay = new window.Razorpay({
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'StaticDrop',
        description: orderData.description,
        order_id: orderData.orderId,
        prefill: {
          name: sessionUser.name,
          email: sessionUser.email,
          contact: sessionUser.phone || phone,
        },
        theme: {
          color: '#111827',
        },
        modal: {
          ondismiss: () => {
            setCheckoutLoading(false);
          },
        },
        handler: async (response) => {
          try {
            const verifyRes = await fetch('/api/payments/verify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                orderId: response.razorpay_order_id,
                razorpayPaymentId: response.razorpay_payment_id,
                razorpaySignature: response.razorpay_signature,
              }),
            });
            const verifyData = await verifyRes.json();

            if (!verifyRes.ok) {
              setBillingError(
                verifyData.error || 'Payment was completed but verification failed.'
              );
              return;
            }

            setBillingSuccess(
              verifyData.message || 'Subscription activated successfully.'
            );
            await update({
              plan: verifyData.plan,
              subscriptionStatus: 'active',
              billingCurrency: verifyData.billingCurrency,
              billingPeriod: verifyData.billingPeriod,
              currentPeriodEndsAt: verifyData.expiresAt,
              trialEndsAt: null,
            });
            router.refresh();
          } catch {
            setBillingError('Payment completed but confirmation could not be saved.');
          } finally {
            setCheckoutLoading(false);
          }
        },
      });

      razorpay.on('payment.failed', (response) => {
        setBillingError(
          response?.error?.description || 'Payment was not completed.'
        );
        setCheckoutLoading(false);
      });

      razorpay.open();
    } catch {
      setBillingError('Unable to start secure checkout right now.');
      setCheckoutLoading(false);
    }
  }

  async function createTeamMember() {
    setMemberLoading(true);
    setMemberError('');
    setMemberSuccess('');

    try {
      const res = await fetch('/api/team/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: memberName,
          email: memberEmail,
          phone: memberPhone,
          password: memberPassword,
          permissions: memberPermissions,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setMemberError(data.error || 'Failed to create team member.');
        return;
      }

      setMemberSuccess('Team member created successfully.');
      setMemberName('');
      setMemberEmail('');
      setMemberPhone('');
      setMemberPassword('');
      router.refresh();
    } catch {
      setMemberError('Failed to create team member.');
    } finally {
      setMemberLoading(false);
    }
  }

  return (
    <div>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" strategy="afterInteractive" />

      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="mt-1 text-gray-500">
          Identity, billing, and account trust live here. Daily work stays focused
          on the inbox.
        </p>
      </div>

      <div className="space-y-8">
        <section className="rounded-[28px] border border-gray-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gray-400">
                Billing and Subscription
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-gray-900">
                Calm billing, not constant upgrade pressure
              </h2>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-gray-600">
                Payment tools appear only when they matter: trial ending, renewal
                window open, or subscription expired.
              </p>
            </div>
            <StatusBadge billing={billing} />
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <MetricCard
              label="Current Access"
              value={billing?.plan === 'free' ? 'Trial / Free' : billing?.plan}
            />
            <MetricCard label="Billing Currency" value={currency} />
            <MetricCard
              label="Next Renewal"
              value={
                billing?.currentPeriodEndsAt
                  ? new Date(billing.currentPeriodEndsAt).toLocaleDateString()
                  : billing?.trialEndsAt
                    ? new Date(billing.trialEndsAt).toLocaleDateString()
                    : 'Not started'
              }
            />
            <MetricCard
              label="Plan Rule"
              value={
                isBillingLocked
                  ? 'Switching still allowed'
                  : 'Choose when ready'
              }
            />
          </div>

          {billing?.subscriptionStatus === 'expired' && (
            <AlertBox tone="amber">
              Your subscription has ended. Choose a plan below to restore hosting
              and form collection.
            </AlertBox>
          )}

          {billing?.expiringSoon && billing?.daysRemaining > 0 && (
            <AlertBox tone="amber">
              Your subscription ends in {billing.daysRemaining} day
              {billing.daysRemaining === 1 ? '' : 's'}. Renew now to avoid
              interruption.
            </AlertBox>
          )}

          {billing?.plan === 'free' &&
            !billing?.trialExpired &&
            billing?.trialDaysLeft <= 1 && (
              <AlertBox tone="blue">
                Your onboarding trial is almost over. Choose a plan when you are
                ready to continue.
              </AlertBox>
            )}

          {billingError && (
            <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {billingError}
            </div>
          )}
          {billingSuccess && (
            <div className="mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
              {billingSuccess}
            </div>
          )}

          {showBillingActions ? (
            <div className="mt-8 grid gap-8 xl:grid-cols-[1.4fr_0.8fr]">
              <div>
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      Choose Your Plan
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Users can switch plans freely, and billing opens only when
                      it is actually needed.
                    </p>
                  </div>
                  <div className="rounded-full border border-gray-200 bg-gray-50 px-4 py-2 text-sm font-medium text-gray-700">
                    {currency === 'INR' ? 'India pricing' : 'Global pricing'}
                  </div>
                </div>

                <div className="mb-6 inline-flex rounded-full border border-gray-200 bg-gray-50 p-1">
                  {['monthly', 'yearly'].map((period) => (
                    <button
                      key={period}
                      type="button"
                      onClick={() => setBillingPeriod(period)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-colors ${
                        billingPeriod === period
                          ? 'bg-gray-900 text-white'
                          : 'text-gray-500 hover:text-gray-900'
                      }`}
                    >
                      {period === 'monthly' ? 'Monthly' : 'Yearly'}
                    </button>
                  ))}
                </div>

                <div className="grid gap-4 lg:grid-cols-3">
                  {paidPlans.map((plan) => {
                    const amount = getPlanAmount(plan, currency, billingPeriod);
                    const isSelected = selectedPlanSlug === plan.slug;

                    return (
                      <button
                        key={plan.id}
                        type="button"
                        onClick={() => setSelectedPlanSlug(plan.slug)}
                        className={`rounded-[24px] border p-5 text-left transition-all ${
                          isSelected
                            ? 'border-gray-900 bg-gray-900 text-white shadow-lg shadow-gray-200'
                            : 'border-gray-200 bg-white hover:border-gray-300'
                        }`}
                      >
                        <p
                          className={`text-xs font-semibold uppercase tracking-[0.2em] ${
                            isSelected ? 'text-gray-300' : 'text-gray-400'
                          }`}
                        >
                          {plan.name}
                        </p>
                        <p className="mt-3 text-3xl font-black tracking-tight">
                          {formatMoney(amount, currency)}
                        </p>
                        <p
                          className={`mt-1 text-sm ${
                            isSelected ? 'text-gray-300' : 'text-gray-500'
                          }`}
                        >
                          per {billingPeriod === 'yearly' ? 'year' : 'month'}
                        </p>
                        <div
                          className={`mt-4 text-sm leading-6 ${
                            isSelected ? 'text-gray-200' : 'text-gray-600'
                          }`}
                        >
                          {plan.maxSites} sites, {plan.maxStorageMB} MB per site,
                          {` ${plan.maxSubmissions.toLocaleString()} submissions`}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-[28px] border border-gray-200 bg-gray-50 p-6">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gray-400">
                  Order Summary
                </p>
                <h3 className="mt-3 text-2xl font-black tracking-tight text-gray-900">
                  {selectedPlan?.name || 'Select a plan'}
                </h3>
                <div className="mt-6 space-y-3 text-sm text-gray-600">
                  <SummaryRow label="Billing cycle" value={billingPeriod} />
                  <SummaryRow label="Currency" value={currency} />
                  <SummaryRow
                    label="Price"
                    value={selectedPlan ? formatMoney(selectedAmount, currency) : '-'}
                  />
                </div>

                <button
                  type="button"
                  onClick={handleCheckout}
                  disabled={!canPurchaseSelection || checkoutLoading || !selectedPlan}
                  className="mt-6 w-full rounded-2xl bg-gray-900 px-5 py-3 text-sm font-semibold text-white transition-colors hover:bg-black disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {checkoutLoading
                    ? 'Opening secure checkout...'
                    : billing?.subscriptionStatus === 'expired'
                      ? 'Renew with Razorpay'
                      : 'Continue to Secure Checkout'}
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-8 rounded-[24px] border border-emerald-200 bg-emerald-50 p-5">
              <h3 className="text-lg font-semibold text-emerald-900">
                Your subscription is healthy
              </h3>
              <p className="mt-2 text-sm leading-6 text-emerald-800">
                You do not need to take any billing action right now. StaticDrop
                will surface renewal controls here only when your billing window is
                close.
              </p>
              {lockedPlan && (
                <p className="mt-3 text-sm font-medium text-emerald-900">
                  Current plan: {lockedPlan.name} ({billing?.billingPeriod || 'monthly'})
                </p>
              )}
            </div>
          )}
        </section>

        <div className="grid gap-8 xl:grid-cols-2">
          <section className="rounded-[28px] border border-gray-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">
              Identity and Trust
            </h2>

            <form onSubmit={handleProfileUpdate} className="space-y-4">
              {profileError && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {profileError}
                </div>
              )}
              {profileSuccess && (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                  {profileSuccess}
                </div>
              )}

              <div className="grid gap-4 md:grid-cols-2">
                <MetricCard label="Country" value={sessionUser?.countryName || sessionUser?.countryCode || 'Unknown'} />
                <MetricCard
                  label="Email Status"
                  value={sessionUser?.emailVerifiedAt ? 'Verified' : 'Needs verification'}
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  value={sessionUser?.email || ''}
                  disabled
                  className="w-full rounded-2xl border border-gray-200 bg-gray-50 px-3 py-2 text-gray-500"
                />
              </div>

              <div>
                <label
                  htmlFor="name"
                  className="mb-1 block text-sm font-medium text-gray-700"
                >
                  Name
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-2xl border border-gray-300 px-3 py-2 shadow-sm focus:border-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-900/10"
                />
              </div>

              <div>
                <label
                  htmlFor="phone"
                  className="mb-1 block text-sm font-medium text-gray-700"
                >
                  Phone
                </label>
                <input
                  id="phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full rounded-2xl border border-gray-300 px-3 py-2 shadow-sm focus:border-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-900/10"
                />
              </div>

              {!sessionUser?.emailVerifiedAt && (
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
                  <p className="text-sm font-medium text-amber-900">
                    Email verification is still pending.
                  </p>
                  <button
                    type="button"
                    onClick={requestVerificationLink}
                    disabled={verificationLoading}
                    className="mt-3 rounded-2xl border border-amber-300 px-4 py-2 text-sm font-medium text-amber-900 hover:bg-amber-100"
                  >
                    {verificationLoading ? 'Generating link...' : 'Generate Verification Link'}
                  </button>
                  {verificationLink && (
                    <div className="mt-3 text-sm text-amber-900">
                      Local verification link:{' '}
                      <a href={verificationLink} className="underline">
                        {verificationLink}
                      </a>
                    </div>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={profileLoading}
                className="rounded-2xl bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-black disabled:opacity-50"
              >
                {profileLoading ? 'Saving...' : 'Save Changes'}
              </button>
            </form>
          </section>

          <section className="rounded-[28px] border border-gray-200 bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">
              Change Password
            </h2>

            <form onSubmit={handlePasswordChange} className="space-y-4">
              {passwordError && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {passwordError}
                </div>
              )}
              {passwordSuccess && (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                  {passwordSuccess}
                </div>
              )}

              <Field
                id="currentPassword"
                label="Current Password"
                type="password"
                value={currentPassword}
                onChange={setCurrentPassword}
              />
              <Field
                id="newPassword"
                label="New Password"
                type="password"
                value={newPassword}
                onChange={setNewPassword}
              />
              <Field
                id="confirmNewPassword"
                label="Confirm New Password"
                type="password"
                value={confirmPassword}
                onChange={setConfirmPassword}
              />

              <button
                type="submit"
                disabled={passwordLoading}
                className="rounded-2xl bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-black disabled:opacity-50"
              >
                {passwordLoading ? 'Changing...' : 'Change Password'}
              </button>
            </form>
          </section>
        </div>

        {canManageTeam && (
          <section className="rounded-[28px] border border-gray-200 bg-white p-6 shadow-sm">
            <div className="mb-6">
              <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gray-400">
                Enterprise Team
              </p>
              <h2 className="mt-2 text-2xl font-black tracking-tight text-gray-900">
                Create focused team roles
              </h2>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-gray-600">
                Invite teammates with limited responsibility, like only viewing
                submissions, only checking analytics, or editing files without full
                ownership access.
              </p>
            </div>

            <div className="grid gap-8 xl:grid-cols-[0.9fr_1.1fr]">
              <div className="space-y-4">
                {memberError && (
                  <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                    {memberError}
                  </div>
                )}
                {memberSuccess && (
                  <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                    {memberSuccess}
                  </div>
                )}

                <Field
                  id="memberName"
                  label="Member Name"
                  type="text"
                  value={memberName}
                  onChange={setMemberName}
                />
                <Field
                  id="memberEmail"
                  label="Member Email"
                  type="email"
                  value={memberEmail}
                  onChange={setMemberEmail}
                />
                <Field
                  id="memberPhone"
                  label="Member Phone"
                  type="tel"
                  value={memberPhone}
                  onChange={setMemberPhone}
                />
                <Field
                  id="memberPassword"
                  label="Temporary Password"
                  type="password"
                  value={memberPassword}
                  onChange={setMemberPassword}
                />

                <div>
                  <p className="mb-2 text-sm font-medium text-gray-700">
                    Permissions
                  </p>
                  <div className="space-y-2">
                    {TEAM_PERMISSION_OPTIONS.map((option) => (
                      <label
                        key={option.value}
                        className="flex items-start gap-3 rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm"
                      >
                        <input
                          type="checkbox"
                          checked={memberPermissions.includes(option.value)}
                          onChange={() => togglePermission(option.value, memberPermissions, setMemberPermissions)}
                          className="mt-1"
                        />
                        <span>
                          <span className="block font-medium text-gray-900">
                            {option.label}
                          </span>
                          <span className="text-gray-500">{option.description}</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={createTeamMember}
                  disabled={memberLoading}
                  className="rounded-2xl bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-black disabled:opacity-50"
                >
                  {memberLoading ? 'Creating...' : 'Create Team Member'}
                </button>
              </div>

              <div className="rounded-[24px] border border-gray-200 bg-gray-50 p-5">
                <h3 className="text-lg font-semibold text-gray-900">
                  Current Team Members
                </h3>
                <div className="mt-4 space-y-3">
                  {teamMembers?.length ? (
                    teamMembers.map((member) => (
                      <div
                        key={member.id}
                        className="rounded-2xl border border-gray-200 bg-white px-4 py-4"
                      >
                        <div className="flex items-center justify-between gap-4">
                          <div>
                            <p className="font-medium text-gray-900">{member.name}</p>
                            <p className="text-sm text-gray-500">{member.email}</p>
                          </div>
                          <span className="text-xs text-gray-400">
                            {new Date(member.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {JSON.parse(member.memberPermissions || '[]').map((permission) => (
                            <span
                              key={permission}
                              className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700"
                            >
                              {permission.replace(/_/g, ' ')}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500">
                      No team members created yet.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function togglePermission(permission, permissions, setPermissions) {
  setPermissions(
    permissions.includes(permission)
      ? permissions.filter((item) => item !== permission)
      : [...permissions, permission]
  );
}

const TEAM_PERMISSION_OPTIONS = [
  {
    value: 'view_submissions',
    label: 'Submission Inbox',
    description: 'See what visitors submit through forms.',
  },
  {
    value: 'view_analytics',
    label: 'Analytics',
    description: 'Review traffic and visitor data.',
  },
  {
    value: 'manage_sites',
    label: 'Site Management',
    description: 'Update site settings and deployment controls.',
  },
  {
    value: 'create_sites',
    label: 'Create Sites',
    description: 'Deploy new sites inside the enterprise workspace.',
  },
  {
    value: 'edit_files',
    label: 'Edit Files',
    description: 'Open the in-app file browser and edit site assets.',
  },
];

function Field({ id, label, type, value, onChange }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium text-gray-700">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required
        minLength={type === 'password' ? 8 : undefined}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-gray-300 px-3 py-2 shadow-sm focus:border-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-900/10"
      />
    </div>
  );
}

function MetricCard({ label, value }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-gray-50 px-4 py-4">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gray-400">
        {label}
      </p>
      <p className="mt-2 text-lg font-semibold text-gray-900 capitalize">
        {value || '-'}
      </p>
    </div>
  );
}

function SummaryRow({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span>{label}</span>
      <span className="font-medium capitalize text-gray-900">{value}</span>
    </div>
  );
}

function AlertBox({ tone, children }) {
  const toneClass =
    tone === 'amber'
      ? 'border-amber-200 bg-amber-50 text-amber-900'
      : 'border-blue-200 bg-blue-50 text-blue-900';

  return (
    <div className={`mt-6 rounded-2xl border px-4 py-3 text-sm ${toneClass}`}>
      {children}
    </div>
  );
}

function StatusBadge({ billing }) {
  const status = billing?.subscriptionStatus || 'trial';
  const styleMap = {
    trial: 'bg-blue-50 text-blue-700 border-blue-200',
    active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    expiring: 'bg-amber-50 text-amber-700 border-amber-200',
    expired: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  return (
    <div
      className={`inline-flex items-center rounded-full border px-4 py-2 text-sm font-semibold capitalize ${
        styleMap[status] || styleMap.trial
      }`}
    >
      {status}
    </div>
  );
}
