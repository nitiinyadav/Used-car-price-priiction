import { headers } from 'next/headers';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import { getBillingSnapshot } from '@/lib/billing';
import { detectPreferredCurrency } from '@/lib/currency';
import SettingsClient from './SettingsClient';

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const [plans, billing] = await Promise.all([
    prisma.plan.findMany({
      where: { isActive: true },
      orderBy: { priority: 'asc' },
    }),
    getBillingSnapshot(session.user.id),
  ]);
  const teamMembers =
    billing?.plan === 'enterprise' && !session.user.ownerId
      ? await prisma.user.findMany({
          where: { ownerId: session.user.id },
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            memberPermissions: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'desc' },
        })
      : [];

  const preferredCurrency = detectPreferredCurrency(headers());

  return (
    <SettingsClient
      sessionUser={session.user}
      plans={plans}
      billing={billing}
      teamMembers={teamMembers}
      preferredCurrency={
        billing?.hasPurchasedBefore ? billing.billingCurrency : preferredCurrency
      }
    />
  );
}
