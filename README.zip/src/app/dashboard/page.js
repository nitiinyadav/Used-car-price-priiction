import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import Link from 'next/link';
import { getUserLimits } from '@/lib/plans';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const limits = await getUserLimits(session.user.id);
  const workspace = await getWorkspaceContext(session.user.id);
  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;

  const [sites, totalSubmissions] = await Promise.all([
    prisma.site.findMany({
      where: { userId: workspaceOwnerId },
      include: { _count: { select: { submissions: true } } },
      orderBy: { createdAt: 'desc' },
    }),
    prisma.formSubmission.count({
      where: { site: { userId: workspaceOwnerId } },
    }),
  ]);

  const recentSubmissions = await prisma.formSubmission.findMany({
    where: { site: { userId: workspaceOwnerId } },
    include: { site: { select: { name: true, subdomain: true } } },
    orderBy: { createdAt: 'desc' },
    take: 5,
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          Welcome back, {session.user.name}!
        </h1>
        <p className="mt-1 text-gray-500">
          Here&apos;s an overview of your deployed sites
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-indigo-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{sites.length}</p>
              <p className="text-sm text-gray-500">Deployed Sites</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {sites.filter((s) => s.isActive).length}
              </p>
              <p className="text-sm text-gray-500">Active Sites</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-purple-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {totalSubmissions}
              </p>
              <p className="text-sm text-gray-500">Form Submissions</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
              <svg
                className="w-5 h-5 text-amber-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {limits.plan === 'free'
                  ? limits.trialExpired
                    ? 'Expired'
                    : `${limits.trialDaysLeft}d`
                  : limits.subscriptionStatus === 'expired'
                    ? 'Expired'
                    : limits.plan}
              </p>
              <p className="text-sm text-gray-500">
                {limits.plan === 'free' ? 'Trial Status' : 'Current Plan'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex items-center space-x-4 mb-8">
        <Link
          href={hasPermission(workspace, 'create_sites') ? '/dashboard/sites/new' : '/dashboard'}
          aria-disabled={!hasPermission(workspace, 'create_sites')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-2 ${
            hasPermission(workspace, 'create_sites')
              ? 'bg-indigo-600 text-white hover:bg-indigo-700'
              : 'bg-gray-200 text-gray-500 cursor-not-allowed'
          }`}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4v16m8-8H4"
            />
          </svg>
          <span>Deploy New Site</span>
        </Link>
        <Link
          href="/dashboard/sites"
          className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:border-gray-400 transition-colors"
        >
          View All Sites
        </Link>
        <Link
          href="/dashboard/submissions"
          className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:border-gray-400 transition-colors"
        >
          Open Inbox
        </Link>
        <Link
          href="/dashboard/settings"
          className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:border-gray-400 transition-colors"
        >
          Account Settings
        </Link>
      </div>

      {/* Recent Submissions */}
      {recentSubmissions.length > 0 && (
        <div className="bg-white rounded-xl border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">
              Recent Form Submissions
            </h2>
          </div>
          <div className="divide-y divide-gray-200">
            {recentSubmissions.map((sub) => {
              const data = JSON.parse(sub.data);
              const preview = Object.entries(data)
                .slice(0, 3)
                .map(([k, v]) => `${k}: ${v}`)
                .join(', ');

              return (
                <div key={sub.id} className="px-6 py-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {sub.site.name}
                      </p>
                      <p className="text-sm text-gray-500 mt-0.5 truncate max-w-md">
                        {preview}
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">
                      {new Date(sub.createdAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty state */}
      {sites.length === 0 && (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
            />
          </svg>
          <h3 className="mt-4 text-lg font-medium text-gray-900">
            No sites deployed yet
          </h3>
          <p className="mt-2 text-gray-500">
            Deploy your first website to get started
          </p>
          <Link
            href="/dashboard/sites/new"
            className="mt-6 inline-block bg-indigo-600 text-white px-6 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors"
          >
            Deploy Your First Site
          </Link>
        </div>
      )}
    </div>
  );
}
