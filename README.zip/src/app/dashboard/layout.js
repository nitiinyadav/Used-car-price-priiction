import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import Sidebar from '@/components/Sidebar';
import Link from 'next/link';
import { getUserLimits } from '@/lib/plans';

export const metadata = {
  title: 'Dashboard - StaticDrop',
};

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const limits = await getUserLimits(session.user.id);
  const showBillingBanner =
    limits &&
    session.user.role !== 'superadmin' &&
    ((limits.plan === 'free' && (limits.trialExpired || limits.trialDaysLeft <= 1)) ||
      limits.subscriptionStatus === 'expired' ||
      limits.expiringSoon);

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      <main className="flex-1">
        {/* Mobile header */}
        <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 bg-indigo-600 rounded-lg flex items-center justify-center">
              <svg
                className="w-4 h-4 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                />
              </svg>
            </div>
            <span className="font-bold text-gray-900">StaticDrop</span>
          </div>
          <span className="text-sm text-gray-500">{session.user.name}</span>
        </div>

        <div className="p-6 lg:p-8">
          {showBillingBanner && (
            <div
              className={`mb-6 rounded-xl border px-4 py-3 text-sm ${
                limits.subscriptionStatus === 'expired' || limits.trialExpired
                  ? 'border-amber-300 bg-amber-50 text-amber-900'
                  : 'border-sky-200 bg-sky-50 text-sky-900'
              }`}
            >
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <p>
                  {limits.subscriptionStatus === 'expired'
                    ? 'Your paid subscription has ended. Renew it from Settings to reactivate hosting and form collection.'
                    : limits.expiringSoon
                      ? `Your subscription ends in ${limits.daysRemaining} day${
                          limits.daysRemaining === 1 ? '' : 's'
                        }. Renew from Settings to avoid interruption.`
                      : limits.trialExpired
                        ? 'Your 3-day free trial has ended. Choose a paid plan from Settings to keep your sites active.'
                        : `Your trial ends in ${limits.trialDaysLeft} day${
                            limits.trialDaysLeft === 1 ? '' : 's'
                          }. Billing is managed from Settings.`}
                </p>
                <Link
                  href="/dashboard/settings"
                  className="inline-flex items-center justify-center rounded-lg bg-gray-900 px-3 py-2 font-medium text-white hover:bg-black"
                >
                  Open Billing
                </Link>
              </div>
            </div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}
