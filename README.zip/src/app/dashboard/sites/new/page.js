'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import FileUpload from '@/components/FileUpload';
import {
  getSitePreviewUrl,
  getSiteSubdomainUrl,
  getRootDomain,
  normalizeDomain,
} from '@/lib/utils';

export default function NewSitePage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [subdomain, setSubdomain] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubdomainChange(e) {
    const value = e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '');
    setSubdomain(value);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Site name is required');
      return;
    }

    if (!subdomain.trim()) {
      setError('Subdomain is required');
      return;
    }

    if (subdomain.length < 3) {
      setError('Subdomain must be at least 3 characters');
      return;
    }

    if (!file) {
      setError('Please upload a ZIP file');
      return;
    }

    setLoading(true);

    try {
      const formData = new FormData();
      formData.append('name', name.trim());
      formData.append('subdomain', subdomain.trim());
      if (customDomain.trim()) {
        formData.append('customDomain', normalizeDomain(customDomain));
      }
      formData.append('file', file);

      const res = await fetch('/api/sites', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Deployment failed');
        return;
      }

      router.push(`/dashboard/sites/${data.site.id}`);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  }

  const rootDomain = getRootDomain();
  const localSubdomainUrl = subdomain
    ? getSiteSubdomainUrl(subdomain)
    : null;
  const previewUrl = subdomain ? getSitePreviewUrl(subdomain) : null;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Deploy New Site</h1>
        <p className="mt-1 text-gray-500">
          Upload your website files and choose a subdomain
        </p>
      </div>

      <div className="max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {/* Site Name */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-5">
            <div>
              <label
                htmlFor="name"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Site Name
              </label>
              <input
                id="name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="My Portfolio"
              />
              <p className="mt-1 text-xs text-gray-500">
                A friendly name for your site (only visible to you)
              </p>
            </div>

            {/* Subdomain */}
            <div>
              <label
                htmlFor="subdomain"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Subdomain
              </label>
              <div className="flex items-center">
                <input
                  id="subdomain"
                  type="text"
                  required
                  value={subdomain}
                  onChange={handleSubdomainChange}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="my-portfolio"
                  maxLength={63}
                />
                <span className="px-3 py-2 bg-gray-50 border border-l-0 border-gray-300 rounded-r-lg text-sm text-gray-500">
                  .{rootDomain.replace(/^https?:\/\//, '')}
                </span>
              </div>
              <p className="mt-1 text-xs text-gray-500">
                Only lowercase letters, numbers, and hyphens. Min 3 characters.
              </p>
              {subdomain && (
                <div className="mt-3 rounded-lg bg-gray-50 border border-gray-200 p-3 text-xs text-gray-600 space-y-1">
                  <p>
                    Local subdomain test:{' '}
                    <code className="bg-white px-1 py-0.5 rounded">
                      {localSubdomainUrl}
                    </code>
                  </p>
                  <p>
                    Fallback preview URL:{' '}
                    <code className="bg-white px-1 py-0.5 rounded">
                      {previewUrl}
                    </code>
                  </p>
                </div>
              )}
            </div>

            {/* Custom Domain (Optional) */}
            <div>
              <label
                htmlFor="customDomain"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Custom Domain{' '}
                <span className="text-gray-400 font-normal">(optional)</span>
              </label>
              <input
                id="customDomain"
                type="text"
                value={customDomain}
                onChange={(e) => setCustomDomain(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="www.example.com"
              />
              <p className="mt-1 text-xs text-gray-500">
                Point a CNAME record to{' '}
                <code className="bg-gray-100 px-1 py-0.5 rounded text-xs">
                  {rootDomain.replace(/^https?:\/\//, '')}
                </code>{' '}
                to use your own domain
              </p>
            </div>
          </div>

          {/* File Upload */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Website Files
            </label>
            <FileUpload onFileSelect={setFile} />
            <div className="mt-3 p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700">
                <strong>Tip:</strong> ZIP your website folder containing{' '}
                <code className="bg-blue-100 px-1 py-0.5 rounded">
                  index.html
                </code>{' '}
                and all CSS/JS/image files. The ZIP may contain your files
                directly or inside one top-level folder, but after extraction
                the site root must still contain <code className="bg-blue-100 px-1 py-0.5 rounded">index.html</code>.
              </p>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {loading ? (
              <>
                <svg
                  className="animate-spin h-5 w-5"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                  />
                </svg>
                <span>Deploying...</span>
              </>
            ) : (
              <>
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  />
                </svg>
                <span>Deploy Site</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
