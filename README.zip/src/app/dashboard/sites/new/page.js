'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import FileUpload from '@/components/FileUpload';
import {
  getRootDomain,
  normalizeDomain,
} from '@/lib/utils';

const STEP_INFO = 1;
const STEP_FILES = 2;
const STEP_DEPLOY = 3;

const STARTER_TEMPLATES = {
  'index.html': `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>My Site</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <h1>Hello World</h1>\n  <p>Welcome to my site.</p>\n  <script src="script.js"></script>\n</body>\n</html>`,
  'style.css': `* { margin: 0; padding: 0; box-sizing: border-box; }\nbody { font-family: system-ui, sans-serif; padding: 2rem; max-width: 800px; margin: 0 auto; }\nh1 { color: #1a1a1a; margin-bottom: 1rem; }\np { color: #666; line-height: 1.6; }`,
  'script.js': `// Your JavaScript here\nconsole.log('Site loaded');`,
};

export default function NewSitePage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [subdomain, setSubdomain] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [deployMethod, setDeployMethod] = useState(null);
  const [file, setFile] = useState(null);
  const [editorFiles, setEditorFiles] = useState(
    Object.entries(STARTER_TEMPLATES).map(([path, content]) => ({ path, content, original: content }))
  );
  const [activeFile, setActiveFile] = useState('index.html');
  const [newFileName, setNewFileName] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [step, setStep] = useState(STEP_INFO);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  function handleSubdomainChange(e) {
    setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''));
  }

  function goToStep2() {
    if (!name.trim()) { setError('Site name is required'); return; }
    if (!subdomain.trim()) { setError('Subdomain is required'); return; }
    if (subdomain.length < 3) { setError('Subdomain must be at least 3 characters'); return; }
    setError('');
    setStep(STEP_FILES);
  }

  function goToStep3() {
    if (deployMethod === 'upload' && !file) { setError('Please upload a ZIP file'); return; }
    if (deployMethod === 'editor' && !editorFiles.some((f) => f.path === 'index.html')) {
      setError('Your site must have an index.html'); return;
    }
    setError('');
    setStep(STEP_DEPLOY);
  }

  function addEditorFile() {
    if (!newFileName.trim()) return;
    const p = newFileName.trim().replace(/\\/g, '/');
    if (editorFiles.some((f) => f.path === p)) { setError('File already exists'); return; }
    setEditorFiles([...editorFiles, { path: p, content: '', original: '' }]);
    setActiveFile(p);
    setNewFileName('');
    setShowNewFile(false);
    setError('');
  }

  function deleteEditorFile(path) {
    if (path === 'index.html') return;
    setEditorFiles(editorFiles.filter((f) => f.path !== path));
    if (activeFile === path) setActiveFile(editorFiles[0]?.path || '');
  }

  function updateFileContent(path, content) {
    setEditorFiles(editorFiles.map((f) => (f.path === path ? { ...f, content } : f)));
  }

  const currentFile = editorFiles.find((f) => f.path === activeFile);

  async function handleDeploy() {
    setError('');
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('name', name.trim());
      formData.append('subdomain', subdomain.trim());
      if (customDomain.trim()) formData.append('customDomain', normalizeDomain(customDomain));
      if (deployMethod === 'upload') {
        formData.append('file', file);
      } else {
        const filesPayload = {};
        editorFiles.forEach((f) => { filesPayload[f.path] = f.content; });
        formData.append('editorFiles', new Blob([JSON.stringify(filesPayload)], { type: 'application/json' }));
      }
      const res = await fetch('/api/sites', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Deployment failed'); return; }
      router.push(`/dashboard/sites/${data.site.id}`);
      router.refresh();
    } catch { setError('An unexpected error occurred'); }
    finally { setLoading(false); }
  }

  const rootDomain = getRootDomain();

  return (
    <div className="max-w-4xl mx-auto">
      {/* Step indicator */}
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-6">
          {[{ num: 1, label: 'Site Info' }, { num: 2, label: 'Add Files' }, { num: 3, label: 'Deploy' }].map((s, i) => (
            <div key={s.num} className="flex items-center gap-3">
              {i > 0 && <div className={`h-px w-8 ${step >= s.num ? 'bg-indigo-600' : 'bg-gray-200'}`} />}
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${step >= s.num ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
                  {step > s.num ? (<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>) : s.num}
                </div>
                <span className={`text-sm font-medium hidden sm:block ${step >= s.num ? 'text-gray-900' : 'text-gray-400'}`}>{s.label}</span>
              </div>
            </div>
          ))}
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Deploy New Site</h1>
        <p className="mt-1 text-gray-500">
          {step === STEP_INFO && 'Name your site and choose a subdomain'}
          {step === STEP_FILES && 'Upload files or build your site right here'}
          {step === STEP_DEPLOY && 'Review and deploy your site'}
        </p>
      </div>

      {error && (<div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm">{error}</div>)}

      {/* STEP 1 */}
      {step === STEP_INFO && (
        <div className="bg-white rounded-2xl border border-gray-200 p-6 space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Site Name</label>
            <input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} autoFocus className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="My Portfolio" />
            <p className="mt-1 text-xs text-gray-400">A friendly name visible only to you</p>
          </div>
          <div>
            <label htmlFor="subdomain" className="block text-sm font-medium text-gray-700 mb-1">Subdomain</label>
            <div className="flex">
              <input id="subdomain" type="text" value={subdomain} onChange={handleSubdomainChange} className="flex-1 px-4 py-3 border border-gray-300 rounded-l-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="my-portfolio" maxLength={63} />
              <span className="px-4 py-3 bg-gray-50 border border-l-0 border-gray-300 rounded-r-xl text-sm text-gray-500 whitespace-nowrap">.{rootDomain.replace(/^https?:\/\//, '')}</span>
            </div>
          </div>
          <div>
            <label htmlFor="customDomain" className="block text-sm font-medium text-gray-700 mb-1">Custom Domain <span className="text-gray-400 font-normal">(optional)</span></label>
            <input id="customDomain" type="text" value={customDomain} onChange={(e) => setCustomDomain(e.target.value)} className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm" placeholder="www.example.com" />
          </div>
          <div className="flex justify-end">
            <button type="button" onClick={goToStep2} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2">
              Next <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            </button>
          </div>
        </div>
      )}

      {/* STEP 2 */}
      {step === STEP_FILES && (
        <div className="space-y-6">
          {!deployMethod && (
            <div className="grid md:grid-cols-2 gap-4">
              <button type="button" onClick={() => setDeployMethod('upload')} className="bg-white rounded-2xl border-2 border-gray-200 p-8 text-left hover:border-indigo-400 hover:bg-indigo-50/30 transition-all group">
                <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-indigo-200 transition-colors">
                  <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                </div>
                <h3 className="text-lg font-bold text-gray-900">Upload ZIP</h3>
                <p className="mt-2 text-sm text-gray-500">Already have your site files? Upload a ZIP containing your HTML, CSS & JS.</p>
              </button>
              <button type="button" onClick={() => setDeployMethod('editor')} className="bg-white rounded-2xl border-2 border-gray-200 p-8 text-left hover:border-purple-400 hover:bg-purple-50/30 transition-all group">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                  <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
                </div>
                <h3 className="text-lg font-bold text-gray-900">Build Here</h3>
                <p className="mt-2 text-sm text-gray-500">Create and edit files in a code editor. Start from a template or scratch.</p>
              </button>
            </div>
          )}

          {deployMethod === 'upload' && (
            <div className="bg-white rounded-2xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Upload ZIP File</h3>
                <button type="button" onClick={() => { setDeployMethod(null); setFile(null); }} className="text-sm text-gray-500 hover:text-gray-700">Change method</button>
              </div>
              <FileUpload onFileSelect={setFile} />
              <p className="mt-3 text-xs text-gray-400">ZIP must contain <code className="bg-gray-100 px-1 py-0.5 rounded">index.html</code> at the root.</p>
            </div>
          )}

          {deployMethod === 'editor' && (
            <div className="bg-gray-900 rounded-2xl overflow-hidden border border-gray-700">
              <div className="flex items-center justify-between px-4 py-2 bg-gray-800 border-b border-gray-700">
                <div className="flex items-center gap-2">
                  <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-500" /><div className="w-3 h-3 rounded-full bg-yellow-500" /><div className="w-3 h-3 rounded-full bg-green-500" /></div>
                  <span className="ml-3 text-xs text-gray-400 font-mono">{name || 'untitled'} — StaticDrop Editor</span>
                </div>
                <button type="button" onClick={() => setDeployMethod(null)} className="text-xs text-gray-400 hover:text-white">Change method</button>
              </div>
              <div className="flex" style={{ minHeight: '480px' }}>
                <div className="w-52 bg-gray-800 border-r border-gray-700 flex flex-col">
                  <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center justify-between">
                    <span>Explorer</span>
                    <button type="button" onClick={() => setShowNewFile(true)} className="text-gray-400 hover:text-white" title="New file">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                    </button>
                  </div>
                  {showNewFile && (
                    <div className="px-2 pb-2">
                      <input autoFocus value={newFileName} onChange={(e) => setNewFileName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addEditorFile(); if (e.key === 'Escape') { setShowNewFile(false); setNewFileName(''); } }} onBlur={() => { if (!newFileName.trim()) setShowNewFile(false); }} className="w-full bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600 focus:outline-none focus:border-indigo-500" placeholder="filename.html" />
                    </div>
                  )}
                  <div className="flex-1 overflow-y-auto">
                    {editorFiles.map((f) => {
                      const isAct = activeFile === f.path;
                      const isMod = f.content !== f.original;
                      const ext = f.path.split('.').pop();
                      const cMap = { html: 'text-orange-400', css: 'text-blue-400', js: 'text-yellow-400', json: 'text-green-400' };
                      return (
                        <div key={f.path} className={`group flex items-center justify-between px-3 py-1.5 cursor-pointer text-xs ${isAct ? 'bg-gray-700/80 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-700/40'}`} onClick={() => setActiveFile(f.path)}>
                          <div className="flex items-center gap-2 truncate">
                            <span className={cMap[ext] || 'text-gray-400'}>{ext === 'html' ? '◆' : ext === 'css' ? '◈' : ext === 'js' ? '◇' : '▫'}</span>
                            <span className="truncate">{f.path}</span>
                            {isMod && <span className="w-2 h-2 rounded-full bg-amber-400 flex-shrink-0" />}
                          </div>
                          {f.path !== 'index.html' && (
                            <button type="button" onClick={(e) => { e.stopPropagation(); deleteEditorFile(f.path); }} className="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-400 ml-2">×</button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className="flex-1 flex flex-col">
                  <div className="flex bg-gray-800 border-b border-gray-700 overflow-x-auto">
                    {editorFiles.map((f) => (
                      <button key={f.path} type="button" onClick={() => setActiveFile(f.path)} className={`px-4 py-2 text-xs font-mono border-r border-gray-700 whitespace-nowrap ${activeFile === f.path ? 'bg-gray-900 text-white border-b-2 border-b-indigo-500' : 'text-gray-400 hover:text-white'}`}>
                        {f.path}{f.content !== f.original && <span className="ml-1 text-amber-400">●</span>}
                      </button>
                    ))}
                  </div>
                  {currentFile ? (
                    <div className="flex-1 flex">
                      <div className="py-3 px-2 bg-gray-900/50 text-gray-600 font-mono text-xs leading-[1.5rem] select-none text-right min-w-[3rem] overflow-hidden">
                        {(currentFile.content || '').split('\n').map((_, i) => (<div key={i}>{i + 1}</div>))}
                      </div>
                      <textarea value={currentFile.content} onChange={(e) => updateFileContent(activeFile, e.target.value)} className="flex-1 bg-gray-900 text-gray-100 font-mono text-xs leading-[1.5rem] p-3 resize-none focus:outline-none" spellCheck={false} />
                    </div>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-500 text-sm">Select a file to edit</div>
                  )}
                  <div className="flex items-center justify-between px-4 py-1 bg-indigo-600 text-white text-xs">
                    <span>{editorFiles.length} files</span>
                    <span className="font-mono">{activeFile ? activeFile.split('.').pop().toUpperCase() : ''}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {deployMethod && (
            <div className="flex justify-between">
              <button type="button" onClick={() => setStep(STEP_INFO)} className="text-gray-600 hover:text-gray-900 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg> Back
              </button>
              <button type="button" onClick={goToStep3} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors flex items-center gap-2">
                Review & Deploy <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
              </button>
            </div>
          )}
        </div>
      )}

      {/* STEP 3 */}
      {step === STEP_DEPLOY && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Review Your Site</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="bg-gray-50 rounded-xl p-4"><p className="text-xs text-gray-400 uppercase font-medium tracking-wide">Site Name</p><p className="mt-1 font-semibold text-gray-900">{name}</p></div>
              <div className="bg-gray-50 rounded-xl p-4"><p className="text-xs text-gray-400 uppercase font-medium tracking-wide">Subdomain</p><p className="mt-1 font-semibold text-gray-900">{subdomain}.{rootDomain.replace(/^https?:\/\//, '')}</p></div>
              {customDomain && (<div className="bg-gray-50 rounded-xl p-4"><p className="text-xs text-gray-400 uppercase font-medium tracking-wide">Custom Domain</p><p className="mt-1 font-semibold text-gray-900">{customDomain}</p></div>)}
              <div className="bg-gray-50 rounded-xl p-4"><p className="text-xs text-gray-400 uppercase font-medium tracking-wide">Deploy Method</p><p className="mt-1 font-semibold text-gray-900">{deployMethod === 'upload' ? `ZIP (${file?.name})` : `${editorFiles.length} editor files`}</p></div>
            </div>
          </div>
          <div className="flex justify-between">
            <button type="button" onClick={() => setStep(STEP_FILES)} className="text-gray-600 hover:text-gray-900 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg> Back
            </button>
            <button type="button" onClick={handleDeploy} disabled={loading} className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center gap-2">
              {loading ? (<><svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg><span>Deploying...</span></>) : (<><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg><span>Deploy Site</span></>)}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
