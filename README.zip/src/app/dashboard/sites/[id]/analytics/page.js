import { getServerSession } from 'next-auth';
import { notFound } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import SiteTabs from '@/components/SiteTabs';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

export const metadata = {
  title: 'Site Analytics - StaticDrop',
};

export default async function SiteAnalyticsPage({ params }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, 'view_analytics')) {
    notFound();
  }

  const site = await prisma.site.findFirst({
    where: { id: params.id, userId: workspace?.workspaceOwnerId || session.user.id },
  });

  if (!site) {
    notFound();
  }

  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const [totalPageViews, recentPageViews, topPages, recentVisitors] = await Promise.all([
    prisma.siteVisit.count({ where: { siteId: site.id } }),
    prisma.siteVisit.count({
      where: { siteId: site.id, createdAt: { gte: sevenDaysAgo } },
    }),
    prisma.siteVisit.groupBy({
      by: ['path'],
      where: { siteId: site.id },
      _count: { path: true },
      orderBy: { _count: { path: 'desc' } },
      take: 5,
    }),
    prisma.siteVisit.findMany({
      where: { siteId: site.id, createdAt: { gte: sevenDaysAgo } },
      distinct: ['ipHash'],
      select: { ipHash: true, countryCode: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
    }),
  ]);

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Site Analytics</h1>
        <p className="mt-1 text-gray-500">
          Understand traffic patterns without leaving your dashboard.
        </p>
      </div>

      <SiteTabs siteId={site.id} />

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <StatCard label="Total Page Views" value={totalPageViews} />
        <StatCard label="Last 7 Days" value={recentPageViews} />
        <StatCard label="Unique Visitors (7d)" value={recentVisitors.length} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-gray-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-gray-900">Top Pages</h2>
          <div className="mt-4 space-y-3">
            {topPages.length === 0 ? (
              <p className="text-sm text-gray-500">No visits recorded yet.</p>
            ) : (
              topPages.map((page) => (
                <div
                  key={page.path}
                  className="flex items-center justify-between rounded-lg border border-gray-100 bg-gray-50 px-4 py-3"
                >
                  <code className="text-sm text-gray-700">{page.path}</code>
                  <span className="text-sm font-medium text-gray-900">
                    {page._count.path} views
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 bg-white p-6">
          <h2 className="text-lg font-semibold text-gray-900">Visitor Regions</h2>
          <div className="mt-4 space-y-3">
            {recentVisitors.length === 0 ? (
              <p className="text-sm text-gray-500">No visitor data yet.</p>
            ) : (
              recentVisitors.slice(0, 8).map((visitor, index) => (
                <div
                  key={`${visitor.ipHash}-${index}`}
                  className="flex items-center justify-between rounded-lg border border-gray-100 bg-gray-50 px-4 py-3"
                >
                  <span className="text-sm text-gray-700">
                    {visitor.countryCode || 'Unknown'}
                  </span>
                  <span className="text-xs text-gray-500">
                    {new Date(visitor.createdAt).toLocaleDateString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-5">
      <p className="text-sm text-gray-500">{label}</p>
      <p className="mt-1 text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}
