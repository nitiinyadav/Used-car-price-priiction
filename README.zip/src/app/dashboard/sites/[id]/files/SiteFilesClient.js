'use client';

import { useEffect, useMemo, useState } from 'react';

const EDITABLE_EXT = /\.(html|css|js|json|txt|md|svg)$/i;
const EXT_COLORS = { html: 'text-orange-400', css: 'text-blue-400', js: 'text-yellow-400', json: 'text-green-400', md: 'text-gray-300', svg: 'text-pink-400', txt: 'text-gray-400' };
const EXT_ICONS = { html: '◆', css: '◈', js: '◇', json: '▣', md: '□', svg: '○', txt: '▫' };

export default function SiteFilesClient({ site }) {
  const [files, setFiles] = useState([]);
  const [selectedPath, setSelectedPath] = useState('');
  const [content, setContent] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newFilePath, setNewFilePath] = useState('');
  const [showNewFile, setShowNewFile] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [openTabs, setOpenTabs] = useState([]);

  const isEditable = EDITABLE_EXT.test(selectedPath);
  const isModified = isEditable && content !== originalContent;
  const totalSize = useMemo(() => files.reduce((acc, f) => acc + (f.size || 0), 0), [files]);
  const storageMB = (totalSize / (1024 * 1024)).toFixed(2);

  useEffect(() => { loadFiles(); }, []);

  useEffect(() => {
    if (selectedPath) {
      loadContent(selectedPath);
      if (!openTabs.includes(selectedPath)) {
        setOpenTabs((prev) => [...prev, selectedPath]);
      }
    } else {
      setContent('');
      setOriginalContent('');
    }
  }, [selectedPath]);

  async function loadFiles() {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`/api/sites/${site.id}/files`);
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to load files.'); return; }
      setFiles(data.files || []);
      if (!selectedPath && data.files?.length) {
        const first = data.files.find((f) => EDITABLE_EXT.test(f.path));
        setSelectedPath(first?.path || data.files[0].path);
      }
    } catch {
      setError('Failed to load files.');
    } finally {
      setLoading(false);
    }
  }

  async function loadContent(filePath) {
    if (!EDITABLE_EXT.test(filePath)) { setContent(''); setOriginalContent(''); return; }
    try {
      const res = await fetch(`/api/sites/${site.id}/files?path=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to load file.'); return; }
      setContent(data.content || '');
      setOriginalContent(data.content || '');
    } catch {
      setError('Failed to load file.');
    }
  }

  async function saveFile() {
    if (!selectedPath) return;
    setSaving(true);
    setStatus('');
    setError('');
    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedPath, content }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to save.'); return; }
      setStatus('Saved');
      setOriginalContent(content);
      setTimeout(() => setStatus(''), 2000);
      await loadFiles();
    } catch {
      setError('Failed to save.');
    } finally {
      setSaving(false);
    }
  }

  async function createFile() {
    if (!newFilePath.trim()) return;
    setError('');
    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: newFilePath.trim(), content: '' }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to create file.'); return; }
      setSelectedPath(newFilePath.trim());
      setNewFilePath('');
      setShowNewFile(false);
      await loadFiles();
    } catch {
      setError('Failed to create file.');
    }
  }

  async function deleteFile() {
    if (!selectedPath) return;
    setError('');
    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedPath }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to delete.'); return; }
      closeTab(selectedPath);
      setConfirmDelete(false);
      await loadFiles();
    } catch {
      setError('Failed to delete.');
    }
  }

  async function handleUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError('');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await fetch(`/api/sites/${site.id}/files`, { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Failed to upload.'); return; }
      await loadFiles();
    } catch {
      setError('Failed to upload.');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  }

  function closeTab(path) {
    const newTabs = openTabs.filter((t) => t !== path);
    setOpenTabs(newTabs);
    if (selectedPath === path) {
      setSelectedPath(newTabs.length ? newTabs[newTabs.length - 1] : '');
    }
  }

  function getExt(p) {
    return (p.split('.').pop() || '').toLowerCase();
  }

  const lines = (content || '').split('\n');

  return (
    <div className="bg-gray-900 rounded-2xl overflow-hidden border border-gray-700" style={{ height: 'calc(100vh - 220px)', minHeight: '500px' }}>
      {/* Title bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>
          <span className="ml-3 text-xs text-gray-400 font-mono">{site.name} — File Editor</span>
        </div>
        <div className="flex items-center gap-3">
          {error && <span className="text-xs text-red-400">{error}</span>}
          {status && <span className="text-xs text-emerald-400">{status}</span>}
          <label className="text-xs text-gray-400 hover:text-white cursor-pointer flex items-center gap-1">
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
            {uploading ? 'Uploading...' : 'Upload'}
            <input type="file" className="hidden" onChange={handleUpload} />
          </label>
        </div>
      </div>

      <div className="flex" style={{ height: 'calc(100% - 64px)' }}>
        {/* Explorer sidebar */}
        <div className="w-56 bg-gray-800 border-r border-gray-700 flex flex-col flex-shrink-0">
          <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center justify-between">
            <span>Explorer</span>
            <button type="button" onClick={() => setShowNewFile(true)} className="text-gray-400 hover:text-white" title="New file">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
            </button>
          </div>
          {showNewFile && (
            <div className="px-2 pb-2">
              <input autoFocus value={newFilePath} onChange={(e) => setNewFilePath(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') createFile(); if (e.key === 'Escape') { setShowNewFile(false); setNewFilePath(''); } }} onBlur={() => { if (!newFilePath.trim()) setShowNewFile(false); }} className="w-full bg-gray-700 text-white text-xs px-2 py-1 rounded border border-gray-600 focus:outline-none focus:border-indigo-500" placeholder="filename.html" />
            </div>
          )}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <p className="px-3 py-2 text-xs text-gray-500">Loading...</p>
            ) : files.length === 0 ? (
              <p className="px-3 py-2 text-xs text-gray-500">No files yet</p>
            ) : (
              files.map((f) => {
                const ext = getExt(f.path);
                const isActive = selectedPath === f.path;
                return (
                  <button key={f.path} type="button" onClick={() => setSelectedPath(f.path)} className={`group flex items-center justify-between w-full px-3 py-1.5 text-xs text-left ${isActive ? 'bg-gray-700/80 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-700/40'}`}>
                    <div className="flex items-center gap-2 truncate">
                      <span className={EXT_COLORS[ext] || 'text-gray-400'}>{EXT_ICONS[ext] || '▫'}</span>
                      <span className="truncate">{f.path}</span>
                    </div>
                    <span className="text-[10px] text-gray-600 ml-2 flex-shrink-0">{f.size}B</span>
                  </button>
                );
              })
            )}
          </div>
          {/* Storage meter */}
          <div className="px-3 py-2 border-t border-gray-700">
            <div className="flex items-center justify-between text-[10px] text-gray-500 mb-1">
              <span>Storage</span>
              <span>{storageMB} MB</span>
            </div>
            <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${Math.min((totalSize / (10 * 1024 * 1024)) * 100, 100)}%` }} />
            </div>
          </div>
        </div>

        {/* Main editor area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Tabs */}
          <div className="flex bg-gray-800 border-b border-gray-700 overflow-x-auto flex-shrink-0">
            {openTabs.map((tab) => (
              <div key={tab} className={`flex items-center gap-1 px-3 py-2 text-xs font-mono border-r border-gray-700 cursor-pointer group ${selectedPath === tab ? 'bg-gray-900 text-white border-b-2 border-b-indigo-500' : 'text-gray-400 hover:text-white'}`} onClick={() => setSelectedPath(tab)}>
                <span className={EXT_COLORS[getExt(tab)] || 'text-gray-400'}>{EXT_ICONS[getExt(tab)] || '▫'}</span>
                <span className="truncate max-w-[120px]">{tab}</span>
                <button type="button" onClick={(e) => { e.stopPropagation(); closeTab(tab); }} className="ml-1 opacity-0 group-hover:opacity-100 hover:text-red-400">×</button>
              </div>
            ))}
          </div>

          {/* Editor content */}
          {!selectedPath ? (
            <div className="flex-1 flex items-center justify-center text-gray-600">
              <div className="text-center">
                <svg className="w-16 h-16 mx-auto mb-4 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
                <p className="text-sm">Select a file to edit</p>
                <p className="text-xs mt-1 text-gray-700">or create a new one from the explorer</p>
              </div>
            </div>
          ) : isEditable ? (
            <div className="flex-1 flex overflow-hidden">
              <div className="py-3 px-2 bg-gray-900/50 text-gray-600 font-mono text-xs leading-[1.5rem] select-none text-right min-w-[3rem] overflow-hidden flex-shrink-0">
                {lines.map((_, i) => (<div key={i}>{i + 1}</div>))}
              </div>
              <textarea value={content} onChange={(e) => setContent(e.target.value)} className="flex-1 bg-gray-900 text-gray-100 font-mono text-xs leading-[1.5rem] p-3 resize-none focus:outline-none" spellCheck={false} />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-gray-500">
              <div className="text-center">
                <svg className="w-12 h-12 mx-auto mb-3 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                <p className="text-sm font-medium">{selectedPath}</p>
                <p className="text-xs mt-1 text-gray-600">Binary file — not editable in browser</p>
              </div>
            </div>
          )}

          {/* Status bar */}
          <div className="flex items-center justify-between px-4 py-1 bg-indigo-600 text-white text-xs flex-shrink-0">
            <div className="flex items-center gap-4">
              {selectedPath && (
                <>
                  <span>{selectedPath}</span>
                  {isModified && <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-300" />Modified</span>}
                </>
              )}
            </div>
            <div className="flex items-center gap-4">
              {isEditable && <span>{lines.length} lines</span>}
              <span>{files.length} files</span>
              {selectedPath && <span className="font-mono">{getExt(selectedPath).toUpperCase()}</span>}
              <div className="flex items-center gap-2">
                {isEditable && (
                  <button type="button" onClick={saveFile} disabled={saving || !isModified} className="hover:text-indigo-200 disabled:opacity-50 flex items-center gap-1">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" /></svg>
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                )}
                {selectedPath && !confirmDelete && (
                  <button type="button" onClick={() => setConfirmDelete(true)} className="hover:text-red-300 flex items-center gap-1">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    Delete
                  </button>
                )}
                {confirmDelete && (
                  <>
                    <span className="text-red-300">Delete?</span>
                    <button type="button" onClick={deleteFile} className="text-red-300 hover:text-red-100 font-medium">Yes</button>
                    <button type="button" onClick={() => setConfirmDelete(false)} className="hover:text-indigo-200">No</button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
