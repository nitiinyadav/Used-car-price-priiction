'use client';

import { useEffect, useMemo, useState } from 'react';

export default function SiteFilesClient({ site }) {
  const [files, setFiles] = useState([]);
  const [selectedPath, setSelectedPath] = useState('');
  const [content, setContent] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [newFilePath, setNewFilePath] = useState('index.html');
  const [uploading, setUploading] = useState(false);

  const selectedFile = useMemo(
    () => files.find((file) => file.path === selectedPath),
    [files, selectedPath]
  );

  useEffect(() => {
    loadFiles();
  }, []);

  useEffect(() => {
    if (selectedPath) {
      loadContent(selectedPath);
    } else {
      setContent('');
    }
  }, [selectedPath]);

  async function loadFiles() {
    setLoading(true);
    setError('');

    try {
      const res = await fetch(`/api/sites/${site.id}/files`);
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to load files.');
        return;
      }

      setFiles(data.files || []);
      if (!selectedPath && data.files?.length) {
        const firstEditable = data.files.find((file) =>
          /\.(html|css|js|json|txt|md|svg)$/i.test(file.path)
        );
        setSelectedPath(firstEditable?.path || data.files[0].path);
      }
    } catch {
      setError('Failed to load files.');
    } finally {
      setLoading(false);
    }
  }

  async function loadContent(filePath) {
    if (!/\.(html|css|js|json|txt|md|svg)$/i.test(filePath)) {
      setContent('');
      return;
    }

    try {
      const res = await fetch(
        `/api/sites/${site.id}/files?path=${encodeURIComponent(filePath)}`
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to load file content.');
        return;
      }
      setContent(data.content || '');
    } catch {
      setError('Failed to load file content.');
    }
  }

  async function saveCurrentFile() {
    if (!selectedPath) return;

    setSaving(true);
    setStatus('');
    setError('');

    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedPath, content }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to save file.');
        return;
      }

      setStatus(data.message || 'Saved.');
      await loadFiles();
    } catch {
      setError('Failed to save file.');
    } finally {
      setSaving(false);
    }
  }

  async function createFile() {
    if (!newFilePath.trim()) return;

    setStatus('');
    setError('');

    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: newFilePath.trim(), content: '' }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to create file.');
        return;
      }

      setStatus(data.message || 'File created.');
      setSelectedPath(newFilePath.trim());
      await loadFiles();
    } catch {
      setError('Failed to create file.');
    }
  }

  async function deleteCurrentFile() {
    if (!selectedPath) return;

    setStatus('');
    setError('');

    try {
      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedPath }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to delete file.');
        return;
      }

      setStatus(data.message || 'File deleted.');
      setSelectedPath('');
      setContent('');
      await loadFiles();
    } catch {
      setError('Failed to delete file.');
    }
  }

  async function handleUpload(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setStatus('');
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch(`/api/sites/${site.id}/files`, {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to upload file.');
        return;
      }

      setStatus(data.message || 'Upload completed.');
      await loadFiles();
    } catch {
      setError('Failed to upload file.');
    } finally {
      setUploading(false);
      event.target.value = '';
    }
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[0.8fr_1.4fr]">
      <div className="rounded-xl border border-gray-200 bg-white p-5">
        <h2 className="text-lg font-semibold text-gray-900">File Browser</h2>
        <p className="mt-1 text-sm text-gray-500">
          Pick the file you want to maintain. Content editing is available for
          HTML, CSS, JS, JSON, TXT, MD, and SVG files.
        </p>

        <div className="mt-4 space-y-3">
          <div className="flex gap-2">
            <input
              value={newFilePath}
              onChange={(e) => setNewFilePath(e.target.value)}
              className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm"
              placeholder="about.html"
            />
            <button
              type="button"
              onClick={createFile}
              className="rounded-lg bg-gray-900 px-3 py-2 text-sm font-medium text-white hover:bg-black"
            >
              New File
            </button>
          </div>

          <label className="inline-flex cursor-pointer rounded-lg border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:border-gray-400">
            {uploading ? 'Uploading...' : 'Upload Asset'}
            <input type="file" className="hidden" onChange={handleUpload} />
          </label>
        </div>

        <div className="mt-5 max-h-[540px] overflow-y-auto rounded-lg border border-gray-200">
          {loading ? (
            <p className="p-4 text-sm text-gray-500">Loading files...</p>
          ) : files.length === 0 ? (
            <p className="p-4 text-sm text-gray-500">No files deployed yet.</p>
          ) : (
            files.map((file) => (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedPath(file.path)}
                className={`flex w-full items-center justify-between border-b border-gray-100 px-4 py-3 text-left text-sm ${
                  selectedPath === file.path ? 'bg-gray-900 text-white' : 'hover:bg-gray-50'
                }`}
              >
                <span className="truncate">{file.path}</span>
                <span
                  className={`ml-3 text-xs ${
                    selectedPath === file.path ? 'text-gray-300' : 'text-gray-400'
                  }`}
                >
                  {file.size} B
                </span>
              </button>
            ))
          )}
        </div>
      </div>

      <div className="rounded-xl border border-gray-200 bg-white p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">
              {selectedPath || 'Select a file'}
            </h2>
            <p className="mt-1 text-sm text-gray-500">
              Keep everyday lead management separate from monthly site maintenance.
            </p>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={saveCurrentFile}
              disabled={!selectedPath || saving || !/\.(html|css|js|json|txt|md|svg)$/i.test(selectedPath)}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Save'}
            </button>
            <button
              type="button"
              onClick={deleteCurrentFile}
              disabled={!selectedPath}
              className="rounded-lg border border-red-200 px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 disabled:opacity-50"
            >
              Delete
            </button>
          </div>
        </div>

        {error && (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}
        {status && (
          <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            {status}
          </div>
        )}

        {!selectedPath ? (
          <div className="mt-6 rounded-lg border border-dashed border-gray-300 p-10 text-center text-sm text-gray-500">
            Select a file from the browser to edit it.
          </div>
        ) : /\.(html|css|js|json|txt|md|svg)$/i.test(selectedPath) ? (
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="mt-6 min-h-[520px] w-full rounded-lg border border-gray-300 bg-gray-950 p-4 font-mono text-sm text-green-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        ) : (
          <div className="mt-6 rounded-lg border border-gray-200 bg-gray-50 p-8 text-sm text-gray-600">
            This file type is stored in StaticDrop and can be replaced with the
            upload button, but it is not editable as text in the browser.
            {selectedFile && (
              <div className="mt-3 font-medium text-gray-900">
                Selected: {selectedFile.path}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
