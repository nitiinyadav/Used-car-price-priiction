'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import FileUpload from '@/components/FileUpload';
import { parseAllowedOrigins } from '@/lib/site-security';

export default function SiteDetailClient({ site }) {
  const router = useRouter();
  const [siteName, setSiteName] = useState(site.name);
  const [customDomain, setCustomDomain] = useState(site.customDomain || '');
  const [allowedOrigins, setAllowedOrigins] = useState(
    parseAllowedOrigins(site.allowedOrigins).join('\n')
  );
  const [honeypotField, setHoneypotField] = useState(site.honeypotField || 'company');
  const [submissionRateLimit, setSubmissionRateLimit] = useState(
    site.submissionRateLimit || 10
  );
  const [isActive, setIsActive] = useState(site.isActive);
  const [savingSettings, setSavingSettings] = useState(false);
  const [redeployFile, setRedeployFile] = useState(null);
  const [redeploying, setRedeploying] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function handleSaveSettings() {
    setError('');
    setMessage('');
    setSavingSettings(true);

    try {
      const res = await fetch(`/api/sites/${site.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: siteName,
          customDomain,
          allowedOrigins,
          honeypotField,
          submissionRateLimit,
          isActive,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Failed to save site settings');
        return;
      }

      setMessage('Site settings updated successfully.');
      setCustomDomain(data.site.customDomain || '');
      setAllowedOrigins(parseAllowedOrigins(data.site.allowedOrigins).join('\n'));
      setHoneypotField(data.site.honeypotField || 'company');
      setSubmissionRateLimit(data.site.submissionRateLimit || 10);
      setIsActive(data.site.isActive);
      setSiteName(data.site.name);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setSavingSettings(false);
    }
  }

  async function handleRedeploy() {
    if (!redeployFile) return;
    setError('');
    setMessage('');
    setRedeploying(true);

    try {
      const formData = new FormData();
      formData.append('file', redeployFile);

      const res = await fetch(`/api/sites/${site.id}/redeploy`, {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Redeploy failed');
        return;
      }

      setMessage('Site redeployed successfully!');
      setRedeployFile(null);
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setRedeploying(false);
    }
  }

  async function handleDelete() {
    setError('');
    setDeleting(true);

    try {
      const res = await fetch(`/api/sites/${site.id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Delete failed');
        return;
      }

      router.push('/dashboard/sites');
      router.refresh();
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-6">
      {message && (
        <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
          {message}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Site Settings
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Update the site name, connect a custom domain, control form security,
          or temporarily disable the deployment.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Site Name
            </label>
            <input
              type="text"
              value={siteName}
              onChange={(e) => setSiteName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Custom Domain
            </label>
            <input
              type="text"
              value={customDomain}
              onChange={(e) => setCustomDomain(e.target.value)}
              placeholder="www.example.com"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
            <p className="mt-1 text-xs text-gray-500">
              Paid plans can point a custom hostname like{' '}
              <code className="bg-gray-100 px-1 py-0.5 rounded">
                www.example.com
              </code>{' '}
              to this site. You can clear this field to disconnect the domain.
            </p>
          </div>

          <label className="flex items-center justify-between rounded-lg border border-gray-200 px-4 py-3">
            <div>
              <p className="text-sm font-medium text-gray-900">Site status</p>
              <p className="text-xs text-gray-500">
                Inactive sites keep their files but return a not found page.
              </p>
            </div>
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
          </label>

          <div className="rounded-xl border border-gray-200 p-4">
            <h4 className="text-sm font-semibold text-gray-900">
              Form Protection
            </h4>
            <div className="mt-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Honeypot Field Name
                </label>
                <input
                  type="text"
                  value={honeypotField}
                  onChange={(e) => setHoneypotField(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Add a hidden input with this name to your HTML form. Bots that
                  fill it will be silently blocked.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Allowed Extra Origins
                </label>
                <textarea
                  rows={4}
                  value={allowedOrigins}
                  onChange={(e) => setAllowedOrigins(e.target.value)}
                  placeholder="www.example.com&#10;landing.example.com"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <p className="mt-1 text-xs text-gray-500">
                  One hostname per line. Only requests from the site domain or
                  these extra origins can submit forms.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rate Limit Per IP
                </label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={submissionRateLimit}
                  onChange={(e) => setSubmissionRateLimit(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Maximum submissions from one IP in a 10 minute window.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSaveSettings}
              disabled={savingSettings}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
            >
              {savingSettings ? 'Saving...' : 'Save Settings'}
            </button>
            <Link
              href="/pricing"
              className="text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              View plans
            </Link>
          </div>
        </div>
      </div>

      {/* Redeploy */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Update Website
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Upload a new ZIP file to replace the current website files.
        </p>
        <FileUpload onFileSelect={setRedeployFile} />
        {redeployFile && (
          <button
            onClick={handleRedeploy}
            disabled={redeploying}
            className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50"
          >
            {redeploying ? 'Redeploying...' : 'Redeploy Site'}
          </button>
        )}
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-xl border border-red-200 p-6">
        <h3 className="text-lg font-semibold text-red-600 mb-2">
          Danger Zone
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          Permanently delete this site and all its form submissions. This action
          cannot be undone.
        </p>

        {!showDelete ? (
          <button
            onClick={() => setShowDelete(true)}
            className="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors border border-red-200"
          >
            Delete Site
          </button>
        ) : (
          <div className="flex items-center space-x-3">
            <button
              onClick={handleDelete}
              disabled={deleting}
              className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              {deleting ? 'Deleting...' : 'Yes, Delete Permanently'}
            </button>
            <button
              onClick={() => setShowDelete(false)}
              className="text-gray-500 hover:text-gray-700 px-4 py-2 text-sm"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
