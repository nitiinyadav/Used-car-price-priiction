import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderId, razorpayPaymentId, razorpaySignature } = await request.json();

    if (!orderId || !razorpayPaymentId || !razorpaySignature) {
      return NextResponse.json(
        { error: 'Missing payment verification fields.' },
        { status: 400 }
      );
    }

    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret) {
      return NextResponse.json(
        { error: 'Razorpay secret is not configured.' },
        { status: 500 }
      );
    }

    const payment = await prisma.payment.findFirst({
      where: {
        userId: session.user.id,
        providerOrderId: orderId,
      },
    });
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { currentPeriodEndsAt: true },
    });

    if (!payment) {
      return NextResponse.json(
        { error: 'Pending checkout not found.' },
        { status: 404 }
      );
    }

    if (payment.status === 'completed') {
      return NextResponse.json({
        success: true,
        message: 'Payment already verified.',
        plan: payment.planSlug,
        expiresAt: payment.expiresAt.toISOString(),
      });
    }

    const generatedSignature = crypto
      .createHmac('sha256', razorpayKeySecret)
      .update(`${orderId}|${razorpayPaymentId}`)
      .digest('hex');

    if (generatedSignature !== razorpaySignature) {
      await prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: 'failed',
          providerPaymentId: razorpayPaymentId,
          providerSignature: razorpaySignature,
        },
      });

      return NextResponse.json(
        { error: 'Payment signature verification failed.' },
        { status: 400 }
      );
    }

    const now = new Date();
    const startsAt =
      user?.currentPeriodEndsAt && new Date(user.currentPeriodEndsAt) > now
        ? new Date(user.currentPeriodEndsAt)
        : now;
    const expiresAt = new Date(startsAt);
    if (payment.billingPeriod === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    }

    await prisma.$transaction([
      prisma.payment.update({
        where: { id: payment.id },
        data: {
          status: 'completed',
          startsAt,
          expiresAt,
          providerPaymentId: razorpayPaymentId,
          providerSignature: razorpaySignature,
          transactionId: razorpayPaymentId,
        },
      }),
      prisma.user.update({
        where: { id: session.user.id },
        data: {
          plan: payment.planSlug,
          subscriptionStatus: 'active',
          billingPeriod: payment.billingPeriod,
          billingCurrency: payment.currency,
          currentPeriodEndsAt: expiresAt,
          trialEndsAt: null,
        },
      }),
    ]);

    return NextResponse.json({
      success: true,
      message: 'Payment verified and subscription activated.',
      plan: payment.planSlug,
      billingPeriod: payment.billingPeriod,
      billingCurrency: payment.currency,
      expiresAt: expiresAt.toISOString(),
    });
  } catch (error) {
    console.error('Payment verification error:', error);
    return NextResponse.json(
      { error: 'Failed to verify payment' },
      { status: 500 }
    );
  }
}
