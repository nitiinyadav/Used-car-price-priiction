import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { getBillingSnapshot } from '@/lib/billing';
import { getPlanAmount } from '@/lib/currency';

const RAZORPAY_ORDERS_URL = 'https://api.razorpay.com/v1/orders';

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { planSlug, billingPeriod, currency } = await request.json();

    if (
      !planSlug ||
      !['monthly', 'yearly'].includes(billingPeriod) ||
      !['USD', 'INR'].includes(currency)
    ) {
      return NextResponse.json(
        { error: 'Invalid plan, billing period, or currency' },
        { status: 400 }
      );
    }

    if (planSlug === 'free') {
      return NextResponse.json(
        {
          error:
            'Free access is only available during the onboarding trial. Paid checkout is only for Starter, Pro, or Enterprise.',
        },
        { status: 400 }
      );
    }

    const [plan, billing] = await Promise.all([
      prisma.plan.findUnique({ where: { slug: planSlug } }),
      getBillingSnapshot(session.user.id),
    ]);

    if (!plan || !plan.isActive) {
      return NextResponse.json(
        { error: 'Plan not found or inactive' },
        { status: 404 }
      );
    }

    if (!billing) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const renewalWindowClosed =
      billing.plan !== 'free' &&
      billing.subscriptionStatus === 'active' &&
      !billing.expiringSoon;

    if (renewalWindowClosed) {
      return NextResponse.json(
        {
          error:
            'Billing changes open when your subscription is close to renewal. Until then, your current plan stays active.',
        },
        { status: 400 }
      );
    }

    const amount = getPlanAmount(plan, currency, billingPeriod);
    if (!amount || amount <= 0) {
      return NextResponse.json(
        { error: 'This plan is not available for the selected currency.' },
        { status: 400 }
      );
    }

    const razorpayKeyId = process.env.RAZORPAY_KEY_ID;
    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;

    if (!razorpayKeyId || !razorpayKeySecret) {
      return NextResponse.json(
        { error: 'Razorpay credentials are not configured.' },
        { status: 500 }
      );
    }

    const receipt = `plan_${session.user.id.slice(-8)}_${Date.now()}`;
    const authHeader = Buffer.from(
      `${razorpayKeyId}:${razorpayKeySecret}`
    ).toString('base64');

    const orderResponse = await fetch(RAZORPAY_ORDERS_URL, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount,
        currency,
        receipt,
        notes: {
          userId: session.user.id,
          planSlug,
          billingPeriod,
        },
      }),
      cache: 'no-store',
    });

    const order = await orderResponse.json();

    if (!orderResponse.ok) {
      return NextResponse.json(
        {
          error:
            order?.error?.description ||
            'Failed to create a Razorpay order for this purchase.',
        },
        { status: 502 }
      );
    }

    const startsAt = new Date();
    const expiresAt = new Date(startsAt);
    if (billingPeriod === 'yearly') {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    } else {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    }

    await prisma.payment.create({
      data: {
        userId: session.user.id,
        planSlug: plan.slug,
        amount,
        currency,
        status: 'pending',
        billingPeriod,
        provider: 'razorpay',
        providerOrderId: order.id,
        startsAt,
        expiresAt,
        notes: JSON.stringify({
          checkoutPhase: billing.plan === 'free' ? 'first_purchase' : 'renewal',
          receipt,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      keyId: razorpayKeyId,
      orderId: order.id,
      amount,
      currency,
      planSlug: plan.slug,
      planName: plan.name,
      billingPeriod,
      description: `${plan.name} plan - ${billingPeriod}`,
    });
  } catch (error) {
    console.error('Checkout error:', error);
    return NextResponse.json(
      { error: 'Failed to start secure checkout' },
      { status: 500 }
    );
  }
}
