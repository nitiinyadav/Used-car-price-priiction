import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

export async function POST() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { emailVerifiedAt: true },
    });

    if (user?.emailVerifiedAt) {
      return NextResponse.json({
        success: true,
        message: 'Your email is already verified.',
      });
    }

    await prisma.emailVerificationToken.deleteMany({
      where: { userId: session.user.id },
    });

    const token = crypto.randomBytes(24).toString('hex');
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    await prisma.emailVerificationToken.create({
      data: {
        userId: session.user.id,
        token,
        expiresAt,
      },
    });

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const verificationUrl = `${appUrl}/verify-email?token=${token}`;

    return NextResponse.json({
      success: true,
      message:
        process.env.NODE_ENV === 'production'
          ? 'Verification email queued.'
          : 'Verification link generated for local testing.',
      verificationUrl:
        process.env.NODE_ENV === 'production' ? undefined : verificationUrl,
    });
  } catch (error) {
    console.error('Request verification error:', error);
    return NextResponse.json(
      { error: 'Failed to create verification link' },
      { status: 500 }
    );
  }
}
