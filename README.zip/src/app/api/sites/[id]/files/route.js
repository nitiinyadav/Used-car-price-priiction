import path from 'path';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import {
  deleteSiteFile,
  getSiteFileList,
  readSiteTextFile,
  saveUploadedFile,
  writeSiteFile,
} from '@/lib/storage';
import { getWorkspaceContext, hasPermission } from '@/lib/workspace';

const EDITABLE_EXTENSIONS = new Set([
  '.html',
  '.css',
  '.js',
  '.json',
  '.txt',
  '.md',
  '.svg',
]);

export async function GET(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
      select: { id: true },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const filePath = request.nextUrl.searchParams.get('path');

    if (!filePath) {
      return NextResponse.json({
        files: getSiteFileList(site.id),
      });
    }

    const extension = path.extname(filePath).toLowerCase();
    if (!EDITABLE_EXTENSIONS.has(extension)) {
      return NextResponse.json(
        { error: 'This file type is not editable in the browser.' },
        { status: 400 }
      );
    }

    const content = readSiteTextFile(site.id, filePath);
    if (content === null) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }

    return NextResponse.json({
      path: filePath,
      content,
    });
  } catch (error) {
    console.error('File GET error:', error);
    return NextResponse.json(
      { error: 'Failed to load files' },
      { status: 500 }
    );
  }
}

export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'edit_files')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
      select: { id: true },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const contentType = request.headers.get('content-type') || '';

    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData();
      const file = formData.get('file');
      const folder = String(formData.get('folder') || '').trim();

      if (!file || typeof file === 'string') {
        return NextResponse.json({ error: 'Missing file upload' }, { status: 400 });
      }

      const buffer = Buffer.from(await file.arrayBuffer());
      const filePath = folder ? `${folder}/${file.name}` : file.name;
      saveUploadedFile(site.id, filePath, buffer);

      return NextResponse.json({
        success: true,
        message: 'File uploaded successfully.',
      });
    }

    const { filePath, content = '' } = await request.json();
    if (!filePath) {
      return NextResponse.json({ error: 'File path is required.' }, { status: 400 });
    }

    writeSiteFile(site.id, filePath, content);
    return NextResponse.json({
      success: true,
      message: 'File created successfully.',
    });
  } catch (error) {
    console.error('File POST error:', error);
    return NextResponse.json(
      { error: 'Failed to create file' },
      { status: 500 }
    );
  }
}

export async function PUT(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'edit_files')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
      select: { id: true },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const { filePath, content } = await request.json();
    if (!filePath) {
      return NextResponse.json({ error: 'File path is required.' }, { status: 400 });
    }

    writeSiteFile(site.id, filePath, content || '');
    return NextResponse.json({
      success: true,
      message: 'File saved successfully.',
    });
  } catch (error) {
    console.error('File PUT error:', error);
    return NextResponse.json(
      { error: 'Failed to save file' },
      { status: 500 }
    );
  }
}

export async function DELETE(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const workspace = await getWorkspaceContext(session.user.id);
    if (!hasPermission(workspace, 'edit_files')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const site = await prisma.site.findFirst({
      where: {
        id: params.id,
        userId: workspace?.workspaceOwnerId || session.user.id,
      },
      select: { id: true },
    });

    if (!site) {
      return NextResponse.json({ error: 'Site not found' }, { status: 404 });
    }

    const { filePath } = await request.json();
    if (!filePath) {
      return NextResponse.json({ error: 'File path is required.' }, { status: 400 });
    }

    const removed = deleteSiteFile(site.id, filePath);
    return NextResponse.json({
      success: removed,
      message: removed ? 'File deleted successfully.' : 'File not found.',
    });
  } catch (error) {
    console.error('File DELETE error:', error);
    return NextResponse.json(
      { error: 'Failed to delete file' },
      { status: 500 }
    );
  }
}
