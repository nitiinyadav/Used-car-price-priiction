import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getUserLimits } from '@/lib/plans';
import { checkRateLimit } from '@/lib/rate-limit';
import {
  extractRequestHost,
  getAllowedSiteHosts,
  isAccessSuspended,
} from '@/lib/site-security';

// Handle CORS preflight
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400',
    },
  });
}

// POST /api/forms/[apiKey] - Submit form data
export async function POST(request, { params }) {
  let corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  try {
    const { apiKey } = params;
    let redirectUrl = null;
    let formName = 'default';

    // Find the site by API key
    const site = await prisma.site.findUnique({
      where: { apiKey },
      include: {
        user: {
          select: {
            id: true,
            plan: true,
            role: true,
            trialEndsAt: true,
            currentPeriodEndsAt: true,
          },
        },
      },
    });

    const requestOrigin = request.headers.get('origin');
    const requestHost = extractRequestHost(request);
    const allowedHosts = site ? getAllowedSiteHosts(site) : [];
    corsHeaders = {
      'Access-Control-Allow-Origin':
        requestOrigin && requestHost && allowedHosts.includes(requestHost)
          ? requestOrigin
          : '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (!site) {
      return NextResponse.json(
        { error: 'Invalid API key' },
        { status: 404, headers: corsHeaders }
      );
    }

    if (!site.isActive) {
      return NextResponse.json(
        { error: 'This site is currently inactive' },
        { status: 403, headers: corsHeaders }
      );
    }

    if (isAccessSuspended(site.user)) {
      return NextResponse.json(
        {
          error:
            'This site is suspended because the owner trial or subscription is no longer active. Renew the subscription to resume form collection.',
        },
        { status: 402, headers: corsHeaders }
      );
    }

    if (!requestHost || !allowedHosts.includes(requestHost)) {
      return NextResponse.json(
        {
          error:
            'Form submission blocked because the request origin is not allowed for this site.',
        },
        { status: 403, headers: corsHeaders }
      );
    }

    // Check submission limit based on user's plan
    const limits = await getUserLimits(site.user.id);
    const submissionCount = await prisma.formSubmission.count({
      where: { siteId: site.id },
    });
    if (submissionCount >= limits.maxSubmissions) {
      return NextResponse.json(
        { error: 'Submission limit reached for this site. Please upgrade your plan.' },
        { status: 429, headers: corsHeaders }
      );
    }

    // Parse form data - support both JSON and form-encoded
    let formData = {};
    const contentType = request.headers.get('content-type') || '';

    if (contentType.includes('application/json')) {
      formData = await request.json();
    } else if (
      contentType.includes('application/x-www-form-urlencoded') ||
      contentType.includes('multipart/form-data')
    ) {
      const data = await request.formData();
      for (const [key, value] of data.entries()) {
        if (key === site.honeypotField && String(value || '').trim()) {
          return NextResponse.json(
            { success: true, message: 'Form submitted successfully' },
            { status: 202, headers: corsHeaders }
          );
        }

        if (key === '_redirect') {
          redirectUrl = String(value);
          continue;
        }

        if (key === '_formName') {
          formName = String(value) || 'default';
          continue;
        }

        // Skip any other reserved/internal fields
        if (key.startsWith('_')) continue;
        formData[key] = value;
      }
    } else {
      // Try to parse as JSON anyway
      try {
        formData = await request.json();
      } catch {
        return NextResponse.json(
          { error: 'Unsupported content type' },
          { status: 400, headers: corsHeaders }
        );
      }
    }

    // Handle special fields from JSON submissions
    if (formData._redirect) {
      redirectUrl = formData._redirect;
      delete formData._redirect;
    }
    if (formData._formName) {
      formName = formData._formName;
      delete formData._formName;
    }

    if (site.honeypotField && formData[site.honeypotField]) {
      return NextResponse.json(
        { success: true, message: 'Form submitted successfully' },
        { status: 202, headers: corsHeaders }
      );
    }

    // Remove any empty or null values
    const cleanData = {};
    for (const [key, value] of Object.entries(formData)) {
      if (key === site.honeypotField) continue;
      if (value !== null && value !== undefined && value !== '') {
        cleanData[key] = String(value);
      }
    }

    if (Object.keys(cleanData).length === 0) {
      return NextResponse.json(
        { error: 'No form data provided' },
        { status: 400, headers: corsHeaders }
      );
    }

    // Get client info
    const ipAddress =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      'unknown';
    const userAgent = request.headers.get('user-agent') || null;
    const rateAllowed = checkRateLimit(
      `${site.id}:${ipAddress}`,
      site.submissionRateLimit || 10,
      10 * 60 * 1000
    );

    if (!rateAllowed) {
      return NextResponse.json(
        {
          error:
            'Too many submissions from this IP. Please wait a few minutes and try again.',
        },
        { status: 429, headers: corsHeaders }
      );
    }

    // Store submission
    const submission = await prisma.formSubmission.create({
      data: {
        formName,
        data: JSON.stringify(cleanData),
        ipAddress,
        userAgent,
        siteId: site.id,
      },
    });

    // For form-encoded submissions, check Accept header or redirect
    const acceptHeader = request.headers.get('accept') || '';
    const isAjax =
      acceptHeader.includes('application/json') ||
      request.headers.get('x-requested-with') === 'XMLHttpRequest' ||
      contentType.includes('application/json');

    if (isAjax) {
      return NextResponse.json(
        {
          success: true,
          message: 'Form submitted successfully',
          id: submission.id,
        },
        { status: 201, headers: corsHeaders }
      );
    }

    // For regular form submissions, redirect or show success page
    if (redirectUrl) {
      // Only allow http/https redirects to prevent open redirect
      try {
        const url = new URL(redirectUrl);
        if (url.protocol === 'http:' || url.protocol === 'https:') {
          return NextResponse.redirect(redirectUrl, {
            status: 303,
            headers: corsHeaders,
          });
        }
      } catch {
        // Invalid URL, fall through to success page
      }
    }

    // Return a simple success page
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Form Submitted</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; background: #f9fafb; }
    .card { background: white; border-radius: 12px; padding: 48px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); max-width: 400px; }
    .icon { width: 64px; height: 64px; background: #ecfdf5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; }
    .icon svg { width: 32px; height: 32px; color: #10b981; }
    h1 { font-size: 24px; color: #111827; margin: 0 0 8px; }
    p { color: #6b7280; margin: 0; }
    a { color: #4f46e5; text-decoration: none; display: inline-block; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
      </svg>
    </div>
    <h1>Thank You!</h1>
    <p>Your form has been submitted successfully.</p>
    <a href="javascript:history.back()">Go Back</a>
  </div>
</body>
</html>`;

    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html',
        ...corsHeaders,
      },
    });
  } catch (error) {
    console.error('Form submission error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500, headers: corsHeaders }
    );
  }
}
