import { NextResponse } from 'next/server';
import { getLocalWildcardHost, getRootHost, stripPort } from '@/lib/utils';

export function middleware(request) {
  const hostname = request.headers.get('host') || '';
  const hostnameWithoutPort = stripPort(hostname);
  const rootDomainWithoutPort = getRootHost();
  const localWildcardHost = getLocalWildcardHost();

  const { pathname } = request.nextUrl;

  // Skip internal Next.js routes, API routes, and app routes
  if (
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/api/') ||
    pathname.startsWith('/login') ||
    pathname.startsWith('/register') ||
    pathname.startsWith('/dashboard') ||
    pathname.startsWith('/admin') ||
    pathname.startsWith('/pricing') ||
    pathname.startsWith('/site/') ||
    pathname === '/favicon.ico'
  ) {
    return NextResponse.next();
  }

  const isRootDomainRequest =
    hostnameWithoutPort === rootDomainWithoutPort ||
    hostnameWithoutPort === `www.${rootDomainWithoutPort}`;

  if (!isRootDomainRequest) {
    const candidateSuffixes = [
      `.${rootDomainWithoutPort}`,
      `.${localWildcardHost}`,
    ].filter((suffix, index, all) => all.indexOf(suffix) === index);

    for (const subdomainSuffix of candidateSuffixes) {
      if (!hostnameWithoutPort.endsWith(subdomainSuffix)) {
        continue;
      }

      const subdomain = hostnameWithoutPort.slice(0, -subdomainSuffix.length);

      if (subdomain) {
        const url = request.nextUrl.clone();
        url.pathname = `/api/serve/${subdomain}${
          pathname === '/' ? '/' : pathname
        }`;
        return NextResponse.rewrite(url);
      }
    }

    // Otherwise treat the hostname as a connected custom domain.
    const url = request.nextUrl.clone();
    url.pathname = `/api/serve/_custom${pathname === '/' ? '/' : pathname}`;
    url.searchParams.set('domain', hostnameWithoutPort);
    return NextResponse.rewrite(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
