const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('password123', 12);
  const adminPassword = await bcrypt.hash('admin@321', 12);
  const trialEndsAt = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);

  // Create super admin
  const admin = await prisma.user.upsert({
    where: { email: 'admin@staticdrop.com' },
    update: {
      role: 'superadmin',
      plan: 'enterprise',
      phone: '+1 555 0100',
      countryCode: 'US',
      countryName: 'United States',
      emailVerifiedAt: new Date(),
      subscriptionStatus: 'active',
      billingPeriod: 'yearly',
      billingCurrency: 'USD',
      currentPeriodEndsAt: null,
      trialEndsAt: null,
    },
    create: {
      name: 'Super Admin',
      email: 'admin@staticdrop.com',
      password: adminPassword,
      role: 'superadmin',
      plan: 'enterprise',
      phone: '+1 555 0100',
      countryCode: 'US',
      countryName: 'United States',
      emailVerifiedAt: new Date(),
      subscriptionStatus: 'active',
      billingPeriod: 'yearly',
      billingCurrency: 'USD',
      currentPeriodEndsAt: null,
      trialEndsAt: null,
    },
  });

  // Create demo user
  const user = await prisma.user.upsert({
    where: { email: 'demo@staticdrop.com' },
    update: {
      role: 'user',
      plan: 'free',
      phone: '+91 98765 43210',
      countryCode: 'IN',
      countryName: 'India',
      emailVerifiedAt: new Date(),
      subscriptionStatus: 'trial',
      billingPeriod: null,
      billingCurrency: 'INR',
      currentPeriodEndsAt: null,
      trialEndsAt,
    },
    create: {
      name: 'Demo User',
      email: 'demo@staticdrop.com',
      password: hashedPassword,
      role: 'user',
      plan: 'free',
      phone: '+91 98765 43210',
      countryCode: 'IN',
      countryName: 'India',
      emailVerifiedAt: new Date(),
      subscriptionStatus: 'trial',
      billingPeriod: null,
      billingCurrency: 'INR',
      currentPeriodEndsAt: null,
      trialEndsAt,
    },
  });

  // Seed pricing plans
  const plans = [
    {
      name: 'Free',
      slug: 'free',
      priceMonthly: 0,
      priceYearly: 0,
      priceMonthlyInr: 0,
      priceYearlyInr: 0,
      maxSites: 3,
      maxStorageMB: 10,
      maxSubmissions: 1000,
      customDomain: false,
      priority: 0,
      features: JSON.stringify([
        '3 websites',
        '3 day free trial',
        '10 MB per site',
        '1,000 form submissions',
        'Free subdomain',
        'Community support',
      ]),
    },
    {
      name: 'Starter',
      slug: 'starter',
      priceMonthly: 900,
      priceYearly: 9000,
      priceMonthlyInr: 79900,
      priceYearlyInr: 799000,
      maxSites: 10,
      maxStorageMB: 50,
      maxSubmissions: 10000,
      customDomain: true,
      priority: 1,
      features: JSON.stringify([
        '10 websites',
        '50 MB per site',
        '10,000 form submissions',
        'Custom domain',
        'Email support',
        'No branding',
      ]),
    },
    {
      name: 'Pro',
      slug: 'pro',
      priceMonthly: 2900,
      priceYearly: 29000,
      priceMonthlyInr: 199900,
      priceYearlyInr: 1999000,
      maxSites: 50,
      maxStorageMB: 200,
      maxSubmissions: 100000,
      customDomain: true,
      priority: 2,
      features: JSON.stringify([
        '50 websites',
        '200 MB per site',
        '100,000 form submissions',
        'Custom domain + SSL',
        'Priority support',
        'Analytics dashboard',
        'Webhook notifications',
      ]),
    },
    {
      name: 'Enterprise',
      slug: 'enterprise',
      priceMonthly: 9900,
      priceYearly: 99000,
      priceMonthlyInr: 599900,
      priceYearlyInr: 5999000,
      maxSites: 500,
      maxStorageMB: 1000,
      maxSubmissions: 1000000,
      customDomain: true,
      priority: 3,
      features: JSON.stringify([
        'Unlimited websites',
        '1 GB per site',
        '1,000,000 form submissions',
        'Custom domain + SSL',
        'Dedicated support',
        'Full analytics',
        'Webhook + API access',
        'White-label option',
        'Team management',
      ]),
    },
  ];

  for (const plan of plans) {
    await prisma.plan.upsert({
      where: { slug: plan.slug },
      update: plan,
      create: plan,
    });
  }

  console.log('Seed completed!');
  console.log('');
  console.log('Super Admin:');
  console.log('  Email: admin@staticdrop.com');
  console.log('  Password: admin@321');
  console.log('');
  console.log('Demo User:');
  console.log('  Email: demo@staticdrop.com');
  console.log('  Password: password123');
  console.log('');
  console.log('Plans seeded: Free, Starter ($9 or Rs 799), Pro ($29 or Rs 1999), Enterprise ($99 or Rs 5999)');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
