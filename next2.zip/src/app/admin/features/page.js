import prisma from '@/lib/prisma';
import AdminFeatureManager from './AdminFeatureManager';

export const metadata = {
  title: 'Feature Marketplace - Admin - LiveInSec',
};

export default async function AdminFeaturesPage() {
  const now = new Date();
  const features = await prisma.feature.findMany({
    orderBy: { sortOrder: 'asc' },
    include: {
      _count: {
        select: {
          featurepurchase: {
            where: {
              status: 'active',
              OR: [
                { expiresAt: null },
                { expiresAt: { gt: now } },
              ],
            },
          },
          cartitem: true,
        },
      },
    },
  });

  // Get revenue per feature (all-time, regardless of status)
  const revenueByFeature = await prisma.featurepurchase.groupBy({
    by: ['featureId'],
    _sum: { amountPaid: true },
    _count: true,
  });

  const revenueMap = {};
  revenueByFeature.forEach((r) => {
    revenueMap[r.featureId] = {
      totalRevenue: r._sum.amountPaid || 0,
      totalPurchases: r._count,
    };
  });

  const enriched = features.map((f) => ({
    ...f,
    activePurchases: f._count.featurepurchase,
    inCarts: f._count.cartitem,
    revenue: revenueMap[f.id]?.totalRevenue || 0,
    totalPurchases: revenueMap[f.id]?.totalPurchases || 0,
  }));

  return <AdminFeatureManager features={enriched} />;
}
