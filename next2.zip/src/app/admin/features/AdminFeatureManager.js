'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

const EMPTY_FEATURE = {
  slug: '',
  name: '',
  description: '',
  icon: '📦',
  category: 'general',
  type: 'quantity',
  unitLabel: '',
  freeQuota: 0,
  priceUsd: 0,
  priceInr: 0,
  minQty: 1,
  maxQty: 100,
  stepQty: 1,
  durationDays: null,
  isActive: true,
  isFeatured: false,
  sortOrder: 0,
  showInSidebar: false,
  sidebarLabel: '',
  sidebarIcon: '',
  sidebarHref: '',
  highlights: '[]',
};

export default function AdminFeatureManager({ features: initialFeatures }) {
  const router = useRouter();
  const [features, setFeatures] = useState(initialFeatures);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FEATURE);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function startCreate() {
    setEditingId('new');
    setForm(EMPTY_FEATURE);
    setMessage('');
    setError('');
  }

  function startEdit(feature) {
    setEditingId(feature.id);
    setForm({
      slug: feature.slug,
      name: feature.name,
      description: feature.description,
      icon: feature.icon || '📦',
      category: feature.category || 'general',
      type: feature.type,
      unitLabel: feature.unitLabel || '',
      freeQuota: feature.freeQuota,
      priceUsd: feature.priceUsd,
      priceInr: feature.priceInr,
      minQty: feature.minQty,
      maxQty: feature.maxQty,
      stepQty: feature.stepQty,
      durationDays: feature.durationDays,
      isActive: feature.isActive,
      isFeatured: feature.isFeatured,
      sortOrder: feature.sortOrder,
      showInSidebar: feature.showInSidebar,
      sidebarLabel: feature.sidebarLabel || '',
      sidebarIcon: feature.sidebarIcon || '',
      sidebarHref: feature.sidebarHref || '',
      highlights: feature.highlights || '[]',
    });
    setMessage('');
    setError('');
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(EMPTY_FEATURE);
  }

  function updateField(key, value) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  async function seedDefaults() {
    setSeeding(true);
    setMessage('');
    setError('');
    try {
      const res = await fetch('/api/features', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seed: true }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Seeding failed');
        return;
      }
      setMessage(data.message);
      router.refresh();
    } catch {
      setError('Network error during seeding');
    } finally {
      setSeeding(false);
    }
  }

  async function saveFeature() {
    setSaving(true);
    setMessage('');
    setError('');

    try {
      // Parse highlights if it's a string
      let highlights = form.highlights;
      if (typeof highlights === 'string') {
        try {
          highlights = JSON.stringify(JSON.parse(highlights));
        } catch {
          setError('Highlights must be valid JSON array');
          setSaving(false);
          return;
        }
      }

      const payload = {
        ...form,
        highlights,
        freeQuota: parseInt(form.freeQuota) || 0,
        priceUsd: parseInt(form.priceUsd) || 0,
        priceInr: parseInt(form.priceInr) || 0,
        minQty: parseInt(form.minQty) || 1,
        maxQty: parseInt(form.maxQty) || 100,
        stepQty: parseInt(form.stepQty) || 1,
        sortOrder: parseInt(form.sortOrder) || 0,
        durationDays: form.durationDays ? parseInt(form.durationDays) : null,
      };

      let res;
      if (editingId === 'new') {
        res = await fetch('/api/features', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(`/api/features/${editingId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Save failed');
        return;
      }

      setMessage(editingId === 'new' ? 'Feature created!' : 'Feature updated!');
      setEditingId(null);
      setForm(EMPTY_FEATURE);
      router.refresh();
    } catch {
      setError('Network error');
    } finally {
      setSaving(false);
    }
  }

  async function deleteFeature(id) {
    const feature = features.find((f) => f.id === id);
    const purchaseInfo = feature?.activePurchases
      ? `\n\nThis feature has ${feature.activePurchases} active purchase(s) and ${feature.inCarts} cart item(s).`
      : '';
    if (!confirm(`Delete "${feature?.name || 'this feature'}"?${purchaseInfo}\n\nActive purchases will block deletion.`)) return;

    try {
      const res = await fetch(`/api/features/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Delete failed');
        return;
      }
      setMessage('Feature deleted');
      router.refresh();
    } catch {
      setError('Network error');
    }
  }

  async function toggleActive(feature) {
    try {
      const res = await fetch(`/api/features/${feature.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !feature.isActive }),
      });
      if (res.ok) router.refresh();
    } catch {
      setError('Toggle failed');
    }
  }

  return (
    <div>
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Feature Marketplace</h1>
          <p className="mt-1 text-gray-400">
            Manage features, pricing, and availability for the store
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={seedDefaults}
            disabled={seeding}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition-colors"
          >
            {seeding ? 'Seeding...' : '🌱 Seed Defaults'}
          </button>
          <button
            onClick={startCreate}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            + Add Feature
          </button>
        </div>
      </div>

      {message && (
        <div className="mb-4 p-3 bg-green-900/50 border border-green-700 text-green-300 rounded-lg text-sm">
          {message}
        </div>
      )}
      {error && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-700 text-red-300 rounded-lg text-sm">
          {error}
        </div>
      )}

      {/* Feature Editor */}
      {editingId && (
        <div className="mb-8 bg-gray-800 rounded-xl border border-gray-700 p-6">
          <h2 className="text-lg font-semibold text-white mb-4">
            {editingId === 'new' ? 'Create Feature' : 'Edit Feature'}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Basic Info */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Slug (unique key)</label>
              <input
                type="text"
                value={form.slug}
                onChange={(e) => updateField('slug', e.target.value)}
                placeholder="e.g. submissions"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                disabled={editingId !== 'new'}
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="Form Submissions"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Icon (emoji)</label>
              <input
                type="text"
                value={form.icon}
                onChange={(e) => updateField('icon', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Category</label>
              <input
                type="text"
                value={form.category}
                onChange={(e) => updateField('category', e.target.value)}
                placeholder="core"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Type</label>
              <select
                value={form.type}
                onChange={(e) => updateField('type', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="quantity">Quantity (countable units)</option>
                <option value="duration">Duration (time-based)</option>
                <option value="boolean">Boolean (on/off)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Unit Label</label>
              <input
                type="text"
                value={form.unitLabel}
                onChange={(e) => updateField('unitLabel', e.target.value)}
                placeholder="submissions, GB, months"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Pricing */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Free Quota</label>
              <input
                type="number"
                value={form.freeQuota}
                onChange={(e) => updateField('freeQuota', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Price USD (cents/unit)</label>
              <input
                type="number"
                value={form.priceUsd}
                onChange={(e) => updateField('priceUsd', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                = ${(parseInt(form.priceUsd) || 0) / 100} per {form.unitLabel || 'unit'}
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Price INR (paise/unit)</label>
              <input
                type="number"
                value={form.priceInr}
                onChange={(e) => updateField('priceInr', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                = ₹{(parseInt(form.priceInr) || 0) / 100} per {form.unitLabel || 'unit'}
              </p>
            </div>

            {/* Quantity Constraints */}
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Min Quantity</label>
              <input
                type="number"
                value={form.minQty}
                onChange={(e) => updateField('minQty', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Max Quantity</label>
              <input
                type="number"
                value={form.maxQty}
                onChange={(e) => updateField('maxQty', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Step Quantity</label>
              <input
                type="number"
                value={form.stepQty}
                onChange={(e) => updateField('stepQty', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Duration (days per unit, empty = lifetime)</label>
              <input
                type="number"
                value={form.durationDays || ''}
                onChange={(e) => updateField('durationDays', e.target.value || null)}
                placeholder="null = lifetime"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1">Sort Order</label>
              <input
                type="number"
                value={form.sortOrder}
                onChange={(e) => updateField('sortOrder', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Toggles */}
            <div className="flex flex-col gap-3">
              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.isActive}
                  onChange={(e) => updateField('isActive', e.target.checked)}
                  className="rounded bg-gray-700 border-gray-600 text-indigo-600 focus:ring-indigo-500"
                />
                Active (visible in store)
              </label>
              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.isFeatured}
                  onChange={(e) => updateField('isFeatured', e.target.checked)}
                  className="rounded bg-gray-700 border-gray-600 text-indigo-600 focus:ring-indigo-500"
                />
                Featured (highlighted in store)
              </label>
              <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.showInSidebar}
                  onChange={(e) => updateField('showInSidebar', e.target.checked)}
                  className="rounded bg-gray-700 border-gray-600 text-indigo-600 focus:ring-indigo-500"
                />
                Show in user sidebar
              </label>
            </div>

            {/* Sidebar Config */}
            {form.showInSidebar && (
              <>
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Sidebar Label</label>
                  <input
                    type="text"
                    value={form.sidebarLabel}
                    onChange={(e) => updateField('sidebarLabel', e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Sidebar Icon (inbox, chart, etc.)</label>
                  <input
                    type="text"
                    value={form.sidebarIcon}
                    onChange={(e) => updateField('sidebarIcon', e.target.value)}
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-400 mb-1">Sidebar Link (href)</label>
                  <input
                    type="text"
                    value={form.sidebarHref}
                    onChange={(e) => updateField('sidebarHref', e.target.value)}
                    placeholder="/dashboard/submissions"
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </>
            )}

            {/* Description */}
            <div className="md:col-span-2 lg:col-span-3">
              <label className="block text-xs font-medium text-gray-400 mb-1">Description</label>
              <textarea
                value={form.description}
                onChange={(e) => updateField('description', e.target.value)}
                rows={2}
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Highlights */}
            <div className="md:col-span-2 lg:col-span-3">
              <label className="block text-xs font-medium text-gray-400 mb-1">Highlights (JSON array)</label>
              <textarea
                value={form.highlights}
                onChange={(e) => updateField('highlights', e.target.value)}
                rows={3}
                placeholder='["Feature 1", "Feature 2"]'
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="mt-4 flex gap-3">
            <button
              onClick={saveFeature}
              disabled={saving}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition-colors"
            >
              {saving ? 'Saving...' : editingId === 'new' ? 'Create Feature' : 'Save Changes'}
            </button>
            <button
              onClick={cancelEdit}
              className="px-5 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 text-sm font-medium rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Feature List */}
      <div className="grid gap-4">
        {features.length === 0 ? (
          <div className="bg-gray-800 rounded-xl border border-gray-700 p-12 text-center">
            <p className="text-4xl mb-4">🏪</p>
            <h3 className="text-lg font-semibold text-white mb-2">No features yet</h3>
            <p className="text-gray-400 text-sm mb-4">
              Click &quot;Seed Defaults&quot; to create the initial feature set, or add features manually.
            </p>
          </div>
        ) : (
          features.map((feature) => (
            <div
              key={feature.id}
              className={`bg-gray-800 rounded-xl border p-5 ${
                feature.isFeatured ? 'border-indigo-500' : 'border-gray-700'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-2xl">{feature.icon}</span>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{feature.name}</h3>
                      <span className="text-xs text-gray-500 font-mono">{feature.slug}</span>
                    </div>
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                        feature.isActive
                          ? 'bg-green-900/50 text-green-300'
                          : 'bg-gray-700 text-gray-400'
                      }`}
                    >
                      {feature.isActive ? 'Active' : 'Inactive'}
                    </span>
                    {feature.isFeatured && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-indigo-900/50 text-indigo-300">
                        Featured
                      </span>
                    )}
                  </div>

                  <p className="text-sm text-gray-400 mb-3 line-clamp-2">{feature.description}</p>

                  <div className="flex flex-wrap gap-4 text-xs text-gray-400">
                    <span>
                      <strong className="text-gray-300">Type:</strong>{' '}
                      {feature.type === 'quantity' ? '📊 Quantity' : feature.type === 'duration' ? '⏱️ Duration' : '🔘 Boolean'}
                    </span>
                    <span>
                      <strong className="text-gray-300">USD:</strong>{' '}
                      ${(feature.priceUsd / 100).toFixed(2)}/{feature.unitLabel || 'unit'}
                    </span>
                    <span>
                      <strong className="text-gray-300">INR:</strong>{' '}
                      ₹{(feature.priceInr / 100).toFixed(2)}/{feature.unitLabel || 'unit'}
                    </span>
                    <span>
                      <strong className="text-gray-300">Free:</strong>{' '}
                      {feature.freeQuota} {feature.unitLabel || 'units'}
                    </span>
                    {feature.durationDays && (
                      <span>
                        <strong className="text-gray-300">Duration:</strong>{' '}
                        {feature.durationDays} days/unit
                      </span>
                    )}
                    {!feature.durationDays && (
                      <span className="text-green-400">♾️ Lifetime</span>
                    )}
                    <span>
                      <strong className="text-gray-300">Qty:</strong>{' '}
                      {feature.minQty}–{feature.maxQty} (step {feature.stepQty})
                    </span>
                  </div>

                  {/* Stats */}
                  <div className="flex flex-wrap gap-4 mt-3 text-xs">
                    <span className="text-green-400">
                      💰 Revenue: ${(feature.revenue / 100).toFixed(2)}
                    </span>
                    <span className="text-blue-400">
                      🛒 In carts: {feature.inCarts}
                    </span>
                    <span className="text-purple-400">
                      ✅ Active purchases: {feature.activePurchases}
                    </span>
                  </div>
                </div>

                <div className="flex sm:flex-col gap-2">
                  <button
                    onClick={() => startEdit(feature)}
                    className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs font-medium rounded-lg transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => toggleActive(feature)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                      feature.isActive
                        ? 'bg-amber-900/50 hover:bg-amber-900/70 text-amber-300'
                        : 'bg-green-900/50 hover:bg-green-900/70 text-green-300'
                    }`}
                  >
                    {feature.isActive ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    onClick={() => deleteFeature(feature.id)}
                    className="px-3 py-1.5 bg-red-900/50 hover:bg-red-900/70 text-red-300 text-xs font-medium rounded-lg transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
