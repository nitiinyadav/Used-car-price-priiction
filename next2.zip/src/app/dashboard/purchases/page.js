'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

function formatDate(dateStr) {
  if (!dateStr) return 'Never';
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export default function PurchasesPage() {
  const [data, setData] = useState(null);
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/purchases').then((r) => r.json()),
      fetch('/api/feature-overview').then((r) => r.json()),
    ])
      .then(([purchaseData, overviewData]) => {
        setData(purchaseData);
        if (overviewData.overview) setOverview(overviewData.overview);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-48 bg-gray-200 dark:bg-gray-700 rounded" />
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  const grouped = data?.grouped || {};
  const slugs = Object.keys(grouped);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Purchases</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Manage your feature subscriptions and usage
          </p>
        </div>
        <Link
          href="/dashboard/store"
          className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" />
          </svg>
          Buy More Features
        </Link>
      </div>

      {slugs.length === 0 ? (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-12 text-center">
          <p className="text-4xl mb-4">📦</p>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            No purchases yet
          </h3>
          <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">
            Visit the feature store to power up your sites with premium features.
          </p>
          <Link
            href="/dashboard/store"
            className="inline-flex items-center px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            Browse Store
          </Link>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Feature Overview Cards */}
          {overview && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {Object.entries(overview).map(([slug, info]) => (
                <div
                  key={slug}
                  className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">{info.feature?.icon || '📦'}</span>
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {info.feature?.name || slug}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                      {info.remaining}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      / {info.total} {info.feature?.unitLabel || ''}
                    </span>
                  </div>
                  {info.total > 0 && (
                    <div className="mt-2 w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1.5">
                      <div
                        className={`h-1.5 rounded-full transition-all ${
                          info.remaining <= 0 ? 'bg-red-500' :
                          info.used / info.total > 0.8 ? 'bg-amber-500' :
                          'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(100, (info.used / info.total) * 100)}%` }}
                      />
                    </div>
                  )}
                  <div className="mt-1 flex justify-between text-xs text-gray-400">
                    <span>Used: {info.used}</span>
                    <span className={info.hasAccess ? 'text-green-500' : 'text-red-500'}>
                      {info.hasAccess ? '✓ Active' : '✗ No access'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Purchase Details */}
          {slugs.map((slug) => {
            const group = grouped[slug];
            const feature = group.feature;

            return (
              <div
                key={slug}
                className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden"
              >
                <div className="p-5 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{feature.icon}</span>
                      <div>
                        <h3 className="font-semibold text-gray-900 dark:text-white">{feature.name}</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {group.activePurchases.length} active purchase{group.activePurchases.length !== 1 ? 's' : ''}
                          {' · '}{group.totalQuantity} {feature.unitLabel || 'units'} total
                        </p>
                      </div>
                    </div>
                    <Link
                      href="/dashboard/store"
                      className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Buy more
                    </Link>
                  </div>
                </div>

                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {group.activePurchases.map((purchase) => {
                    const remaining = daysUntil(purchase.expiresAt);
                    return (
                      <div key={purchase.id} className="px-5 py-3 flex items-center justify-between">
                        <div>
                          <span className="text-sm text-gray-900 dark:text-white">
                            {purchase.quantity} {feature.unitLabel || 'units'}
                          </span>
                          <span className="text-xs text-gray-400 ml-2">
                            Purchased {formatDate(purchase.createdAt)}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          {purchase.expiresAt ? (
                            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                              remaining <= 0
                                ? 'bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300'
                                : remaining <= 7
                                  ? 'bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300'
                                  : 'bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300'
                            }`}>
                              {remaining <= 0 ? 'Expired' : `${remaining}d left`}
                            </span>
                          ) : (
                            <span className="text-xs px-2 py-1 rounded-full font-medium bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300">
                              ♾️ Lifetime
                            </span>
                          )}
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300">
                            Active
                          </span>
                        </div>
                      </div>
                    );
                  })}

                  {group.expiredPurchases.length > 0 && (
                    <div className="px-5 py-3">
                      <p className="text-xs text-gray-400 mb-2">{group.expiredPurchases.length} expired purchase{group.expiredPurchases.length !== 1 ? 's' : ''}</p>
                      {group.expiredPurchases.map((purchase) => (
                        <div key={purchase.id} className="flex items-center justify-between py-1 opacity-50">
                          <span className="text-xs text-gray-500">
                            {purchase.quantity} {feature.unitLabel || 'units'} — {formatDate(purchase.createdAt)}
                          </span>
                          <span className="text-xs text-red-400">Expired</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
