import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";
import Link from "next/link";
import SubmissionsTable from "@/components/SubmissionsTable";
import { getWorkspaceContext, hasPermission } from "@/lib/workspace";
import { redirect } from "next/navigation";
import { getUserLimits } from "@/lib/plans";
import { getUserFeatureQuota } from "@/lib/feature-access";

export const metadata = {
  title: "Submission Inbox - LiveInSec",
};

export default async function DashboardSubmissionsPage({ searchParams }) {
  const session = await getServerSession(authOptions);
  const workspace = await getWorkspaceContext(session.user.id);

  if (!hasPermission(workspace, "view_submissions")) {
    redirect("/dashboard");
  }

  const limits = await getUserLimits(session.user.id);

  // Check feature-based access first, fall back to plan-based
  let hasSubmissionAccess = true;
  try {
    const quota = await getUserFeatureQuota(session.user.id, 'submissions');
    hasSubmissionAccess = quota.hasAccess;
  } catch (err) {
    // Feature table may not exist yet; fall back to plan limits
    console.error('Feature quota check failed, falling back to plan limits:', err.message);
    hasSubmissionAccess = limits?.maxSubmissions !== 0;
  }

  // Free users without submission access see analytics-only view
  if (!hasSubmissionAccess && session.user.role !== 'superadmin') {
    const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
    const [totalSubmissions, recentCount, sitesWithSubmissions, topSites] = await Promise.all([
      prisma.formSubmission.count({ where: { site: { userId: workspaceOwnerId } } }),
      prisma.formSubmission.count({
        where: { site: { userId: workspaceOwnerId }, createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
      }),
      prisma.site.count({ where: { userId: workspaceOwnerId, formsubmission: { some: {} } } }),
      prisma.site.findMany({
        where: { userId: workspaceOwnerId },
        select: { id: true, name: true, subdomain: true, _count: { select: { formsubmission: true } } },
        orderBy: { formsubmission: { _count: 'desc' } },
        take: 5,
      }),
    ]);
    return (
      <div>
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Submission Analytics</h1>
          <p className="mt-1 text-gray-500">Overview of form submissions across your sites.</p>
        </div>

        <div className="mb-6 grid gap-4 md:grid-cols-3">
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm text-gray-500">Total Submissions</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">{totalSubmissions}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm text-gray-500">Last 7 Days</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
          </div>
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <p className="text-sm text-gray-500">Sites Receiving Leads</p>
            <p className="mt-1 text-2xl font-bold text-gray-900">{sitesWithSubmissions}</p>
          </div>
        </div>

        {topSites.length > 0 && (
          <div className="mb-6 rounded-xl border border-gray-200 bg-white overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h3 className="text-sm font-semibold text-gray-900">Submissions by Site</h3>
            </div>
            <div className="divide-y divide-gray-50">
              {topSites.map(s => (
                <div key={s.id} className="flex items-center justify-between px-5 py-3">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{s.name}</p>
                    <p className="text-xs text-gray-400">{s.subdomain}</p>
                  </div>
                  <span className="text-sm font-semibold text-gray-700">{s._count.formsubmission}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="rounded-2xl border border-gray-200 bg-white p-8 text-center">
          <div className="mx-auto w-14 h-14 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
            <svg className="w-7 h-7 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">Viewing Submission Details Requires a Purchase</h2>
          <p className="text-gray-500 mb-6 max-w-md mx-auto text-sm">
            Buy the Form Submissions feature to read individual form submissions, export data, and receive email notifications for new leads.
          </p>
          <Link href="/dashboard/store" className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 100 4 2 2 0 000-4z" /></svg>
            Buy Submissions
          </Link>
        </div>
      </div>
    );
  }

  const workspaceOwnerId = workspace?.workspaceOwnerId || session.user.id;
  const page = Math.max(1, Number(searchParams?.page || 1));
  const query = String(searchParams?.q || "").trim();
  const pageSize = 12;

  const where = {
    site: { userId: workspaceOwnerId },
    ...(query
      ? {
          OR: [
            { formName: { contains: query } },
            { data: { contains: query } },
            { site: { name: { contains: query } } },
          ],
        }
      : {}),
  };

  const [submissions, total, recentCount, sitesWithSubmissions] =
    await Promise.all([
      prisma.formSubmission.findMany({
        where,
        include: {
          site: { select: { id: true, name: true, subdomain: true } },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      prisma.formSubmission.count({ where }),
      prisma.formSubmission.count({
        where: {
          site: { userId: workspaceOwnerId },
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          },
        },
      }),
      prisma.site.count({
        where: { userId: workspaceOwnerId, formsubmission: { some: {} } },
      }),
    ]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Submission Inbox</h1>
        <p className="mt-1 text-gray-500">
          Review incoming leads across all of your deployed sites.
        </p>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Total Submissions</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Last 7 Days</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">{recentCount}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-5">
          <p className="text-sm text-gray-500">Sites Receiving Leads</p>
          <p className="mt-1 text-2xl font-bold text-gray-900">
            {sitesWithSubmissions}
          </p>
        </div>
      </div>

      <form className="mb-4 rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <input
            type="text"
            name="q"
            defaultValue={query}
            placeholder="Search by site name, form name, or submission content"
            className="flex-1 rounded-lg border border-gray-300 px-3 py-2 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            type="submit"
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
          >
            Search
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-gray-200 bg-white p-6">
        <SubmissionsTable
          submissions={submissions}
          siteName="all-sites"
          totalCount={total}
          page={page}
          totalPages={totalPages}
          basePath="/dashboard/submissions"
          searchQuery={query}
          showSiteColumn
        />
      </div>
    </div>
  );
}
