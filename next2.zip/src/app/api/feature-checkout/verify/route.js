import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';

// POST /api/feature-checkout/verify — Verify Razorpay payment and create purchases
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { orderId, razorpayPaymentId, razorpaySignature } = await request.json();

    if (!orderId || !razorpayPaymentId || !razorpaySignature) {
      return NextResponse.json({ error: 'Missing payment verification fields' }, { status: 400 });
    }

    if (typeof orderId !== 'string' || typeof razorpayPaymentId !== 'string' || typeof razorpaySignature !== 'string') {
      return NextResponse.json({ error: 'Invalid payment verification fields' }, { status: 400 });
    }

    const razorpayKeySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!razorpayKeySecret) {
      return NextResponse.json({ error: 'Payment secret not configured' }, { status: 500 });
    }

    // Find the featureorder — use interactive transaction for atomicity
    const result = await prisma.$transaction(async (tx) => {
      const order = await tx.featureorder.findFirst({
        where: {
          userId: session.user.id,
          razorpayOrderId: orderId,
        },
        include: {
          orderitem: { include: { feature: true } },
        },
      });

      if (!order) {
        return { error: 'Order not found', status: 404 };
      }

      // Idempotency: if already paid, return success without creating duplicate purchases
      if (order.status === 'paid') {
        return {
          success: true,
          message: 'Payment already verified',
          orderId: order.id,
        };
      }

      // Reject if already failed — don't allow retries on a failed order
      if (order.status === 'failed') {
        return { error: 'This order has already been marked as failed', status: 400 };
      }

      // Verify Razorpay signature
      const generatedSignature = crypto
        .createHmac('sha256', razorpayKeySecret)
        .update(`${orderId}|${razorpayPaymentId}`)
        .digest('hex');

      if (generatedSignature !== razorpaySignature) {
        await tx.featureorder.update({
          where: { id: order.id },
          data: {
            status: 'failed',
            razorpayPaymentId,
            razorpaySignature,
          },
        });

        return { error: 'Payment signature verification failed', status: 400 };
      }

      // Signature verified — update order status FIRST
      await tx.featureorder.update({
        where: { id: order.id },
        data: {
          status: 'paid',
          razorpayPaymentId,
          razorpaySignature,
        },
      });

      // Create feature purchases
      const now = new Date();
      for (const oi of order.orderitem) {
        let expiresAt = null;
        if (oi.durationDays) {
          // For duration features: quantity = number of periods (e.g., 3 months)
          // Total duration = durationDays * quantity
          expiresAt = new Date(now.getTime() + oi.durationDays * oi.quantity * 24 * 60 * 60 * 1000);
        }

        await tx.featurepurchase.create({
          data: {
            userId: session.user.id,
            featureId: oi.featureId,
            quantity: oi.durationDays ? 1 : oi.quantity, // duration: store 1; quantity: store actual count
            expiresAt,
            amountPaid: oi.totalPrice,
            currency: order.currency,
            razorpayPaymentId,
            orderId: order.id,
            status: 'active',
          },
        });
      }

      // Clear the user's cart ONLY after all purchases are committed
      await tx.cartitem.deleteMany({ where: { userId: session.user.id } });

      return {
        success: true,
        orderId: order.id,
        purchases: order.orderitem.map((oi) => ({
          feature: oi.feature.name,
          quantity: oi.quantity,
          expiresAt: oi.durationDays
            ? new Date(now.getTime() + oi.durationDays * oi.quantity * 24 * 60 * 60 * 1000).toISOString()
            : null,
        })),
      };
    });

    // Handle results from transaction
    if (result.error) {
      return NextResponse.json({ error: result.error }, { status: result.status || 500 });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Feature verify error:', error);
    return NextResponse.json({ error: 'Payment verification failed' }, { status: 500 });
  }
}
