import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { env } from '@/lib/env';

const RAZORPAY_ORDERS_URL = 'https://api.razorpay.com/v1/orders';

// POST /api/feature-checkout — Create Razorpay order from cart
export async function POST(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { currency = 'USD' } = await request.json();

    if (!['USD', 'INR'].includes(currency)) {
      return NextResponse.json({ error: 'Invalid currency' }, { status: 400 });
    }

    // Get cart items
    const cartItems = await prisma.cartitem.findMany({
      where: { userId: session.user.id },
      include: { feature: true },
    });

    if (cartItems.length === 0) {
      return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
    }

    // Validate all features are still active and calculate total
    let totalAmount = 0;
    const orderItems = [];

    for (const item of cartItems) {
      if (!item.feature.isActive) {
        return NextResponse.json(
          { error: `"${item.feature.name}" is no longer available. Please remove it from your cart.` },
          { status: 400 }
        );
      }

      const unitPrice = currency === 'INR' ? item.feature.priceInr : item.feature.priceUsd;
      const itemTotal = unitPrice * item.quantity;
      totalAmount += itemTotal;

      orderItems.push({
        featureId: item.featureId,
        quantity: item.quantity,
        unitPrice,
        totalPrice: itemTotal,
        durationDays: item.feature.durationDays,
      });
    }

    if (totalAmount <= 0) {
      return NextResponse.json({ error: 'Invalid order total' }, { status: 400 });
    }

    const razorpayKeyId = env.RAZORPAY_KEY_ID;
    const razorpayKeySecret = env.RAZORPAY_KEY_SECRET;

    if (!razorpayKeyId || !razorpayKeySecret) {
      return NextResponse.json(
        { error: 'Payment provider is not configured.' },
        { status: 500 }
      );
    }

    // Create Razorpay order
    const receipt = `feat_${session.user.id.slice(-8)}_${Date.now()}`;
    const authHeader = Buffer.from(`${razorpayKeyId}:${razorpayKeySecret}`).toString('base64');

    const rpResponse = await fetch(RAZORPAY_ORDERS_URL, {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authHeader}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: totalAmount,
        currency,
        receipt,
        notes: {
          userId: session.user.id,
          type: 'feature_purchase',
          itemCount: cartItems.length,
        },
      }),
      cache: 'no-store',
    });

    const rpOrder = await rpResponse.json();

    if (!rpResponse.ok) {
      return NextResponse.json(
        { error: rpOrder?.error?.description || 'Failed to create payment order' },
        { status: 502 }
      );
    }

    // Validate Razorpay order response
    if (!rpOrder.id || typeof rpOrder.id !== 'string') {
      console.error('Razorpay returned invalid order:', rpOrder);
      return NextResponse.json(
        { error: 'Payment provider returned an invalid response' },
        { status: 502 }
      );
    }

    // Create featureorder + orderitems in DB
    const order = await prisma.featureorder.create({
      data: {
        userId: session.user.id,
        totalAmountUsd: currency === 'USD' ? totalAmount : 0,
        totalAmountInr: currency === 'INR' ? totalAmount : 0,
        currency,
        razorpayOrderId: rpOrder.id,
        status: 'pending',
        orderitem: {
          create: orderItems,
        },
      },
      include: { orderitem: { include: { feature: true } } },
    });

    return NextResponse.json({
      success: true,
      keyId: razorpayKeyId,
      orderId: rpOrder.id,
      dbOrderId: order.id,
      amount: totalAmount,
      currency,
      description: `${cartItems.length} feature${cartItems.length > 1 ? 's' : ''} from LiveInSec Store`,
      items: order.orderitem.map((oi) => ({
        name: oi.feature.name,
        quantity: oi.quantity,
        unitPrice: oi.unitPrice,
        totalPrice: oi.totalPrice,
      })),
    });
  } catch (error) {
    console.error('Feature checkout error:', error);
    return NextResponse.json({ error: 'Failed to start checkout' }, { status: 500 });
  }
}
